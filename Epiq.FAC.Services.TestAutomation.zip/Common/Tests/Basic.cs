using System;
using System.Threading.Tasks;
using Common.Tests.Base;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Octopus;
using Automation;

namespace Common.Tests
{   
    public class Basic : CommonBaseTest
    {
        public async Task Ping(string apibaseuri)
        {
            ApiBaseUri = apibaseuri;
            RequestUri = "ping";

            Report.Get(RequestUri);
            var response = await Get(RequestUri);            

            Utils.AssertResponseCodeOk(response);
        }

        public async Task Version(string apibaseuri, string OctopusProject)
        {
            ApiBaseUri = apibaseuri;
            RequestUri = "Version";

            Report.Get(RequestUri);
            var response = await Get(RequestUri);

            Utils.AssertResponseCodeOk(response);

            Report.Step("Deserialize the " + RequestUri + " JSON response");
            var jsonResponse = Deserialize<Models.Version>(response);

            Report.Assert("version is not null");
            string version = jsonResponse.version;
            Assert.IsNotNull(version);

            Report.Step("Get Octopus release version");
            string OctopusReleaseVersion = null;
            try
            {
                Dashboard dash = await Dashboard.Create(OctopusServerAddress, OctopusApiKey);
                OctopusReleaseVersion = dash.GetReleaseVersion(OctopusProject, OctopusEnvironment);
            }
            catch (Exception e)
            {
                Assert.Inconclusive("Could not get release version from Octopus: " + e.Message);
            }
            Report.Assert("version " + version + " matches Octopus release version");
            Assert.AreEqual(OctopusReleaseVersion, version);
        }
    }
}
