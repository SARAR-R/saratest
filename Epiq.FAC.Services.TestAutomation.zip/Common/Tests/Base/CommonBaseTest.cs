﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Epiq.TestAutomation.API.Tests;
using JetBrains.Annotations;

namespace Common.Tests.Base
{    
    [TestClass]
    public class CommonBaseTest : BaseApiTest
    {
        [PublicAPI]
        public static CommonService Common;

        public static string OctopusServerAddress;
        public static string OctopusApiKey;
        public static string OctopusEnvironment;
        
        [ClassInitialize]
        public static void CommonBaseClassInit(TestContext context)
        {
            System.Console.WriteLine("CommonBaseTest initializing");
            Common = new CommonService();
            
            OctopusServerAddress = context.Properties["OctopusServerAddress"].ToString();
            OctopusApiKey = context.Properties["OctopusApiKey"].ToString();
            OctopusEnvironment = context.Properties["OctopusEnvironment"].ToString();
        }

        [ClassCleanup]
        public static void CommonBaseClassCleanup()
        {
            BaseApiClassCleanup();
        }
    }
}

