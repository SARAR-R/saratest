﻿namespace Common.Models
{
    public class Version
    {
        public string name { get; set; }
        public string version { get; set; }
        public string major { get; set; }
        public string minor { get; set; }
        public string build { get; set; }
        public string revision { get; set; }
    }
}
