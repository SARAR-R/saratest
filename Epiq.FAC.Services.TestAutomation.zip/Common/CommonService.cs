﻿using System;
using Epiq.TestAutomation.API.Core;
using static System.Console;

namespace Common
{
    public class CommonService : ApiBase
    {
        public CommonService()
        {
            WriteLine("CommonService initializing");
            Timeout = TimeSpan.FromSeconds(30);
        }
    }
}