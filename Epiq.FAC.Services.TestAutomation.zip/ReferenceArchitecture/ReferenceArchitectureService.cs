﻿using System;
using Epiq.TestAutomation.API.Core;
using static System.Console;

namespace ReferenceArchitecture
{
    public class ReferenceArchitectureService : ApiBase
    {
        public ReferenceArchitectureService()
        {
            WriteLine("ReferenceArchitectureService initializing");
            Timeout = TimeSpan.FromSeconds(30);
        }
    }
}