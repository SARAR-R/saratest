﻿using System.Threading.Tasks;
using ReferenceArchitecture.Tests.Base;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Automation;

namespace ReferenceArchitecture.Tests
{
    [TestClass]
    public class Authentication : ReferenceArchitectureBaseTest
    {
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            ReferenceArchitectureBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            ReferenceArchitectureBaseClassCleanup();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            //You can only see this if you've been authenticated! No authorization claims are being checked on this endpoint.
            RequestUri = "example/GetAuthenticated"; 
        }

        [TestMethod]
        public async Task Authenticated()
        {
            await AccessControl.Tokens.GetIdentityToken(); 

            Report.Get(RequestUri);
            var response = await Get(RequestUri);

            Utils.AssertResponseCodeOk(response);
        }

        [TestMethod]
        public async Task UnauthorizedIdentityTokenExpired()
        {
            AuthToken = "Bearer " + ExpiredIdentityToken;
            await Unauthorized();
        }
        
        [TestMethod]
        public async Task UnauthorizedIdentityTokenInvalid()
        {
            AuthToken = "Bearer " + InvalidIdentityToken;
            await Unauthorized();
        }

        [TestMethod]
        public async Task UnauthorizedNoIdentityToken()
        {
            await Unauthorized();            
        }

        private async Task Unauthorized()
        {
            Report.Get(RequestUri);
            var response = await Get(RequestUri);

            Utils.AssertResponseCodeUnauthorized(response);
        }
    }
}
