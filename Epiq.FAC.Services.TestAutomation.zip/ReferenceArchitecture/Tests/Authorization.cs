﻿using System.Threading.Tasks;
using ReferenceArchitecture.Tests.Base;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Automation;

namespace ReferenceArchitecture.Tests
{
    [TestClass]
    public class Authorization : ReferenceArchitectureBaseTest
    {
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            ReferenceArchitectureBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            ReferenceArchitectureBaseClassCleanup();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            //This endpoint requires the "mail-ui-x" claim
            RequestUri = "example/hasclaim"; 
        }

        [TestMethod]
        public async Task Authorized()
        {
            await AccessControl.Tokens.GetAuthorizationToken();

            Report.Get(RequestUri);
            var response = await Get(RequestUri);

            Utils.AssertResponseCodeOk(response);
        }

        [TestMethod]
        public async Task UnauthorizedAuthTokenExpired()
        {
            AuthToken = "Bearer " + ExpiredAuthToken;
            await Unauthorized();
        }

        [TestMethod]
        public async Task UnauthorizedAuthTokenNoClaim()
        {
            //This endpoint is looking for a claim called "nonexistent", so the failure of claims can be tested here
            RequestUri = "example/failclaim"; 

            await AccessControl.Tokens.GetAuthorizationToken();
            await Unauthorized();
        }

        [TestMethod]
        public async Task UnauthorizedAuthTokenInvalid()
        {
            AuthToken = "Bearer " + InvalidAuthToken;
            await Unauthorized();
        }

        [TestMethod]
        public async Task UnauthorizedNoAuthToken()
        {
            await Unauthorized();            
        }

        private async Task Unauthorized()
        {
            Report.Get(RequestUri);
            var response = await Get(RequestUri);

            Utils.AssertResponseCodeUnauthorized(response);
        }
    }
}
