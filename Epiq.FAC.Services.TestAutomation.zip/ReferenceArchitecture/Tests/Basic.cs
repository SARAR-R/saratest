﻿using System.Threading.Tasks;
using ReferenceArchitecture.Tests.Base;
using Epiq.TestAutomation.Core.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ReferenceArchitecture.Tests
{    
    [TestClass]
    public class Basic : ReferenceArchitectureBaseTest
    {
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            ReferenceArchitectureBaseClassInit(context);
            Common.Tests.Base.CommonBaseTest.CommonBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            ReferenceArchitectureBaseClassCleanup();
            Common.Tests.Base.CommonBaseTest.CommonBaseClassCleanup();
        }

        [TestInitialize]
        public void TestInitialize()
        {
           CommonTests = new Common.Tests.Basic();
        }

        public Common.Tests.Basic CommonTests;
        
        [TestCategory(TestCategories.Api)]
        [TestMethod]
        public async Task Ping()
        {
            await CommonTests.Ping(ApiBaseUri);
        }

        [TestCategory(TestCategories.Api)]
        [TestMethod]
        public async Task Version()
        {
            await CommonTests.Version(ApiBaseUri, OctopusProject);
        }        
    }
}
