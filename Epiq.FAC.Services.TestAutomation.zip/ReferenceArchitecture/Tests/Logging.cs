﻿using System;
using System.Threading.Tasks;
using ReferenceArchitecture.Tests.Base;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;
using Automation;
using Automation.Database;

namespace ReferenceArchitecture.Tests
{    
    [TestClass]
    public class Logging : ReferenceArchitectureBaseTest
    {
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            ReferenceArchitectureBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            ReferenceArchitectureBaseClassCleanup();
        }

        [TestMethod]
        public async Task PersistLogToService()
        {
            RequestUri = "example"; //writes a single log message to logging service

            DataReader reader = null;
            string queryString = "select top 1 * from [dbo].[LogMessages] order by LogMessageId desc";
            int logmessageid_before = 0;
            int logmessageid_after = 0;

            Report.Step("Query the database to get last LogMessageId");
            try
            {
                reader = new DataReader(queryString, LogToServiceConnectionString);
                while (reader.Read())
                {
                    logmessageid_before = int.Parse(reader.Col("LogMessageId").ToString());
                }
            }
            finally
            {
                reader.Close();
            }

            Report.Get(RequestUri);
            var response = await Get(RequestUri);

            Utils.AssertResponseCodeOk(response);

            System.Threading.Thread.Sleep(3000);

            Report.Step("Query the database to get last LogMessageId");
            try
            {
                reader = new DataReader(queryString, LogToServiceConnectionString);
                while (reader.Read())
                {
                    logmessageid_after = int.Parse(reader.Col("LogMessageId").ToString());
                    Report.Assert("values persisted");
                    Assert.AreEqual(OctopusProject, reader.Col("Location"));
                    Assert.AreEqual("This is an example log message.", reader.Col("Message"));
                }
            }
            finally
            {
                reader.Close();
            }

            Report.Assert("LogMessageId is incremented by 1");
            Assert.IsTrue(logmessageid_after == logmessageid_before + 1);
        }
    }
}
