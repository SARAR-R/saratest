﻿namespace Logging.Requests
{
    public class ExceptionMessage
    {
        public string TenantId { get; set; }
        public string DateLogged { get; set; }
        public string Username { get; set; }
        public string Location { get; set; }
        public string Exception { get; set; }
        public string InnerException { get; set; }
        public string Site { get; set; }
        public string StackTrace { get; set; }
        public string KafkaTopic { get; set; }
        public string KafkaOffset { get; set; }        
    }
}



