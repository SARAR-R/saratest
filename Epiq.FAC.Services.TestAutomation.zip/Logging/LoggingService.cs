﻿using System;
using Epiq.TestAutomation.API.Core;

namespace Logging
{
    public class LoggingService : ApiBase
    {
        public LoggingService()
        {
            Console.WriteLine("LoggingService initializing");
            Timeout = TimeSpan.FromSeconds(30);
        }
    }
}