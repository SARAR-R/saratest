﻿using System;
using System.Threading.Tasks;
using Logging.Tests.Base;
using Logging.Requests;
using Epiq.TestAutomation.Core.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Epiq.TestAutomation.Core.Utilities;
using Automation;
using Automation.Database;

namespace Logging.Tests
{    
    [TestClass]
    public class LogMessages : LoggingBaseTest
    {
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            LoggingBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            LoggingBaseClassCleanup();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            RequestUri = "LogMessages";
        }

        public LogMessage newLogMessage;

        [TestCategory(TestCategories.Api)]
        [TestMethod]
        public async Task PostLogMessage()
        {
            Report.Step("Create a new LogMessage data object");
            newLogMessage = new LogMessage
            {                
                TenantId = DataUtils.GenerateRandomString(10),
                Level = DataUtils.GenerateRandomNumber(1,9),
                MessageType = DataUtils.GenerateRandomString(20),
                DateLogged = $"{DateTime.Now:M/d/yyyy}",
                Username = DataUtils.GenerateRandomString(20),
                Location = DataUtils.GenerateRandomString(20),
                Message = DataUtils.GenerateRandomString(100),
                KafkaTopic = DataUtils.GenerateRandomString(20),
                KafkaOffset = DataUtils.GenerateRandomString(20)
            };
            
            Report.Step("Create the LogMessage JSON request body");
            var requestBody = Serialize(newLogMessage);

            Report.Post(RequestUri);
            var response = await Post(RequestUri, requestBody);

            Utils.AssertResponseCodeAccepted(response);
        }

        [TestMethod]
        public async Task PersistLogMessage()
        {
            DataReader reader = null;
            string queryString = "select top 1 * from [dbo].[LogMessages] order by LogMessageId desc";

            await PostLogMessage();
                        
            try
            {
                reader = new DataReader(queryString, ConnectionString);                
                while (reader.Read())
                {
                    Report.Assert("values persisted");
                    Assert.AreEqual(newLogMessage.TenantId, reader.Col("TenantId"));
                    Assert.AreEqual(newLogMessage.Level, Convert.ToInt32(reader.Col("Level")));
                    Assert.AreEqual(newLogMessage.MessageType, reader.Col("MessageType"));
                    Assert.AreEqual(newLogMessage.DateLogged, $"{reader.Col("DateLogged"):M/d/yyyy}");
                    Assert.AreEqual(newLogMessage.Username, reader.Col("Username"));
                    Assert.AreEqual(newLogMessage.Location, reader.Col("Location"));
                    Assert.AreEqual(newLogMessage.Message, reader.Col("Message"));
                    Assert.AreEqual(newLogMessage.KafkaTopic, reader.Col("KafkaTopic"));
                    Assert.AreEqual(newLogMessage.KafkaOffset, reader.Col("KafkaOffset"));
                }
            }
            finally
            {
                reader.Close();
            }
        }
    }
}
