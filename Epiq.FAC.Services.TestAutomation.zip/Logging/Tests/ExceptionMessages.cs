﻿using System;
using System.Threading.Tasks;
using Logging.Tests.Base;
using Logging.Requests;
using Epiq.TestAutomation.Core.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Epiq.TestAutomation.Core.Utilities;
using Automation;
using Automation.Database;

namespace Logging.Tests
{
    [TestClass]
    public class ExceptionMessages : LoggingBaseTest
    {
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            LoggingBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            LoggingBaseClassCleanup();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            RequestUri = "ExceptionMessages";
        }

        public ExceptionMessage newExceptionMessage;

        [TestCategory(TestCategories.Api)]
        [TestMethod]
        public async Task PostExceptionMessage()
        {
            Report.Step("Create a new ExceptionMessage data object");
            newExceptionMessage = new ExceptionMessage
            {
                TenantId = DataUtils.GenerateRandomString(10),
                DateLogged = $"{DateTime.Now:M/d/yyyy}",
                Username = DataUtils.GenerateRandomString(20),
                Location = DataUtils.GenerateRandomString(20),
                Exception = DataUtils.GenerateRandomString(100),
                InnerException = DataUtils.GenerateRandomString(100),
                Site = DataUtils.GenerateRandomString(20),
                StackTrace = DataUtils.GenerateRandomString(1000),                
                KafkaTopic = DataUtils.GenerateRandomString(20),
                KafkaOffset = DataUtils.GenerateRandomString(20),
            };

            Report.Step("Create the ExcpetionMessage JSON request body");
            var requestBody = Serialize(newExceptionMessage);

            Report.Post(RequestUri);
            var response = await Post(RequestUri, requestBody);

            Utils.AssertResponseCodeAccepted(response);
        }

        [TestMethod]
        public async Task PersistExceptionMessage()
        {
            DataReader reader = null;
            string queryString = "select top 1 * from [dbo].[ExceptionMessages] order by ExceptionMessageId desc";

            await PostExceptionMessage();

            try
            {
                reader = new DataReader(queryString, ConnectionString);
                while (reader.Read())
                {
                    Report.Assert("values persisted");
                    Assert.AreEqual(newExceptionMessage.TenantId, reader.Col("TenantId"));
                    Assert.AreEqual(newExceptionMessage.DateLogged, $"{reader.Col("DateLogged"):M/d/yyyy}");
                    Assert.AreEqual(newExceptionMessage.Username, reader.Col("Username"));
                    Assert.AreEqual(newExceptionMessage.Location, reader.Col("Location"));
                    Assert.AreEqual(newExceptionMessage.Exception, reader.Col("Exception"));
                    Assert.AreEqual(newExceptionMessage.InnerException, reader.Col("InnerException"));
                    Assert.AreEqual(newExceptionMessage.Site, reader.Col("Site"));
                    Assert.AreEqual(newExceptionMessage.StackTrace, reader.Col("StackTrace"));
                    Assert.AreEqual(newExceptionMessage.KafkaTopic, reader.Col("KafkaTopic"));
                    Assert.AreEqual(newExceptionMessage.KafkaOffset, reader.Col("KafkaOffset"));
                }
            }
            finally
            {
                reader.Close();
            }            
        }
    }
}
