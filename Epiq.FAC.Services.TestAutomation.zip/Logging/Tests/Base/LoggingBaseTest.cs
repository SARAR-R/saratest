﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Epiq.TestAutomation.API.Tests;
using JetBrains.Annotations;

namespace Logging.Tests.Base
{
    [TestClass]
    public class LoggingBaseTest : BaseApiTest
    {
        [PublicAPI]
        public static LoggingService Logging;

        public static string ConnectionString;

        [ClassInitialize]
        public static void LoggingBaseClassInit(TestContext context)
        {
            BaseApiClassInit(context);
            Logging = new LoggingService();
            ApiBaseUri = context.Properties["ApiBaseUri_Logging"].ToString();
            ConnectionString = context.Properties["ConnectionString_Logging"].ToString();
        }

        [ClassCleanup]
        public static void LoggingBaseClassCleanup()
        {
            BaseApiClassCleanup();
        }
    }
}
