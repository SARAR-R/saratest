﻿using System;
using Epiq.TestAutomation.API.Core;

namespace AccessControl
{
    public class AccessControlService : ApiBase
    {
        public AccessControlService()
        {
            Console.WriteLine("AccessControlService initializing");
            Timeout = TimeSpan.FromSeconds(30);
        }
    }
}