﻿using Epiq.TestAutomation.API.Core;
using System.Threading.Tasks;

namespace AccessControl
{
    public class Tokens : ApiBase
    {
        public async static Task GetAuthorizationToken()
        {
            Tests.Tokens tokens = new Tests.Tokens();
            await tokens.GetAuthorizationToken();
            AuthToken = "Bearer " + tokens.AuthorizationToken;
        }

        public async static Task GetIdentityToken()
        {
            Tests.Tokens tokens = new Tests.Tokens();
            await tokens.GetIdentityToken();
            AuthToken = "Bearer " + tokens.IdentityToken;
        }
    }
}