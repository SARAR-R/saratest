﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccessControl.Responses
{
    public class AuthorizationToken
    {
        public string access_token { get; set; }
        public string token_type { get; set; }
        public int expires_in { get; set; }
        public string refresh_token { get; set; }
        public string ac_token_type { get; set; }
        public string rightsCount { get; set; }
        //public string __invalid_name__.issued { get; set; }
        //public string __invalid_name__.expires { get; set; }
    }
}
