﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Epiq.TestAutomation.API.Tests;
using JetBrains.Annotations;

namespace AccessControl.Tests.Base
{
    [TestClass]
    public class AccessControlBaseTest : BaseApiTest
    {
        [PublicAPI]
        public static AccessControlService AccessControl;

        public static string username;
        public static string password;
        public static string subsystem;
        public static string ApiBaseUri_AccessControl;

        [ClassInitialize]
        public static void AccessControlBaseClassInit(TestContext context)
        {
            BaseApiClassInit(context);
            AccessControl = new AccessControlService();            
            SetUriAndCredentials(context);            
        }

        [ClassCleanup]
        public static void AccessControlBaseClassCleanup()
        {
            BaseApiClassCleanup();
        }

        public static void SetUriAndCredentials(TestContext context)
        {
            ApiBaseUri_AccessControl = context.Properties["ApiBaseUri_AccessControl"].ToString();
            username = context.Properties["username_AccessControl"].ToString();
            password = context.Properties["password_AccessControl"].ToString();
            subsystem = context.Properties["subsystem_AccessControl"].ToString();
        }
    }
}
