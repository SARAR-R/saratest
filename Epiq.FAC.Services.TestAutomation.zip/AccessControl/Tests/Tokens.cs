﻿using System;
using System.Threading.Tasks;
using AccessControl.Tests.Base;
using AccessControl.Responses;
using Epiq.TestAutomation.Core.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Collections.Generic;
using Automation;

namespace AccessControl.Tests
{
    [TestClass]    
    public class Tokens : AccessControlBaseTest
    {
        public string IdentityToken;
        public string AuthorizationToken;

        public new string RequestUri = "token";

        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            AccessControlBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            AccessControlBaseClassCleanup();
        }

        [TestCategory(TestCategories.Api)]
        [TestMethod]        
        public async Task GetIdentityToken()
        {
            Report.Step("Create the Identity Token request");

            Client = new HttpClient { BaseAddress = new Uri(ApiBaseUri_AccessControl + RequestUri) };

            var request = new HttpRequestMessage(HttpMethod.Post, ApiBaseUri_AccessControl + RequestUri);

            var keyValues = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("grant_type", "password"),
                new KeyValuePair<string, string>("username", username),
                new KeyValuePair<string, string>("password", password)
            };

            request.Content = new FormUrlEncodedContent(keyValues);

            Report.Step("Send the Identity Token request");
            var response = await Send(Client, request);

            Report.Step("Deserialize the Identity Token JSON response");
            var jsonResponse = Deserialize<IdentityToken>(response);

            Report.Assert("access_token is present");
            Assert.IsNotNull(jsonResponse.access_token);

            IdentityToken = jsonResponse.access_token;            
        }

        [TestCategory(TestCategories.Api)]
        [TestMethod]
        public async Task GetAuthorizationToken()
        {
            Report.Step("Get the identity token");
            await GetIdentityToken();

            Report.Step("Create the Authorization Token request");

            Client = new HttpClient { BaseAddress = new Uri(ApiBaseUri_AccessControl + RequestUri) };

            var request = new HttpRequestMessage(HttpMethod.Post, ApiBaseUri_AccessControl + RequestUri);

            var keyValues = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("grant_type", "authorization_token"),
                new KeyValuePair<string, string>("identity_token", IdentityToken),
                new KeyValuePair<string, string>("subsystem", subsystem),
                new KeyValuePair<string, string>("username", username)
            };

            request.Content = new FormUrlEncodedContent(keyValues);

            Report.Step("Send the Authorization Token request");
            var response = await Send(Client, request);

            Report.Step("Deserialize the Authorization Token JSON response");
            var jsonResponse = Deserialize<AuthorizationToken>(response);

            Report.Assert("access_token is present");
            Assert.IsNotNull(jsonResponse.access_token);

            AuthorizationToken = jsonResponse.access_token;            
        }
    }
}
