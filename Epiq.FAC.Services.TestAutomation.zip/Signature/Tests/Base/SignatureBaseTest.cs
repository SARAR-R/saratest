﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Epiq.TestAutomation.API.Tests;
using JetBrains.Annotations;

namespace Signature.Tests.Base
{
    [TestClass]
    public class SignatureBaseTest : BaseApiTest
    {
        [PublicAPI]
        public static SignatureService Signature;

        [ClassInitialize]
        public static void SignatureBaseClassInit(TestContext context)
        {
            BaseApiClassInit(context);
            Signature = new SignatureService();
            ApiBaseUri = context.Properties["ApiBaseUri_Signature"].ToString();

            AccessControl.Tests.Base.AccessControlBaseTest.SetUriAndCredentials(context);            
        }

        [ClassCleanup]
        public static void SignatureBaseClassCleanup()
        {
            BaseApiClassCleanup();
        }
    }
}
