﻿using System.Threading.Tasks;
using Signature.Tests.Base;
using Epiq.TestAutomation.Core.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Signature.Tests
{    
    [TestClass]
    public class Basic : SignatureBaseTest
    {
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            SignatureBaseClassInit(context);
            Common.Tests.Base.CommonBaseTest.CommonBaseClassInit(context);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            SignatureBaseClassCleanup();
            Common.Tests.Base.CommonBaseTest.CommonBaseClassCleanup();
        }

        [TestInitialize]
        public void TestInitialize()
        {            
            CommonTests = new Common.Tests.Basic();
        }

        public Common.Tests.Basic CommonTests;

        [TestCategory(TestCategories.Api)]
        [TestMethod]
        public async Task Ping()
        {
            await AccessControl.Tokens.GetAuthorizationToken();
            await CommonTests.Ping(ApiBaseUri);
        }
    }
}
