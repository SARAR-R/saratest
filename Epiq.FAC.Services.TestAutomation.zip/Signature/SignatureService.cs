﻿using System;
using Epiq.TestAutomation.API.Core;

namespace Signature
{
    public class SignatureService : ApiBase
    {
        public SignatureService()
        {
            Console.WriteLine("SignatureService initializing");
            Timeout = TimeSpan.FromSeconds(30);
        }
    }
}