﻿using System.Data.SqlClient;

namespace Automation.Database
{
    public class DataReader
    {
        public DataReader(string queryString, string connectionString)
        {
            Report.Query(queryString);
            connection = new SqlConnection(connectionString);
            var command = new SqlCommand(queryString, connection);
            connection.Open();
            reader = command.ExecuteReader();
        }

        private SqlConnection connection;
        private SqlDataReader reader;
       
        public object Col(string columnName)
        {
            return reader[columnName];
        }

        public bool Read()
        {
            return reader.Read();
        }

        public void Close()
        {
            reader.Close();
            connection.Close();
        }
    }
}
