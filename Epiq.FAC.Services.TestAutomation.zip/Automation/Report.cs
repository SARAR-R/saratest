﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Automation
{
    public static class Report
    {        
        public static void Step(string description)
        {           
            Console.WriteLine(string.Format("STEP: {0}", description));           
        }        

        public static void Get(string uri)
        {
            Console.WriteLine(string.Format("GET: {0}", uri));
        }

        public static void Post(string uri)
        {
            Console.WriteLine(string.Format("POST: {0}", uri));
        }

        public static void Query(string query)
        {
            Console.WriteLine(string.Format("QUERY: {0}", query));
        }

        public static void Assert(string description)
        {
            Console.WriteLine(string.Format("ASSERT: {0}", description));
        }
    }
}
