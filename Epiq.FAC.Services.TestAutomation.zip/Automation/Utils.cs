using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Net.Http;

namespace Automation
{
    public class Utils
    {
        public static void AssertResponseCodeUnauthorized(HttpResponseMessage response)
        {            
            Report.Assert("response status Unauthorized");
            Assert.AreEqual("Unauthorized", response.StatusCode.ToString());
        }

        public static void AssertResponseCodeOk(HttpResponseMessage response)
        {
            Report.Assert("response status Ok");
            Assert.AreEqual("OK", response.StatusCode.ToString());
        }

        public static void AssertResponseCodeAccepted(HttpResponseMessage response)
        {
            Report.Assert("response status Accepted");
            Assert.AreEqual("Accepted", response.StatusCode.ToString());
        }
    }
}
