﻿using System.Threading.Tasks;
using Octopus.Client;
using Octopus.Client.Model;
using System.Collections.Generic;

namespace Octopus
{
    public class Dashboard
    {
        private Dashboard()
        {
        }

        private static DashboardResource dash;

        public static async Task<Dashboard> Create(string server, string apiKey)
        {            
            var endpoint = new OctopusServerEndpoint(server, apiKey);
            using (var client = await OctopusAsyncClient.Create(endpoint))
            {
                dash = await client.Repository.Dashboards.GetDashboard();
                return new Dashboard();
            }
        }

        public string GetReleaseVersion(string projectname, string environment)
        {            
            List<DashboardItemResource> items = dash.Items;
            DashboardItemResource item = new DashboardItemResource();
            List<DashboardProjectResource> projs = dash.Projects;
            List<DashboardEnvironmentResource> envs = dash.Environments;

            var projID = projs.Find(x => x.Name == projectname).Id;
            var envID = envs.Find(x => x.Name == environment).Id;
            item = items.Find(x => x.ProjectId == projID && x.EnvironmentId == envID);

            return item.ReleaseVersion;           
        }
    }
}
