In Microsoft Test Manager:
1. Open the test plan.
2. Select the Test tab.
3. Right click on the test that has configured for automation (as described [here](testmanager.md)).
4. This will queue up a run on a remote server.  There will be no activity on your machine until it completes and test manager will show the test as passed or failed.

To view the results:
1. From the Test tab, select Analyze Test Runs.
2. Double click the run just completed.
3. Under the attachment section, open the .trx file.  This should open in visual studio and allow you to view the console out as you would expect to see from a local run.

[Back](README.md)
