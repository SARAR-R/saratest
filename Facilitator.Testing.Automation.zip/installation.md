1. Clone the entire Facilitator.Testing.Automation repository.
2. In the solution, find the Selenium folder under the Automation project.
3. Copy the contents of that folder to a local folder (preferably C:\Selenium).
