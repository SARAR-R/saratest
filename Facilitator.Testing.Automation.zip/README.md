#Introduction
This is the Automation project.  Initially designed around Facilitator, it is not intended to be restricted to that (despite the repository name suggesting otherwise).  It has a lot of generic code that can theoretically be reused for any web project.  

#Getting Started
*	[Installation process](installation.md)
*	[Software dependencies](dependencies.md)
*	[Test Manager Integration](testmanager.md)

#Build and Test
* [Running locally](localrun.md)
* [Running through MTM](mtmrun.md)

#Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

