In visual studio:
1. Open the solution.
2. Pull the latest code.
    1. In Team Exporer, select the Sync tab.
    2. Select the Sync (or Pull) link. 
3. Select the desired configuration to build.  Debug is for Facilitator Core, the rest should be self descriptive.
4. Build the solution.
5. Once the build is successful, open the Test Exporer view (Test > Windows > Text Exporer).  You should see a whole list of tests available.  You may find it useful to group by class.
6. Right-click on the desired test and click run.

If everything is set up properly, at this point you should see browser window open and run through the test.  Once it is complete, you can view the test results from test exporer.  Just select the test and click on the Output link to view the results.

Note: You can queue up multiple tests to run at once, they will run back to back, so it may take a while but you can do so without needing to pay attention to what it's doing.

[Back](README.md)