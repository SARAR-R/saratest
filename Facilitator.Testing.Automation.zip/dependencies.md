* Visual Studio
* Chrome (latest)
* Firefox (latest)
* IE 11+
* Microsoft Test Manager (For automatic test running)

[Back](README.md)