﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Automation;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace BreachPortal
{
    public class Test : test
    {
        public static string Note;

        public static string GenerateString(int size, bool special = false)
        {
            var rand = new Random();
            var alphabet = special ?
                "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789~!@#$%^&*()_+`-={}:<>?[];',./":
                "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var chars = new char[size];
            for (var i = 0; i < size; i++)
            {
                chars[i] = alphabet[rand.Next(alphabet.Length)];
            }
            return new string(chars);
        }

        public static string GenerateNumberString(int size)
        {
            var rand = new Random();
            const string alphabet = "0123456789";
            var chars = new char[size];
            chars[0] = alphabet[rand.Next(1, alphabet.Length)];  //Ensure string doesn't start with a zero
            for (var i = 1; i < size; i++)
            {
                chars[i] = alphabet[rand.Next(alphabet.Length)];
            }
            return new string(chars);
        }

        public static DateTime GenerateDate()
        {
            var rnd = new Random();
            var start = new DateTime(1995, 1, 1);
            var range = (DateTime.Today - start).Days;
            return start.AddDays(rnd.Next(range));
        }

        public static bool RandomBoolean()
        {
            Thread.Sleep(100);
            var rnd = new Random();
            return (rnd.NextDouble() > .5);
        }

        public static string RandomStringFromList(List<string> list)
        {
            Thread.Sleep(100);
            return list.Skip(new Random().Next(1, list.Count())).First();
        }

        public class FieldDetail
        {
            public string Type { get; set; }
            public string Label { get; set; }
            public int Length { get; set; }
            public string InvalidText { get; set; }
            public string ValidText { get; set; }
            public string ValidationType { get; set; }
            public By Field { get; set; }
            public By Validation { get; set; }
        }

        public static void ValidateFields(List<FieldDetail> fields, bool modal = false)
        {
            var save = modal ? Matter.Contacts._ModalSave : Matter.BasicInfo._Save;
            foreach (var field in fields)
            {
                if (field.Label == null) throw new Exception("Must supply the label for each field.");
                if (field.ValidText == null)
                {
                    switch (field.Type)
                    {
                        case "date":
                            field.ValidText = GenerateDate().ToString("M/d/yyyy");
                            break;
                        case "numeric":
                            if (field.Length == 0) throw new Exception("Must supply a length (or explicit ValidText) for all numeric fields.");
                            field.ValidText = GenerateNumberString(field.Length);
                            break;
                        case "postalCode":
                            field.ValidText = GenerateNumberString(5) + "-" + GenerateNumberString(4);
                            break;
                        default:
                            if (field.Length == 0) throw new Exception("Must supply a length (or explicit ValidText) for all non-date or postal code fields.");
                            field.ValidText = GenerateString(field.Length, true);
                            break;
                    }
                }

                if (field.InvalidText == null) field.InvalidText = field.ValidText + "a";                
                
                if (field.ValidationType == null)
                    switch (field.Type)
                    {
                        case "date":
                            field.ValidationType = "$error.date";
                            break;
                        case "numeric":
                            field.ValidationType = "$error.pattern";
                            break;
                        case "postalCode":
                            field.ValidationType = "$error.postalCode";
                            break;
                        default:
                            field.ValidationType = "$error.maxlength";
                            break;
                    }
                if (field.Field == null)
                    //Date fields expect an input to come under an extra div as compared to other field types.
                    if (field.Type == "date")
                        field.Field = By.XPath("//label[text()='" + 
                        field.Label + "']//following-sibling::div//input ");
                    else
                    {
                        field.Field = By.XPath("//label[text()='" +
                        field.Label + "']//following-sibling::*[self:: input | self::textarea]");
                    }
                 
                if (field.Validation == null)
                    field.Validation = By.XPath("//label[text()='" + field.Label +
                                                "']//following-sibling::span[contains(@ng-show | @ng-if, '" +
                                                field.ValidationType + "')]");
                Thread.Sleep(100);
            }
            foreach (var field in fields)
            {
                try
                {
                    
                    WaitForElement(field.Field);
                    if (field.Type == "combo")
                    {
                        EditCombo(field.Field.ToString().Substring(10), field.InvalidText);
                    }
                    else
                    {
                        EditField(field.Field, field.InvalidText);    
                    }
                    Thread.Sleep(500);
                    VerifyElementDisplay(field.Validation, true); //Validation messaging showing
                    VerifyElementEnabled(save, false); //Save disabled
                    if (field.Type == "combo")
                    {
                        EditCombo(field.Field.ToString().Substring(10), field.ValidText);
                    }
                    else
                    {
                        EditField(field.Field, field.ValidText);
                    }

                    Thread.Sleep(500);
                    VerifyElementDisplay(field.Validation, false); //Validation messaging not showing
                    VerifyElementEnabled(save, true); //Save reenabled
                }
                catch (Exception e)
                {
                    report.Fail("Unable to verify the validation for " + field.Label, e);
                    
                }

            }
            Click(save);
            if (modal)
            {
                Grid.SortByColumn("Last Name", "asc");
                Click(By.XPath(Matter.Contacts.Edit));
            }
            else
            {
                navigate.Refresh(driver);
            }
         //Only validate the last valid text
            foreach (var field in fields.GroupBy(x => x.Label).Select(y => y.Last())) 
            {
                WaitForElement(field.Field);
                vars.verify(VerifyFieldValue(field.Field, field.ValidText));
            }
            if (modal) Click(Matter.Contacts._ModalCancel);
            
        }

        public static By ByNgModel(string ngModel)
        {
            return By.XPath("//*[contains(@ng-model, '" + ngModel + "')]");
        }

        public static int VerifyToggleValue(string xpath, bool expectedValue)
        {
            var by = By.XPath(xpath + "//input");
            return VerifyCheckBoxValue(by, expectedValue);
        }

        public static int VerifySectionValue(string xpath, bool expectedValue)
        {
            var by = By.XPath(xpath + "//span");
            return VerifyClassExists(by, "on", expectedValue);
        }

        public static void SetToggle(string xpath, bool value)
        {
            var input = By.XPath(xpath + "//input");
            var span = By.XPath(xpath + "//span");
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(config.TIMEOUT));
            wait.Until(d => d.FindElement(span).Enabled);
            WaitForPageToLoad(driver);
            if (value)
            {
                if (driver.FindElement(input).GetAttribute("class").Contains("ng-empty"))
                {
                    Click(span);
                }
                else
                {
                    report.Action("Skip", xpath + " is already true");
                }
            }
            else
            {
                if (driver.FindElement(input).GetAttribute("class").Contains("ng-not-empty"))
                {
                  
                            Click(span);
                }
                else
                {
                    report.Action("Skip", xpath + " is already false");
                }
            }
            WaitForPageToLoad(driver);
        }

        public static void SetSection(string xpath, bool value, bool? confirm = null)
        {
            var span = By.XPath(xpath + "//span");
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(config.TIMEOUT));
            wait.Until(d => d.FindElement(span).Enabled);
            WaitForPageToLoad(driver);
            if (value)
            {
                if (!driver.FindElement(span).GetAttribute("class").Contains("on"))
                {
                    Click(span);
                }
                else
                {
                    report.Action("Skip", xpath + " is already true");
                }
            }
            else
            {
                if (driver.FindElement(span).GetAttribute("class").Contains("on"))
                {
                    switch (confirm)
                    {
                        case true:
                            ClickandConfirm(span);
                            break;
                        case false:
                            ClickandCancel(span);
                            break;
                        case null:
                            Click(span);
                            break;
                    }
                }
                else
                {
                    report.Action("Skip", xpath + " is already false");
                }
            }
            WaitForPageToLoad(driver);
        }

        public new static void EditField(By by, string text)
        {
            try
            {
                report.Action("Edit", by.ToString(), text.Length + " characters");
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(config.TIMEOUT));
                var element = driver.FindElement(by);

                if (text.Length > 0)
                {
                    var text1 = text.Substring(0, text.Length - 1);
                    var text2 = text.Substring(text.Length - 1, 1);
                    wait.Until(d => d.FindElement(by).Enabled);
                    WaitForPageToLoad();
                    element.Clear();
                    if (text.Length > 0)
                        ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].value = arguments[1]",
                            element, text1);
                    element.SendKeys(text2 + Keys.Tab);
                    WaitForPageToLoad();
                }
                else
                {
                    wait.Until(d => d.FindElement(by).Enabled);
                    WaitForPageToLoad();
                    element.Clear();
                    element.SendKeys(Keys.Tab);
                    WaitForPageToLoad();
                }
                
            }
            catch (Exception e)
            {
                report.Fail("Unable to add the following text into " + by + ": " + text);
                Console.WriteLine("Error: " + e.Message);
            }
        }

        public static int VerifySectionEditability(string xpath, bool edit)
        {
            return VerifyClassExists(By.XPath(xpath + "//label"), "readOnly", !edit);
        }

        public static int VerifyToggleEditability(string xpath, bool edit)
        {
            return VerifyClassExists(By.XPath(xpath + "//span"), "readOnly", !edit);
        }

        public static int VerifyToast(string text)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            var by = By.XPath("//div[contains(@class, 'toast')]//div[text() = '" + text +"']");
            try
            {
                wait.Until(d => (d.FindElements(by).Count != 0));
                report.Pass("Toasts include:  " + text);
                driver.FindElement(by).Click();
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Toasts do not include:  " + text, e);
                return 1;
            }
        }

        public static int VerifyElementDisplay(By by, bool expected)
        {
            try
            {
                //Verifies both the existence of and hidden state of an element.
                bool exists;
            
                try
                {
                    WaitForPageToLoad(driver);                
                    var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(1));
                    wait.Until(d => driver.FindElement(by).Displayed);
                    exists = true;
                }
                catch (WebDriverTimeoutException)
                {
                    exists = false;
                }

                if (!exists && !expected)
                {
                    report.Pass("Element (" + by + ") does not exist as expected.");
                    return 0;
                }
                if (!exists)
                {
                    report.Fail("Element (" + by + ") does not exist.");
                    return 0;
                }
                var visible = !driver.FindElement(by).GetAttribute("class").Contains("ng-hide");
                if (!visible && !expected)
                {
                    report.Pass("Element (" + by + ") is not displayed as expected.");
                    return 0;
                }
                if (visible && expected)
                {
                    report.Pass("Element (" + by + ") is displayed as expected.");
                    return 0;
                }

                report.Fail("Element existed but " + (visible ? "was not hidden." : "was hidden."));
                return 1;
            }
            catch (Exception e)
            {
                report.Fail("Error occured while determing display state of element (" + by + ")",e);
                return 1;
            }
            
        }

        public static void EditCombo(string field, string text)
        {
            var box = By.XPath(field + "/following-sibling::div//div[contains(@class, 'ui-select-match')]");
            var input = By.XPath(field + "/following-sibling::div//input");

            report.Action("Edit Combo", field, text);
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(config.TIMEOUT));
            wait.Until(d => d.FindElement(box).Enabled);
            WaitForPageToLoad(driver);
            ScrollTo(driver, box);
            driver.FindElement(box).Click();
            driver.FindElement(input).SendKeys(text + Keys.Tab);
            WaitForPageToLoad(driver);
        }

        public static int VerifySelectContains(By by, string value)
        {
            try
            {
                var options = new SelectElement(driver.FindElement(by)).Options.Select(a => a.Text).ToList();
                if (options.Contains(value))
                {
                    report.Pass("SelectElement " + by + " contains " + value + ".");
                    return 0;
                }
                report.Fail("SelectElement " + by + " does not contain " + value + ".");
                return 1;
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying select list item.", e);
                return 1;
            }
        }

        public static int VerifyComboContains(string xpath, string value)
        {
            try
            {
                Click(By.XPath(xpath + "/following-sibling::div//span[contains(@class, 'ui-select-toggle')]"));
                var listItems = driver.FindElements(By.XPath(xpath + "/following-sibling::div//ul[contains(@class, 'ui-select-choices')]//span"));
                if (listItems.Any(a => a.Text == value))
                {
                    report.Pass("Combo box " + xpath + " contains " + value + ".");
                    driver.FindElement(By.XPath(xpath + "/following-sibling::div//input")).SendKeys(Keys.Escape);
                    return 0;
                }
                report.Fail("Combo box " + xpath + " does not contain " + value + ".");
                driver.FindElement(By.XPath(xpath + "/following-sibling::div//input")).SendKeys(Keys.Escape);
                return 1;
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying combo list items.", e);
                return 1;
            }
        }
    }
}
