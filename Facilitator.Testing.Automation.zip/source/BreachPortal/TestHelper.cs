﻿using Automation;
using Facilitator.Template;
using OpenQA.Selenium;

namespace BreachPortal
{
    public class TestHelper
    {

        public static string Start()
        {
            testHelper.Start(test.driver, Config.Username, Config.Password);
            return "success";
        }

        public static string Start(int mid)
        {
            report.Step("Log in, load matter");
            testHelper.Start(test.driver, Config.Username, Config.Password);
            Automation.navigate.URL(Navigate.MatterDetailPath + mid);
            return "success";
        }

        public static void End()
        {
            report.Step("Log out");
            test.Click(By.XPath("//span[@ng-bind='vm.username()']"));
            test.WaitForIE(test.driver, 200);
            test.Click(By.LinkText("Logout"));
        }
    }
}
