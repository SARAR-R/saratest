namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchReportQuery")]
    public partial class SearchReportQuery
    {
        public int SearchReportQueryId { get; set; }

        [Required]
        public string Query { get; set; }

        public string CountQuery { get; set; }

        [Required]
        public string SearchViewModel { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime LastAccessed { get; set; }

        public Guid Guid { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public string Columns { get; set; }
    }
}
