namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CalendarDate")]
    public partial class CalendarDate
    {
        public int CalendarDateId { get; set; }

        public int CalendarItemTypeId { get; set; }

        [Required]
        [StringLength(50)]
        public string Title { get; set; }

        public DateTime Start { get; set; }

        [StringLength(50)]
        public string EventPayload { get; set; }

        [StringLength(50)]
        public string ToolTip { get; set; }

        public virtual CalendarItemType CalendarItemType { get; set; }
    }
}
