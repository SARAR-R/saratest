namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("FileValidation")]
    public partial class FileValidation
    {
        public int FileValidationId { get; set; }

        public int MatterId { get; set; }

        [Required]
        [StringLength(100)]
        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        [Required]
        [StringLength(300)]
        public string FileName { get; set; }

        [StringLength(300)]
        public string OutputFileName { get; set; }

        public bool IsValid { get; set; }

        public int RecordCount { get; set; }

        public int ErrorCount { get; set; }

        public int FileSize { get; set; }

        public virtual Matter Matter { get; set; }
    }
}
