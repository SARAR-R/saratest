namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CallCenter")]
    public partial class CallCenter
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CallCenter()
        {
            Matters = new HashSet<Matter>();
        }

        public int CallCenterId { get; set; }

        public int? CallCenterLanguageId { get; set; }

        public int? SetupTurnAroundId { get; set; }

        public int? AgentTypeId { get; set; }

        public bool WebChatToLiveAgent { get; set; }

        public bool EmailRoutingToLiveAgent { get; set; }

        public bool ClientCallback { get; set; }

        public bool ReportingSuite { get; set; }

        public bool StandardScript { get; set; }

        public bool StandardFaq { get; set; }

        [StringLength(25)]
        public string LocalPhone { get; set; }

        [StringLength(25)]
        public string TollFreePhone { get; set; }

        [StringLength(2000)]
        public string Notes { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public virtual AgentType AgentType { get; set; }

        public virtual CallCenterLanguage CallCenterLanguage { get; set; }

        public virtual SetupTurnAround SetupTurnAround { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Matter> Matters { get; set; }
    }
}
