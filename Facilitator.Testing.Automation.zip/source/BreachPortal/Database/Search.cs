namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.Search")]
    public partial class Search
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(500)]
        public string MatterName { get; set; }

        [StringLength(20)]
        public string Status { get; set; }

        [StringLength(500)]
        public string CompanyName { get; set; }

        [StringLength(50)]
        public string InsuranceCompany { get; set; }

        public DateTime? EnrollmentDeadlineDate { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(3)]
        public string IsCreditMonitored { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(3)]
        public string IsStateSpecific { get; set; }

        [StringLength(50)]
        public string SAPContractCode { get; set; }

        [StringLength(20)]
        public string CaseSetupSRNumber { get; set; }
    }
}
