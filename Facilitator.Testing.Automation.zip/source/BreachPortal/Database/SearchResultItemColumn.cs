namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchResultItemColumn")]
    public partial class SearchResultItemColumn
    {
        public int SearchResultItemColumnId { get; set; }

        [Required]
        [StringLength(50)]
        public string TableName { get; set; }

        [Required]
        [StringLength(50)]
        public string ColumnName { get; set; }

        [Required]
        [StringLength(50)]
        public string AliasName { get; set; }

        [Required]
        [StringLength(50)]
        public string DisplayName { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsDefault { get; set; }

        [StringLength(50)]
        public string Permission { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }
    }
}
