namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.MatterQuickSearchStringIndex")]
    public partial class MatterQuickSearchStringIndex
    {
        [StringLength(500)]
        public string VALUE { get; set; }

        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int MatterId { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(16)]
        public string MatchedColumn { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int AllowPartialValue { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int SearchAnywhereInField { get; set; }
    }
}
