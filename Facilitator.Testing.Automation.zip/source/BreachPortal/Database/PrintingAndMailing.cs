namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PrintingAndMailing")]
    public partial class PrintingAndMailing
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public PrintingAndMailing()
        {
            Matters = new HashSet<Matter>();
        }

        public int PrintingAndMailingId { get; set; }

        public bool StandardForms { get; set; }

        public bool CustomLogo { get; set; }

        public bool CustomText { get; set; }

        public bool CustomSignature { get; set; }

        public bool QCRequired { get; set; }

        public bool Duplex { get; set; }

        public bool StandardPaperAndEnvelopes { get; set; }

        public bool TranslationServices { get; set; }

        public int? TurnAroundId { get; set; }

        public string Notes { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Matter> Matters { get; set; }

        public virtual TurnAround TurnAround { get; set; }
    }
}
