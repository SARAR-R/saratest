namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.QuickSearchSortPriority")]
    public partial class QuickSearchSortPriority
    {
        [Key]
        [StringLength(40)]
        public string ColumnName { get; set; }

        public int? SortPriority { get; set; }
    }
}
