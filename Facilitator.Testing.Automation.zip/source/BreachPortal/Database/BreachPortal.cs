namespace BreachPortal.Database
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class BreachPortal : DbContext
    {
        public BreachPortal()
            : base("name=BreachPortal")
        {
        }

        public virtual DbSet<C__RefactorLog> C__RefactorLog { get; set; }
        public virtual DbSet<AgentType> AgentTypes { get; set; }
        public virtual DbSet<CalendarDate> CalendarDates { get; set; }
        public virtual DbSet<CalendarItemType> CalendarItemTypes { get; set; }
        public virtual DbSet<CallCenter> CallCenters { get; set; }
        public virtual DbSet<CallCenterColumn> CallCenterColumns { get; set; }
        public virtual DbSet<CallCenterColumnChange> CallCenterColumnChanges { get; set; }
        public virtual DbSet<CallCenterLanguage> CallCenterLanguages { get; set; }
        public virtual DbSet<Company> Companies { get; set; }
        public virtual DbSet<CompanyColumn> CompanyColumns { get; set; }
        public virtual DbSet<CompanyColumnChange> CompanyColumnChanges { get; set; }
        public virtual DbSet<Contact> Contacts { get; set; }
        public virtual DbSet<ContactColumn> ContactColumns { get; set; }
        public virtual DbSet<ContactColumnChange> ContactColumnChanges { get; set; }
        public virtual DbSet<ContactType> ContactTypes { get; set; }
        public virtual DbSet<FileValidation> FileValidations { get; set; }
        public virtual DbSet<InsuranceCompany> InsuranceCompanies { get; set; }
        public virtual DbSet<IVR> IVRs { get; set; }
        public virtual DbSet<IVRColumn> IVRColumns { get; set; }
        public virtual DbSet<IVRColumnChange> IVRColumnChanges { get; set; }
        public virtual DbSet<IVRLanguage> IVRLanguages { get; set; }
        public virtual DbSet<LawFirm> LawFirms { get; set; }
        public virtual DbSet<Matter> Matters { get; set; }
        public virtual DbSet<MatterColumn> MatterColumns { get; set; }
        public virtual DbSet<MatterColumnChange> MatterColumnChanges { get; set; }
        public virtual DbSet<MatterNoticeType> MatterNoticeTypes { get; set; }
        public virtual DbSet<MatterNoticeTypeColumn> MatterNoticeTypeColumns { get; set; }
        public virtual DbSet<MatterNoticeTypeColumnChange> MatterNoticeTypeColumnChanges { get; set; }
        public virtual DbSet<MatterToContact> MatterToContacts { get; set; }
        public virtual DbSet<MatterToContactColumn> MatterToContactColumns { get; set; }
        public virtual DbSet<MatterToContactColumnChange> MatterToContactColumnChanges { get; set; }
        public virtual DbSet<NoticeType> NoticeTypes { get; set; }
        public virtual DbSet<NoticeTypeColumn> NoticeTypeColumns { get; set; }
        public virtual DbSet<NoticeTypeColumnChange> NoticeTypeColumnChanges { get; set; }
        public virtual DbSet<PrintingAndMailing> PrintingAndMailings { get; set; }
        public virtual DbSet<PrintingAndMailingColumn> PrintingAndMailingColumns { get; set; }
        public virtual DbSet<PrintingAndMailingColumnChange> PrintingAndMailingColumnChanges { get; set; }
        public virtual DbSet<SetupTurnAround> SetupTurnArounds { get; set; }
        public virtual DbSet<SubmittedMatterLog> SubmittedMatterLogs { get; set; }
        public virtual DbSet<SubmittedMatterLogColumn> SubmittedMatterLogColumns { get; set; }
        public virtual DbSet<SubmittedMatterLogColumnChange> SubmittedMatterLogColumnChanges { get; set; }
        public virtual DbSet<Tracking> Trackings { get; set; }
        public virtual DbSet<TrackingColumn> TrackingColumns { get; set; }
        public virtual DbSet<TrackingColumnChange> TrackingColumnChanges { get; set; }
        public virtual DbSet<TurnAround> TurnArounds { get; set; }
        public virtual DbSet<QuickSearchSortPriority> QuickSearchSortPriorities { get; set; }
        public virtual DbSet<SearchReportControlType> SearchReportControlTypes { get; set; }
        public virtual DbSet<SearchReportCriteriaFilter> SearchReportCriteriaFilters { get; set; }
        public virtual DbSet<SearchReportCriteriaItem> SearchReportCriteriaItems { get; set; }
        public virtual DbSet<SearchReportCriteriaItemDetail> SearchReportCriteriaItemDetails { get; set; }
        public virtual DbSet<SearchReportListItem> SearchReportListItems { get; set; }
        public virtual DbSet<SearchReportQuery> SearchReportQueries { get; set; }
        public virtual DbSet<SearchReportResultItem> SearchReportResultItems { get; set; }
        public virtual DbSet<SearchReportTableSql> SearchReportTableSqls { get; set; }
        public virtual DbSet<SearchResultItemColumn> SearchResultItemColumns { get; set; }
        public virtual DbSet<SearchReportFilterListType> SearchReportFilterListTypes { get; set; }
        public virtual DbSet<CalendarItem> CalendarItems { get; set; }
        public virtual DbSet<FullExport> FullExports { get; set; }
        public virtual DbSet<MatterQuickSearchStringIndex> MatterQuickSearchStringIndexes { get; set; }
        public virtual DbSet<Search> Searches { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AgentType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarDate>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarDate>()
                .Property(e => e.EventPayload)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarDate>()
                .Property(e => e.ToolTip)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItemType>()
                .Property(e => e.ItemType)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItemType>()
                .Property(e => e.Color)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItemType>()
                .Property(e => e.TextColor)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItemType>()
                .Property(e => e.CssClassName)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItemType>()
                .Property(e => e.ClientEvent)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItemType>()
                .HasMany(e => e.CalendarDates)
                .WithRequired(e => e.CalendarItemType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CallCenter>()
                .Property(e => e.LocalPhone)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenter>()
                .Property(e => e.TollFreePhone)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenter>()
                .Property(e => e.Notes)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenter>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenter>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CallCenterColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenterColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenterColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenterColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenterColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CallCenterLanguage>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Company>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Company>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Company>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CompanyColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CompanyColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CompanyColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CompanyColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CompanyColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.CompanyName)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Phone)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.PhoneAlternate)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<ContactColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ContactType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<FileValidation>()
                .Property(e => e.CreatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<FileValidation>()
                .Property(e => e.FileName)
                .IsUnicode(false);

            modelBuilder.Entity<FileValidation>()
                .Property(e => e.OutputFileName)
                .IsUnicode(false);

            modelBuilder.Entity<InsuranceCompany>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<IVR>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<IVR>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<IVRColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<IVRColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<IVRColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<IVRColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<IVRColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<IVRLanguage>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<LawFirm>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<LawFirm>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<LawFirm>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<Matter>()
                .Property(e => e.MatterName)
                .IsUnicode(false);

            modelBuilder.Entity<Matter>()
                .Property(e => e.CompanyName)
                .IsUnicode(false);

            modelBuilder.Entity<Matter>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<Matter>()
                .Property(e => e.InsuranceCompanyNameOther)
                .IsUnicode(false);

            modelBuilder.Entity<Matter>()
                .Property(e => e.LawFirm)
                .IsUnicode(false);

            modelBuilder.Entity<Matter>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Matter>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<Matter>()
                .HasMany(e => e.FileValidations)
                .WithRequired(e => e.Matter)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Matter>()
                .HasMany(e => e.MatterNoticeTypes)
                .WithRequired(e => e.Matter)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Matter>()
                .HasMany(e => e.MatterToContacts)
                .WithRequired(e => e.Matter)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Matter>()
                .HasMany(e => e.SubmittedMatterLogs)
                .WithRequired(e => e.Matter)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MatterColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MatterColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MatterColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MatterNoticeType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<MatterNoticeType>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MatterNoticeType>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MatterNoticeTypeColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterNoticeTypeColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterNoticeTypeColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MatterNoticeTypeColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MatterNoticeTypeColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.CompanyName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.ContactTypeName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.Phone)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.PhoneAlternate)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContact>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MatterToContactColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContactColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContactColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContactColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MatterToContactColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<NoticeType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<NoticeType>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<NoticeTypeColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<NoticeTypeColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<NoticeTypeColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<NoticeTypeColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<NoticeTypeColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PrintingAndMailing>()
                .Property(e => e.Notes)
                .IsUnicode(false);

            modelBuilder.Entity<PrintingAndMailing>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PrintingAndMailing>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PrintingAndMailingColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PrintingAndMailingColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PrintingAndMailingColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PrintingAndMailingColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PrintingAndMailingColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SetupTurnAround>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<SubmittedMatterLog>()
                .Property(e => e.CreatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SubmittedMatterLog>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SubmittedMatterLog>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<SubmittedMatterLogColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SubmittedMatterLogColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SubmittedMatterLogColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<SubmittedMatterLogColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<SubmittedMatterLogColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Tracking>()
                .Property(e => e.SAPContractCode)
                .IsUnicode(false);

            modelBuilder.Entity<Tracking>()
                .Property(e => e.CaseSetupSRNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Tracking>()
                .Property(e => e.CaseCode)
                .IsUnicode(false);

            modelBuilder.Entity<Tracking>()
                .Property(e => e.Notes)
                .IsUnicode(false);

            modelBuilder.Entity<Tracking>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Tracking>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<TrackingColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<TrackingColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<TrackingColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<TrackingColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<TrackingColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<TurnAround>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<QuickSearchSortPriority>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportControlType>()
                .Property(e => e.ControlType)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportControlType>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.Display)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.ComparisonOperator)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.FormatString)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItem>()
                .Property(e => e.PropertyName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItem>()
                .Property(e => e.DisplayName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItem>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.TableName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.TableAlias)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.FieldName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.FormatString)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.JoinClause)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.GroupByClause)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.StoredProcName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.ListItemText)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.ListItemValue)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.TableSource)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.FieldSource)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.SqlSource)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.Query)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.CountQuery)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.SearchViewModel)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.LastAccessed)
                .HasPrecision(0);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.Columns)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportResultItem>()
                .Property(e => e.FieldName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportResultItem>()
                .Property(e => e.FieldAlias)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportResultItem>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.FromSql)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.DecryptionOpenText)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.DecryptionCloseText)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.TableName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.AliasName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.DisplayName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.Permission)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportFilterListType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportFilterListType>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.EventPayload)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.Tooltip)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.ItemType)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.Color)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.TextColor)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.CssClassName)
                .IsUnicode(false);

            modelBuilder.Entity<CalendarItem>()
                .Property(e => e.ClientEvent)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.MatterName)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.HasIVR)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.HasPrintingAndMailing)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.HasCallCenter)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CompanyName)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.InsuranceCompany)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.LawFirm)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IsEblast)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.NoticeTypes)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IsW2)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IsRushFee)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IsCreditMonitored)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.HasEquifax)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.HasExperian)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.HasTransunion)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.BasicInformationLastUpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.SAPContractCode)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CaseSetupSRNumber)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CaseCode)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.TrackingNotes)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.TrackingInformationLastUpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.StandardForms)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CustomLogo)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CustomText)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CustomSignature)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.QCRequired)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.Duplex)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.StandardPaperAndEnvelopes)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.TranslationServices)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.TurnAround)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.PrintingAndMailingNotes)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.PMInformationLastUpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IVRLanguage)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IsStandardScript)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IsInboundFax)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.IVRInformationLastUpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CallCenterLanguage)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.SetupAgent)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.AgentType)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.WebChatToLiveAgent)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.EmailRoutingToLiveAgent)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.ClientCallback)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.ReportingSuite)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.StandardScript)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.StandardFaq)
                .IsUnicode(false);

            modelBuilder.Entity<FullExport>()
                .Property(e => e.CallCenterInformationLastUpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MatterQuickSearchStringIndex>()
                .Property(e => e.VALUE)
                .IsUnicode(false);

            modelBuilder.Entity<MatterQuickSearchStringIndex>()
                .Property(e => e.MatchedColumn)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.MatterName)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CompanyName)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.InsuranceCompany)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.IsCreditMonitored)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.IsStateSpecific)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.SAPContractCode)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CaseSetupSRNumber)
                .IsUnicode(false);
        }
    }
}
