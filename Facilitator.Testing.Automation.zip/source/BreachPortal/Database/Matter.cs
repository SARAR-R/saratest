namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Matter")]
    public partial class Matter
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Matter()
        {
            FileValidations = new HashSet<FileValidation>();
            MatterNoticeTypes = new HashSet<MatterNoticeType>();
            MatterToContacts = new HashSet<MatterToContact>();
            SubmittedMatterLogs = new HashSet<SubmittedMatterLog>();
        }

        public int MatterId { get; set; }

        public int? CallCenterId { get; set; }

        public int? PrintingAndMailingId { get; set; }

        public int? IVRId { get; set; }

        public bool HasIVR { get; set; }

        public bool HasPrintingAndMailing { get; set; }

        public bool HasCallCenter { get; set; }

        public int? TrackingId { get; set; }

        [Required]
        [StringLength(500)]
        public string MatterName { get; set; }

        [StringLength(500)]
        public string CompanyName { get; set; }

        [StringLength(20)]
        public string Status { get; set; }

        public int? InsuranceCompanyId { get; set; }

        [StringLength(100)]
        public string InsuranceCompanyNameOther { get; set; }

        public int? AffectedPopulationSize { get; set; }

        [StringLength(500)]
        public string LawFirm { get; set; }

        public bool IsStateSpecific { get; set; }

        public bool IsAdult { get; set; }

        public bool IsEblast { get; set; }

        public bool IsW2 { get; set; }

        public bool IsRushFee { get; set; }

        public bool IsDeceased { get; set; }

        public bool IsCreditMonitored { get; set; }

        public bool HasEquifax { get; set; }

        public bool HasExperian { get; set; }

        public bool HasTransunion { get; set; }

        public DateTime? EnrollmentDeadlineDate { get; set; }

        public DateTime? RegulatoryDeadlineDate { get; set; }

        public DateTime? ProjectedMailDate { get; set; }

        public DateTime? CallCenterLiveDate { get; set; }

        public DateTime? DeliverablesReceivedDate { get; set; }

        public int? CallCenterLiveNotificationInterval { get; set; }

        public DateTime? CallCenterLiveNotificationDate { get; set; }

        public DateTime? CallCenterLiveNotificationDateSent { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public virtual CallCenter CallCenter { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<FileValidation> FileValidations { get; set; }

        public virtual InsuranceCompany InsuranceCompany { get; set; }

        public virtual IVR IVR { get; set; }

        public virtual PrintingAndMailing PrintingAndMailing { get; set; }

        public virtual Tracking Tracking { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MatterNoticeType> MatterNoticeTypes { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MatterToContact> MatterToContacts { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<SubmittedMatterLog> SubmittedMatterLogs { get; set; }
    }
}
