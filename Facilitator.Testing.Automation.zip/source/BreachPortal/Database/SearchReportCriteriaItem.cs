namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchReportCriteriaItem")]
    public partial class SearchReportCriteriaItem
    {
        public int SearchReportCriteriaItemId { get; set; }

        public int SearchReportFilterListTypeId { get; set; }

        [Required]
        [StringLength(100)]
        public string PropertyName { get; set; }

        [Required]
        [StringLength(100)]
        public string DisplayName { get; set; }

        public int DisplayOrder { get; set; }

        public int DefaultSearchReportCriteriaFilterID { get; set; }

        public int SearchReportControlTypeId { get; set; }

        public bool? IsAdvanced { get; set; }

        [StringLength(50)]
        public string SearchReportSourceTable { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }
    }
}
