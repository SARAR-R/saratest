namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("FullExport")]
    public partial class FullExport
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int MatterId { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(500)]
        public string MatterName { get; set; }

        [StringLength(20)]
        public string Status { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(3)]
        public string HasIVR { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(3)]
        public string HasPrintingAndMailing { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(3)]
        public string HasCallCenter { get; set; }

        [StringLength(500)]
        public string CompanyName { get; set; }

        [StringLength(100)]
        public string InsuranceCompany { get; set; }

        public int? AffectedPopulationSize { get; set; }

        [StringLength(500)]
        public string LawFirm { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(3)]
        public string IsEblast { get; set; }

        public string NoticeTypes { get; set; }

        [Key]
        [Column(Order = 6)]
        [StringLength(3)]
        public string IsW2 { get; set; }

        [Key]
        [Column(Order = 7)]
        [StringLength(3)]
        public string IsRushFee { get; set; }

        [Key]
        [Column(Order = 8)]
        [StringLength(3)]
        public string IsCreditMonitored { get; set; }

        [Key]
        [Column(Order = 9)]
        [StringLength(3)]
        public string HasEquifax { get; set; }

        [Key]
        [Column(Order = 10)]
        [StringLength(3)]
        public string HasExperian { get; set; }

        [Key]
        [Column(Order = 11)]
        [StringLength(3)]
        public string HasTransunion { get; set; }

        public DateTime? EnrollmentDeadlineDate { get; set; }

        public DateTime? RegulatoryDeadlineDate { get; set; }

        public DateTime? ProjectedMailDate { get; set; }

        public DateTime? CallCenterLiveDate { get; set; }

        public DateTime? DeliverablesReceivedDate { get; set; }

        [Key]
        [Column(Order = 12)]
        public DateTime BasicInformationCreated { get; set; }

        [Key]
        [Column(Order = 13)]
        public DateTime BasicInformationUpdated { get; set; }

        [Key]
        [Column(Order = 14)]
        [StringLength(256)]
        public string BasicInformationLastUpdatedBy { get; set; }

        [StringLength(50)]
        public string SAPContractCode { get; set; }

        [StringLength(20)]
        public string CaseSetupSRNumber { get; set; }

        [StringLength(20)]
        public string CaseCode { get; set; }

        public string TrackingNotes { get; set; }

        public DateTime? TrackingInformationAdded { get; set; }

        public DateTime? TrackingInformationUpdated { get; set; }

        [StringLength(256)]
        public string TrackingInformationLastUpdatedBy { get; set; }

        [Key]
        [Column(Order = 15)]
        [StringLength(3)]
        public string StandardForms { get; set; }

        [Key]
        [Column(Order = 16)]
        [StringLength(3)]
        public string CustomLogo { get; set; }

        [Key]
        [Column(Order = 17)]
        [StringLength(3)]
        public string CustomText { get; set; }

        [Key]
        [Column(Order = 18)]
        [StringLength(3)]
        public string CustomSignature { get; set; }

        [Key]
        [Column(Order = 19)]
        [StringLength(3)]
        public string QCRequired { get; set; }

        [Key]
        [Column(Order = 20)]
        [StringLength(3)]
        public string Duplex { get; set; }

        [Key]
        [Column(Order = 21)]
        [StringLength(3)]
        public string StandardPaperAndEnvelopes { get; set; }

        [Key]
        [Column(Order = 22)]
        [StringLength(3)]
        public string TranslationServices { get; set; }

        [StringLength(50)]
        public string TurnAround { get; set; }

        public string PrintingAndMailingNotes { get; set; }

        public DateTime? PMInformationAdded { get; set; }

        public DateTime? PMInformationUpdated { get; set; }

        [StringLength(256)]
        public string PMInformationLastUpdatedBy { get; set; }

        [StringLength(50)]
        public string IVRLanguage { get; set; }

        [Key]
        [Column(Order = 23)]
        [StringLength(3)]
        public string IsStandardScript { get; set; }

        [Key]
        [Column(Order = 24)]
        [StringLength(3)]
        public string IsInboundFax { get; set; }

        public DateTime? IVRInformationAdded { get; set; }

        public DateTime? IVRInformationUpdated { get; set; }

        [StringLength(256)]
        public string IVRInformationLastUpdatedBy { get; set; }

        [StringLength(50)]
        public string CallCenterLanguage { get; set; }

        [StringLength(50)]
        public string SetupAgent { get; set; }

        [StringLength(50)]
        public string AgentType { get; set; }

        [Key]
        [Column(Order = 25)]
        [StringLength(3)]
        public string WebChatToLiveAgent { get; set; }

        [Key]
        [Column(Order = 26)]
        [StringLength(3)]
        public string EmailRoutingToLiveAgent { get; set; }

        [Key]
        [Column(Order = 27)]
        [StringLength(3)]
        public string ClientCallback { get; set; }

        [Key]
        [Column(Order = 28)]
        [StringLength(3)]
        public string ReportingSuite { get; set; }

        [Key]
        [Column(Order = 29)]
        [StringLength(3)]
        public string StandardScript { get; set; }

        [Key]
        [Column(Order = 30)]
        [StringLength(3)]
        public string StandardFaq { get; set; }

        public DateTime? CallCenterInformationAdded { get; set; }

        public DateTime? CallCenterInformationUpdatedBy { get; set; }

        [StringLength(256)]
        public string CallCenterInformationLastUpdatedBy { get; set; }
    }
}
