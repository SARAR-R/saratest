namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchReportCriteriaItemDetail")]
    public partial class SearchReportCriteriaItemDetail
    {
        public int SearchReportCriteriaItemDetailId { get; set; }

        public int SearchReportCriteriaItemId { get; set; }

        public int SearchReportCriteriaFilterId { get; set; }

        [Required]
        [StringLength(100)]
        public string TableName { get; set; }

        [Required]
        [StringLength(10)]
        public string TableAlias { get; set; }

        [Required]
        [StringLength(100)]
        public string FieldName { get; set; }

        [Required]
        [StringLength(500)]
        public string FormatString { get; set; }

        public bool RemoveNonAlphaCharacters { get; set; }

        public bool RemoveNonNumericCharacters { get; set; }

        public int SortOrder { get; set; }

        [StringLength(1000)]
        public string JoinClause { get; set; }

        [StringLength(2000)]
        public string GroupByClause { get; set; }

        [StringLength(100)]
        public string StoredProcName { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }
    }
}
