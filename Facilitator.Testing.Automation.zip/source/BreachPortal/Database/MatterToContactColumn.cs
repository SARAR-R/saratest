namespace BreachPortal.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MatterToContactColumn")]
    public partial class MatterToContactColumn
    {
        public int MatterToContactColumnId { get; set; }

        [Required]
        [StringLength(50)]
        public string ColumnName { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
