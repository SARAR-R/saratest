﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using BreachPortal.Database;
using OpenQA.Selenium;
using BreachPortal.Matter;
using OpenQA.Selenium.Support.UI;
using CallCenter = BreachPortal.Matter.CallCenter;
using PrintingAndMailing = BreachPortal.Matter.PrintingAndMailing;
using Tracking = BreachPortal.Matter.Tracking;

namespace BreachPortal
{
    public class Permissions
    {
        public static void ValidateMenuItems(bool matterSelected, bool edit)
        {
            try
            {
                report.Step("Verify Menu Items");
                test.VerifyElementExists(Navigate._Search, true);
                test.VerifyElementExists(Navigate._MatterDetail, matterSelected);
                test.VerifyElementExists(Navigate._CreateNewMatter, edit);
                test.VerifyElementExists(Navigate._Reports, true);
                test.VerifyElementExists(Navigate._MaintainContacts, edit);
                test.VerifyElementExists(Navigate._Calendar, true);
            }
            catch (Exception e)
            {
                report.Fail("Validate Menu Items failed due to: " + e.Message);
                
            }
        }

        public static void ValidateSearch(int matterId)
        {
            var record = Data.GetMatter(matterId);
            try
            {              
                report.Step("Validate Search");
                test.VerifyElementAvailability(By.XPath("//label[text()='Matter Name']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='Status']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='Company Name']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='Insurance Company']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='Enrollment Deadline']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='Credit Monitoring']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='State Specific']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='SAP Contract Code']"), true);
                test.VerifyElementAvailability(By.XPath("//label[text()='Case Setup SR Number']"), true);
                //validate quick search functionality
                Search.ValidateQuickSearch(record.MatterName);
            }
            catch (Exception e)
            {
                report.Fail("Validate Search failed due to: " + e.Message);
                
            }
        }

        public static void ValidateMatterDetail(int matterId, bool edit)
        {
            
            try
            {
                report.Step("Validate Matter Detail Data");
                var basicInfo = Data.GetMatter(matterId);
                var noticeTypes = Data.GetMatterNoticeType(matterId);
                var contacts = Data.GetMatterToContact(matterId);
                var tracking = Data.GetTracking(matterId);
                var printingAndMailing = Data.GetPrintingAndMailing(matterId);
                var ivr = Data.GetIvr(matterId);
                var callCenter = Data.GetCallCenter(matterId);

                BasicInfo.ValidateRecord(basicInfo, noticeTypes);
                Contacts.ValidateRecords(contacts.OrderBy(l => l.LastName).ToList());
                Tracking.ValidateRecord(tracking);
                PrintingAndMailing.ValidateRecord(printingAndMailing);
                Ivr.ValidateRecord(ivr);
                CallCenter.ValidateRecord(callCenter);

                ValidateBasicInfo(edit);
                ValidateContacts(contacts, edit); 
                ValidateTracking(edit);
                ValidatePrintingAndMailing(edit, basicInfo.HasPrintingAndMailing);
                ValidateIvr(edit, basicInfo.HasIVR);
                ValidateCallCenter(edit, basicInfo.HasCallCenter);
                ValidateFileUpload(edit);
            }
            catch (Exception e)
            {
                report.Fail("Validate Matter Detail failed due to: " + e.Message);
                
            }
        }

        public static void ValidateCreateNew(bool edit)
        {
            try
            {
                report.Step("Validate Create New");
                if (!edit)
                {
                    test.VerifyAccess(false);
                }
                else
                {
                    ValidateBasicInfo(true, false);
                    ValidateContacts(null, false, true);
                    ValidateTracking(true);
                    test.Click(By.XPath(PrintingAndMailing.Section));
                    ValidatePrintingAndMailing(true, true);
                    test.Click(By.XPath(Ivr.Section));
                    ValidateIvr(true, true);
                    test.Click(By.XPath(CallCenter.Section));
                    ValidateCallCenter(true, true);
                    ValidateFileUpload(true, true);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Create New failed due to: " + e.Message);
                
            }
        }

        public static void ValidateBasicInfo(bool edit, bool submit = true)
        {
            report.Step("Validate Basic Info Editability");
            if (edit) //To cause save/submit to enabled
            {
                test.EditField(By.XPath(BasicInfo.MatterName), "TempName");   
                test.EditField(By.XPath(BasicInfo.CompanyName), "CompanyName");
                test.SelectField(By.XPath(BasicInfo.InsuranceCompany), "Other");
                test.EditField(By.XPath(BasicInfo.Other), "OtherName");
                test.EditField(By.XPath(BasicInfo.AffectedPopulationSize), "100");
            }

            test.VerifyElementEnabled(BasicInfo._Save, edit);
            test.VerifyElementEnabled(BasicInfo._Cancel, edit);
            test.VerifyElementVisibility(BasicInfo._Submit, submit);
            if (submit) test.VerifyElementEnabled(BasicInfo._Submit, edit);
 
            test.VerifyElementEnabled(By.XPath(BasicInfo.MatterName), edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.CompanyName), edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.InsuranceCompany), edit);
            if (new SelectElement(test.driver.FindElement(By.XPath(BasicInfo.InsuranceCompany)))
                    .SelectedOption.Text == "Other")
            {
                test.VerifyElementEnabled(By.XPath(BasicInfo.Other), edit);
            }
            else
            {
                test.VerifyElementExists(By.XPath(BasicInfo.Other), false);
            }              
            test.VerifyElementEnabled(By.XPath(BasicInfo.AffectedPopulationSize), edit);
            test.VerifyElementVisibility(By.XPath(BasicInfo.LawFirm), !edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.Status), edit);
            //TODO: Figure out how to determine Notice Types are disabled once Bug 235595 is fixed.
            Test.VerifyToggleEditability(BasicInfo.EBlast, edit);
            Test.VerifyToggleEditability(BasicInfo.W2, edit);
            Test.VerifyToggleEditability(BasicInfo.CreditMonitoring, edit);
            Test.VerifyToggleEditability(BasicInfo.Equifax, edit);
            Test.VerifyToggleEditability(BasicInfo.Experian, edit);
            Test.VerifyToggleEditability(BasicInfo.Transunion, edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.EnrollmentDeadline), edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.RegulatoryDeadline), edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.ProjectedMailDate), edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.CallCenterLiveDate), edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.CallCenterLiveNotificationInterval), 
                !string.IsNullOrEmpty(test.driver.FindElement(By.XPath(BasicInfo.CallCenterLiveDate)).GetAttribute("value")) && edit);
            test.VerifyElementEnabled(By.XPath(BasicInfo.CallCenterLiveNotificationDate), false);
            test.VerifyElementEnabled(By.XPath(BasicInfo.DeliverablesReceivedDate), edit);
            if (edit) test.Click(BasicInfo._Cancel);  //To revert changes
        }

        public static void ValidateContacts(List<MatterToContact> records, bool edit, bool createNew = false)
        {
            report.Step("Validate Contacts Editability");
            if (createNew)
            {
                test.VerifyElementDoesNotExist(Contacts._Grid);  //Ensure grid is hidden.
                test.VerifyElementExists(Contacts._GridHiddenMessage); //Ensure message is displayed
            }
            else
            {
                test.VerifyElementEnabled(Contacts._AddContact, edit);
            
                if (records?.Count > 0)
                {
                    test.VerifyElementExists(By.XPath(Contacts.View), !edit);
                    test.VerifyElementExists(By.XPath(Contacts.Edit), edit);
                    test.VerifyElementVisibility(By.XPath(Contacts.Delete), edit);
                }
                else
                {
                    Grid.VerifyRowCount(By.XPath(Contacts.Row), 0);
                }
            }
        }

        public static void ValidateTracking(bool edit)
        {
            report.Step("Validate Tracking Editability");
            test.VerifyElementEnabled(By.XPath(Tracking.SapContractCode), edit);
            test.VerifyElementEnabled(By.XPath(Tracking.CaseSetupSrNumber), edit);
            test.VerifyElementEnabled(By.XPath(Tracking.CaseCode), edit);
            test.VerifyElementEnabled(By.XPath(Tracking.Notes), edit);
        }

        public static void ValidatePrintingAndMailing(bool edit, bool enabled)
        {
            report.Step("Validate Printing And Mailing Editability");
            Test.VerifySectionEditability(PrintingAndMailing.Section, edit);
            if (!enabled) return;
            Test.VerifyToggleEditability(PrintingAndMailing.StandardForms, edit);
            Test.VerifyToggleEditability(PrintingAndMailing.CustomText, edit);
            Test.VerifyToggleEditability(PrintingAndMailing.QcRequired, edit);
            Test.VerifyToggleEditability(PrintingAndMailing.StandardPaperAndEnvelopes, edit);
            Test.VerifyToggleEditability(PrintingAndMailing.CustomLogo, edit);
            Test.VerifyToggleEditability(PrintingAndMailing.CustomSignature, edit);
            test.VerifyElementEnabled(By.XPath(PrintingAndMailing.Turnaround), edit);
            Test.VerifyToggleEditability(PrintingAndMailing.Duplex, edit);
            Test.VerifyToggleEditability(PrintingAndMailing.TranslationServices, edit);
            test.VerifyElementEnabled(By.XPath(PrintingAndMailing.PrintingAndMailingNotes), edit);
        }

        public static void ValidateIvr(bool edit, bool enabled)
        {
            report.Step("Validate IVR Editability");
            Test.VerifySectionEditability(Ivr.Section, edit);
            if (!enabled) return;
            Test.VerifyToggleEditability(Ivr.StandardScript, edit);
            Test.VerifyToggleEditability(Ivr.InboundFax, edit);
            test.VerifyElementEnabled(By.XPath(Ivr.Languages), edit);           
        }

        public static void ValidateCallCenter(bool edit, bool enabled)
        {
            report.Step("Validate Call Center Editability");
            Test.VerifySectionEditability(CallCenter.Section, edit);
            if (!enabled) return;
            test.VerifyElementEnabled(By.XPath(CallCenter.Languages), edit);
            Test.VerifyToggleEditability(CallCenter.WebChatToLiveAgent, edit);
            Test.VerifyToggleEditability(CallCenter.ReportingSuite, edit);
            test.VerifyElementEnabled(By.XPath(CallCenter.Agents), edit);
            Test.VerifyToggleEditability(CallCenter.EmailRoutingToLiveAgent, edit);
            Test.VerifyToggleEditability(CallCenter.StandardScript, edit);
            test.VerifyElementEnabled(By.XPath(CallCenter.SetupTurnAround), edit);
            Test.VerifyToggleEditability(CallCenter.ClientCallback, edit);
            Test.VerifyToggleEditability(CallCenter.StandardFaq, edit);
        }

        public static void ValidateFileUpload(bool edit, bool createNew = false)
        {
            report.Step("Validate File Upload Editability");
            
            if (createNew)
            {
                test.VerifyClassExists(By.XPath(FileUpload.Directive), "ng-hide");  //Ensure uploader is hidden.
                test.VerifyClassExists(FileUpload._SectionHiddenMessage, "ng-hide", false); //Ensure message is displayed
            }
            else
            {
                if (edit)

                {
                    test.VerifyElementEnabled(FileUpload._SelectFile, true);
                }
                else
                {
                    test.VerifyElementVisibility(By.XPath(FileUpload.Directive), false);
                }
            }
            
        }

        public static void ValidateReports()
        {
            report.Step("Validate Reports page access");
            test.VerifyAccess(true);
        }

        public static void ValidateMaintainContacts(bool edit)
        {
            var records = Data.GetContact();

            report.Step("Validate Maintain Contacts page");
            if (!edit)
            {
                test.VerifyAccess(false);
            }
            else
            {
                if (records?.Count > 0)
                {
                    test.WaitForElement(By.XPath(Grid.Row));
                    
                    test.VerifyElementEnabled(MaintainContact._Add, true);
                    test.Click(MaintainContact._Add);
                    MaintainContact.ValidateModalEditability(true);
                    test.Click(MaintainContact._ModalCancel);

                    test.VerifyElementExists(By.XPath(MaintainContact.Edit), true);
                    test.Click(By.XPath(MaintainContact.Edit));
                    MaintainContact.ValidateModalEditability(true);
                    test.Click(MaintainContact._ModalCancel);

                    test.VerifyElementVisibility(By.XPath(MaintainContact.Delete), true);
                    test.Click(By.XPath(MaintainContact.Delete));
                    MaintainContact.ValidateModalEditability(false);
                    test.Click(MaintainContact._ModalCancel);

                }
                else
                {
                    test.VerifyElementEnabled(MaintainContact._Add, true);
                    test.Click(MaintainContact._Add);
                    MaintainContact.ValidateModalEditability(true);
                    test.Click(MaintainContact._ModalCancel);

                    Grid.VerifyRowCount(By.XPath(Grid.Row), 0);
                }

                
            }
        }

        public static void ValidateCalendar()
        {
            report.Step("Validate Calendar page access");
            Calendar.ValidateMonthlyView(DateTime.Now);
        }

    }
}
