﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Automation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace BreachPortal
{
    public class Grid
    {
        public static By _PageSize = By.XPath("//select[@ng-model='grid.options.paginationPageSize']");
        public static By _TotalItems = By.XPath("//div[@class='ui-grid-pager-count-container']");
        public static By _CurPage = By.XPath("//input[@ng-model='grid.options.paginationCurrentPage']");
        public static By _NumPages = By.XPath("//span[contains(@class, 'ui-grid-pager-max-pages-number')]");
        public static By _FirstPage = By.XPath("//button[@ng-click='pageFirstPageClick()']");
        public static By _PreviousPage = By.XPath("//button[@ng-click='pagePreviousPageClick()']");
        public static By _NextPage = By.XPath("//button[@ng-click='pageNextPageClick()']");
        public static By _LastPage = By.XPath("//button[@ng-click='pageLastPageClick()']");
        public static string View = "//a[contains(@ng-click, 'edit')]/i[contains(@class, 'fa-eye')]";
        public static string Edit = "//a[contains(@ng-click, 'edit')]/i[contains(@class, 'fa-pencil')]";
        public static string Delete = "//a[contains(@ng-click, 'delete')]";
        public static string Row = "//div[@ui-grid-row]";

        public static void SortByColumn(string columnName, string sort)
        {
            var asc = By.XPath("//span[text()='" + columnName +
                               "']/following-sibling::span[@aria-label='Sort Ascending']");
            var desc = By.XPath("//span[text()='" + columnName +
                                "']/following-sibling::span[@aria-label='Sort Descending']");
            var column = By.XPath("//span[text()='" + columnName + "']");

            //If both are hidden, column is unsorted.
            if (test.driver.FindElements(asc).Count == 1 && test.driver.FindElements(desc).Count == 1)
            {
                test.Click(column);
                test.WaitForElement(asc);
            }

            switch (sort)
            {
                case "ascending":
                case "asc":
                    //If only ascending is hidden, then it is sorted by ascending
                    if (test.driver.FindElements(asc).Count == 1 && test.driver.FindElements(desc).Count == 0) break;
                    test.Click(column);
                    test.WaitForElement(asc);
                    break;
                case "descending":
                case "desc":
                    //If only descending is hidden, then it is sorted by descending
                    if (test.driver.FindElements(asc).Count == 0 && test.driver.FindElements(desc).Count == 1) break;
                    test.Click(column);
                    test.WaitForElement(desc);
                    break;
                default:
                    report.Fail("Sort method (" + sort + ") not supported.");

                    break;
            }

        }

        public static string ColumnUid(string column)
        {
            var col = test.driver
                .FindElement(By.XPath("//span[text()='" + column +
                                      "']/ancestor::div[contains(@class, 'ui-grid-header-cell') and contains(@class, 'ng-scope')]"))
                .GetAttribute("class");
            var attributes = col.Split(' ');
            return attributes[4];
        }

        public class ColumnDetails
        {
            public string Label { get; set; }
            public string Type { get; set; } = "text";
        }

        public static int VerifySortOrder(string column, string type)
        {
            var by = By.XPath("//div[contains(@class, '" + ColumnUid(column) +
                              "') and contains(@class, 'ui-grid-cell')]//div");
            try
            {
                //Ascending Sort
                if (test.driver.FindElements(By.XPath("//span[text()='" + column +
                                                      "']/ancestor::div[@aria-sort='ascending']"))
                        .Count == 0) //If not already sorted by ascending
                {
                    SortByColumn(column, "ascending");
                }

                test.WaitForElement(By.XPath("//span[text()='" + column + "']/ancestor::div[@aria-sort='ascending']"));
                var asc = test.driver.FindElements(by).Where(s => !string.IsNullOrWhiteSpace(s.Text)).ToList();
                Assert.IsTrue(type == "numeric"
                        ? asc.OrderBy(t => int.Parse(t.Text)).SequenceEqual(asc)
                        : asc.OrderBy(t => t.Text, StringComparer.OrdinalIgnoreCase).SequenceEqual(asc),
                    test.ListToString(asc));
                report.Pass(column + " column is sorting by ascending correctly.");
            }
            catch (Exception e)
            {
                report.Fail(column + " column is not sorting by ascending correctly.", e);
                return 1;
            }

            try
            {
                //Descending Sort
                SortByColumn(column, "descending");
                test.WaitForElement(By.XPath("//span[text()='" + column + "']/ancestor::div[@aria-sort='descending']"));
                var desc = test.driver.FindElements(by).Where(s => !string.IsNullOrWhiteSpace(s.Text)).ToList();
                Assert.IsTrue(type == "numeric"
                    ? desc.OrderByDescending(t => int.Parse(t.Text)).SequenceEqual(desc)
                    : desc.OrderByDescending(t => t.Text).SequenceEqual(desc), test.ListToString(desc));
                report.Pass(column + " column is sorting by descending correctly.");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail(column + " column is not sorting by descending correctly.", e);
                return 1;
            }

        }

        public static void ValidateColumnSorting(List<ColumnDetails> columns)
        {
            foreach (var column in columns)
            {
                VerifySortOrder(column.Label, column.Type);
            }
        }

        public static void ValidatePaging(string table, string defaultSize)
        {
            report.Step("Validate Paging");
            try
            {
                var records = TotalItems();
                var sizes = new[] {"10", "25", "50", "100"};
                //Page Sizing
                VerifyNumberOfPages();
                var defaultMax =
                    int.Parse(defaultSize) > 15 ? 15 : int.Parse(defaultSize); //Grid will show at most 16 rows
                VerifyRowCount(By.XPath(table + Row), defaultMax, records);
                foreach (var size in sizes)
                {
                    if (size == defaultSize) continue;
                    test.SelectField(_PageSize, size);
                    VerifyNumberOfPages();
                    var expectedMax = int.Parse(size) > 15 ? 15 : int.Parse(size); //Grid will show at most 16 rows
                    VerifyRowCount(By.XPath(table + Row), expectedMax, records);
                }

                //Page Navigation
                test.SelectField(_PageSize, "10");

                double pageSize = int.Parse(new SelectElement(test.driver.FindElement(_PageSize)).SelectedOption.Text);

                if (records <= pageSize)
                    throw new InvalidOperationException(
                        "There are not enough records in this grid to validate page navigation.");

                test.Click(_NextPage);
                test.VerifyFieldValue(_CurPage, "2");
                test.Click(_PreviousPage);
                test.VerifyFieldValue(_CurPage, "1");
                test.Click(_LastPage);
                test.VerifyFieldValue(_CurPage,
                    Math.Ceiling(records / pageSize).ToString(CultureInfo.InvariantCulture));
                test.Click(_FirstPage);
                test.VerifyFieldValue(_CurPage, "1");
                test.SelectField(_PageSize, defaultSize);
            }
            catch (Exception e)
            {
                report.Fail("Unable to validate paging: " + e.Message);

            }

        }

        public static int TotalItems()
        {
            var regex = new Regex("of (.*?) items"); 
            var result = regex.Match(test.driver.FindElement(_TotalItems).Text).Groups[1].Value;
            return int.Parse(result);
        }

        public static int VerifyNumberOfPages()
        {
            try
            {
                var numPages = double.Parse(test.driver.FindElement(_NumPages).Text.Substring(2));
                var pageSize = double.Parse(new SelectElement(test.driver.FindElement(_PageSize)).SelectedOption.Text);
                var records = TotalItems();

                try
                {
                    Assert.AreEqual(Math.Ceiling((records == 0  ? 1 : records) / pageSize), numPages);
                    report.Pass("Number of pages (" + numPages + ") matches expected value for page size (" + pageSize +
                                ") and total records (" + records + ").");
                    return 0;
                }
                catch (Exception e)
                {
                    report.Fail(
                        "Number of pages (" + numPages + ") does not match expected value for page size (" + pageSize +
                        ") and total records (" + records + ").", e);
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail(
                    "Unable to Verify Number of Pages", e);
                return 1;
            }
        }

        public static int VerifyRowCount(By rowXpath, int expected, double totalRecords)
        {
            try
            {
                var count = test.driver.FindElements(rowXpath).Count;
                if (expected > totalRecords)
                {
                    expected = Convert.ToInt32(totalRecords);
                }

                if (count == expected)
                {
                    report.Pass("Number of rows found matches expected (" + expected + ")");
                    return 0;
                }
                else
                {
                    report.Fail("Number of rows found (" + count + ") does not match expected (" + expected + ")");
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying the row count", e);
                return 1;
            }
        }

        public static int VerifyRowCount(By row, int expectedCount)
        {
            try
            {
                var actualCount = test.driver.FindElements(row).Count;
                if (actualCount == expectedCount)
                {
                    report.Pass("There are " + expectedCount + " " + row + " elements.");
                    return 0;
                }
                else
                {
                    report.Fail("There are " + actualCount + " " + row + " elements.  Expected: " + expectedCount);
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying the row count: ", e);
                return 1;
            }
        }

        public static int VerifyCellContents(string columnName, string expectedValue, int row = 1)
        {
            return VerifyCellContents("//*", columnName, expectedValue, row);
        }

        public static int VerifyCellContents(string directive, string columnName, string expectedValue, int row = 1)
        {
            try
            {
                var columnClass = test.driver.FindElement(By.XPath(directive + "//div[text()='" + columnName + "']")).GetAttribute("class");
                var columnNumber = columnClass.Split(' ')[2].Substring(4);
                var cell = By.XPath("(" + directive + "//div[contains(@class, 'col" + columnNumber + " colt" +
                                    columnNumber + "')]//*[contains(@class, 'ngCell')])[" + row + "]");
                return test.VerifyTextContains(test.driver, cell, expectedValue ?? "");
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while attempting to verify " + columnName + ".", e);
                return 1;
            }
        }

        public static int VerifyCellContents(int column, string expectedValue, int row = 1)
        {
            try
            {
                var cell = By.XPath("(//div[@ui-grid-row])[" + row + "]//div[@ui-grid-cell][" + column + "]/div");
                return test.VerifyTextContains(test.driver, cell, expectedValue ?? "");
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while attempting to verify column " + column + ".", e);
                return 1;
            }
        }

        public static int VerifyGridLoaded()
        {
            try
            {
                test.WaitForElement(By.XPath(Row));
                report.Pass("Grid Loaded");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Unable to verify grid load: ", e);
                test.readConsole("Console");
                return 1;
            }
            
        }

    }
}
