﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using BreachPortal.Database;
using CallCenter = BreachPortal.Database.CallCenter;
using PrintingAndMailing = BreachPortal.Database.PrintingAndMailing;
using Tracking = BreachPortal.Database.Tracking;
using Contact = BreachPortal.Database.Contact;

namespace BreachPortal
{
    public class Data
    {
        public static List<Database.Matter> GetMatter()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.Matters
                    select c;

                return query.Include(i => i.InsuranceCompany).ToList();
            }
        }

        public static Database.Matter GetMatter(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.Matters
                    where c.MatterId == matterId
                    select c;

                return query.Include(i => i.InsuranceCompany).FirstOrDefault();
            }
        }

        public static List<InsuranceCompany> GetInsuranceCompany()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.InsuranceCompanies
                    select c;

                return query.ToList();
            }
        }

        public static List<LawFirm> GetLawFirm()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.LawFirms
                    select c;

                return query.ToList();
            }
        }

        public static List<Tracking> GetTracking()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.Trackings
                    select c;

                return query.ToList();
            }

        }

        public static Tracking GetTracking(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.Trackings
                    join d in context.Matters 
                    on c.TrackingId equals d.TrackingId
                    where d.MatterId == matterId
                    select c;

                return query.FirstOrDefault();
            }
        }

        public static List<Contact> GetContact()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.Contacts
                        .Include(c => c.ContactType)
                    orderby c.LastName
                    select c;
                
                return query.ToList();
            }
        }
        
        public static List<ContactType> GetContactType()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.ContactTypes
                    select c;

                return query.ToList();
            }
        }

        public static List<MatterToContact> GetMatterToContact()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.MatterToContacts
                    orderby c.LastName
                    select c;
                
                return query.ToList();
            }
        }

        public static List<MatterToContact> GetMatterToContact(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.MatterToContacts
                    where c.MatterId == matterId
                    orderby c.LastName
                    select c;
                
                return query.ToList();
            }
        }

        public static List<Company> GetCompany()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.Companies
                    select c;
                
                return query.ToList();
            }
        }

        public static List<PrintingAndMailing> GetPrintingAndMailing()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.PrintingAndMailings
                    select c;

                return query.Include(t => t.TurnAround).ToList();
            }
        }

        public static PrintingAndMailing GetPrintingAndMailing(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.PrintingAndMailings
                    join d in context.Matters
                    on c.PrintingAndMailingId equals d.PrintingAndMailingId
                    where d.MatterId == matterId
                    select c;

                return query.Include(t => t.TurnAround).FirstOrDefault();
            }
        }

        public static List<TurnAround> GetTurnAround()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.TurnArounds
                    select c;

                return query.ToList();
            }
        }

        public static List<CallCenter> GetCallCenter()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.CallCenters
                    select c;

                return query.Include(l => l.CallCenterLanguage).Include(a => a.AgentType).Include(s => s.SetupTurnAround).ToList();
            }
        }

        public static CallCenter GetCallCenter(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.CallCenters
                    join d in context.Matters
                    on c.CallCenterId equals d.CallCenterId
                    where d.MatterId == matterId
                    select c;

                return query.Include(l => l.CallCenterLanguage).Include(a => a.AgentType).Include(s => s.SetupTurnAround).FirstOrDefault();
            }
        }

        public static List<CallCenterLanguage> GetCallCenterLanguage()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.CallCenterLanguages
                    select c;

                return query.ToList();
            }
        }

        public static List<AgentType> GetAgentType()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.AgentTypes
                    select c;

                return query.ToList();
            }
        }

        public static List<SetupTurnAround> GetSetupTurnAround()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.SetupTurnArounds
                    select c;

                return query.ToList();
            }
        }

        public static List<IVR> GetIvr()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.IVRs
                    select c;

                return query.Include(l => l.IVRLanguage).ToList();
            }
        }

        public static IVR GetIvr(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.IVRs
                    join d in context.Matters
                    on c.IVRId equals d.IVRId
                    where d.MatterId == matterId
                    select c;

                return query.Include(l => l.IVRLanguage).FirstOrDefault();
            }
        }

        public static List<IVRLanguage> GetIvrLanguage()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.IVRLanguages
                    select c;

                return query.ToList();
            }
        }

        public static List<SubmittedMatterLog> GetSubmittedMatterLog()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.SubmittedMatterLogs
                    select c;

                return query.ToList();
            }
        }

        public static List<SubmittedMatterLog> GetSubmittedMatterLog(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.SubmittedMatterLogs
                    where c.MatterId == matterId
                    select c;

                return query.ToList();
            }
        }

        public static List<MatterNoticeType> GetMatterNoticeType()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.MatterNoticeTypes
                    select c;

                return query.ToList();
            }
        }

        public static List<MatterNoticeType> GetMatterNoticeType(int matterId)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.MatterNoticeTypes
                    where c.MatterId == matterId
                    select c;

                return query.ToList();
            }
        }

        public static List<NoticeType> GetNoticeType()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.NoticeTypes
                    select c;

                return query.ToList();
            }
        }

        public static List<Search.SearchResult> GetSearchResults(string value)
        {
            using (var context = new Database.BreachPortal())
            {
                var submittedMatterLog = GetSubmittedMatterLog();

                var query =
                    from c in context.Trackings
                    join d in context.Matters on c.TrackingId equals d.TrackingId
                    join e in context.InsuranceCompanies on d.InsuranceCompanyId equals e.InsuranceCompanyId
                    where d.MatterName.Contains(value)
                    select new { c, d, e };

                var query2 =
                    from c in context.Trackings
                    join d in context.Matters on c.TrackingId equals d.TrackingId
                    join e in context.InsuranceCompanies on d.InsuranceCompanyId equals e.InsuranceCompanyId
                    where d.CompanyName.Contains(value)
                    select new { c, d, e };

                var query3 =
                    from c in context.Trackings
                    join d in context.Matters on c.TrackingId equals d.TrackingId
                    join e in context.InsuranceCompanies on d.InsuranceCompanyId equals e.InsuranceCompanyId
                    where e.Name.Contains(value)
                    select new { c, d, e };


                var result = new List<Search.SearchResult>();
                foreach (var record in query)
                {
                    result.Add(new Search.SearchResult
                    {
                        MatterId = record.d.MatterId,
                        MatchedColumn = "MatterName",
                        MatterName = record.d.MatterName,
                        Status = submittedMatterLog.Any(i => i.MatterId == record.d.MatterId) ? "Submitted" : "Not Submitted",
                        CompanyName = record.d.CompanyName,
                        InsuranceCompany = record.e.Name,
                        EnrollmentDeadline = Format.Date(record.d.EnrollmentDeadlineDate),
                        CreditMonitoring = Format.YesNoString(record.d.IsCreditMonitored),
                        StateSpecific = Format.YesNoString(record.d.IsStateSpecific),
                        SapContractCode = record.c.SAPContractCode,
                        CaseSetupSrNumber = record.c.CaseSetupSRNumber
                    });
                }

                foreach (var record in query2)
                {
                    result.Add(new Search.SearchResult
                    {
                        MatterId = record.d.MatterId,
                        MatchedColumn = "CompanyName",
                        MatterName = record.d.MatterName,
                        Status = submittedMatterLog.Any(i => i.MatterId == record.d.MatterId) ? "Submitted" : "Not Submitted",
                        CompanyName = record.d.CompanyName,
                        InsuranceCompany = record.e.Name,
                        EnrollmentDeadline = Format.Date(record.d.EnrollmentDeadlineDate),
                        CreditMonitoring = Format.YesNoString(record.d.IsCreditMonitored),
                        StateSpecific = Format.YesNoString(record.d.IsStateSpecific),
                        SapContractCode = record.c.SAPContractCode,
                        CaseSetupSrNumber = record.c.CaseSetupSRNumber
                    });
                }

                foreach (var record in query3)
                {
                    result.Add(new Search.SearchResult
                    {
                        MatterId = record.d.MatterId,
                        MatchedColumn = "InsuranceCompany",
                        MatterName = record.d.MatterName,
                        Status = submittedMatterLog.Any(i => i.MatterId == record.d.MatterId) ? "Submitted" : "Not Submitted",
                        CompanyName = record.d.CompanyName,
                        InsuranceCompany = record.e.Name,
                        EnrollmentDeadline = Format.Date(record.d.EnrollmentDeadlineDate),
                        CreditMonitoring = Format.YesNoString(record.d.IsCreditMonitored),
                        StateSpecific = Format.YesNoString(record.d.IsStateSpecific),
                        SapContractCode = record.c.SAPContractCode,
                        CaseSetupSrNumber = record.c.CaseSetupSRNumber
                    });
                }

                return result.OrderBy(i => i.MatterId).ToList();
            }
        }

        public static List<MatterColumnChange> GetMatterColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.MatterColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<MatterNoticeTypeColumnChange> GetMatterNoticeTypeColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.MatterNoticeTypeColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<ContactColumnChange> GetContactColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.ContactColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<MatterToContactColumnChange> GetMatterToContactColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.MatterToContactColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<TrackingColumnChange> GetTrackingColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.TrackingColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<PrintingAndMailingColumnChange> GetPrintingAndMailingColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.PrintingAndMailingColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<IVRColumnChange> GetIvrColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.IVRColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<CallCenterColumnChange> GetCallCenterColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.CallCenterColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<SubmittedMatterLogColumnChange> GetSubmittedMatterLogColumnChange(int id)
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.SubmittedMatterLogColumnChanges.AsNoTracking()
                    where c.Id == id
                    select c;

                return query.ToList();
            }
        }

        public static List<FileValidation> GetFileValidation()
        {
            using (var context = new Database.BreachPortal())
            {
                var query =
                    from c in context.FileValidations
                    select c;

                return query.ToList();
            }
        }

        public static void PopulateMatterToContact(int matterId, int minRecords)
        {
            using (var context = new Database.BreachPortal())
            {
                while (GetMatterToContact(matterId).Count < minRecords)
                {
                    var addContact = GetContact().OrderBy(x => Guid.NewGuid())
                        .First(m => GetMatterToContact(matterId).All(c => c.ContactId != m.ContactId));

                    System.Threading.Thread.Sleep(1);
                    var update = new MatterToContact
                    {
                        ContactId = addContact.ContactId,
                        MatterId = matterId,
                        ContactTypeName = addContact.ContactType?.Name,
                        FirstName = addContact.FirstName,
                        LastName = addContact.LastName,
                        Phone = addContact.Phone,
                        Email = addContact.Email,
                        Primary = addContact.Primary,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "autoscript",
                    };
                    context.MatterToContacts.Add(update);
                    context.SaveChanges();
                    Automation.report.Action("Contact Added: ", update.FirstName + " " + update.LastName + " to MatterId " + matterId);
                }
            }
        }

        public static void PopulateContact(int minRecords = 11)
        {
            using (var context = new Database.BreachPortal())
            {
                while (GetContact().Count < minRecords)
                {
                    System.Threading.Thread.Sleep(1);
                    var append = DateTime.Now.ToString("ssfff");
                    var update = new Contact
                    {
                        ContactTypeId = new Random().Next(1, 5),
                        FirstName = "Generated" + append,
                        LastName = "Contact" + append,
                        Phone = "+1 555 666 7" + append,
                        Email = "email" + append + "@mail.com",
                        Title = "Title" + append,
                        Primary = Test.RandomBoolean(),
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "autoscript",
                    };
                    context.Contacts.Add(update);
                    context.SaveChanges();
                    Automation.report.Action("Contact Added: ",
                        update.FirstName + " " + update.LastName);
                }
            }
        }

        public static void PopulateFileValidation(int matterId, int records)
        {
            using (var context = new Database.BreachPortal())
            {
                while (GetFileValidation().Count(x => x.MatterId == matterId) < records)
                {
                    System.Threading.Thread.Sleep(1);
                    var append = DateTime.Now.ToString("fff");
                    var update = new FileValidation
                    {
                        MatterId = matterId,
                        CreatedBy = Config.Username,
                        CreatedDate = DateTime.Now,
                        FileName = "Fakefile" + append + ".xlsx",
                        IsValid = true,
                        RecordCount =  9,
                        ErrorCount =  0,
                        FileSize = 12160
                    };
                    context.FileValidations.Add(update);
                    context.SaveChanges();
                    Automation.report.Action("File Added: ",
                        update.FileName);
                }
            }
        }

        public static void PopulateCalendar()
        {
            //Ensures current month has at least one of each type of date visible
            using (var context = new Database.BreachPortal())
            {
                var dates = GetMatter();
                if (!dates.Any(m =>
                    m.ProjectedMailDate?.Date.Month == DateTime.Now.Date.Month &&
                    m.ProjectedMailDate?.Date.Year == DateTime.Now.Date.Year))
                {
                    var date = context.Matters.Single(i => i.MatterId == 2);
                    date.ProjectedMailDate = DateTime.Now.Date;
                    date.UpdatedBy = Config.Username;
                    context.Entry(date).Property(x => x.UpdatedBy).IsModified = true; //Force update of username due to triggers
                    context.SaveChanges();
                }
                if (!dates.Any(m =>
                    m.CallCenterLiveDate?.Date.Month == DateTime.Now.Date.Month &&
                    m.CallCenterLiveDate?.Date.Year == DateTime.Now.Date.Year))
                {
                    var date = context.Matters.Single(i => i.MatterId == 3);
                    date.CallCenterLiveDate = DateTime.Now.Date;
                    date.UpdatedBy = Config.Username;
                    context.Entry(date).Property(x => x.UpdatedBy).IsModified = true; //Force update of username due to triggers
                    context.SaveChanges();
                }

                if (dates.Any(m =>
                    m.ProjectedMailDate?.Date.Month == DateTime.Now.Date.Month &&
                    m.ProjectedMailDate?.Date.Year == DateTime.Now.Date.Year &&
                    m.ProjectedMailDate?.Date == m.CallCenterLiveDate?.Date
                )) return;
                {
                    var date = context.Matters.Single(i => i.MatterId == 4);
                    date.ProjectedMailDate = DateTime.Now.Date;
                    date.CallCenterLiveDate = DateTime.Now.Date;
                    date.UpdatedBy = Config.Username;
                    context.Entry(date).Property(x => x.UpdatedBy).IsModified = true; //Force update of username due to triggers
                    context.SaveChanges();
                }
            }
        }


        public static void CleanUpContacts(string email)
        {
            using (var context = new Database.BreachPortal())
            {
                context.Database.ExecuteSqlCommand(@"Update Contact Set IsSetForDelete = 1, UpdatedBy = 'CleanupScript' WHERE Email = '" + email + "'");
            }
        }   
 
        //Troubleshooting for DBValidationErrors
        public static void SaveChanges(Database.BreachPortal context)
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                    .SelectMany(x => x.ValidationErrors)
                    .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
        }

    }
}