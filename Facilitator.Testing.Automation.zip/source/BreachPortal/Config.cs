﻿using System;
using System.Configuration;
using System.IO;

namespace BreachPortal
{
    public class Config
    {
        public static string Browser = "Chrome";
        public static string Url = ConfigurationManager.AppSettings.Get("url");
        public static string Username = ConfigurationManager.AppSettings.Get("username");
        public static string Password = ConfigurationManager.AppSettings.Get("password");
        public static int MatterId = 1;
        public static string FilePath = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + "\\TestFiles\\");
        private static readonly string PathUser = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        public static string DownloadPath = Path.Combine(PathUser, "Downloads");
        public static string MatterDetailPath = Url + "/matterdetail?mode=edit&mid=";
    }
}