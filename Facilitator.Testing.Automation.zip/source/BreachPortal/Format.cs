﻿using System;
using Automation;

namespace BreachPortal
{
    public class Format
    {
        public static string Timestamp(DateTime? value)
        {
            return value?.ToString("MMddyyyyhhmmssfff");
        }

        public static string Date(DateTime? value, string format = "MM/dd/yyyy")
        {
            return value?.ToString(format) ?? "";
        }

        public static string DateTime(DateTime? value, string format = "MM/dd/yyyy hh:mm")
        {
            return value?.ToString(format);
        }

        public static string PostalCode(string postalCode, string format = "United States")
        {
            if (postalCode == null) return "";
            switch (format)
            {
                case "United States":
                    return (postalCode.Length == 9) ? $"{int.Parse(postalCode):#####-####}" : postalCode;
                case "Canada":
                    return (postalCode.Length == 6) ? postalCode.Substring(0, 3) + " " + postalCode.Substring(3): postalCode;
                default:
                    return postalCode;
            }
        }

        public static string YesNoString(bool? value)
        {
            switch (value)
            {
                case true: return "Yes";
                case false: return "No";
                default: return "";
            }
                
        }
    }
}
