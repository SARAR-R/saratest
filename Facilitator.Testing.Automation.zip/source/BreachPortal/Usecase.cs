﻿using System;
using System.Collections.Generic;
using System.IO;
using Automation;
using Facilitator.Template;
using OpenQA.Selenium;
using System.Linq;
using BreachPortal.Matter;
using OpenQA.Selenium.Chrome;
using navigate = Automation.navigate;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exception = System.Exception;

namespace BreachPortal
{
    public static class Usecase
    {
        public static void Testing()
        {
            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine(new[] {"Active", "Closed"}[new Random().Next(0, 2)]);
                System.Threading.Thread.Sleep(1000);
            }
            //TestHelper.Start(1);

            //TestHelper.End();
        }
      
        public static void Logon()
        {
            try
            {
                report.Step("Verify page loads without error");
                navigate.URL(Config.Url);
                test.VerifyNoErrorToasts(test.driver);

                //Logon and verify - Unauthorized user
                report.Step("Verify Unauthorized login");
                if (user.Login(test.driver, Config.Username, "BadPassword").Contains("Login was unsuccessful."))
                {
                    report.Pass("Login was unsuccessful for unauthorized user.");
                }
                else
                {
                    report.Fail("Unauthorized user successfully logged in.");
                    
                }

                //Logon and verify - Authorized user
                report.Step("Verify Authorized login");
                if (user.Login(test.driver) == "Success")
                {
                    report.Pass("Login was successful for authorized user.");
                }
                else
                {
                    report.Fail("Authorized user failed to log in.");
                    
                }
                test.VerifyNoErrorToasts(test.driver);

                TestHelper.End();
            }
            catch (Exception e)
            {
                report.Fail("Error occurred with Logon test.", e);
            }
        }

        public static void Logout()
        {
            try
            {
                //Logon - Valid
                if (user.Login(test.driver) == "Success")
                {
                    report.Pass("Login was successful for authorized user.");
                }
                else
                {
                    report.Fail("Authorized user failed to log in.");
                    
                }
                test.VerifyNoErrorToasts(test.driver);

                //Log out
                report.Step("Verify logout without errors, and identity token removed");
                TestHelper.End();
                test.VerifyNoErrorToasts(test.driver);
                test.VerifyCookie("identityData", false);

                //Navigate to a restricted page
                report.Step("Verify redirect to login page, unauthenticated access");
                navigate.URL(Config.Url + "/quicksearch");
                //Verify redirect to login
                test.VerifyURL(test.driver, Config.Url + "/login");

            }
            catch (Exception e)
            {
                report.Fail("Error occurred with Logout test.", e);
            }
        }

        public static void QuickSearch()
        {
            var record = Data.GetMatter().OrderBy(x => Guid.NewGuid()).First(c => c.CompanyName != null);

            TestHelper.Start();
            test.VerifyElementExists(Search._QuickCriteria, true);
            test.Click(Navigate._CreateNewMatter);
            test.VerifyNoErrorToasts();
            test.Click(Navigate._Search);
            test.VerifyElementExists(Search._QuickCriteria, true);
            Search.ValidateQuickSearch(record.MatterName);
            Search.ValidateQuickSearch(record.CompanyName);
            Search.ValidateQuickSearch(record.InsuranceCompany?.Name);
            TestHelper.End();

        }

        public static void BasicInformation(int matterId)
        {
            var originalRecord = Data.GetMatter(matterId);
            var noticeTypes = Data.GetMatterNoticeType(matterId);
            TestHelper.Start(matterId);
            BasicInfo.ValidateRecord(originalRecord, noticeTypes);
            BasicInfo.VerifyLastUpdated(originalRecord.UpdatedBy, Format.DateTime(originalRecord.UpdatedDate));
            var updateRecord = BasicInfo.GenerateRecord(matterId);
            var updateNotices = BasicInfo.GenerateNoticeTypes();
            BasicInfo.UpdateRecord(updateRecord, updateNotices);
            BasicInfo.Save();
            navigate.Refresh();
            BasicInfo.ValidateRecord(updateRecord, updateNotices);
            report.Step("Validate Custom Law Firm");
            updateRecord.LawFirm = random.GenerateString(20);
            Test.EditCombo(BasicInfo.LawFirm, updateRecord.LawFirm);
            BasicInfo.Save();
            navigate.Refresh();
            test.VerifyFieldValue(By.XPath(BasicInfo.LawFirm), updateRecord.LawFirm);
            Test.VerifyComboContains(BasicInfo.LawFirm, updateRecord.LawFirm);
            BasicInfo.ValidateDuplicateName(updateRecord, updateNotices);
            TestHelper.End();
        }

        public static void Contacts(int matterId)
        {
            Data.PopulateMatterToContact(matterId, 11);
            var records = Data.GetMatterToContact(matterId);
            TestHelper.Start(matterId);
            report.Step("Validate existing records.");
            Matter.Contacts.ValidateRecords(records);
            Grid.ValidateColumnSorting(Matter.Contacts.Columns);
            report.Step("Verify add modal");
            var unassociatedContacts = Data.GetContact().Where(m => Data.GetMatterToContact(matterId)
                .All(c => c.ContactId != m.ContactId)).ToList();
            test.Click(Matter.Contacts._AddContact);
            Matter.Contacts.ValidateAddModalRecords(unassociatedContacts);
            test.Click(Matter.Contacts._MaintainContacts);
            test.VerifyURL("/maintaincontacts");
            navigate.URL(Navigate.MatterDetailPath + matterId);
            report.Step("Associate Existing Contact");
            var addRecord = Matter.Contacts.ToMatterToContact(unassociatedContacts.First(), matterId);
            test.Click(Matter.Contacts._AddContact);
            test.EditField(Matter.Contacts._TextFilter, addRecord.Email);
            test.Click(By.XPath(Matter.Contacts.Select));
            test.Click(Matter.Contacts._ModalSave);
            test.VerifyNoErrorToasts();
            records.Insert(0, addRecord);
            navigate.Refresh();
            Matter.Contacts.ValidateRecords(records);
            report.Step("Update Contact Record");
            var updateRecord = Matter.Contacts.GenerateRecord();
            test.Click(By.XPath("//div[text()='" + addRecord.LastName + "']/ancestor::div[@ui-grid-row]" + Grid.Edit));
            Matter.Contacts.ValidateRecord(addRecord);
            Matter.Contacts.UpdateRecord(updateRecord);
            test.Click(Matter.Contacts._ModalSave);
            test.VerifyNoErrorToasts();
            records.Remove(addRecord);
            records.Insert(0, updateRecord);
            navigate.Refresh();
            Matter.Contacts.ValidateRecords(records);
            report.Step("Delete Contact Record");
            test.Click(By.XPath("//div[text()='" + updateRecord.LastName + "']/ancestor::div[@ui-grid-row]" + Grid.Delete));
            Matter.Contacts.ValidateRecord(updateRecord);
            test.Click(Matter.Contacts._ModalCancel);
            Matter.Contacts.ValidateRecords(records);
            test.Click(By.XPath(Matter.Contacts.Delete));
            test.Click(Matter.Contacts._ModalDelete);
            test.VerifyNoErrorToasts();
            records.Remove(updateRecord);
            navigate.Refresh();
            Matter.Contacts.ValidateRecords(records);
            TestHelper.End();
        }

        public static void Tracking(int matterId)
        {
            var originalRecord = Data.GetTracking(matterId);
            TestHelper.Start(matterId);
            if (originalRecord != null) Matter.Tracking.ValidateRecord(originalRecord);
            var updateRecord = Matter.Tracking.GenerateRecord(matterId);
            Matter.Tracking.UpdateRecord(updateRecord);
            BasicInfo.Save();
            navigate.Refresh();
            Matter.Tracking.ValidateRecord(updateRecord);
            TestHelper.End();
        }

        public static void PrintingAndMailing(int matterId)
        {      
            var originalRecord = Data.GetPrintingAndMailing(matterId);
            TestHelper.Start(matterId);
            Matter.PrintingAndMailing.ValidateRecord(originalRecord);
            var updateRecord = Matter.PrintingAndMailing.GenerateRecord(matterId);
            Matter.PrintingAndMailing.UpdateRecord(updateRecord);
            BasicInfo.Save();
            navigate.Refresh();
            Matter.PrintingAndMailing.ValidateRecord(updateRecord);
            report.Step("Disable and cancel record deletion");
            Test.SetSection(Matter.PrintingAndMailing.Section, false, false);
            Matter.PrintingAndMailing.ValidateRecord(updateRecord);  //Record unchanged
            report.Step("Disable and confirm record deletion");
            Test.SetSection(Matter.PrintingAndMailing.Section, false, true);
            BasicInfo.Save();
            test.VerifyTrue(Data.GetMatter(matterId).HasPrintingAndMailing, false, "Verifying HasPrintingAndMailing value is false.");
            test.VerifyTrue(Data.GetPrintingAndMailing(matterId) == null, true, "Verifying PrintingAndMailing record is removed.");
            TestHelper.End();
        }

        public static void Ivr(int matterId)
        {
            TestHelper.Start(matterId);
            var originalRecord = Data.GetIvr(matterId);
            Matter.Ivr.ValidateRecord(originalRecord);
            var updateRecord = Matter.Ivr.GenerateRecord(matterId);
            //Ensure there is at least one change to save.
            if (updateRecord.IsStandardScript == originalRecord?.IsStandardScript &&
                updateRecord.IsInboundFax == originalRecord.IsInboundFax &&
                updateRecord.IVRLanguage?.Name == originalRecord.IVRLanguage?.Name)
                updateRecord.IVRLanguage = Data.GetIvrLanguage()
                    .First(i => i.IVRLanguageId != updateRecord.IVRLanguage?.IVRLanguageId);

            Matter.Ivr.UpdateRecord(updateRecord);
            BasicInfo.Save();
            navigate.Refresh();
            Matter.Ivr.ValidateRecord(updateRecord);
            report.Step("Disable and cancel record deletion");
            Test.SetSection(Matter.Ivr.Section, false, false);
            Matter.Ivr.ValidateRecord(updateRecord);  //Record unchanged
            report.Step("Disable and confirm record deletion");
            Test.SetSection(Matter.Ivr.Section, false, true);
            BasicInfo.Save();
            test.VerifyTrue(Data.GetMatter(matterId).HasIVR, false, "Verifying HasIVR value is false.");
            test.VerifyTrue(Data.GetIvr(matterId) == null, true, "Verifying IVR record is removed.");
            TestHelper.End();
        }

        public static void CallCenter(int matterId)
        {
            var originalRecord = Data.GetCallCenter(matterId);
            TestHelper.Start(matterId);
            Matter.CallCenter.ValidateRecord(originalRecord);
            var updateRecord = Matter.CallCenter.GenerateRecord(matterId);
            Matter.CallCenter.UpdateRecord(updateRecord);
            BasicInfo.Save();
            navigate.Refresh();
            Matter.CallCenter.ValidateRecord(updateRecord);
            report.Step("Disable and cancel record deletion");
            Test.SetSection(Matter.CallCenter.Section, false, false);
            Matter.CallCenter.ValidateRecord(updateRecord);  //Record unchanged
            report.Step("Disable and confirm record deletion");
            Test.SetSection(Matter.CallCenter.Section, false, true);
            BasicInfo.Save();
            test.VerifyTrue(Data.GetMatter(matterId).HasCallCenter, false, "Verifying HasCallCenter value is false.");
            test.VerifyTrue(Data.GetCallCenter(matterId) == null, true, "Verifying CallCenter record is removed.");
            TestHelper.End();
        }

        public static void FileUpload(int matterId)
        {
            TestHelper.Start(matterId);
            Matter.FileUpload.ValidateFileSize();
            Matter.FileUpload.ValidateFileType();

            report.Step("Verify Successful xls");
            var successfulXls = new Database.FileValidation
            {
                MatterId = matterId,
                CreatedBy = Config.Username,
                FileName = "Successful.xls",
                IsValid = true,
                RecordCount = 9,
                ErrorCount = 0
            };
            Matter.FileUpload.ValidateFileUpload(successfulXls, "File passes validation!");

            report.Step("Verify Successful xlsx");
            var successfulXlsx = new Database.FileValidation
            {
                MatterId = matterId,
                CreatedBy = Config.Username,
                FileName = "Successful.xlsx",
                IsValid = true,
                RecordCount = 9,
                ErrorCount = 0
            };
            Matter.FileUpload.ValidateFileUpload(successfulXlsx, "File passes validation!");

            report.Step("Verify Successful csv");
            var successfulCsv = new Database.FileValidation
            {
                MatterId = matterId,
                CreatedBy = Config.Username,
                FileName = "Successful.csv",
                IsValid = true,
                RecordCount = 9,
                ErrorCount = 0
            };
            Matter.FileUpload.ValidateFileUpload(successfulCsv, "File passes validation!");
          
            report.Step("Validate Missing Columns.");
            var missingColumnValidation = new Database.FileValidation
            {
                MatterId = matterId,
                CreatedBy = Config.Username,
                FileName = "MissingColumnHeader.xlsx",
                IsValid = false,
                RecordCount = 0,
                ErrorCount = 0
            };
            Matter.FileUpload.ValidateFileUpload(missingColumnValidation, "1) Column Header UniqueID not found");

            report.Step("Validate Duplicate Columns.");
            var dupeColumnValidation = new Database.FileValidation
            {
                MatterId = matterId,
                CreatedBy = Config.Username,
                FileName = "DupeColumnHeaders.xls",
                IsValid = false,
                RecordCount = 0,
                ErrorCount = 0
            };
            Matter.FileUpload.ValidateFileUpload(dupeColumnValidation, "1) Header Last_Name is duplicated");

            report.Step("Validate Multiple Tabs.");
            var multiTabValidation = new Database.FileValidation
            {
                MatterId = matterId,
                CreatedBy = Config.Username,
                FileName = "MultiTabs.xls",
                IsValid = false,
                RecordCount = 0,
                ErrorCount = 0
            };
            Matter.FileUpload.ValidateFileUpload(multiTabValidation, "1) Expected tab count (1) doesn't match (2)");

            report.Step("Validate Other Failures");
            var allFailuresValidation = new Database.FileValidation
            {
                MatterId = matterId,
                CreatedBy = Config.Username,
                FileName = "AllFailures.xlsx",
                IsValid = false,
                RecordCount = 8,
                ErrorCount = 8
            };
            var allFailuresFailures = new List<string>
            {
                "1) Row 2, column ZipCode has an invalid zip code format",
                "2) Row 2, column Enrollment_Deadline must be a date",
                "3) Row 2, column Email_Address has an invalid email format",
                "4) Row 2, column Date_of_Birth must be a date",
                "5) Row 2, column Deceased value maybe is not allowed",
                "6) Row 3, column ZipCode has an invalid zip code format",
                "7) Row 3, column Enrollment_Deadline must be a date",
                "8) Row 3, column Date_of_Birth must be a date",
                "9) Row 3, column Deceased value text is not allowed",
                "10) Row 4, column First_Name must be 25 characters or less",
                "11) Row 4, column Middle_Name must be 15 characters or less",
                "12) Row 4, column Last_Name must be 30 characters or less",
                "13) Row 4, column Business_Name must be 60 characters or less",
                "14) Row 4, column Address_1 must be 70 characters or less",
                "15) Row 4, column Address_2 must be 70 characters or less",
                "16) Row 4, column Address_3 must be 70 characters or less",
                "17) Row 4, column Address_4 must be 70 characters or less",
                "18) Row 4, column Address_5 must be 70 characters or less",
                "19) Row 4, column City must be 35 characters or less",
                "20) Row 4, column State must be 2 characters or less",
                "21) Row 4, column ZipCode must be 10 characters or less",
                "22) Row 4, column Country must be 50 characters or less",
                "23) Row 4, column Enrollment_Code must be 15 characters or less",
                "24) Row 4, column Engagement_Number must be 15 characters or less",
                "25) Row 4, column Day_Phone_Number must be 25 characters or less",
                "26) Row 4, column Email_Address must be 70 characters or less",
                "27) Row 4, column Notice_Type must be 20 characters or less",
                "28) Row 4, column UniqueID must be 15 characters or less",
                "29) Row 5, column Day_Phone_Number must be 25 characters or less",
                "30) Row 6, column ZipCode has an invalid zip code format",
                "31) Row 7, column ZipCode has an invalid zip code format",
                "32) Row 8, column ZipCode must be 10 characters or less",
                "33) Row 9, column First_Name cannot be blank",
                "34) Row 9, column Last_Name cannot be blank",
                "35) Row 9, column Address_1 cannot be blank",
                "36) Row 9, column City cannot be blank",
                "37) Row 9, column State cannot be blank",
                "38) Row 9, column ZipCode cannot be blank"
            };
            Matter.FileUpload.ValidateFileUpload(allFailuresValidation, allFailuresFailures);

            TestHelper.End();
        }

        public static void SubmitMatter(int matterId)
        {
            TestHelper.Start(matterId);
            var matter = Data.GetMatter(matterId);
            var currentSubmissions = Data.GetSubmittedMatterLog(matterId);
            var insurance = Data.GetInsuranceCompany().OrderBy(x => Guid.NewGuid()).First(n => n.Name != "Other").Name;
            //Ensure all submission required fields are populated.
            if (matter.CompanyName == null) test.EditField(By.XPath(BasicInfo.CompanyName), "Submission Company");
            if (matter.InsuranceCompanyId == null) test.SelectField(By.XPath(BasicInfo.InsuranceCompany), insurance);
            if (matter.AffectedPopulationSize == null) test.EditField(By.XPath(BasicInfo.AffectedPopulationSize), new Random().Next(100, 1000000).ToString());
            test.VerifyElementEnabled(BasicInfo._Submit, true);
            test.ClearField(By.XPath(BasicInfo.MatterName));
            test.VerifyElementEnabled(BasicInfo._Submit, false);
            test.EditField(By.XPath(BasicInfo.MatterName), matter.MatterName);
            test.VerifyElementEnabled(BasicInfo._Submit, true);
            test.ClearField(By.XPath(BasicInfo.CompanyName));
            test.VerifyElementEnabled(BasicInfo._Submit, false);
            test.EditField(By.XPath(BasicInfo.CompanyName), matter.CompanyName);
            test.VerifyElementEnabled(BasicInfo._Submit, true);
            test.ClearField(By.XPath(BasicInfo.AffectedPopulationSize));
            test.VerifyElementEnabled(BasicInfo._Submit, false);
            test.EditField(By.XPath(BasicInfo.AffectedPopulationSize), matter.AffectedPopulationSize.ToString());
            test.VerifyElementEnabled(BasicInfo._Submit, true);
            test.SelectField(By.XPath(BasicInfo.InsuranceCompany), "");
            test.VerifyElementEnabled(BasicInfo._Submit, false);
            test.SelectField(By.XPath(BasicInfo.InsuranceCompany), insurance);
            test.VerifyElementEnabled(BasicInfo._Submit, true);
            test.SelectField(By.XPath(BasicInfo.InsuranceCompany), "Other");
            test.VerifyElementEnabled(BasicInfo._Submit, false);
            test.EditField(By.XPath(BasicInfo.Other), "Submission Other");
            test.VerifyElementEnabled(BasicInfo._Submit, true);

            test.Click(BasicInfo._Submit);
            test.VerifyNoErrorToasts();
            Test.VerifyToast("Matter submitted successfully.");
            //Find the newly generated record.
            var submission = currentSubmissions.Count > 0 ?
                Data.GetSubmittedMatterLog(matterId).FirstOrDefault(d => d.InsertedDate > currentSubmissions.Last().InsertedDate) :
                    Data.GetSubmittedMatterLog(matterId).FirstOrDefault();
            if (submission != null && submission.CreatedBy == Config.Username)
            {
                report.Pass("Submission has been successfully logged.");
            }
            else
            {
                if (submission == null) report.Fail("Submission was not successfully logged.");
                else
                {
                    report.Fail("Submission was logged but details are incorrect:");
                    Console.WriteLine("SubmittedMatterLogId = " + submission.SubmittedMatterLogId);
                }
                
            }
            TestHelper.End();
        }

        public static void DeleteMatter()
        {
            TestHelper.Start();
            report.Step("Create new record to delete");
            var basicInfo = BasicInfo.GenerateRecord();
            test.Click(Navigate._CreateNewMatter);
            BasicInfo.UpdateRecord(basicInfo, BasicInfo.GenerateNoticeTypes());
            Matter.Tracking.UpdateRecord(Matter.Tracking.GenerateRecord());
            Matter.PrintingAndMailing.UpdateRecord(Matter.PrintingAndMailing.GenerateRecord());
            Matter.Ivr.UpdateRecord(Matter.Ivr.GenerateRecord());
            Matter.CallCenter.UpdateRecord(Matter.CallCenter.GenerateRecord());
            BasicInfo.Save();         
            var matterId = Data.GetMatter().First(n => n.MatterName == basicInfo.MatterName).MatterId;
            //Add Contacts
            test.Click(Matter.Contacts._AddContact);
            test.Click(By.XPath(Matter.Contacts.Select));
            test.Click(By.XPath(Matter.Contacts.Select + "[last()]"));
            test.Click(Matter.Contacts._ModalSave);
            //Simulate uploaded files
            Data.PopulateFileValidation(matterId, 2);
            //Submit Record Twice
            test.Click(BasicInfo._Submit);
            test.Click(BasicInfo._Submit);
            report.Step("Delete and Cancel");
            test.ClickandCancel(BasicInfo._Delete);
            test.VerifyTrue(Data.GetMatter(matterId) == null, false, "Verifying Matter record is still present.");
            test.VerifyURL("/matterdetail");
            report.Step("Delete and Confirm");
            test.ClickandConfirm(BasicInfo._Delete);
            test.VerifyTrue(Data.GetMatter(matterId) == null, true, "Verifying Matter record is removed.");
            test.VerifyURL("/quicksearch");
            navigate.URL(Config.MatterDetailPath + matterId);
            test.VerifyText(By.XPath("//span[@class='text-danger']"), "The matter you are trying to view has been deleted or hasn’t been created yet. Please return to search and find the desired matter.");
            TestHelper.End();
        }

        public static void CreateNewMatter()
        {
            TestHelper.Start();
            test.Click(Navigate._CreateNewMatter);
            var basicInfo = BasicInfo.GenerateRecord();
            var noticeTypes = BasicInfo.GenerateNoticeTypes();
            basicInfo.HasPrintingAndMailing = true;
            basicInfo.HasIVR = true;
            basicInfo.HasCallCenter = true;
            var tracking = Matter.Tracking.GenerateRecord();
            var contacts = new List<Database.MatterToContact>();
            var printingAndMailing = Matter.PrintingAndMailing.GenerateRecord();
            var ivr = Matter.Ivr.GenerateRecord();
            var callCenter = Matter.CallCenter.GenerateRecord();
            report.Step("Update new matter information.");
            BasicInfo.UpdateRecord(basicInfo, noticeTypes);
            Matter.Tracking.UpdateRecord(tracking);
            test.VerifyElementDoesNotExist(Matter.Contacts._Grid);  //Ensure grid is hidden.
            test.VerifyElementExists(Matter.Contacts._GridHiddenMessage); //Ensure message is displayed
            Matter.PrintingAndMailing.UpdateRecord(printingAndMailing);
            Matter.Ivr.UpdateRecord(ivr);
            Matter.CallCenter.UpdateRecord(callCenter);
            test.VerifyClassExists(By.XPath(Matter.FileUpload.Directive), "ng-hide");  //Ensure uploader is hidden.
            test.VerifyClassExists(Matter.FileUpload._SectionHiddenMessage, "ng-hide", false); //Ensure message is displayed
            test.Click(BasicInfo._Save);
            test.VerifyNoErrorToasts();
            report.Step("Search for newly added matter.");
            test.EditField(Search._HeaderCriteria, basicInfo.MatterName);
            test.Click(Search._HeaderSubmit);
            report.Step("Verify new matter information.");
            BasicInfo.ValidateRecord(basicInfo, noticeTypes);
            Matter.Contacts.ValidateRecords(contacts);
            Matter.Tracking.ValidateRecord(tracking);
            Matter.PrintingAndMailing.ValidateRecord(printingAndMailing);
            Matter.Ivr.ValidateRecord(ivr);
            Matter.CallCenter.ValidateRecord(callCenter);
            test.VerifyClassExists(By.XPath(Matter.FileUpload.Directive), "ng-hide", false);  //Ensure uploader is displayed.
            test.VerifyClassExists(Matter.FileUpload._SectionHiddenMessage, "ng-hide"); //Ensure message is hidden
            TestHelper.End();
        }

        public static void ReportView()
        {
            const string fileName = "FullExport.xlsx";
            var path = Path.Combine(Config.DownloadPath, fileName);
            if (File.Exists(path))
            {
                report.Step("Deleting Existing file.");
                File.Delete(path);
            }
            TestHelper.Start();
            test.Click(Navigate._Reports);
            download.DownloadFile(By.LinkText("Full Export"));
            download.VerifyDownloadedFile(fileName);
            TestHelper.End();
        }

        public static void CalendarView()
        {
            Data.PopulateCalendar();
            TestHelper.Start();
            test.Click(Navigate._Calendar);
            Calendar.ValidateMonthlyView(DateTime.Now);
            report.Step("Verify Navigation");
            test.Click(Calendar._Next);
            Calendar.ValidateMonthlyView(DateTime.Now.AddMonths(1), 5);
            test.Click(Calendar._Today);
            Calendar.ValidateMonthlyView(DateTime.Now, 5);
            test.Click(Calendar._Previous);
            Calendar.ValidateMonthlyView(DateTime.Now.AddMonths(-1), 5);
            report.Step("Verify Views");
            test.Click(Calendar._Today);
            test.Click(Calendar._ByWeek);
            Calendar.ValidateWeeklyView(DateTime.Now);
            test.Click(Calendar._ByDay);
            Calendar.ValidateDailyView(DateTime.Now); 
            test.Click(Calendar._ByMonth);
            report.Step("Validate Links");
            var callCenter = Data.GetMatter().First(d => d.CallCenterLiveDate?.Month == DateTime.Now.Month &&
                                                         d.CallCenterLiveDate?.Year == DateTime.Now.Year &&
                                                         d.ProjectedMailDate?.Date != d.CallCenterLiveDate?.Date);
            test.Click(Calendar.GenerateRecordXpath(callCenter, "Call Center"));
            test.VerifyURL("matterdetail?mode=edit&mid=" + callCenter.MatterId);
            test.Click(Navigate._Calendar);
            var projectedMailDate = Data.GetMatter().First(d => d.ProjectedMailDate?.Month == DateTime.Now.Month &&
                                                                d.ProjectedMailDate?.Year == DateTime.Now.Year &&
                                                                d.ProjectedMailDate?.Date != d.CallCenterLiveDate?.Date);
            test.Click(Calendar.GenerateRecordXpath(projectedMailDate, "Mailing"));
            test.VerifyURL("matterdetail?mode=edit&mid=" + projectedMailDate.MatterId);
            test.Click(Navigate._Calendar);
            var both = Data.GetMatter().First(d => d.ProjectedMailDate?.Month == DateTime.Now.Month && 
                                                   d.ProjectedMailDate?.Year == DateTime.Now.Year &&
                                                   d.ProjectedMailDate?.Date == d.CallCenterLiveDate?.Date);
            test.Click(Calendar.GenerateRecordXpath(both, "Both"));
            test.VerifyURL("matterdetail?mode=edit&mid=" + both.MatterId);
            test.Click(Navigate._Calendar);
            TestHelper.End();
        }

        public static void MaintainContacts()
        {
            Data.PopulateContact();
            var records = Data.GetContact();
            if (records.Any(x => x.LastName.StartsWith("aaa"))) throw new Exception("There's already a record from a previous run starting with aaa.  Please remove and rerun.");
            TestHelper.Start();
            test.Click(Navigate._MaintainContacts);
            MaintainContact.ValidateRecords(records);
            report.Step("Validate Filter");
            var filterRecord = random.Record(records.Where(e => !string.IsNullOrEmpty(e.Email)));
            test.EditField(MaintainContact._TextFilter, filterRecord.Email);
            MaintainContact.ValidateRecords(MaintainContact.GetFilteredContacts(filterRecord.Email));
            var filterRecord2 = random.Record(records.Where(l => !string.IsNullOrEmpty(l.LastName)));
            test.EditField(MaintainContact._TextFilter, filterRecord2.LastName);
            MaintainContact.ValidateRecords(MaintainContact.GetFilteredContacts(filterRecord2.LastName));
            var filterRecord3 = random.Record(records.Where(f => !string.IsNullOrEmpty(f.FirstName)));
            test.EditField(MaintainContact._TextFilter, filterRecord3.FirstName);
            MaintainContact.ValidateRecords(MaintainContact.GetFilteredContacts(filterRecord3.FirstName));
            test.ClearField(MaintainContact._TextFilter);
            report.Step("Validate Sorting & Paging");
            Grid.ValidateColumnSorting(MaintainContact.Columns);
            Grid.ValidatePaging("//*", "10");
            report.Step("Add New Record");
            var addRecord = MaintainContact.GenerateRecord();
            test.Click(MaintainContact._Add);
            MaintainContact.UpdateRecord(addRecord);
            test.Click(MaintainContact._ModalSave);
            test.VerifyNoErrorToasts();
            records.Add(addRecord);
            navigate.Refresh();
            MaintainContact.ValidateRecords(records);
            report.Step("Update New Record");
            var updateRecord = MaintainContact.GenerateRecord();
            test.Click(By.XPath(MaintainContact.Edit));
            MaintainContact.ValidateRecord(addRecord);
            MaintainContact.UpdateRecord(updateRecord);
            test.Click(MaintainContact._ModalSave);
            test.VerifyNoErrorToasts();
            records.Remove(addRecord);
            records.Add(updateRecord);
            navigate.Refresh();
            MaintainContact.ValidateRecords(records);
            report.Step("Delete New Record");
            test.Click(By.XPath(MaintainContact.Delete));
            MaintainContact.ValidateRecord(updateRecord);
            test.Click(MaintainContact._ModalCancel);
            MaintainContact.ValidateRecords(records);
            test.Click(By.XPath(MaintainContact.Delete));
            test.Click(MaintainContact._ModalDelete);
            test.VerifyNoErrorToasts();
            records.Remove(updateRecord);
            navigate.Refresh();
            MaintainContact.ValidateRecords(records);
            TestHelper.End();
        }

        public static void User(string username, string password)
        {
            testHelper.Start(test.driver, username, password);
            Permissions.ValidateMenuItems(false, true);
            Permissions.ValidateSearch(Config.MatterId);
            if (!test.driver.Url.Contains("/matterdetail")) navigate.URL(Config.Url + "/matterdetail?mode=edit&mid=" + Config.MatterId);
            Permissions.ValidateMenuItems(true, true);
            Permissions.ValidateMatterDetail(Config.MatterId, true);
            test.Click(Navigate._CreateNewMatter);
            Permissions.ValidateCreateNew(true);
            test.Click(Navigate._Reports);
            Permissions.ValidateReports();
            test.Click(Navigate._MaintainContacts);
            Permissions.ValidateMaintainContacts(true);
            test.Click(Navigate._Calendar);
            Permissions.ValidateCalendar();
            TestHelper.End();
        }

        public static void ReadOnly(string username, string password)
        {
            testHelper.Start(test.driver, username, password);
            Permissions.ValidateMenuItems(false, false);
            Permissions.ValidateSearch(Config.MatterId);
            if (!test.driver.Url.Contains("/matterdetail")) navigate.URL(Config.Url + "/matterdetail?mode=edit&mid=" + Config.MatterId);
            Permissions.ValidateMenuItems(true, false);
            Permissions.ValidateMatterDetail(Config.MatterId, false);
            navigate.URL(Config.Url + "/matterdetailcreate?mode=add");
            Permissions.ValidateCreateNew(false);
            test.Click(Navigate._Reports);
            Permissions.ValidateReports();
            navigate.URL(Config.Url + "/maintaincontacts");
            Permissions.ValidateMaintainContacts(false);
            test.Click(Navigate._Calendar);
            Permissions.ValidateCalendar();
            TestHelper.End();
        }

        public static void Concurrency(int matterId)
        {
            var driver2 = new ChromeDriver();

            TestHelper.Start(matterId);
            user.Login(driver2, "automation", Config.Password, Config.Url);
            driver2.Navigate().GoToUrl(Config.Url + "/matterdetail?mode=edit&mid=" + matterId);
            test.WaitForPageToLoad(driver2);
            test.EditField(By.XPath(BasicInfo.MatterName), BasicInfo.GenerateRecord(matterId).MatterName ?? "");
            test.EditField(driver2, By.XPath(BasicInfo.MatterName), BasicInfo.GenerateRecord(matterId).MatterName ?? "");
            test.Click(BasicInfo._Save);
            test.VerifyNoErrorToasts();
            test.Click(driver2, BasicInfo._Save);
            test.VerifyNoErrorToasts();
            test.VerifyText(driver2, BasicInfo._ErrorMessage, "Concurrency error! The record you are attempting to update has been updated by another user. Please refresh your browser and try again.");
            test.Click(driver2, By.XPath("//span[@ng-bind='vm.username()']"));            
            test.Click(driver2, By.LinkText("Logout"));
            driver2.Quit();
            TestHelper.End();
        }

        public static void BasicInfoFieldValidation(int matterId)
        {
            TestHelper.Start(matterId);
            if (test.driver.FindElement(By.XPath(BasicInfo.InsuranceCompany)).GetAttribute("value") != "Other")
            {
                test.SelectField(By.XPath(BasicInfo.InsuranceCompany), "Other");
                test.EditField(By.XPath(BasicInfo.Other), "Other Text");
            }
                
            Test.ValidateFields(BasicInfo.FieldValidation());
            TestHelper.End();
        }

        public static void ContactsFieldValidation(int matterId)
        {
            Data.PopulateMatterToContact(matterId, 1);
            TestHelper.Start(matterId);
            var currentRecord = Data.GetMatterToContact().First();
            report.Step("Verify validation on Edit Modal");
            test.Click(By.XPath(Matter.Contacts.Edit));
            Test.ValidateFields(Matter.Contacts.FieldValidation(), true);
            report.Step("Revert to original values");
            test.Click(By.XPath(Matter.Contacts.Edit));
            Matter.Contacts.UpdateRecord(currentRecord);
            test.Click(Matter.Contacts._ModalSave);
            TestHelper.End();
        }

        public static void TrackingFieldValidation(int matterId)
        {
            TestHelper.Start(matterId);
            Test.ValidateFields(Matter.Tracking.FieldValidation());
            TestHelper.End();
        }

        public static void PrintingAndMailingFieldValidation(int matterId)
        {
            TestHelper.Start(matterId);
            Test.SetSection(Matter.PrintingAndMailing.Section, true);
            Test.ValidateFields(Matter.PrintingAndMailing.FieldValidation());
            TestHelper.End();
        }

        public static void CallCenterFieldValidation(int matterId)
        {
            TestHelper.Start(matterId);
            Test.SetSection(Matter.CallCenter.Section, true);
            Test.ValidateFields(Matter.CallCenter.FieldValidation());
            TestHelper.End();
        }

        public static void MaintainContactsFieldValidation(int matterId)
        {
            
            if (Data.GetContact().Any(l => l.LastName.StartsWith("aaa")))
                throw new Exception(
                    "There already exists an automation record (LastName starts with aaa).  Please remove and re-run.");

            var contactFields = MaintainContact.FieldValidation();
            TestHelper.Start();
            test.Click(Navigate._MaintainContacts);
            report.Step("Verify validation on Add Modal");
            test.Click(MaintainContact._Add);
            //Need to populate the required fields so that save button is enabled before starting validation testing.
            MaintainContact.UpdateRecord
            (
                new Database.Contact
                {
                    LastName = "Validation",
                    Email = "validation@mail.com"
                }
            );  
            Test.ValidateFields(contactFields, true);
            report.Step("Verify validation on Edit Modal");
            test.Click(By.XPath(MaintainContact.Edit));
            Test.ValidateFields(contactFields, true);
            report.Step("Clean up record");
            test.Click(By.XPath(MaintainContact.Delete));
            test.Click(MaintainContact._ModalDelete);
            test.VerifyNoErrorToasts();
            TestHelper.End();

        }

        public static void History()
        {
            TestHelper.Start();
            report.Step("Add Matter");
            test.Click(Navigate._CreateNewMatter);
            var matter = BasicInfo.GenerateRecord();
            matter.HasPrintingAndMailing = true;
            matter.HasIVR = true;
            matter.HasCallCenter = true;
            BasicInfo.UpdateRecord(matter, BasicInfo.GenerateNoticeTypes(1));
            Matter.Tracking.UpdateRecord(Matter.Tracking.GenerateRecord());
            Matter.PrintingAndMailing.UpdateRecord(Matter.PrintingAndMailing.GenerateRecord());
            Matter.Ivr.UpdateRecord(Matter.Ivr.GenerateRecord());
            Matter.CallCenter.UpdateRecord(Matter.CallCenter.GenerateRecord());
            BasicInfo.Save();
            test.Click(Matter.Contacts._AddContact);
            test.Click(By.XPath(Matter.Contacts.Select));
            test.Click(Matter.Contacts._ModalSave);
            test.VerifyNoErrorToasts();
            var newMatter = Data.GetMatter().Last();
            var newNoticeType = Data.GetMatterNoticeType(newMatter.MatterId).Last();
            var newContact = Data.GetMatterToContact(newMatter.MatterId).First();
            BreachPortal.History.VerifyMatterColumnChange(newMatter, 1);
            BreachPortal.History.VerifyMatterNoticeTypeColumnChange(newNoticeType, 1);
            BreachPortal.History.VerifyMatterToContactColumnChange(newContact, 1);
            BreachPortal.History.VerifyTrackingColumnChange(newMatter, 1);
            BreachPortal.History.VerifyPrintingAndMailingColumnChange(newMatter, 1);
            BreachPortal.History.VerifyIvrColumnChange(newMatter, 1);
            BreachPortal.History.VerifyCallCenterColumnChange(newMatter, 1);
            
            report.Step("Submit Matter");
            test.Click(BasicInfo._Submit);
            test.VerifyNoErrorToasts();
            var submittedMatter = Data.GetSubmittedMatterLog(newMatter.MatterId).Last();
            BreachPortal.History.VerifySubmittedMatterLogColumnChange(submittedMatter, 1);
            //To be added when implemented - Story 254107
            //report.Step("File Upload (simulated)");
            //Data.PopulateFileValidation(newMatter.MatterId, 2);
            //var fileValidation = Data.GetFileValidation().Last(m => m.MatterId == newMatter.MatterId);
            //BreachPortal.History.VerifyFileValidationColumnChange(fileValidation, 1)

            report.Step("Update Matter");
            var matterUpdate = BasicInfo.GenerateRecord();
            matterUpdate.HasPrintingAndMailing = true;
            matterUpdate.HasIVR = true;
            matterUpdate.HasCallCenter = true;
            BasicInfo.UpdateRecord(matterUpdate, null);  //This will remove the notice type
            test.Click(By.XPath(Matter.Contacts.Edit));
            Matter.Contacts.UpdateRecord(Matter.Contacts.GenerateRecord());
            test.Click(Matter.Contacts._ModalSave);
            test.VerifyNoErrorToasts();
            Matter.Tracking.UpdateRecord(Matter.Tracking.GenerateRecord());
            Matter.PrintingAndMailing.UpdateRecord(Matter.PrintingAndMailing.GenerateRecord());
            Matter.Ivr.UpdateRecord(Matter.Ivr.GenerateRecord());
            Matter.CallCenter.UpdateRecord(Matter.CallCenter.GenerateRecord());
            BasicInfo.Save();
            BreachPortal.History.VerifyMatterColumnChange(newMatter, 2);
            BreachPortal.History.VerifyMatterToContactColumnChange(newContact, 2);
            BreachPortal.History.VerifyTrackingColumnChange(newMatter, 2);
            BreachPortal.History.VerifyPrintingAndMailingColumnChange(newMatter, 2);
            BreachPortal.History.VerifyIvrColumnChange(newMatter, 2);
            BreachPortal.History.VerifyCallCenterColumnChange(newMatter, 2);

            report.Step("Delete Matter");
            test.ClickandConfirm(BasicInfo._Delete);
            test.VerifyNoErrorToasts();
            BreachPortal.History.VerifyMatterColumnChange(newMatter, 3);
            BreachPortal.History.VerifyMatterNoticeTypeColumnChange(newNoticeType, 3);
            BreachPortal.History.VerifyMatterToContactColumnChange(newContact, 3);
            BreachPortal.History.VerifyPrintingAndMailingColumnChange(newMatter, 3);
            BreachPortal.History.VerifyIvrColumnChange(newMatter, 3);
            BreachPortal.History.VerifyCallCenterColumnChange(newMatter, 3);
            BreachPortal.History.VerifySubmittedMatterLogColumnChange(submittedMatter, 3);
            //To be added when implemented - Story 254107
            //BreachPortal.History.VerifyFileValidationColumnChange(fileValidation, 3)

            report.Step("Verify Maintain Contacts History");
            test.Click(Navigate._MaintainContacts);
            test.Click(MaintainContact._Add);
            MaintainContact.UpdateRecord(MaintainContact.GenerateRecord());            
            test.Click(MaintainContact._ModalSave);
            test.VerifyNoErrorToasts();
            var addedContact = Data.GetContact().OrderBy(d => d.InsertedDate).Last();
            BreachPortal.History.VerifyContactColumnChange(addedContact, 1);
            test.Click(By.XPath(MaintainContact.Edit));
            MaintainContact.UpdateRecord(MaintainContact.GenerateRecord());            
            test.Click(MaintainContact._ModalSave);
            test.VerifyNoErrorToasts();
            BreachPortal.History.VerifyContactColumnChange(addedContact, 2);
            test.Click(By.XPath(MaintainContact.Delete));
            test.Click(MaintainContact._ModalDelete);
            test.VerifyNoErrorToasts();
            BreachPortal.History.VerifyContactColumnChange(addedContact, 3);

            TestHelper.End();
        }

        public static void DefaultData()
        {
            TestHelper.Start();

            report.Step("Verify Defaults on Create New Matter page");
            test.Click(Navigate._CreateNewMatter);
            BasicInfo.ValidateRecord(BasicInfo.GenerateDefaultValues(), null);
            Grid.VerifyRowCount(By.XPath(Matter.Contacts.Row), 0);
            Test.SetSection(Matter.PrintingAndMailing.Section, true);
            Matter.PrintingAndMailing.ValidateRecord(Matter.PrintingAndMailing.GenerateDefaultValues());
            Test.SetSection(Matter.Ivr.Section, true);
            Matter.Ivr.ValidateRecord(Matter.Ivr.GenerateDefaultValues());
            Test.SetSection(Matter.CallCenter.Section, true);
            Matter.CallCenter.ValidateRecord(Matter.CallCenter.GenerateDefaultValues());

            report.Step("Verify Defaults on Existing Matter");
            var existingMatter = Data.GetMatter()
                .FirstOrDefault(a => a.HasPrintingAndMailing != true && a.HasIVR != true && a.HasCallCenter != true);
            if (existingMatter == null)
                throw new Exception("Please ensure there is at least one matter that does not have any toggleable sections enabled.");
            test.EditField(Search._HeaderCriteria, existingMatter.MatterName);
            test.Click(Search._HeaderSubmit);
            test.VerifyNoErrorToasts();
            Test.SetSection(Matter.PrintingAndMailing.Section, true);
            Matter.PrintingAndMailing.ValidateRecord(Matter.PrintingAndMailing.GenerateDefaultValues());
            Test.SetSection(Matter.Ivr.Section, true);
            Matter.Ivr.ValidateRecord(Matter.Ivr.GenerateDefaultValues());
            Test.SetSection(Matter.CallCenter.Section, true);
            Matter.CallCenter.ValidateRecord(Matter.CallCenter.GenerateDefaultValues());

            TestHelper.End();
        }

        public static void PageLoads(int matterId, int maxIterations)
        {   //For investigating Bugs 230309 & 231267
            report._debuglevel = 4;
            var totalIterations = 0;
            var searchFailures = 0;
            var matterFailures = 0;
            double totalSearch = 0;
            double totalMatter = 0;

            TestHelper.Start();
            searchFailures += test.VerifyNoErrorToasts();
            navigate.URL(Config.Url + "/matterdetail?mode=edit&mid=" + matterId);
            matterFailures += test.VerifyNoErrorToasts();
            if (searchFailures > 0)
            {
                report.Fail("Search failed to load on iteration " + totalIterations);
            }
            if (matterFailures > 0)
            {
                report.Fail("Matter failed to load on iteration " + totalIterations);
            }

            while (totalIterations < maxIterations)
            {
                ++totalIterations;
                var startSearch = DateTime.Now;
                test.Click(Navigate._Search);
                var search = test.VerifyNoErrorToasts();
                var endSearch = DateTime.Now;
                var searchTime = (startSearch - endSearch).TotalMilliseconds;
                var startMatter = DateTime.Now;
                navigate.URL(Config.Url + "/matterdetail?mode=edit&mid=" + matterId);
                var matter = test.VerifyNoErrorToasts();
                var endMatter = DateTime.Now;
                var matterTime = (startMatter - endMatter).TotalMilliseconds;
  
                if (search > 0)
                {
                    report.Fail("Search failed to load on iteration " + totalIterations);
                    searchFailures += search;
                    Console.WriteLine("Iteration " + totalIterations + " search time: " + searchTime + " ms.");
                }
                else
                {
                    totalSearch += searchTime;
                }
                if (matter > 0)
                {
                    report.Fail("Matter failed to load on iteration " + totalIterations);
                    matterFailures += matter;
                    Console.WriteLine("Iteration " + totalIterations + " matter time: " + matterTime + " ms.");
                }
                else
                {
                    totalMatter += matterTime;
                }               
            }

            if (searchFailures == 0 && matterFailures == 0)
            {
                Console.WriteLine("No failures occured in " + maxIterations + " attempts.");
            }
            else
            {
                Assert.Fail("Test failed " + (searchFailures + matterFailures) + " verification steps." +
                Environment.NewLine + "Total Iterations: " + totalIterations +
                Environment.NewLine + "Total Search Failures: " + searchFailures + "(" + 100 * ((double)searchFailures / totalIterations) + "%)" +
                Environment.NewLine + "Total Matter Failures: " + matterFailures + "(" + 100 * ((double)matterFailures / totalIterations) + "%)" +
                Environment.NewLine + "Note: VerifyNoErrorToasts waits 5 seconds for the toast before moving on if none are found.  So it's expected that passes will take that much extra time over failures." +
                Environment.NewLine + "Average For Search Time Successes: " + totalSearch / (totalIterations - searchFailures) + " ms." +
                Environment.NewLine + "Average For Matter Time Successes: " + totalMatter / (totalIterations - matterFailures) + " ms.");

                //searchFailures + matterFailures);
                //Console.WriteLine("Total Iterations: " + totalIterations);
                //Console.WriteLine("Total Search Failures: " + searchFailures + "(" + 100 * ((double)searchFailures / totalIterations) + "%)");
                //Console.WriteLine("Total Matter Failures: " + matterFailures + "(" + 100 * ((double)matterFailures / totalIterations) + "%)");
                //Console.WriteLine("Note for timings.  VerifyNoErrorToasts waits 5 seconds for the toast before moving on if none are found.  So it's expected that passes will take that much extra time over failures.");
                //Console.WriteLine("Average For Search Time Successes: " + totalSearch / (totalIterations - searchFailures) + " ms.");
                //Console.WriteLine("Average For Matter Time Successes: " + totalMatter / (totalIterations - matterFailures) + " ms.");

            }
            TestHelper.End();

        }

        public static void MaintainContactsNavigation(int maxIterations)
        {   //For investigating Bugs 230309 & 231267
            report._debuglevel = 4;
            var totalIterations = 0;
            var totalFailures = 0;

            TestHelper.Start();

            while (totalIterations < maxIterations)
            {
                ++totalIterations;
                test.Click(Navigate._Reports);
                test.Click(Navigate._MaintainContacts);
                totalFailures += Grid.VerifyGridLoaded();
            }

            if (totalFailures == 0)
            {
                Console.WriteLine("No failures occured in " + maxIterations + " attempts.");
            }
            else
            {
                Assert.Fail("Test failed " + totalFailures + " verification steps." +
                            Environment.NewLine + "Total Iterations: " + totalIterations);
                //searchFailures + matterFailures);
                //Console.WriteLine("Total Iterations: " + totalIterations);
                //Console.WriteLine("Total Search Failures: " + searchFailures + "(" + 100 * ((double)searchFailures / totalIterations) + "%)");
                //Console.WriteLine("Total Matter Failures: " + matterFailures + "(" + 100 * ((double)matterFailures / totalIterations) + "%)");
                //Console.WriteLine("Note for timings.  VerifyNoErrorToasts waits 5 seconds for the toast before moving on if none are found.  So it's expected that passes will take that much extra time over failures.");
                //Console.WriteLine("Average For Search Time Successes: " + totalSearch / (totalIterations - searchFailures) + " ms.");
                //Console.WriteLine("Average For Matter Time Successes: " + totalMatter / (totalIterations - matterFailures) + " ms.");

            }
            TestHelper.End();

        }

        public static void MaintainContactsPageLoad(int maxIterations)
        {   //For investigating grid load failures.
            //report._debuglevel = 4;
            var totalIterations = 0;
            var addFailures = 0;
            var editFailures = 0;
            var deleteFailures = 0;
            var totalFailures = 0;

            TestHelper.Start();
            navigate.URL(Config.Url + "/maintaincontacts");
            totalFailures += Grid.VerifyGridLoaded();

            while (totalIterations < maxIterations)
            {
                ++totalIterations;
                test.Click(MaintainContact._Add);
                test.EditField(By.XPath(Matter.Contacts.ContactLastName), "aaa" + Format.Timestamp(DateTime.Now));
                test.EditField(By.XPath(Matter.Contacts.Email), "page@loading.com");
                test.Click(MaintainContact._ModalSave);
                test.VerifyNoErrorToasts();
                navigate.Refresh();
                var result = Grid.VerifyGridLoaded();
                addFailures += result;
                if (result == 1)
                {
                    var retries = 0;
                    while (result == 1 && retries < 5)
                    {
                        retries++;
                        navigate.Refresh();
                        result = Grid.VerifyGridLoaded();
                        addFailures += result;
                    }
                    if (retries == 5) throw new Exception("Unable to get grid to load after " + retries + " attempts.");
                }
                
                test.Click(By.XPath(MaintainContact.Edit));
                test.EditField(By.XPath(Matter.Contacts.ContactLastName), "aaa" + Format.Timestamp(DateTime.Now));
                test.Click(MaintainContact._ModalSave);
                navigate.Refresh();
                result = Grid.VerifyGridLoaded();
                editFailures += result;
                if (result == 1)
                {
                    var retries = 0;
                    while (result == 1 && retries < 5)
                    {
                        retries++;
                        navigate.Refresh();
                        result = Grid.VerifyGridLoaded();
                        editFailures += result;
                    }
                    if (retries == 5) throw new Exception("Unable to get grid to load after " + retries + " attempts.");
                }
                test.Click(By.XPath(MaintainContact.Delete));
                test.Click(MaintainContact._ModalDelete);
                navigate.Refresh();
                result = Grid.VerifyGridLoaded();
                deleteFailures += result;
                if (result != 1) continue;
                {
                    var retries = 0;
                    while (result == 1 && retries < 5)
                    {
                        retries++;
                        navigate.Refresh();
                        result = Grid.VerifyGridLoaded();
                        deleteFailures += result;
                    }
                    if (retries == 5) throw new Exception("Unable to get grid to load after " + retries + " attempts.");
                }
            }  

            TestHelper.End();

            totalFailures += addFailures + editFailures + deleteFailures;

            if (totalFailures == 0)
            {
                Console.WriteLine("No failures occured in " + maxIterations + " attempts.");
            }
            else
            {
                Assert.Fail("Test failed " + totalFailures + " verification steps." +
                            Environment.NewLine + "Total Iterations: " + totalIterations +
                            Environment.NewLine + "Total Failures: " + totalFailures +
                            Environment.NewLine + "% Failed: " + Math.Round((double)(100 * totalFailures)/totalIterations) +
                            Environment.NewLine + "Add Failures: " + addFailures +
                            Environment.NewLine + "Edit Failures: " + editFailures +
                            Environment.NewLine + "Delete Failures: " + deleteFailures
                            );
            }
        }

        public static void PageSave(int matterId, int maxIterations)

        {  //For investigating work item 235271
            report.Step("Performing " + maxIterations + " save attempts.");
            //var by = By.XPath(Matter.Matter.BasicInfo.MatterName);
            TestHelper.Start(matterId);
            
            for (var count = 0; count < maxIterations; count++)
            {
                //var text = "SaveTesting" + count;
                var record = BasicInfo.GenerateRecord();
                BasicInfo.UpdateRecord(record, null);
                //test.EditField(by, text);
                test.Click(BasicInfo._Save);
                navigate.Refresh();
                test.WaitForTextInElement(By.XPath(BasicInfo.MatterName));
                var result = 0;
                result += test.VerifyFieldValue(By.XPath(BasicInfo.MatterName), record.MatterName ?? "");
                result += test.VerifyFieldValue(By.XPath(BasicInfo.CompanyName), record.CompanyName ?? "");
                result += test.VerifySelectedValue(By.XPath(BasicInfo.InsuranceCompany),
                    record.InsuranceCompany?.Name);
                result += test.VerifyFieldValue(By.XPath(BasicInfo.Other), record.InsuranceCompanyNameOther ?? "");
                result += test.VerifyFieldValue(By.XPath(BasicInfo.AffectedPopulationSize),
                    record.AffectedPopulationSize.ToString());
                result += test.VerifyFieldValue(By.XPath(BasicInfo.LawFirm), record.LawFirm ?? "");
                result += test.VerifyFieldValue(By.XPath(BasicInfo.EnrollmentDeadline),
                    Format.Date(record.EnrollmentDeadlineDate));
                result += test.VerifyFieldValue(By.XPath(BasicInfo.RegulatoryDeadline),
                    Format.Date(record.RegulatoryDeadlineDate));
                result += test.VerifyFieldValue(By.XPath(BasicInfo.ProjectedMailDate),
                    Format.Date(record.ProjectedMailDate));
                result += test.VerifyFieldValue(By.XPath(BasicInfo.CallCenterLiveDate),
                    Format.Date(record.CallCenterLiveDate));
                //result += Matter.Matter.BasicInfo.VerifyNoticeTypes(noticeTypes);
                result += Test.VerifyToggleValue(BasicInfo.EBlast, record.IsEblast);
                result += Test.VerifyToggleValue(BasicInfo.W2, record.IsW2);
                result += Test.VerifyToggleValue(BasicInfo.CreditMonitoring, record.IsCreditMonitored);
                result += Test.VerifyToggleValue(BasicInfo.Equifax, record.HasEquifax);
                result += Test.VerifyToggleValue(BasicInfo.Experian, record.HasExperian);
                result += Test.VerifyToggleValue(BasicInfo.Transunion, record.HasTransunion);
                result += Test.VerifySectionValue(Matter.PrintingAndMailing.Section,
                    record.HasPrintingAndMailing);
                result += Test.VerifySectionValue(Matter.Ivr.Section, record.HasIVR);
                result += Test.VerifySectionValue(Matter.CallCenter.Section, record.HasCallCenter);
                if (result > 0)
                {
                    report.Fail("Save failed on iteration " + count);
                    
                }
                else
                {
                    report.Pass("Save succeeded on iteration " + count);
                }
                
                //test.VerifyFieldValue(by, text));
            }
            
            TestHelper.End();

        }

        public static void SessionContinuousUse(int iterations, int sleepTime)
        {
            testHelper.Start(test.driver, "timeout2", "P@ssword1");
            report.Step("Start: " + DateTime.Now.ToLongTimeString());
            for (var i = 0; i < iterations; i++)
            {
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(sleepTime));
                report.Step("Refresh at: " + DateTime.Now.ToLongTimeString());
                navigate.Refresh();
                if (test.driver.Url.Contains("/login"))
                {
                    throw new Exception("User session has been lost at: " + DateTime.Now.ToLongTimeString());
                }
                report.Pass("User session persisted.");
            }
            report.Step("End: " + DateTime.Now.ToLongTimeString());
            TestHelper.End();
        }

        public static void SessionContinuousSave(int iterations, int sleepTime)
        {
            TestHelper.Start(2);
            report.Step("Start: " + DateTime.Now.ToLongTimeString());
            for (var i = 0; i < iterations; i++)
            {
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(sleepTime));
                var timestamp = DateTime.Now.ToLongTimeString();
                report.Step("Update at: " + timestamp );
                test.EditField(By.XPath(BasicInfo.MatterName), "Session " + timestamp);
                test.Click(BasicInfo._Save);
                if (test.driver.Url.Contains("/login"))
                {
                    throw new Exception("User session has been lost at: " + DateTime.Now.ToLongTimeString());
                }
                report.Pass("User session persisted.");
            }
            report.Step("End: " + DateTime.Now.ToLongTimeString());
            TestHelper.End();
        }

        public static void SessionTimeout(int idle = 7200, int timeout = 900, string page = "Matter Detail")
        {
            switch (page)
            {
                case "Matter Detail":
                    TestHelper.Start(Config.MatterId);
                    break;
                case "Create New Matter":
                    TestHelper.Start();
                    test.Click(Navigate._CreateNewMatter);
                    break;
                default:
                    TestHelper.Start();
                    break;
            }
            report.Step("Start: " + DateTime.Now.ToLongTimeString());
            Navigate.VerifySessionTimeout(idle, timeout);
            report.Step("Stay connected: " + DateTime.Now.ToLongTimeString());
            test.Click(By.XPath("//button[text()='Stay connected']"));
            test.VerifyNoErrorToasts();
            System.Threading.Thread.Sleep(timeout + 60);
            navigate.Refresh();
            if (test.driver.Url.Contains("/login"))
            {
                var error = "User session has been lost at: " + DateTime.Now.ToLongTimeString();
                report.Fail(error);
                throw new Exception(error);
            }
            Navigate.VerifySessionTimeout(idle, timeout);
            if (test.driver.FindElements(By.XPath("//button[text()='Logout']")).Count > 0)
            {
                test.Click(By.XPath("//button[text()='Logout']"));
                test.VerifyNoErrorToasts();
                if (!test.driver.Url.Contains("/login"))
                {
                    var error = "User session was not logged out at: " + DateTime.Now.ToLongTimeString();
                    report.Fail(error);
                    throw new Exception(error);
                }
            }
            TestHelper.End();
        }

        public static void GridLoad(int iterations)
        {
            TestHelper.Start(1);
            var failures = Grid.VerifyGridLoaded();
            test.Click(Navigate._MaintainContacts);
            for (var i = 0; i < iterations; i++)
            {
                navigate.Refresh();
                failures += Grid.VerifyGridLoaded();
            }

            TestHelper.End();

            if (failures > 0)
            {
                Assert.Fail("There were " + failures + " failures in " + iterations + " attempts.");
            }
            Console.WriteLine("There were no failures in " + iterations + " attempts.");

        }

    }
}
