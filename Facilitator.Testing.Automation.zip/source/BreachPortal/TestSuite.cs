﻿using System;
using Automation;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BreachPortal
{
    [TestClass]
    public class TestSuite
    {
        public TestContext TestContext { get; set; }

        // ReSharper disable once UnusedMember.Local
        private static void MyContext()
        {
            var type = typeof(System.Data.Entity.SqlServer.SqlProviderServices);
            if (type == null)
                throw new Exception("Do not remove, ensures static reference to System.Data.Entity.SqlServer");
        }

        [TestInitialize]
        public void Startup()
        {
            if (TestContext.Properties["__Tfs_TestConfigurationName__"] == null)  //Only override if not provided by test manager
            {
                switch (Config.Browser)
                {
                    case "Firefox":
                        TestContext.Properties["__Tfs_TestConfigurationName__"] = "Firefox";
                        TestContext.Properties["BuildDirectory"] = AppDomain.CurrentDomain.BaseDirectory;
                        break;
                    case "IE":
                    case "Internet Explorer":
                        TestContext.Properties["__Tfs_TestConfigurationName__"] = "IE";
                        TestContext.Properties["BuildDirectory"] = AppDomain.CurrentDomain.BaseDirectory;
                        break;
                }
            }         
            test.startup(TestContext);
        }

        [TestCleanup]
        public void Teardown()
        {
            test.driver.Quit();
            try
            {
                Assert.AreEqual(0, test.vars.errorcount);
            }
            catch
            {
                var message = (Test.Note != null)
                    ? Environment.NewLine + Test.Note + Environment.NewLine +
                      "Test failed " + test.vars.errorcount + " verification steps."
                    : "Test failed " + test.vars.errorcount + " verification steps.";
                Assert.Fail(message);
            }
        }

        [TestCategory("Debug"), TestMethod]
        public void Testing()
        {
            Usecase.Testing();
        }

        [TestCategory("Regression"), TestMethod]
        public void Logon()
        {
            Usecase.Logon();
        }

        [TestCategory("Regression"), TestMethod]
        public void Logout()
        {
            Usecase.Logout();
        }

        [TestCategory("Regression"), TestMethod]
        public void QuickSearch()
        {
            Usecase.QuickSearch();
        }

        [TestCategory("Regression"), TestMethod]
        public void BasicInformation()
        {
            Usecase.BasicInformation(Config.MatterId);
        }

        [TestCategory("Regression"), TestMethod]
        public void Contacts()
        {
            Usecase.Contacts(Config.MatterId);
        }

        [TestCategory("Regression"), TestMethod]
        public void Tracking()
        {
            Usecase.Tracking(Config.MatterId);
        }

        [TestCategory("Regression"), TestMethod]
        public void PrintingAndMailing()
        {
            Usecase.PrintingAndMailing(Config.MatterId);
        }

        [TestCategory("Regression"), TestMethod]
        public void CallCenter()
        {
            Usecase.CallCenter(Config.MatterId);
        }

        [TestCategory("Regression"), TestMethod]
        public void Ivr()
        {
            Usecase.Ivr(Config.MatterId);
        }

        [TestCategory("Regression"), TestMethod]
        public void FileUpload()
        {
            Usecase.FileUpload(Config.MatterId);
        }

        [TestCategory("Regression"), TestMethod]
        public void CreateNewMatter()
        {
            Usecase.CreateNewMatter();
        }

        [TestCategory("Regression"), TestMethod]
        public void Reports()
        {
            Usecase.ReportView();
        }

        [TestCategory("Regression"), TestMethod]
        public void Calendar()
        {
            Usecase.CalendarView();
        }

        [TestCategory("Regression"), TestMethod]
        public void MaintainContacts()
        {
            Usecase.MaintainContacts();
        }
       
        [TestCategory("Functional"), TestMethod]
        public void Concurrency()
        {
            Usecase.Concurrency(Config.MatterId);
        }

        [TestCategory("Functional"), TestMethod]
        public void BasicInfoFieldValidation()
        {
            Usecase.BasicInfoFieldValidation(Config.MatterId);
        }

        [TestCategory("Functional"), TestMethod]
        public void ContactsFieldValidation()
        {
            Usecase.ContactsFieldValidation(Config.MatterId);
        }

        [TestCategory("Functional"), TestMethod]
        public void TrackingFieldValidation()
        {
            Usecase.TrackingFieldValidation(Config.MatterId);
        }

        [TestCategory("Functional"), TestMethod]
        public void PrintingAndMailingFieldValidation()
        {
            Usecase.PrintingAndMailingFieldValidation(Config.MatterId);
        }

        [TestCategory("Functional"), TestMethod]
        public void CallCenterFieldValidation()
        {
            Usecase.CallCenterFieldValidation(Config.MatterId);
        }

        [TestCategory("Functional"), TestMethod]
        public void MaintainContactsFieldValidation()
        {
            Usecase.MaintainContactsFieldValidation(Config.MatterId);
        }

        [TestCategory("Roles"), TestMethod]
        public void User()
        {
            Usecase.User(Config.Username, Config.Password);
        }

        [TestCategory("Roles"), TestMethod]
        public void ReadOnly()
        {
            Usecase.ReadOnly("eReadOnly", Config.Password);
        }

        [TestCategory("Functional"), TestMethod]
        public void History()
        {
            Usecase.History();
        }

        [TestCategory("Functional"), TestMethod]
        public void DefaultData()
        {
            Usecase.DefaultData();
        }

        [TestCategory("Performance"), TestMethod, Timeout(7200000)]
        public void PageLoads()
        {
            Usecase.PageLoads(Config.MatterId, 50);
        }
        
        [TestCategory("Performance"), TestMethod, Timeout(7200000)]
        public void MaintainContactsPageLoad()
        {
            Usecase.MaintainContactsPageLoad(100);
        }

        [TestCategory("Regression"), TestMethod]
        public void SubmitMatter()
        {
            Usecase.SubmitMatter(Config.MatterId);
        }

        [TestCategory("Performance"), TestMethod]
        public void PageSave()
        {
            Usecase.PageSave(Config.MatterId, 10);
        }

        [TestCategory("Regression"), TestMethod]
        public void DeleteMatter()
        {
            Usecase.DeleteMatter();
        }

        [TestCategory("Performance"), TestMethod, Timeout(10800000)]
        public void SessionContinuousUse()
        {
            Usecase.SessionContinuousUse(6, 300);
        }

        [TestCategory("Performance"), TestMethod, Timeout(10800000)]
        public void SessionContinuousSave()
        {
            Usecase.SessionContinuousSave(1, 1800);
        }

        [TestCategory("Performance"), TestMethod, Timeout(18000000)]
        public void SessionTimeout()
        {
            Usecase.SessionTimeout();
        }

        [TestCategory("Performance"), TestMethod, Timeout(7200000)]
        public void MaintainContactsNavigation()
        {
            Usecase.MaintainContactsNavigation(100);
        }

        [TestCategory("Performance"), TestMethod, Timeout(7200000)]
        public void GridLoad()
        {
            Usecase.GridLoad(1000);
        }
    }
}
