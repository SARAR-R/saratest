﻿using System;
using System.Linq;
using Automation;

namespace BreachPortal
{
    public class History
    {
        public static int VerifyMatterColumnChange(Database.Matter record, int action)
        {
            try
            {
                if (record == null) throw new Exception("No Matter data present");
                var history = Data.GetMatterColumnChange(record.MatterId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyMatterNoticeTypeColumnChange(Database.MatterNoticeType record, int action)
        {
            try
            {
                if (record == null) throw new Exception("No Notice Type data present");
                var history = Data.GetMatterNoticeTypeColumnChange(record.MatterNoticeTypeId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyMatterToContactColumnChange(Database.MatterToContact record, int action)
        {
            try
            {
                if (record == null) throw new Exception("No Contact data present");
                var history = Data.GetMatterToContactColumnChange(record.MatterToContactId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyContactColumnChange(Database.Contact contact, int action)
        {
            try
            {
                if (contact == null) throw new Exception("No Contact data present");
                var history = Data.GetContactColumnChange(contact.ContactId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyTrackingColumnChange(Database.Matter matter, int action)
        {
            try
            {
                if (matter.TrackingId == null) throw new Exception("No Tracking data present");
                var history = Data.GetTrackingColumnChange((int) matter.TrackingId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyPrintingAndMailingColumnChange(Database.Matter matter, int action)
        {
            try
            {
                if (matter.PrintingAndMailingId == null) throw new Exception("No PrintingAndMailing data present");
                var history = Data.GetPrintingAndMailingColumnChange((int) matter.PrintingAndMailingId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyIvrColumnChange(Database.Matter matter, int action)
        {
            try
            {
                if (matter.IVRId == null) throw new Exception("No IVR data present");
                var history = Data.GetIvrColumnChange((int) matter.IVRId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyCallCenterColumnChange(Database.Matter matter, int action)
        {
            try
            {
            if (matter.CallCenterId == null) throw new Exception("No Call Center data present");
                var history = Data.GetCallCenterColumnChange((int) matter.CallCenterId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifySubmittedMatterLogColumnChange(Database.SubmittedMatterLog record, int action)
        {
            try
            {
                if (Data.GetSubmittedMatterLog(record.MatterId) == null) throw new Exception("No Submission data present");
                var history = Data.GetSubmittedMatterLogColumnChange(record.SubmittedMatterLogId);
                return VerifyColumnChange(history.Any(a => a.Action == action), 
                    action, history.First()?.GetType().Name);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying history.", e);
                return 1;
            }
        }

        public static int VerifyColumnChange(bool exists, int action, string tablename)
        {
            string actionType;
            switch (action)
            {
                case 1:
                    actionType = "created";
                    break;
                case 2:
                    actionType = "updated";
                    break;
                case 3:
                    actionType = "deleted";
                    break;
                default:
                    report.Fail("Invalid action type: " + action);
                    return 1;
            }
            if (exists)
            {
                report.Pass("Record has been " + actionType + " in the " + tablename + " table.");
                return 0;
            }
            report.Fail("Record has not been " + actionType + " in the " + tablename + " table.");
            return 1;
        }

    }
}
