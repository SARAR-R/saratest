﻿using System;
using System.Linq;
using Automation;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace BreachPortal
{
    public class Calendar
    {
        public static By _CurrentView = By.XPath("//div[@class='fc-left']");
        public static By _ByDay = By.XPath("//button[contains(@class,'fc-agendaDay-button')]");
        public static By _ByWeek = By.XPath("//button[contains(@class,'fc-agendaWeek-button')]");
        public static By _ByMonth = By.XPath("//button[contains(@class,'fc-month-button')]");
        public static By _Today = By.XPath("//button[contains(@class,'fc-today-button')]");
        public static By _Previous = By.XPath("//button[contains(@class,'fc-prev-button')]");
        public static By _Next = By.XPath("//button[contains(@class,'fc-next-button')]");

        public static void ValidateMonthlyView(DateTime date, int? numRecords = null)
        {
            var filterDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-3);
            //If not current date, default view will be starting at the first of the month
            if (date.Date != DateTime.Now.Date)
            {
                date = new DateTime(date.Year, date.Month, 1);
            }

            report.Step("Verify Date Range");
            test.VerifyText(_CurrentView, date.ToString("MMMM yyyy"));

            report.Step("Verify Monthly View");
            var records = Data.GetMatter().Where(
                d => d.ProjectedMailDate?.Month == date.Month && 
                     d.ProjectedMailDate?.Year == date.Year &&
                     d.ProjectedMailDate?.Date >= filterDate || 
                     d.CallCenterLiveDate?.Month == date.Month &&
                     d.CallCenterLiveDate?.Year == date.Year &&
                     d.CallCenterLiveDate?.Date >= filterDate
                ).ToList();

            if (!records.Any())
            {
                report.Action("Skip", "No records present for current view");
                return;
            }
            if (numRecords != null) records = records.Take((int)numRecords).ToList();

            foreach (var record in records)
            {
                if (record.ProjectedMailDate?.Date == record.CallCenterLiveDate?.Date)
                {
                    VerifyDate(record, "Both");
                    continue;
                }

                if (record.ProjectedMailDate?.Month == date.Month &&
                    record.ProjectedMailDate?.Year == date.Year)
                {
                    VerifyDate(record, "Mailing");
                }

                if (record.CallCenterLiveDate?.Month == date.Month &&
                    record.CallCenterLiveDate?.Year == date.Year)
                {
                    VerifyDate(record, "Call Center");
                }
            }

        }     

        public static void ValidateWeeklyView(DateTime date, int? numRecords = null)
        {
            var filterDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-3);
            //If not current date, default view will be starting at the first of the month
            if (date.Date != DateTime.Now.Date)
            {
                date = new DateTime(date.Year, date.Month, 1);
            }

            var weekStart = date.AddDays(-1 * (int)date.DayOfWeek);
            var weekEnd = weekStart.Date.AddDays(6);
            
            report.Step("Verify Date Range");
            test.VerifyText(_CurrentView, weekStart.ToString("MMM d – ") + (weekStart.Month == weekEnd.Month ?
                                          weekEnd.ToString("d, yyyy") : weekEnd.ToString("MMM d, yyyy")));

            report.Step("Verify Weekly View");
           
            var records = Data.GetMatter().Where(
                d => d.ProjectedMailDate?.Date >= weekStart && d.ProjectedMailDate?.Date <= weekEnd &&
                     d.ProjectedMailDate?.Date >= filterDate || 
                     d.CallCenterLiveDate?.Date >= weekStart && d.CallCenterLiveDate?.Date <= weekEnd &&
                     d.CallCenterLiveDate?.Date >= filterDate
                     ).ToList();

            if (!records.Any())
            {
                report.Action("Skip", "No records present for current view");
                return;
            }
            if (numRecords != null) records = records.Take((int)numRecords).ToList();

            foreach (var record in records)
            {
                if (record.ProjectedMailDate?.Date == record.CallCenterLiveDate?.Date)
                {
                    VerifyDate(record, "Both");
                    continue;
                }

                if (record.ProjectedMailDate?.Date >= weekStart && record.ProjectedMailDate?.Date <= weekEnd)
                {
                    VerifyDate(record, "Mailing");
                }

                if (record.CallCenterLiveDate?.Date >= weekStart && record.CallCenterLiveDate?.Date <= weekEnd)
                {
                    VerifyDate(record, "Call Center");
                }
            }

        }     

        public static void ValidateDailyView(DateTime date, int? numRecords = null)
        {
            var filterDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-3);
            //If not current date, default view will be starting at the first of the month
            if (date.Date != DateTime.Now.Date)
            {
                date = new DateTime(date.Year, date.Month, 1);
            }

            report.Step("Verify Date Range");
            test.VerifyText(_CurrentView, date.ToString("MMMM d, yyyy"));

            report.Step("Verify Daily View");
            
            var records = Data.GetMatter().Where(
                d => d.ProjectedMailDate?.Date == date.Date  &&
                     d.ProjectedMailDate?.Date >= filterDate || 
                     d.CallCenterLiveDate?.Date == date.Date &&
                     d.CallCenterLiveDate?.Date >= filterDate
                     ).ToList(); 

            if (!records.Any())
            {
                report.Action("Skip", "No records present for current view");
                return;
            }

            if (numRecords != null) records = records.Take((int)numRecords).ToList();

            foreach (var record in records)
            {
                if (record.ProjectedMailDate?.Date == record.CallCenterLiveDate?.Date)
                {
                    VerifyDate(record, "Both");
                    continue;
                }

                if (record.ProjectedMailDate?.Date == date.Date)
                {
                    VerifyDate(record, "Mailing");
                }

                if (record.CallCenterLiveDate?.Date == date.Date)
                {
                    VerifyDate(record, "Call Center");
                }
            }

        }   

        public static int VerifyDate(Database.Matter record, string dateType)
        {
            try
            {
                var by = GenerateRecordXpath(record, dateType);
                test.WaitForPageToLoad(test.driver);                
                var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(5));
                wait.Until(d => d.FindElement(by).Displayed);
                report.Pass(dateType + " Date for matter " + record.CompanyName + "/" + record.MatterName + " exists.");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail(dateType + " Date for matter " + record.CompanyName + "/" + record.MatterName + " does not exist.", e);
                return 1;
            }
        }

        public static By GenerateRecordXpath(Database.Matter record, string dateType)
        {
            string date;
            string color;
                
            switch (dateType)
            {
                case "Both":
                case "Call Center And Mailing":
                    date = record.CallCenterLiveDate?.ToString("yyyy-MM-dd");
                    color = "#7dd98e";
                    break;
                case "Call Center":
                case "Call Center Live":
                    date = record.CallCenterLiveDate?.ToString("yyyy-MM-dd");
                    color = "#6faade";
                    break;
                case "Mailing":
                case "Projected Mail Date":
                    date = record.ProjectedMailDate?.ToString("yyyy-MM-dd");
                    color = "#fbff8a";
                    break;
                default:
                    throw new Exception("Invalid date dateType: " + dateType);
            }
            //Get expected date position  (note, really only verifies it's in the proper row).
            var div = test.driver.FindElements(
                              By.XPath("//tbody//div[contains(@class, 'fc-row') and div[@class='fc-bg']//td[@data-date = '" + date + "']]/preceding-sibling::div"))
                          .Count + 1;
            //Filter on Position, Matter Name, Color and Company Name.
            return By.XPath("//tbody//div[contains(@class, 'fc-row')]["+ div + 
                    "]//div[@class='fc-content-skeleton']//tbody//a[@title = \"Matter Name: " + record.MatterName + 
                    "\" and contains(@style, '" + color + "')]//span[text()=\"" + record.CompanyName + "\"]");
        }
    }
}
