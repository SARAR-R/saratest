﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using OpenQA.Selenium;

namespace BreachPortal.Matter
{
    public class CallCenter
    {
        #region Variables

        public static string Section = "//breach-portal-panel-toggle[@value='vm.matter.hasCallCenter']";
        public static string Languages = "//select[@ng-model='vm.matter.callCenter.callCenterLanguageId']";
        public static string WebChatToLiveAgent = "//breach-portal-checkbox-toggle[@value='vm.matter.callCenter.webChatToLiveAgent']";
        public static string ReportingSuite = "//breach-portal-checkbox-toggle[@value='vm.matter.callCenter.reportingSuite']";
        public static string Agents = "//select[@ng-model='vm.matter.callCenter.agentTypeId']";
        public static string EmailRoutingToLiveAgent = "//breach-portal-checkbox-toggle[@value='vm.matter.callCenter.emailRoutingToLiveAgent']";
        public static string StandardScript = "//breach-portal-checkbox-toggle[@value='vm.matter.callCenter.standardScript']";
        public static string SetupTurnAround = "//select[@ng-model='vm.matter.callCenter.setupTurnAroundId']";
        public static string ClientCallback = "//breach-portal-checkbox-toggle[@value='vm.matter.callCenter.clientCallback']";
        public static string StandardFaq = "//breach-portal-checkbox-toggle[@value='vm.matter.callCenter.standardFaq']";
        public static string LocalPhoneNumber = "//input[@ng-model='vm.matter.callCenter.localPhone']";
        public static string TollFreePhoneNumber = "//input[@ng-model='vm.matter.callCenter.tollFreePhone']";
        public static string AdditionalNumbers = "//textarea[@ng-model='vm.matter.callCenter.notes']";
        
        #endregion

        public static void ValidateRecord(Database.CallCenter record)
        {
            if (record == null)
            {
                report.Action("Skip", "No Call Center data to validate.");
                return;
            }
            test.VerifySelectedValue(By.XPath(Languages), record.CallCenterLanguage?.Name ?? "");
            Test.VerifyToggleValue(WebChatToLiveAgent, record.WebChatToLiveAgent);
            Test.VerifyToggleValue(ReportingSuite, record.ReportingSuite);
            test.VerifySelectedValue(By.XPath(Agents), record.AgentType?.Name ?? "");
            Test.VerifyToggleValue(EmailRoutingToLiveAgent, record.EmailRoutingToLiveAgent);
            Test.VerifyToggleValue(StandardScript, record.StandardScript);
            test.VerifySelectedValue(By.XPath(SetupTurnAround), record.SetupTurnAround?.Name ?? "");
            Test.VerifyToggleValue(ClientCallback, record.ClientCallback);
            Test.VerifyToggleValue(StandardFaq, record.StandardFaq);
            test.VerifyFieldValue(By.XPath(LocalPhoneNumber), record.LocalPhone ?? "");
            test.VerifyFieldValue(By.XPath(TollFreePhoneNumber), record.TollFreePhone ?? "");
            test.VerifyFieldValue(By.XPath(AdditionalNumbers), record.Notes ?? "");
            

        }

        public static Database.CallCenter GenerateRecord(int? matterId = null)
        {
            var append = DateTime.Now.ToString("fff");
            var record = (matterId != null) ? Data.GetCallCenter((int)matterId) ?? new Database.CallCenter() : new Database.CallCenter();
            record.CallCenterLanguage = Data.GetCallCenterLanguage().OrderBy(x => Guid.NewGuid()).First();
            record.WebChatToLiveAgent = Test.RandomBoolean();
            record.ReportingSuite = Test.RandomBoolean();
            record.AgentType = Data.GetAgentType().OrderBy(x => Guid.NewGuid()).First();
            record.EmailRoutingToLiveAgent = Test.RandomBoolean();
            record.StandardScript = Test.RandomBoolean();
            record.SetupTurnAround = Data.GetSetupTurnAround().OrderBy(x => Guid.NewGuid()).First();
            record.ClientCallback = Test.RandomBoolean();
            record.StandardFaq = Test.RandomBoolean();
            record.LocalPhone = "+1 456 789 0" + append;
            record.TollFreePhone = "+1 800 555 6" + append;
            record.Notes = "Additional Numbers " + append;
            return record;
        }

        public static void UpdateRecord(Database.CallCenter record)
        {
            Test.SetSection(Section, true);
            test.SelectField(By.XPath(Languages), record.CallCenterLanguage?.Name ?? "");
            Test.SetToggle(WebChatToLiveAgent, record.WebChatToLiveAgent);
            Test.SetToggle(ReportingSuite, record.ReportingSuite);
            test.SelectField(By.XPath(Agents), record.AgentType?.Name ?? "");
            Test.SetToggle(EmailRoutingToLiveAgent, record.EmailRoutingToLiveAgent);
            Test.SetToggle(StandardScript, record.StandardScript);
            test.SelectField(By.XPath(SetupTurnAround), record.SetupTurnAround?.Name ?? "");
            Test.SetToggle(ClientCallback, record.ClientCallback);
            Test.SetToggle(StandardFaq, record.StandardFaq);
            test.EditField(By.XPath(LocalPhoneNumber), record.LocalPhone ?? "");
            test.EditField(By.XPath(TollFreePhoneNumber), record.TollFreePhone ?? "");
            test.EditField(By.XPath(AdditionalNumbers), record.Notes ?? "");

        }

        public static Database.CallCenter GenerateDefaultValues()
        {
            return new Database.CallCenter
            {
                CallCenterLanguage = Data.GetCallCenterLanguage().First(n => n.Name == "English Only"),
                StandardScript = false,
                StandardFaq = false,
                WebChatToLiveAgent = false, 
                EmailRoutingToLiveAgent = false,
                ClientCallback = false, 
                ReportingSuite = false, 
                SetupTurnAround = Data.GetSetupTurnAround().First(n => n.Name == "3 Days")
            };
        }

        public static Database.CallCenter UpdateSystemFields(Database.CallCenter record, int matterId)
        {
            var source = Data.GetCallCenter(matterId);
            record.CallCenterId = source.CallCenterId;
            record.InsertedDate = source.InsertedDate;
            record.UpdatedDate = source.UpdatedDate;
            record.UpdatedBy = source.UpdatedBy;
            return record;
        }

        public static List<Test.FieldDetail> FieldValidation()
        {
            return new List<Test.FieldDetail>
            {
                new Test.FieldDetail
                {
                    Label = "Local Phone Number",
                    Length = 15,
                    InvalidText = Test.GenerateString(15),
                    ValidText = "+1 555 666 " + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneFormat"
                },
                new Test.FieldDetail
                {
                    Label = "Local Phone Number",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(3),
                    ValidText = "+2" + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneMinLength"
                },
                new Test.FieldDetail
                {
                    Label = "Local Phone Number",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(20),
                    ValidText = "+2" + Test.GenerateNumberString(19),
                    ValidationType = "$error.phoneMaxLength"
                },
                new Test.FieldDetail
                {
                    Label = "Toll Free Phone Number",
                    Length = 15,
                    InvalidText = Test.GenerateString(15),
                    ValidText = "+1 555 666 " + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneFormat"
                },
                new Test.FieldDetail
                {
                    Label = "Toll Free Phone Number",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(3),
                    ValidText = "+2" + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneMinLength"
                },
                new Test.FieldDetail
                {
                    Label = "Toll Free Phone Number",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(20),
                    ValidText = "+2" + Test.GenerateNumberString(19),
                    ValidationType = "$error.phoneMaxLength"
                },
                new Test.FieldDetail
                {
                    Label = "Additional Numbers",
                    Length = 2000
                }
            };
        }

    }
}
