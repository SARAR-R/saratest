﻿using System;
using System.Linq;
using Automation;
using BreachPortal.Database;
using OpenQA.Selenium;

namespace BreachPortal.Matter
{
    public class Ivr
    {
        #region Variables
   
        public static string Section = "//breach-portal-panel-toggle[@value='vm.matter.hasIVR']";
        public static string StandardScript = "//breach-portal-checkbox-toggle[@value='vm.matter.ivr.isStandardScript']";
        public static string InboundFax = "//breach-portal-checkbox-toggle[@value='vm.matter.ivr.isInboundFax']";
        public static string Languages = "//select[@ng-model='vm.matter.ivr.ivrLanguageId']";

        #endregion

        public static void ValidateRecord(IVR record)
        {
            if (record == null)
            {
                report.Action("Skip", "No IVR data to validate.");
                return;
            }
            Test.VerifyToggleValue(StandardScript, record.IsStandardScript);
            Test.VerifyToggleValue(InboundFax, record.IsInboundFax);
            test.VerifySelectedValue(By.XPath(Languages), record.IVRLanguage?.Name ?? "");
        }

        public static IVR GenerateRecord(int? matterId = null)
        {
            var record = (matterId != null) ? Data.GetIvr((int)matterId) ?? new IVR(): new IVR();
            record.IsStandardScript = Test.RandomBoolean();
            record.IsInboundFax = Test.RandomBoolean();
            record.IVRLanguage = Data.GetIvrLanguage().OrderBy(x => Guid.NewGuid()).First();
            return record;
        }

        public static void UpdateRecord(IVR record)
        {
            Test.SetSection(Section, true);
            Test.SetToggle(StandardScript, record.IsStandardScript);
            Test.SetToggle(InboundFax, record.IsInboundFax);
            test.SelectField(By.XPath(Languages), record.IVRLanguage?.Name ?? "");
        }

        public static IVR GenerateDefaultValues()
        {
            return new IVR
            {
                IsStandardScript = false,
                IVRLanguage = Data.GetIvrLanguage().First(n => n.Name == "English Only"),
                IsInboundFax = false
            };
        }
    }
}
