﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using BreachPortal.Database;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace BreachPortal.Matter
{
    public class Contacts
    {
        #region Variables
        //Section Elements
        public static string Section = "//div[@class='panel-heading hand']/span[text()='Contacts']";
        public static By _Grid = By.XPath("//breach-portal-contact-section/div");
        public static By _GridHiddenMessage = By.XPath("//breach-portal-contact-section/h5");
        public static By _AddContact = By.XPath("//button[@ng-click='vmc.add()']");
        public static string View = Grid.View;
        public static string Edit = Grid.Edit;
        public static string Delete = Grid.Delete;
        public static string Row = "//breach-portal-contact-section" + Grid.Row;
        
        public static List<Grid.ColumnDetails> Columns = new List<Grid.ColumnDetails>
        {
            new Grid.ColumnDetails {Label = "Last Name"},
            new Grid.ColumnDetails {Label = "First Name"},
            new Grid.ColumnDetails {Label = "Type"},
            new Grid.ColumnDetails {Label = "Phone Number"},
            new Grid.ColumnDetails {Label = "Email"},
            new Grid.ColumnDetails {Label = "Company"},
            new Grid.ColumnDetails {Label = "Title"},
            new Grid.ColumnDetails {Label = "Primary"}
        };

        //Modal Elements
        public static string ContactType = "//select[@ng-model='vm.contact.contactTypeName']";
        public static string ContactFirstName = "//input[@ng-model='vm.contact.firstName']";
        public static string ContactLastName = "//input[@ng-model='vm.contact.lastName']";
        public static string CompanyName = "//input[@ng-model='vm.contact.companyName']";
        public static string PhoneNumber = "//input[@ng-model='vm.contact.phone']";
        public static string PhoneNumber2 = "//input[@ng-model='vm.contact.phoneAlternate']";
        public static string Email = "//input[@ng-model='vm.contact.email']";
        public static string Title = "//input[@ng-model='vm.contact.title']";
        public static string Primary = "//breach-portal-checkbox-toggle[@value='vm.contact.primary']";
        public static string Select = "//div[input[contains(@class, 'contact-selection-input')]]";
        public static By _TextFilter = By.XPath("//input[@ng-model='vm.searchText']");
        public static By _MaintainContacts = By.XPath("//button[@ng-click='vm.navToMaintainContacts()']");
        public static By _ModalSave = By.XPath("//button[@ng-click='vm.ok()']");
        public static By _ModalCancel = By.XPath("//button[@ng-click='vm.cancel()']");
        public static By _ModalDelete = By.XPath("//button[@ng-click='vm.delete()']");
        #endregion

        public static void ValidateRecords(List<MatterToContact> records, bool sortByLast = true)
        {
            try
            {
                if (records.Count > 0) test.WaitForElement(By.XPath(Grid.Row));               
                Grid.VerifyRowCount(By.XPath(Grid.Row), records.Count);

                if (sortByLast)
                {
                    Grid.SortByColumn("Last Name", "asc");
                    records = records.OrderBy(l => l.LastName).ToList();
                }

                var row = 0;
                foreach (var record in records)
                {
                    row++;
                    Grid.VerifyCellContents(2, record.LastName, row);
                    Grid.VerifyCellContents(3, record.FirstName, row);
                    Grid.VerifyCellContents(4, record.ContactTypeName, row);
                    Grid.VerifyCellContents(5, record.Phone, row);
                    Grid.VerifyCellContents(6, record.Email, row);
                    Grid.VerifyCellContents(7, record.CompanyName, row);
                    Grid.VerifyCellContents(8, record.Title, row);
                    Grid.VerifyCellContents(9, Format.YesNoString(record.Primary), row);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate records failed due to: ", e);
                navigate.Refresh();
            }
           
        }

        public static void ValidateRecord(MatterToContact record)
        {
            test.VerifySelectedValue(By.XPath(ContactType), record.ContactTypeName ?? "");
            test.VerifyFieldValue(By.XPath(ContactFirstName), record.FirstName ?? "");
            test.VerifyFieldValue(By.XPath(ContactLastName), record.LastName ?? "");
            test.VerifyFieldValue(By.XPath(CompanyName), record.CompanyName ?? "");
            test.VerifyFieldValue(By.XPath(Title), record.Title ?? "");
            test.VerifyFieldValue(By.XPath(PhoneNumber), record.Phone ?? "");
            test.VerifyFieldValue(By.XPath(PhoneNumber2), record.PhoneAlternate ?? "");
            test.VerifyFieldValue(By.XPath(Email), record.Email ?? "");
            Test.VerifyToggleValue(Primary, record.Primary);
        }

        public static void ValidateAddModalRecords(List<Contact> records, int pageSize = 10)
        {
            var modalRow = By.XPath("//form[@name='vm.addContactForm']" + Grid.Row);
            if (records.Count > 0) test.WaitForElement(modalRow);
            Grid.VerifyRowCount(modalRow, (records.Count > pageSize) ? pageSize : records.Count);

            var row = 0;
            foreach (var record in records)
            {
                row++;
                if (row > pageSize) continue;
                Grid.VerifyCellContents(2, record.LastName, row);
                Grid.VerifyCellContents(3, record.FirstName, row);
                Grid.VerifyCellContents(4, record.ContactType?.Name, row);
                Grid.VerifyCellContents(5, record.Phone, row);
                Grid.VerifyCellContents(6, record.Email, row);
                Grid.VerifyCellContents(7, record.CompanyName, row);
                Grid.VerifyCellContents(8, record.Title, row);
            }
        }
        
        public static MatterToContact GenerateRecord()
        {
            var append = DateTime.Now.ToString("fff");
            return new MatterToContact
            {
                FirstName = "First" + append,
                LastName = "aaaLast" + append,
                CompanyName = Data.GetCompany().OrderBy(x => Guid.NewGuid()).First().Name,
                ContactTypeName = Data.GetContactType().OrderBy(x => Guid.NewGuid()).First().Name,
                Phone = "+1 555 666 7" + append,
                PhoneAlternate = "+1 444 555 6" + append,
                Email = "testuser" + append + "@testing.com",
                Title = "Title" + append,
                Primary = Test.RandomBoolean()
            };           
        }

        public static void UpdateRecord(MatterToContact record)
        {
            test.SelectField(By.XPath(ContactType), record.ContactTypeName ?? "");
            test.EditField(By.XPath(ContactFirstName), record.FirstName ?? "");
            test.EditField(By.XPath(ContactLastName), record.LastName ?? "");
            Test.EditCombo(CompanyName, record.CompanyName ?? "");
            test.EditField(By.XPath(Title), record.Title ?? "");
            test.EditField(By.XPath(PhoneNumber), record.Phone ?? "");
            test.EditField(By.XPath(PhoneNumber2), record.PhoneAlternate ?? "");
            test.EditField(By.XPath(Email), record.Email ?? "");
            Test.SetToggle(Primary, record.Primary);
        }

        public static List<Test.FieldDetail> FieldValidation()
        {
            var lastName = "aaa" + Test.GenerateString(27);
            var email = Test.GenerateString(61) + "@mail.com";
            return new List<Test.FieldDetail>
            {
                //Contact Type Dropdown
                new Test.FieldDetail
                {
                    Label = "First Name",
                    Length = 25
                },
                new Test.FieldDetail
                {
                    Label = "Last Name",
                    ValidText = lastName,
                    Length = 30
                },
                new Test.FieldDetail
                {
                    Label = "Last Name",
                    InvalidText = "",
                    ValidText = lastName,
                    Length = 30,
                    ValidationType = "$error.required"
                },
                new Test.FieldDetail
                {
                    Type = "combo",
                    Label = "Company",
                    Length = 100
                },
                new Test.FieldDetail
                {
                    Label = "Title",
                    Length = 70
                },
                new Test.FieldDetail
                {
                    Label = "Phone Number",
                    Length = 15,
                    InvalidText = Test.GenerateString(15),
                    ValidText = "+1 555 666 " + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneFormat"
                },
                new Test.FieldDetail
                {
                    Label = "Phone Number",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(3),
                    ValidText = "+2" + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneMinLength"
                },
                new Test.FieldDetail
                {
                    Label = "Phone Number",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(20),
                    ValidText = "+2" + Test.GenerateNumberString(19),
                    ValidationType = "$error.phoneMaxLength"
                },
                new Test.FieldDetail
                {
                    Label = "Phone Number 2",
                    Length = 15,
                    InvalidText = Test.GenerateString(15),
                    ValidText = "+1 555 666 " + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneFormat"
                },
                new Test.FieldDetail
                {
                    Label = "Phone Number 2",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(3),
                    ValidText = "+2" + Test.GenerateNumberString(4),
                    ValidationType = "$error.phoneMinLength"
                },
                new Test.FieldDetail
                {
                    Label = "Phone Number 2",
                    Length = 15,
                    InvalidText = "+2" + Test.GenerateNumberString(20),
                    ValidText = "+2" + Test.GenerateNumberString(19),
                    ValidationType = "$error.phoneMaxLength"
                },
                new Test.FieldDetail
                {
                    Label = "Email",
                    InvalidText = Test.GenerateString(62) + "@mail.com",
                    ValidText = email,
                    Length = 70
                },
                new Test.FieldDetail
                {
                    Label = "Email",
                    InvalidText = Test.GenerateString(70),
                    ValidText = email,
                    Length = 70,
                    ValidationType = "$error.pattern"

                },
                new Test.FieldDetail
                {
                    Label = "Email",
                    InvalidText = "",
                    ValidText = email,
                    Length = 70,
                    ValidationType = "$error.required"
                }
                //Primary Toggle
            };
        }

        public static MatterToContact ToMatterToContact(Contact record, int matterId)
        {
            return new MatterToContact
            {
                MatterId = matterId,
                ContactId = record.ContactId,
                ContactTypeName = record.ContactType?.Name,
                FirstName = record.FirstName,
                LastName = record.LastName,
                CompanyName = record.CompanyName,
                Title = record.Title,
                Email = record.Email,
                Phone = record.Phone,
                PhoneAlternate = record.PhoneAlternate,
                Primary = false  //Primary is stripped when associated.
            };
        }

        public static void SelectContact(By by)
        {
            report.Action("Select", by.ToString());            
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));

            test.WaitForPageToLoad(test.driver);
            wait.Until(d => d.FindElement(by).Enabled);
            wait.Until(ExpectedConditions.ElementToBeClickable(by));           
            test.ScrollTo(test.driver, by); //Chrome requires element onscreen to click
            test.dismissToasts(test.driver);
            test.driver.FindElement(by).Click();
            test.WaitForPageToLoad(test.driver);     
        }
    }
}
