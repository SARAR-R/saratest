﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Automation;
using OpenQA.Selenium;
using System.Windows.Forms;
using BreachPortal.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;

namespace BreachPortal.Matter
{
    public class FileUpload
    {
        #region Variables

        public static string Section = "//div[@class='panel-heading hand']/span[text()='File Upload']";
        public static string Directive = "//uploader";
        public static By _SelectFile = By.XPath("//button[@pl-instance='vm.uploader']");
        public static By _UploadAndValidateFile = By.XPath("//button[@ng-click='vm.doUpload()']");
        public static By _Clear = By.XPath("//button[@ng-click='vm.clear()']");
        public static By _FileError = By.XPath("//ul[@class='error-file-list']//div[contains(@class, 'col')][2]");
        public static By _FileStatus = By.XPath("//ul[@class='file-list']//div[contains(@class, 'col')][3]");
        public static By _FileResults = By.XPath("//div[@uib-collapse='panelResultsCollapsed']");
        public static By _SectionHiddenMessage = By.XPath("//div[@ng-hide='!vm.hideUpload || !vm.canUpload']");
        #endregion

        public static void ValidateFileSize()
        {
            report.Step("Verify File Size Validation");
            SelectFile();
            System.Threading.Thread.Sleep(2000);
            SendKeys.SendWait(Config.FilePath + "SizeValidation.xls");
            SendKeys.SendWait("{ENTER}");
            System.Threading.Thread.Sleep(2000);
            test.VerifyFieldText(_FileError, "File size error.");
            test.VerifyElementEnabled(_UploadAndValidateFile, false);
            test.Click(_Clear);
        }

        public static void ValidateFileType()
        {
            report.Step("Verify File Type Validation");
            SelectFile();
            System.Threading.Thread.Sleep(2000);
            SendKeys.SendWait(Config.FilePath + "TypeValidation.pdf");
            SendKeys.SendWait("{ENTER}");
            System.Threading.Thread.Sleep(2000);
            test.VerifyFieldText(_FileError, "File extension error.");
            test.VerifyElementEnabled(_UploadAndValidateFile, false);
            test.Click(_Clear);
        }

        public static void ValidateFileUpload(FileValidation expected, string resultMessage)
        {
            ValidateFileUpload(expected, new List<string> {resultMessage});
        }

        public static void ValidateFileUpload(FileValidation expected, List<string> resultMessage)
        {
            if (!File.Exists(Config.FilePath + expected.FileName))
            {
                report.Fail("File does not exist: " + Config.FilePath + expected.FileName);
                
                return;
            }
            var lastUpload = Data.GetFileValidation().LastOrDefault()?.FileValidationId;
            VerifyResult(UploadFile(Config.FilePath + expected.FileName), resultMessage);
            if (lastUpload == null)
            {
                VerifyLog(expected,
                    Data.GetFileValidation().LastOrDefault());
            }
            else
            {
                VerifyLog(expected,
                    Data.GetFileValidation().LastOrDefault(x => x.FileValidationId > lastUpload));
            }
        }

        public static string UploadFile(string filePath)
        {
            report.Step("Upload file: " + filePath);
            SelectFile();
            System.Threading.Thread.Sleep(2000);
            SendKeys.SendWait(filePath);
            SendKeys.SendWait("{ENTER}");
            System.Threading.Thread.Sleep(2000);
            test.Click(_UploadAndValidateFile);
            test.WaitForElement(_FileStatus);
            test.VerifyFieldText(_FileStatus, "Done");
            return test.driver.FindElement(_FileResults).Text;
        }

        public static int VerifyResult(string result, List<string> expected)
        {
            try
            {                
                foreach (var line in expected)
                {
                    if (result.Contains(line)) continue;
                    report.Fail("File result did not contain the expected text: " + line);
                    report.Fail("Result: " + result);
                    return 1;
                }
                report.Pass("File result contains the expected text: ");
                foreach (var line in expected) Console.WriteLine(line);

                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying the result.", e);
                return 1;
            }
        }

        public static void SelectFile()
        {
            report.Action("Click", "Select File");
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
            try
            {
                wait.Until(d => d.FindElement(_SelectFile).Enabled);
                wait.Until(ExpectedConditions.ElementToBeClickable(_SelectFile));
                test.WaitForPageToLoad(test.driver);
                test.ScrollTo(test.driver, _SelectFile); //Chrome requires element onscreen to click
                test.dismissToasts(test.driver);
                test.driver.FindElement(_SelectFile).Click();
            }
            catch (Exception e)
            {
                report.Fail("Unable to click Select File.", e);
                Assert.Fail(e.ToString());
            }
        }

        public static int VerifyLog(FileValidation expected, FileValidation actual)
        {
            if (actual == null)
            {
                report.Fail("Upload was not successfully logged.");
                return 1;
            }
            var failures = new List<string>();
            if (expected.FileName != actual.FileName) failures.Add("Filename: " + actual.FileName + " instead of " + expected.FileName);
            if (expected.IsValid != actual.IsValid) failures.Add("IsValid: " + actual.IsValid + " instead of " + expected.IsValid);
            if (expected.MatterId != actual.MatterId) failures.Add("MatterId: " + actual.MatterId + " instead of " + expected.MatterId);
            if (expected.CreatedBy != actual.CreatedBy) failures.Add("CreatedBy: " + actual.CreatedBy + " instead of " + expected.CreatedBy);
            if (expected.RecordCount != actual.RecordCount) failures.Add("RecordCount: " + actual.RecordCount + " instead of " + expected.RecordCount);
            if (expected.ErrorCount != actual.ErrorCount) failures.Add("ErrorCount: " + actual.ErrorCount + " instead of " + expected.ErrorCount);
            if (failures.Count > 0)
            {
                report.Fail("Upload logged incorrect details:");
                foreach (var failure in failures) Console.WriteLine(failure);               
                return 1;
            }
            report.Pass("Upload has been successfully logged as FileValidationId: " + actual.FileValidationId);
            return 0;
        }
    }
}
