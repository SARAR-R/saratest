﻿using Automation;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace BreachPortal.Matter
{
    public class BasicInfo
    {
        #region Variables
        
        public static By _Save = By.XPath("//button[@ng-click='vm.save()']");
        public static By _Cancel = By.XPath("//button[@ng-click='vm.cancel()']");
        public static By _Submit = By.XPath("//button[@ng-click='vm.submit()']");
        public static By _Delete = By.XPath("//button[@ng-click='vm.delete()']");
        public static By _ErrorMessage = By.XPath("//div[contains(@ng-show,'vm.validationErrors')]//span");

        public static string Section = "//div[@class='panel-heading hand']/span[text()='Basic Information']";
        public static string MatterName = "//input[@ng-model='vm.matter.matterName']";
        public static string CompanyName = "//input[@ng-model='vm.matter.companyName']";
        public static string InsuranceCompany = "//select[@ng-model='vm.matter.insuranceCompanyId']";
        public static string Other = "//input[@ng-model='vm.matter.insuranceCompanyNameOther']";
        public static string AffectedPopulationSize = "//input[@ng-model='vm.matter.affectedPopulationSize']";
        public static string LawFirm = "//input[@ng-model='vm.matter.lawFirm']";
        public static string Status = "//select[@ng-model='vm.matter.status']";
        public static string EnrollmentDeadline = "//input[@ng-model='vm.matter.enrollmentDeadlineDate']";
        public static string RegulatoryDeadline = "//input[@ng-model='vm.matter.regulatoryDeadlineDate']";
        public static string ProjectedMailDate = "//input[@ng-model='vm.matter.projectedMailDate']";
        public static string CallCenterLiveDate = "//input[@ng-model='vm.matter.callCenterLiveDate']";
        public static string CallCenterLiveNotificationInterval = "//input[@ng-model='vm.matter.callCenterLiveNotificationInterval']";
        public static string CallCenterLiveNotificationDate = "//input[@ng-model='vm.matter.callCenterLiveNotificationDate']";
        public static string DeliverablesReceivedDate = "//input[@ng-model='vm.matter.deliverablesReceivedDate']";
        public static string NoticeTypes = "//breach-portal-pill-multi-select//input";
        public static string NoticeTypePill = "//breach-portal-pill-multi-select//button";
        public static string EBlast = "//breach-portal-checkbox-toggle[@value='vm.matter.isEblast']";
        public static string W2 = "//breach-portal-checkbox-toggle[@value='vm.matter.isW2']";
        public static string RushFee = "//breach-portal-checkbox-toggle[@value='vm.matter.isRushFee']";
        public static string CreditMonitoring = "//breach-portal-checkbox-toggle[@value='vm.matter.isCreditMonitored']";
        public static string Equifax = "//breach-portal-checkbox-toggle[@value='vm.matter.hasEquifax']";
        public static string Experian = "//breach-portal-checkbox-toggle[@value='vm.matter.hasExperian']";
        public static string Transunion = "//breach-portal-checkbox-toggle[@value='vm.matter.hasTransunion']";
        
        #endregion

        public static void ValidateRecord(Database.Matter record, List<Database.MatterNoticeType> noticeTypes)
        {
            if (!string.IsNullOrEmpty(record.MatterName)) test.WaitForTextInElement(By.XPath(MatterName));
            test.VerifyFieldValue(By.XPath(MatterName), record.MatterName ?? "");
            test.VerifyFieldValue(By.XPath(CompanyName), record.CompanyName ?? "");
            test.VerifySelectedValue(By.XPath(InsuranceCompany), record.InsuranceCompany?.Name ?? "");
            if (!string.IsNullOrEmpty(record.InsuranceCompanyNameOther))
            {
                test.VerifyFieldValue(By.XPath(Other), record.InsuranceCompanyNameOther ?? "");
            }
            else
            {
                test.VerifyElementExists(By.XPath(Other), false);    
            }
            test.VerifyFieldValue(By.XPath(AffectedPopulationSize),
                record.AffectedPopulationSize.ToString());
            test.VerifyFieldValue(By.XPath(LawFirm), record.LawFirm ?? "");
            test.VerifySelectedValue(By.XPath(Status), record.Status ?? "");
            VerifyNoticeTypes(noticeTypes);
            Test.VerifyToggleValue(EBlast, record.IsEblast);
            Test.VerifyToggleValue(W2, record.IsW2);
            Test.VerifyToggleValue(RushFee, record.IsRushFee);
            Test.VerifyToggleValue(CreditMonitoring, record.IsCreditMonitored);
            Test.VerifyToggleValue(Equifax, record.HasEquifax);
            Test.VerifyToggleValue(Experian, record.HasExperian);
            Test.VerifyToggleValue(Transunion, record.HasTransunion);
            test.VerifyFieldValue(By.XPath(EnrollmentDeadline),
                Format.Date(record.EnrollmentDeadlineDate));
            test.VerifyFieldValue(By.XPath(RegulatoryDeadline),
                Format.Date(record.RegulatoryDeadlineDate));
            test.VerifyFieldValue(By.XPath(ProjectedMailDate),
                Format.Date(record.ProjectedMailDate));
            test.VerifyFieldValue(By.XPath(CallCenterLiveDate),
                Format.Date(record.CallCenterLiveDate));
            test.VerifyFieldValue(By.XPath(CallCenterLiveNotificationInterval),
                record.CallCenterLiveNotificationInterval.ToString());
            test.VerifyFieldValue(By.XPath(CallCenterLiveNotificationDate),
                Format.Date(record.CallCenterLiveNotificationDate));
            test.VerifyFieldValue(By.XPath(DeliverablesReceivedDate),
                Format.Date(record.DeliverablesReceivedDate));
            Test.VerifySectionValue(PrintingAndMailing.Section,
                record.HasPrintingAndMailing);
            Test.VerifySectionValue(Ivr.Section, record.HasIVR);
            Test.VerifySectionValue(CallCenter.Section, record.HasCallCenter);
        }

        public static Database.Matter GenerateRecord(int? matterId = null)
        {
            var append = DateTime.Now.ToString("fff");
            var record = (matterId != null) ? Data.GetMatter((int) matterId) : new Database.Matter();
            record.MatterName = "MatterName" + append;
            record.CompanyName = "CompanyName" + append;
            record.InsuranceCompany = Data.GetInsuranceCompany().OrderBy(x => Guid.NewGuid()).First();
            record.InsuranceCompanyNameOther = (record.InsuranceCompany?.Name == "Other")                                              
                ? "Other " + append
                : null;
            record.AffectedPopulationSize = new Random().Next(0, 99999999);
            record.LawFirm = Data.GetLawFirm().OrderBy(x => Guid.NewGuid()).First().Name;
            record.Status = new [] {"Active", "Closed" } [new Random().Next(0, 2)];
            record.IsEblast = Test.RandomBoolean();
            record.IsW2 = Test.RandomBoolean();
            record.IsRushFee = Test.RandomBoolean();
            record.IsCreditMonitored = Test.RandomBoolean();
            record.HasEquifax = record.IsCreditMonitored && Test.RandomBoolean();
            record.HasExperian = record.IsCreditMonitored && Test.RandomBoolean();
            record.HasTransunion = record.IsCreditMonitored && Test.RandomBoolean();
            record.EnrollmentDeadlineDate = DateTime.Now.AddDays(int.Parse(append));
            record.RegulatoryDeadlineDate = record.EnrollmentDeadlineDate.Value.AddDays(30);
            record.ProjectedMailDate = record.EnrollmentDeadlineDate.Value.AddDays(60);
            record.CallCenterLiveDate = record.EnrollmentDeadlineDate.Value.AddDays(90);
            record.CallCenterLiveNotificationInterval = new Random().Next(1, 999);
            record.CallCenterLiveNotificationDate = record.CallCenterLiveDate.Value.AddDays((double)record.CallCenterLiveNotificationInterval);
            record.DeliverablesReceivedDate = record.EnrollmentDeadlineDate.Value.AddDays(-30);
            record.HasPrintingAndMailing = Test.RandomBoolean();
            record.HasIVR = Test.RandomBoolean();
            record.HasCallCenter = Test.RandomBoolean();
            return record;
        }

        public static List<Database.MatterNoticeType> GenerateNoticeTypes(int totalRecords = 2)
        {
            var records = new List<Database.MatterNoticeType>();
            var count = 1;
            while (count <= totalRecords)
            {
                if (count % 2 == 0) //Alternate standard and custom records
                {
                    System.Threading.Thread.Sleep(10); //Ensure different timestamp
                    records.Add(new Database.MatterNoticeType
                    {
                        Name = "Custom Type " + DateTime.Now.ToString("fff")
                    });
                }
                else
                {
                    records.Add(new Database.MatterNoticeType
                    {
                        Name = Data.GetNoticeType().OrderBy(x => Guid.NewGuid()).First().Name                 
                    });
                }    
                count++;
            }
            return records;
        }
        
        public static void UpdateRecord(Database.Matter record, List<Database.MatterNoticeType> noticeTypes)
        {
            test.EditField(By.XPath(MatterName), record.MatterName ?? "");
            test.EditField(By.XPath(CompanyName), record.CompanyName ?? "");
            test.SelectField(By.XPath(InsuranceCompany), record.InsuranceCompany?.Name);
            if (record.InsuranceCompany?.Name == "Other")
                test.EditField(By.XPath(Other), record.InsuranceCompanyNameOther ?? "");
            test.EditField(By.XPath(AffectedPopulationSize), record.AffectedPopulationSize.ToString());
            Test.EditCombo(LawFirm, record.LawFirm ?? "");
            test.SelectField(By.XPath(Status), record.Status);
            test.EditField(By.XPath(EnrollmentDeadline), Format.Date(record.EnrollmentDeadlineDate));
            test.EditField(By.XPath(RegulatoryDeadline), Format.Date(record.RegulatoryDeadlineDate));
            test.EditField(By.XPath(ProjectedMailDate), Format.Date(record.ProjectedMailDate));
            test.EditField(By.XPath(CallCenterLiveDate), Format.Date(record.CallCenterLiveDate));
            if (record.CallCenterLiveDate != null) 
                test.EditField(By.XPath(CallCenterLiveNotificationInterval), record.CallCenterLiveNotificationInterval.ToString());
            test.EditField(By.XPath(DeliverablesReceivedDate), Format.Date(record.DeliverablesReceivedDate));
            UpdateNoticeTypes(noticeTypes);
            Test.SetToggle(EBlast, record.IsEblast);
            Test.SetToggle(W2, record.IsW2);
            Test.SetToggle(RushFee, record.IsRushFee);
            Test.SetToggle(CreditMonitoring, record.IsCreditMonitored);
            if (record.IsCreditMonitored)
            {
                Test.SetToggle(Equifax, record.HasEquifax);
                Test.SetToggle(Experian, record.HasExperian);
                Test.SetToggle(Transunion, record.HasTransunion);
            }

            Test.SetSection(PrintingAndMailing.Section, record.HasPrintingAndMailing, true);
            Test.SetSection(Ivr.Section, record.HasIVR, true);
            Test.SetSection(CallCenter.Section, record.HasCallCenter, true);
        }

        public static Database.Matter GenerateDefaultValues()
        {
            return new Database.Matter
            {
                Status = "Active",
                IsRushFee = false,
                IsW2 = false,
                IsEblast = false,
                IsCreditMonitored = false,
                HasEquifax = false,
                HasExperian = false,
                HasTransunion = false,
                HasPrintingAndMailing = false,
                HasIVR = false,
                HasCallCenter = false,
                DeliverablesReceivedDate = DateTime.Now
            };
        }

        public static void ValidateDuplicateName(Database.Matter record, List<Database.MatterNoticeType> noticeTypes)
        {
            report.Step("Verify Duplicate Name Validation");
            var dupeName = Data.GetMatter().OrderBy(x => Guid.NewGuid()).First(i => i.MatterId != record.MatterId)
                .MatterName;
            test.EditField(By.XPath(MatterName), dupeName);
            test.Click(_Save);
            test.VerifyText(test.driver, _ErrorMessage,
                dupeName + " already in use, matter names must be unique.");
            test.Click(_Cancel);
            ValidateRecord(record, noticeTypes);
        }

        public static List<Test.FieldDetail> FieldValidation()
        {
            return new List<Test.FieldDetail>
            {
                new Test.FieldDetail
                {
                    Label = "Matter Name",
                    Length = 100
                },
                new Test.FieldDetail
                {
                    Label = "Matter Name",
                    InvalidText = "",
                    Length = 100,
                    ValidationType = "$error.required"
                },
                new Test.FieldDetail
                {
                    Label = "Matter Name",
                    InvalidText = Test.GenerateString(2),
                    Length = 100,
                    ValidationType = "$error.minlength"
                },
                new Test.FieldDetail
                {
                    Label = "Company Name (Breach)",
                    Length = 100
                },
                new Test.FieldDetail
                {
                    Label = "Other Insurance Company Name",
                    Length = 100
                },
                new Test.FieldDetail
                {
                    Label = "Other Insurance Company Name",
                    InvalidText = "",
                    Length = 100,
                    ValidationType = "$error.required"
                },
                new Test.FieldDetail
                {
                    Label = "Affected Population Size",
                    Type = "numeric",
                    Length = 9
                },
                new Test.FieldDetail
                {
                    Label = "Law Firm",
                    Type = "combo",
                    Length = 100
                },
                new Test.FieldDetail
                {
                    Label = "Enrollment Deadline",
                    Type = "date",
                    ValidText = Format.Date(DateTime.Now.AddDays(DateTime.Now.Millisecond)),
                },
                new Test.FieldDetail
                {
                    Label = "Enrollment Deadline",
                    Type = "date",
                    ValidationType = "$error.minimumDateValue",
                    ValidText = "01/01/2014",
                    InvalidText = "12/31/2013"
                },
                new Test.FieldDetail
                {
                    Label = "Regulatory Deadline",
                    Type = "date",
                    ValidText = Format.Date(DateTime.Now.AddDays(DateTime.Now.Millisecond)),
                },
                new Test.FieldDetail
                {
                    Label = "Regulatory Deadline",
                    Type = "date",
                    ValidationType = "$error.minimumDateValue",
                    ValidText = "01/01/2014",
                    InvalidText = "01/01/2013"
                },
                new Test.FieldDetail
                {
                    Label = "Projected Mail Date",
                    Type = "date",
                    ValidText = Format.Date(DateTime.Now.AddDays(DateTime.Now.Millisecond)),
                },
                new Test.FieldDetail
                {
                    Label = "Projected Mail Date",
                    Type = "date",
                    ValidationType = "$error.minimumDateValue",
                    ValidText = "01/01/2014",
                    InvalidText = "05/05/1950"
                },
                new Test.FieldDetail
                {
                    Label = "Call Center Live Date",
                    Type = "date",
                    ValidText = Format.Date(DateTime.Now.AddDays(DateTime.Now.Millisecond)),
                },
                new Test.FieldDetail
                {
                    Label = "Call Center Live Date",
                    Type = "date",
                    ValidationType = "$error.minimumDateValue",
                    ValidText = "01/01/2014",
                    InvalidText = "08/08/1998"
                },
                new Test.FieldDetail
                {
                    Label = "Notification Interval",
                    Type = "numeric",
                    ValidText = "999",
                    Field = By.XPath(CallCenterLiveNotificationInterval),
                    Validation = By.XPath("//label[text()='Notification Interval']//following-sibling::div//following-sibling::span[contains(@ng-show | @ng-if, '$error.pattern')]"),
                    Length = 3
                },
                new Test.FieldDetail
                {
                    Label = "Deliverables Received",
                    Type = "date",
                    ValidText = Format.Date(DateTime.Now.AddDays(DateTime.Now.Millisecond)),
                },
                new Test.FieldDetail
                {
                    Label = "Deliverables Received",
                    Type = "date",
                    ValidationType = "$error.minimumDateValue",
                    ValidText = "01/01/2014",
                    InvalidText = "08/08/1998"
                }
            };
        }

        public static int VerifyLastUpdated(string by, string date)
        {
            var text = test.driver.FindElement(By.XPath("//breach-portal-last-update/span")).Text;
            try
            {
                if (!text.Contains(by) || !text.Contains(date))
                    throw new Exception(text + " does not contain " + by + " and " + date);
                report.Pass("Last Updated by contains " + by + " and " + date);
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Error occurred: ", e);
                return 1;
            }
        }

        public static void Save()
        {
            test.Click(_Save);
            test.VerifyNoErrorToasts();
        }

        public static int VerifyNoticeTypes(List<Database.MatterNoticeType> records)
        {
            try
            {
                if (records == null || records.Count == 0)
                {
                    var actual = test.driver.FindElements(By.XPath("//breach-portal-pill-multi-select//button")).Count;
                    if (actual == 0)
                    {
                        report.Pass("There are no notice types associated as expected.");
                        return 0;
                    }
                    else
                    {
                        report.Fail("There were " + actual + " notice types associated unexpectedely.");
                        return 1;
                    }
                    
                }
                var failures = 0;
                foreach (var record in records)
                {
                    failures += test.VerifyElementExists(
                        By.XPath("//breach-portal-pill-multi-select//button[contains(text(), '" + record.Name + "')]"));
                }
                return failures > 0 ? 1 : 0;
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying Notice Types", e);
                return 1;
            }
        }

        public static void UpdateNoticeTypes(List<Database.MatterNoticeType> records)
        {
            try
            {
                while (test.driver.FindElements(By.XPath("//breach-portal-pill-multi-select//button")).Count > 0)
                { 
                    test.Click(By.XPath("//breach-portal-pill-multi-select//button"));
                }
                if (records == null || records.Count == 0)
                {
                    report.Action("Skip", "No Notice Types to add");
                    return;
                }
                foreach (var record in records)
                {
                    report.Action("Add", "Pill", record.Name);
                    var action = new Actions(test.driver);
                    action.MoveToElement(test.driver.FindElement(By.XPath("//div[@class='pill-box']"))).Perform();
                    var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
                    wait.Until(d => d.FindElement(By.XPath(NoticeTypes)).Enabled);
                    test.WaitForPageToLoad();
                    test.driver.FindElement(By.XPath(NoticeTypes)).Clear();
                    test.driver.FindElement(By.XPath(NoticeTypes)).SendKeys(record.Name + Keys.Enter);
                    test.WaitForPageToLoad();
                }
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while updating Notice Types.", e);
                
            }
        }
    }
}