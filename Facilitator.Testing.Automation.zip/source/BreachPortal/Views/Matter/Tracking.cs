﻿using System;
using System.Collections.Generic;
using Automation;
using OpenQA.Selenium;

namespace BreachPortal.Matter
{
    public class Tracking
    {
        #region Variables

        public static string Section = "//div[@class='panel-heading hand']/span[text()='Tracking']";
        public static string SapContractCode = "//input[@ng-model='vm.matter.tracking.sapContractCode']";
        public static string CaseSetupSrNumber = "//input[@ng-model='vm.matter.tracking.caseSetupSRNumber']";
        public static string CaseCode = "//input[@ng-model='vm.matter.tracking.caseCode']";
        public static string Notes = "//textarea[@ng-model='vm.matter.tracking.notes']";
        
        #endregion

        public static void ValidateRecord(Database.Tracking record)
        {
            if (record == null)
            {
                report.Action("Skip", "No Tracking data to validate.");
                return;
            }
            test.VerifyFieldValue(By.XPath(SapContractCode), record.SAPContractCode ?? "");
            test.VerifyFieldValue(By.XPath(CaseSetupSrNumber), record.CaseSetupSRNumber ?? "");
            test.VerifyFieldValue(By.XPath(CaseCode), record.CaseCode ?? "");
            test.VerifyFieldValue(By.XPath(Notes), record.Notes ?? "");
        }

        public static Database.Tracking GenerateRecord(int? matterId = null)
        {
            var append = DateTime.Now.ToString("fff");
            var record = (matterId != null) ? Data.GetTracking((int)matterId) ?? new Database.Tracking() : new Database.Tracking();
            record.SAPContractCode = "99999" + append;
            record.CaseSetupSRNumber = "88888" + append;
            record.CaseCode = "CA0" + append;
            record.Notes = "Notes " + append;
            return record;
        }

        public static void UpdateRecord(Database.Tracking record)
        {
            test.EditField(By.XPath(SapContractCode), record.SAPContractCode ?? "");
            test.EditField(By.XPath(CaseSetupSrNumber), record.CaseSetupSRNumber ?? "");
            test.EditField(By.XPath(CaseCode), record.CaseCode ?? "");
            test.EditField(By.XPath(Notes), record.Notes ?? "");
        }

        public static List<Test.FieldDetail> FieldValidation()
        {
            return new List<Test.FieldDetail>
            {
                new Test.FieldDetail
                {
                    Label = "SAP Contract Code",
                    Type = "numeric",
                    Length = 8
                },
                new Test.FieldDetail
                {
                    Label = "SAP Contract Code",
                    Type = "numeric",
                    Length = 8,
                    InvalidText = Test.GenerateNumberString(9),
                    ValidationType = "$error.maxlength"
                },   
                new Test.FieldDetail
                {
                    Label = "SAP Contract Code",
                    Type = "numeric",
                    Length = 8,
                    InvalidText = Test.GenerateNumberString(7),
                    ValidationType = "$error.minlength"
                },
                new Test.FieldDetail
                {
                    Label = "Case Setup SR Number",
                    Type = "numeric",
                    Length = 20
                },
                new Test.FieldDetail
                {
                    Label = "Case Setup SR Number",
                    Type = "numeric",
                    Length = 20,
                    InvalidText = Test.GenerateNumberString(21),
                    ValidationType = "$error.maxlength"
                },
                new Test.FieldDetail
                {
                    Label = "Case Code",
                    Length = 20
                },
                new Test.FieldDetail
                {
                    Label = "Notes",
                    Length = 8000
                },
            };
        }
    }
}
