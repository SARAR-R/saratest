﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using OpenQA.Selenium;

namespace BreachPortal.Matter
{
    public class PrintingAndMailing
    {
        #region Variables

        public static string Section = "//breach-portal-panel-toggle[@value='vm.matter.hasPrintingAndMailing']";
        public static string StandardForms = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.standardForms']";
        public static string CustomText = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.customText']";
        public static string QcRequired = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.qcRequired']";
        public static string StandardPaperAndEnvelopes = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.standardPaperAndEnvelopes']";
        public static string CustomLogo = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.customLogo']";
        public static string CustomSignature = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.customSignature']";
        public static string Duplex = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.duplex']";
        public static string TranslationServices = "//breach-portal-checkbox-toggle[@value='vm.matter.printingAndMailing.translationServices']";
        public static string Turnaround = "//select[@ng-model='vm.matter.printingAndMailing.turnAroundId']";
        public static string PrintingAndMailingNotes = "//textarea[@ng-model='vm.matter.printingAndMailing.notes']";

        #endregion

        public static void ValidateRecord(Database.PrintingAndMailing record)
        {
            if (record == null)
            {
                report.Action("Skip", "No Printing And Mailing data to validate.");
                return;
            }            
            Test.VerifyToggleValue(StandardForms, record.StandardForms);
            Test.VerifyToggleValue(CustomText, record.CustomText);
            Test.VerifyToggleValue(QcRequired, record.QCRequired);
            Test.VerifyToggleValue(StandardPaperAndEnvelopes, record.StandardPaperAndEnvelopes);
            Test.VerifyToggleValue(CustomLogo, record.CustomLogo);
            Test.VerifyToggleValue(CustomSignature, record.CustomSignature);
            Test.VerifyToggleValue(Duplex, record.Duplex);
            Test.VerifyToggleValue(TranslationServices, record.TranslationServices);
            test.VerifySelectedValue(By.XPath(Turnaround), record.TurnAround?.Name ?? "");
            test.VerifyFieldValue(By.XPath(PrintingAndMailingNotes), record.Notes ?? "");
        }

        public static Database.PrintingAndMailing GenerateRecord(int? matterId = null)
        {
            var append = DateTime.Now.ToString("fff");
            var record = (matterId != null) ? Data.GetPrintingAndMailing((int)matterId) ?? new Database.PrintingAndMailing() : new Database.PrintingAndMailing();
            var turnAround = 
            record.StandardForms = Test.RandomBoolean();
            record.CustomText = Test.RandomBoolean();
            record.QCRequired = Test.RandomBoolean();
            record.StandardPaperAndEnvelopes = Test.RandomBoolean();
            record.CustomLogo = Test.RandomBoolean();
            record.CustomSignature = Test.RandomBoolean();
            record.Duplex = Test.RandomBoolean();
            record.TranslationServices = Test.RandomBoolean();
            record.TurnAround = Data.GetTurnAround().OrderBy(x => Guid.NewGuid()).First();
            record.Notes = "Notes" + append;
            return record;
        }

        public static void UpdateRecord(Database.PrintingAndMailing record)
        {
            Test.SetSection(Section, true);
            Test.SetToggle(StandardForms, record.StandardForms);
            Test.SetToggle(CustomText, record.CustomText);
            Test.SetToggle(QcRequired, record.QCRequired);
            Test.SetToggle(StandardPaperAndEnvelopes, record.StandardPaperAndEnvelopes);
            Test.SetToggle(CustomLogo, record.CustomLogo);
            Test.SetToggle(CustomSignature, record.CustomSignature);
            Test.SetToggle(Duplex, record.Duplex);
            Test.SetToggle(TranslationServices, record.TranslationServices);
            test.SelectField(By.XPath(Turnaround), record.TurnAround?.Name ?? "");
            test.EditField(By.XPath(PrintingAndMailingNotes), record.Notes ?? "");

        }

        public static List<Test.FieldDetail> FieldValidation()
        {
            return new List<Test.FieldDetail>
            {
                new Test.FieldDetail
                {
                    Label = "Printing and Mailing Notes",
                    Length = 8000
                }
            };
        }

        public static Database.PrintingAndMailing GenerateDefaultValues()
        {
            return new Database.PrintingAndMailing
            {
                StandardForms = false,
                CustomLogo = false,
                CustomText = false,
                CustomSignature = false,
                QCRequired = false,
                Duplex = false, 
                StandardPaperAndEnvelopes = false, 
                TranslationServices = false, 
                TurnAround = Data.GetTurnAround().First(n => n.Name == "5 Days")

            };
        }

    }
}
