﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using BreachPortal.Database;
using OpenQA.Selenium;

namespace BreachPortal
{
    public class MaintainContact
    {
        #region Variables
        public static By _TextFilter = By.XPath("//input[@ng-model='vm.searchText']");
        public static string Edit = Grid.Edit;
        public static string View = Grid.View;
        public static string Delete = Grid.Delete;
        public static By _Add = By.XPath("//button[@ng-click='vm.add()']");

        public static List<Grid.ColumnDetails> Columns = new List<Grid.ColumnDetails>
        {
            new Grid.ColumnDetails {Label = "Last Name"},
            new Grid.ColumnDetails {Label = "First Name"},
            new Grid.ColumnDetails {Label = "Type"},
            new Grid.ColumnDetails {Label = "Phone Number"},
            new Grid.ColumnDetails {Label = "Email"},
            new Grid.ColumnDetails {Label = "Company"},
            new Grid.ColumnDetails {Label = "Title"}
        };

        //Modal Elements
        public static string ContactType = "//select[@ng-model='vm.contact.contactTypeId']";
        public static string ContactFirstName = Matter.Contacts.ContactFirstName;
        public static string ContactLastName = Matter.Contacts.ContactLastName;
        public static string CompanyName = Matter.Contacts.CompanyName;
        public static string Title = Matter.Contacts.Title;
        public static string PhoneNumber = Matter.Contacts.PhoneNumber;
        public static string PhoneNumber2 = Matter.Contacts.PhoneNumber2;
        public static string Email = Matter.Contacts.Email;
        public static By _ModalSave = Matter.Contacts._ModalSave;
        public static By _ModalCancel = Matter.Contacts._ModalCancel;
        public static By _ModalDelete = Matter.Contacts._ModalDelete;
        #endregion

        public static void ValidateRecords(List<Contact> records, int pageSize = 10, bool sortByLast = true) //Update with maintain table
        {
            try
            {
                if (records.Count > 0) test.WaitForElement(By.XPath(Grid.Row));
                var expectedMax = pageSize > 16 ? 16 : pageSize;  //Grid will show at most 16 rows
                Grid.VerifyRowCount(By.XPath(Grid.Row), (records.Count > expectedMax) ? expectedMax : records.Count);

                if (sortByLast)
                {
                    Grid.SortByColumn("Last Name", "asc");
                    records = records.OrderBy(l => l.LastName).ToList();
                }

                var row = 0;
                foreach (var record in records)
                {
                    row++;
                    if (row > pageSize) continue;
                    Grid.VerifyCellContents(2, record.LastName, row);
                    Grid.VerifyCellContents(3, record.FirstName, row);
                    Grid.VerifyCellContents(4, record.ContactType?.Name, row);
                    Grid.VerifyCellContents(5, record.Phone, row);
                    Grid.VerifyCellContents(6, record.Email, row);
                    Grid.VerifyCellContents(7, record.CompanyName, row);
                    Grid.VerifyCellContents(8, record.Title, row);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate records failed due to: ", e);
                navigate.Refresh();
            }
           
        }

        public static void ValidateRecords(Contact record, int pageSize = 10)
        {
            ValidateRecords(new List<Contact>{record}, pageSize);
        }

        public static void ValidateRecord(Contact record)
        {
            test.VerifySelectedValue(By.XPath(ContactType), record.ContactType?.Name ?? "");
            test.VerifyFieldValue(By.XPath(ContactFirstName), record.FirstName ?? "");
            test.VerifyFieldValue(By.XPath(ContactLastName), record.LastName ?? "");
            test.VerifyFieldValue(By.XPath(CompanyName), record.CompanyName ?? "");
            test.VerifyFieldValue(By.XPath(Title), record.Title ?? "");
            test.VerifyFieldValue(By.XPath(PhoneNumber), record.Phone ?? "");
            test.VerifyFieldValue(By.XPath(PhoneNumber2), record.PhoneAlternate ?? "");
            test.VerifyFieldValue(By.XPath(Email), record.Email ?? "");   
        }

        public static Contact GenerateRecord()
        {
            var append = DateTime.Now.ToString("fff");
            return new Database.Contact
            {
                FirstName = "First" + append,
                LastName = "aaaLast" + append,
                CompanyName = Data.GetCompany().OrderBy(x => Guid.NewGuid()).First().Name,
                ContactType = Data.GetContactType().OrderBy(x => Guid.NewGuid()).First(),
                Phone = "+1 555 666 7" + append,
                PhoneAlternate = "+1 333 444 5" + append,
                Email = "testuser" + append + "@testing.com",
                Title = "Title" + append
            };          
        }

        public static void UpdateRecord(Contact record)
        {
            test.SelectField(By.XPath(ContactType), record.ContactType?.Name ?? "");
            test.EditField(By.XPath(ContactFirstName), record.FirstName ?? "");
            test.EditField(By.XPath(ContactLastName), record.LastName ?? "");
            Test.EditCombo(CompanyName, record.CompanyName ?? "");
            test.EditField(By.XPath(Title), record.Title ?? "");
            test.EditField(By.XPath(PhoneNumber), record.Phone ?? "");
            test.EditField(By.XPath(PhoneNumber2), record.PhoneAlternate ?? "");
            test.EditField(By.XPath(Email), record.Email ?? "");
        }

        public static void ValidateModalEditability(bool edit)
        {
            test.VerifyElementEnabled(By.XPath(ContactType), edit);
            test.VerifyElementEditability(By.XPath(ContactFirstName), edit);
            test.VerifyElementEditability(By.XPath(ContactLastName), edit);
            test.VerifyElementEditability(By.XPath(CompanyName), edit);
            test.VerifyElementEditability(By.XPath(Title), edit);
            test.VerifyElementEditability(By.XPath(PhoneNumber), edit);
            test.VerifyElementEditability(By.XPath(PhoneNumber2), edit);
            test.VerifyElementEditability(By.XPath(Email), edit);
        }

        public static List<Test.FieldDetail> FieldValidation()
        {
            return Matter.Contacts.FieldValidation();
        }


        public static List<Contact> GetFilteredContacts(string filterText)
        {
            //Actual - Current bug 265399
            return Data.GetContact().Where(c => 
                ((c.Email ?? "") + (c.LastName ?? "") + (c.FirstName ?? "")).ToUpper().Contains(filterText.ToUpper())
            ).OrderBy(l => l.LastName).ToList();
            
            //Expected.
            //return Data.GetContact().Where(c => 
            //    c.LastName != null && c.LastName.ToUpper().Contains(filterText.ToUpper())
            //    || c.FirstName != null && c.FirstName.ToUpper().Contains(filterText.ToUpper())
            //    || c.Email != null && c.Email.ToUpper().Contains(filterText.ToUpper())
            //).OrderBy(l => l.LastName).ToList();
        }
    }
}
