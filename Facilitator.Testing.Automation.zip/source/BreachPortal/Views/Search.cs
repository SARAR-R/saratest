﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using OpenQA.Selenium;

namespace BreachPortal
{
    public class Search
    {

        #region Variables

        public static By _QuickCriteria = By.XPath("//input[@ng-model='vm.criteria']");
        public static By _QuickSubmit = By.XPath("//button[@ng-click='vm.searchClick()']");
        public static By _HeaderCriteria = By.XPath("//input[@ng-model='vm.quickSearchCriteria']");
        public static By _HeaderSubmit = By.XPath("//button[@ng-click='vm.quickSearchClick()']");

        #endregion

        public class SearchResult
        {
            public int MatterId { get; set; }
            public string MatchedColumn { get; set; }
            public string MatterName { get; set; }
            public string Status { get; set; }
            public string CompanyName { get; set; }
            public string InsuranceCompany { get; set; }
            public string EnrollmentDeadline { get; set; }
            public string CreditMonitoring { get; set; }
            public string StateSpecific { get; set; }
            public string SapContractCode { get; set; }
            public string CaseSetupSrNumber { get; set; }
        }

        public static void NewQuickSearch()
        {
            if (!test.driver.Url.Contains("/quicksearch"))
            {
                test.Click(Navigate._Search);
            }
            else
            {
                if (test.driver.FindElement(By.XPath("//span[text()='Filter Criteria & Available Columns']/../following-sibling::div")).GetAttribute("class").Contains("collapse in") == false)
                {
                    test.ToggleSection("Filter Criteria & Available Columns");
                }
            }
        }

        public static void ValidateQuickSearch(string value)
        {
            report.Step("Verify Quick Search on " + value);
            NewQuickSearch();
            SelectAllColumns();
            test.EditField(_QuickCriteria, "\"" + value + "\"");
            test.Click(_QuickSubmit);
            test.VerifyNoErrorToasts();
            var searchResults = Data.GetSearchResults(value);
            if (searchResults.Count == 0)
                throw new Exception("There were no results for the following criteria: " + value);
            ValidateSearchResults(searchResults);
        }

        public static int VerifySearchResult(By by, string expected)
        {
            var errors = 0;
            try
            {
                if (test.driver.Url.Contains("/matterdetail"))
                {
                    test.WaitForPageToLoad();
                    return test.VerifyFieldValue(by, expected);
                }
                const string rowXpath = "//div[@ng-grid='vm.gridOptions']//div[contains(@class, 'grid-row')]";
                var rows = test.driver.FindElements(By.XPath(rowXpath)).Count;
                for (var i = 1; i <= rows; i++)
                {
                    var columnName = test.driver.FindElement(By.XPath("((" + rowXpath + ")[" + i + "]//span)[1]")).Text;
                    string result;
                    switch (columnName)
                    {
                        case "MatterName":
                            result = test.driver.FindElement(By.XPath("((" + rowXpath + ")[" + i + "]//span)[2]")).Text;
                            break;
                        case "CompanyName":
                            result = test.driver.FindElement(By.XPath("((" + rowXpath + ")[" + i + "]//span)[4]")).Text;
                            break;
                        case "InsuranceCompany":
                            result = test.driver.FindElement(By.XPath("((" + rowXpath + ")[" + i + "]//span)[5]")).Text;
                            break;
                        default:
                            result = "";
                            break;
                    }
                    if (result.Contains(expected)) continue;
                    report.Fail("Row " + i + " does not contain the search criteria.  MatchedColumn: " + columnName + " Column contents: " + result);
                    errors += 1;
                }
                if (errors == 0)
                {
                    report.Pass("All results contain " + expected);
                }
                else
                {
                    report.Fail("Not all records contained the expected value.");
                }
                return errors;
                
            }
            catch (Exception e)
            {
                report.Fail("Search Result not loaded: " + e);
                return 1;
            }
        }

        public static void ValidateSearchResults(List<SearchResult> results, int pageSize = 10)
        {
            try
            {
                if (results.Count == 1)
                {
                    test.WaitForPageToLoad();
                    Matter.BasicInfo.ValidateRecord(Data.GetMatter(results.First().MatterId), Data.GetMatterNoticeType(results.First().MatterId));
                }
                const string rowXpath = "//div[@ng-grid='vm.gridOptions']//div[contains(@class, 'grid-row')]";
                var totalRows = test.driver.FindElements(By.XPath(rowXpath)).Count;
                var rows = (totalRows < pageSize) ? totalRows : pageSize;
                for (var i = 1; i <= rows; i++)
                {
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[1]"), results[i - 1].MatchedColumn);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[2]"), results[i - 1].MatterName);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[3]"), results[i - 1].Status); 
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[4]"), results[i - 1].CompanyName);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[5]"), results[i - 1].InsuranceCompany);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[6]"), results[i - 1].EnrollmentDeadline);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[7]"), results[i - 1].CreditMonitoring);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[8]"), results[i - 1].StateSpecific);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[9]"), results[i - 1].SapContractCode);
                    test.VerifyTextContains(By.XPath("((" + rowXpath + ")[" + i + "]//span)[10]"), results[i - 1].CaseSetupSrNumber);
                }
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while validating search: " + e);
                
            }
        }

        public static void SelectAllColumns()
        {
            var elements = test.driver.FindElements(By.XPath("//search-column-selector//label"));

            foreach (var element in elements)
            {
                if (element.GetAttribute("class").Contains("active")) continue;
                report.Action("Click", element.Text + " column");
                element.Click();
            }
        }
    }
}
