﻿using System;
using Automation;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace BreachPortal
{
    public class Navigate
    {
        public static By _Search = By.XPath("//a[text()='Search']/parent::li");
        public static By _MatterDetail = By.XPath("//a[text()='Matter Detail']/parent::li");
        public static By _CreateNewMatter = By.XPath("//a[text()='Create New Matter']/parent::li");
        public static By _Reports = By.XPath("//a[text()='Reports']/parent::li");
        public static By _Calendar = By.XPath("//a[text()='Calendar']/parent::li");
        public static By _MaintainContacts = By.XPath("//a[text()='Maintain Contacts']/parent::li");

        public static string MatterDetailPath = Config.Url + "/matterdetail?mode=edit&mid=";

        public static void HandleFailedLoad(int maxTries = 5)   //Workaround for bug 230309
        {
            var retries = 0;
            while (test.driver.FindElements(By.XPath("//div[@ng-grid]")).Count == 0 && retries < maxTries)
            {
                retries++;
                report.Step("Section failed to load properly.  Refreshing try " + retries);
                navigate.Refresh();
            }
            if (retries <= maxTries) return;
            report.Fail("Unable to load page without error after " + maxTries + " retries.");
            test.stopTestExecution(true);
        }

        public static int VerifySessionTimeout(int idle, int timeout)
        {
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(idle + timeout + 60));
            try
            {
                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//*[contains(text(), 'Session inactive')]")));
                report.Pass("Session Timeout message displayed at: " + DateTime.Now.ToLongTimeString());
                browser.TakeScreenshot("Session Timeout");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Session Timeout message did not display before timeout.  End: " + DateTime.Now.ToLongTimeString(), e);
                return 1;
            }
        }
    }
}
