﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;
using System.Configuration;

namespace Facilitator.Plugin.DRW.Tests
{

    public static class workflow
    {        
        public static By _Save = By.XPath("//div[contains(@class, 'active')]//button[@ng-click='vm.save()']");
        public static By _SaveAndPromote = By.XPath("//div[contains(@class, 'active')]//button[@ng-click='vm.promote()']");
        
        public static By _Demote = By.XPath("//button[@ng-click='vm.demote()']");
        public static By _DemoteModalOK = By.XPath("//button[@ng-click='vm.ok()']");

        public static By _AddFact = By.XPath("//button[@ng-click='vm.addAnswer(question)']");
        public static By _RemoveFact = By.XPath("//button[@ng-click='vm.removeAnswer(question, answer)']");
        public static By _FactText = By.XPath("//textarea[contains(@name, 'answer')]");
        public static By _Citation = By.XPath("//select[contains(@name, 'citation')]");
        public static By _StartPage = By.XPath("//input[contains(@name, 'start')]");
        public static By _EndPage = By.XPath("//input[contains(@name, 'end')]");
        
        public static string[] activity = ConfigurationManager.AppSettings["activity"].Split(',');

        public static void Save()
        {
            test.Click(_Save);
        }

        public static void ExpandSection(IWebDriver driver, string section)
        {
            try
            {
                test.Click(driver, By.XPath("//span[.='" + section + "']"));
            }
            catch (Exception e)
            {
                Console.WriteLine("Cannot expand section:  " + section, e);
            }
        }                

        public static void ExpandIncomingDocuments(IWebDriver driver)
        {
            test.ScrollDown(driver);
            ExpandSection(driver, ConfigurationManager.AppSettings.Get("incoming_documents"));
        }

        public static void ExpandProcessingNotes(IWebDriver driver)
        {
            test.ScrollDown(driver);
            ExpandSection(driver, ConfigurationManager.AppSettings.Get("processing_notes"));
        }


        public static int VerifyCurrentStep(IWebDriver driver, string expected)
        {
            return VerifyCurrentStep(driver, expected, false);
        }

        public static int VerifyCurrentStep(IWebDriver driver, string expected, bool stopTest)
        {
            try 
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

                wait.Until(d => d.FindElements(By.XPath("//li[@class='ng-scope active' and @role='presentation']/a")).Count > 0);
                Assert.AreEqual(expected, driver.FindElement(By.XPath("//li[@class='ng-scope active' and @role='presentation']/a")).Text);
                report.Pass("Current activity is " + expected + ".");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Current activity is not " + expected + ": " + e); 
                test.stopTestExecution(stopTest);
                return 1;
            }
        }


        
        public static void VerifyTabs(IWebDriver driver, testVars vars)
        {
            report.Step("Verifying tabs");
           
            foreach (string step in activity)
            {
                test.VerifyText(driver, By.LinkText(step), step);
            }
           
        }

       public static void VerifyFactAndCitation(IWebDriver driver, testVars vars)
       {
            report.Step("Adding Fact and Citation");

            string facttext = "Fact entered by " + ConfigurationManager.AppSettings.Get("username") + " on " + test.GetCurrentDateTime() + ".";
            string notetext = "Review saved by " + ConfigurationManager.AppSettings.Get("username") + " on " + test.GetCurrentDateTime() + ".";
            string startpage = "1";
            string endpage = "2";
            string citation;

            removeFacts(driver);
            
            test.Click(driver, _AddFact);
            test.EditField(driver, _FactText, facttext);
            test.SelectFieldByIndex(driver, _Citation, 2);
            test.EditField(driver, _StartPage, startpage);
            test.EditField(driver, _EndPage, endpage);

            citation = driver.FindElement(_Citation).GetAttribute("value");

            test.EditField(driver, By.Name("notes"), notetext);
            test.Click(driver, _Save);
            test.VerifyNoErrorToasts(driver);
            test.VerifySuccessToast(driver, "Workflow item has been successfully saved");

            report.Step("Verify updates persist");
            navigate.Refresh(driver);

            test.VerifyEditFieldText(driver, By.Name("notes"), "value", notetext);
            test.VerifyEditFieldText(driver, _FactText, "value", facttext);
            test.VerifyEditFieldText(driver, _Citation, "value", citation);
            test.VerifyEditFieldText(driver, _StartPage, "value", startpage);
            test.VerifyEditFieldText(driver, _EndPage, "value", endpage);
       }

        public static void Promote(IWebDriver driver, testVars vars, string disposition)
       {
            report.Step("Promoting workflow with " + disposition);
            test.SelectField(driver, By.Name("disposition"), "");
            test.SelectField(driver, By.Name("disposition"), disposition);            
            test.EditField(driver, By.Name("notes"), "Workflow promoted by " + ConfigurationManager.AppSettings.Get("username") + " on " + test.GetCurrentDateTime() + " to " + disposition + ".");
            test.Click(driver, _SaveAndPromote);            
       }

        public static void Demote(IWebDriver driver, testVars vars)
        {
            report.Step("Demoting Workflow");
            test.Click(driver, _Demote);
            test.EditField(driver, By.Name("demotionNote"), "Workflow demoted by " + ConfigurationManager.AppSettings.Get("username") + " on " + test.GetCurrentDateTime() + ".");
            test.Click(driver, _DemoteModalOK);           
        }

        private static void removeFacts(IWebDriver driver)
        {
            while (driver.FindElements(_RemoveFact).Count > 0)
            {
                try
                {
                    test.Click(driver, _RemoveFact);                    
                    test.Click(driver, _Save);
                }
                catch
                {
                    break;
                }
            }
        }
    }
}
