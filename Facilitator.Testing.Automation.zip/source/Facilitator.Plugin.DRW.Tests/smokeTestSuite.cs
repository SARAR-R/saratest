﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;
using System.Configuration;
using System.Diagnostics;


namespace Facilitator.Plugin.DRW.Tests
{

    [TestClass]
    public class smokeTestSuite
    {
        public TestContext TestContext { get; set; }

        void Main(string[] args) { }

        [TestInitialize]
        public void startup()
        {           
            test.startup(TestContext);
        }

        [TestCleanup]
        public void teardown()
        {            
            test.teardown();
        }

               

        [TestMethod]
        public void DRW_TechConfig()
        {
            usecase.TechConfigPlugin(test.driver, test.vars);
        }
        
        [TestMethod]
        public void DRW_WorkflowQueue()
        {
            usecase.WorkflowQueue(test.driver, test.vars);
        }

        [TestMethod]
        public void DRW_Workflow()
        {
            usecase.Workflow(test.driver, test.vars);
        }

        
    }
}
