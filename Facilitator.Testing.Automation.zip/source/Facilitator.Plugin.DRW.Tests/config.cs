﻿namespace Facilitator.Plugin.DRW.Tests
{
    public class config : Facilitator.Template.config
    {
        public const string casename = "DRW";
        public const string connectionstring = "Data Source=D016ECASQLS01.epiqcorp.com,1433\\ECAKCDV01;Initial Catalog=CA9993_QA;Integrated Security=True";
      
        public const string plugin_name = "DRW";

        public const string workflow_queue = "Workflow Queue";
        public const string workflow = "Workflow";
        public const string activity = "LPS: Request,Submitted,LPS: Escalation Response,Epiq: Escalation from LPS,Epiq: Review,Epiq: Review 2,Epiq: Escalation from Reviewer";

    }
}
