﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Linq;

namespace Facilitator.Plugin.DRW.Tests
{
    public class navigate : Facilitator.Template.navigate
    {
        public static void Workflow(IWebDriver driver)
        {
            Menu(driver, ConfigurationManager.AppSettings.Get("workflow"));
        }

        public static void WorkflowQueue(IWebDriver driver)
        {
            Menu(driver, ConfigurationManager.AppSettings.Get("workflow_queue"));
        }
    }
}
