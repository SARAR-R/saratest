﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Diagnostics;
using Automation;
using Facilitator.Template;


namespace Facilitator.Plugin.DRW.Tests
{
    public class usecase : Facilitator.Template.Tests.usecase
    {
        public static void WorkflowQueue(IWebDriver driver, testVars vars)
        {
            try
            {
                testHelper.Start(driver);

                report.Step("Navigate to the Workflow Queue");
                navigate.WorkflowQueue(driver);
                test.VerifyNoErrorToasts(driver);

                report.Step("Select a review step");
                test.SelectField(driver, workflowQueue._Select, workflow.activity[0]);
                test.VerifyNoErrorToasts(driver);
                test.VerifyTextDoesNotEqual(driver, grid._Total, "Total Items: 0");

                report.Step("Select a review");                
                workflowQueue.selectWorkflowFromResults(driver);
                test.VerifyNoErrorToasts(driver);
                workflow.VerifyCurrentStep(driver, workflow.activity[0]);
            }

            finally { }
        }

        
        public static void Workflow(IWebDriver driver, testVars vars)
        {

            try
            {
                testHelper.Start(driver);

                report.Step("Navigate to the Workflow Queue");
                navigate.WorkflowQueue(driver);
                
                report.Step("Select first step");
                test.SelectField(driver, workflowQueue._Select, workflow.activity[0]);
                report.Step("Select a review");                
                workflowQueue.selectWorkflowFromResults(driver);
                test.VerifyNoErrorToasts(driver);

                report.Step("Navigate away");                
                navigate.WorkflowQueue(driver);

                report.Step("Navigate back");
                navigate.Workflow(driver);
                test.VerifyNoErrorToasts(driver);

                workflow.VerifyTabs(driver, vars);
                workflow.VerifyCurrentStep(driver, workflow.activity[0], true);

                report.Step("Load Documents");
                workflow.ExpandIncomingDocuments(driver);
                test.VerifyNoErrorToasts(driver);

                report.Step("Load Notes");
                workflow.ExpandProcessingNotes(driver);
                test.VerifyNoErrorToasts(driver);

                workflow.VerifyFactAndCitation(driver, vars);

                workflow.Promote(driver, vars, "Submitted");
                test.VerifyNoErrorToasts(driver);
                test.VerifySuccessToast(driver, "Workflow item has been successfully promoted");
                navigate.Refresh(driver);
                workflow.VerifyCurrentStep(driver, workflow.activity[1]);

                workflow.Demote(driver, vars);
                test.VerifyNoErrorToasts(driver);
                test.VerifySuccessToast(driver, "Workflow item has been successfully demoted");
                navigate.Refresh(driver);
                workflow.VerifyCurrentStep(driver, workflow.activity[0]);
            }

            finally { }
        }

        public static void Load_Plugin_Pages(IWebDriver driver, testVars vars)
        {
            try
            {
                testHelper.Start(driver, 1);

                navigate.WorkflowQueue(driver);
                test.VerifyNoErrorToasts(driver);

                navigate.Workflow(driver);
                phoneAgent.ExpandIncomingDocuments(driver);
                phoneAgent.ExpandProcessingNotes(driver);
                test.VerifyNoErrorToasts(driver);                
            }

            finally { }
        }

        public static void Save_Plugin_Pages(IWebDriver driver, testVars vars)
        {
            try
            {
                testHelper.Start(driver);

                navigate.WorkflowQueue(driver);
                test.SelectField(driver, workflowQueue._Select, workflow.activity[0]);
                test.VerifyNoErrorToasts(driver);
                test.VerifyTextDoesNotEqual(driver, grid._Total, "Total Items: 0");

                workflowQueue.selectWorkflowFromResults(driver);
                workflow.ExpandIncomingDocuments(driver);
                workflow.ExpandProcessingNotes(driver);
                test.VerifyNoErrorToasts(driver);

                test.EditField(driver, By.Name("notes"), "updated by automation");
                workflow.Save();
                test.VerifySuccessToast(driver, "Workflow item has been successfully saved");
                test.VerifyNoErrorToasts(driver);
            }

            finally { }
        }

    }
}
