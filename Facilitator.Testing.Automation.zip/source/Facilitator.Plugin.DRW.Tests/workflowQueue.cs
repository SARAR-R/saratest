﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace Facilitator.Plugin.DRW.Tests
{

    public static class workflowQueue
    {
        public static By _Select = By.CssSelector("select.input-sm");

        public static void selectWorkflowFromResults(IWebDriver driver)
        {
            test.Click(driver, By.XPath("//div[@class='ngCell  col0 colt0']"));
        }
       
    }    
}
