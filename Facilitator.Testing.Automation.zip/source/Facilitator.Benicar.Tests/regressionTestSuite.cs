﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;
using System.Configuration;

namespace Facilitator.KandP.Tests
{

    [TestClass]
    public class KandPRegressionTestSuite
    {
        public TestContext TestContext { get; set; }

        void Main(string[] args) { }

        [TestInitialize]
        public void startup()
        {
            test.startup(TestContext);
        }

        [TestCleanup]
        public void teardown()
        {
            test.teardown();
        }

        [TestMethod]
        public void KandP_QuickSearchAllFields()
        {
            Template.Tests.usecase.QuickSearchAllFields(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_StandardSearchAllFields()
        {
            Template.Tests.usecase.StandardSearchAllFields(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_StandardSearchCriteria()
        {
            Template.Tests.usecase.StandardSearchCriteria(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_AdvancedSearchFields()
        {
            Template.Tests.usecase.AdvancedSearchFields(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_AdvancedSearchCriteria()
        {
            Template.Tests.usecase.AdvancedSearchCriteria(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_ClaimantPersonalInfo()
        {
            Template.Tests.usecase.ClaimantPersonalInfo(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_ClaimantClaimInfo()
        {
            Template.Tests.usecase.ClaimantClaimInfo(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_CombinedCommunication()
        {
            Template.Tests.usecase.CombinedCommunication(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_IncomingDocuments()
        {
            NECC.Tests.usecase.IncomingDocuments(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_OutgoingMailings()
        {
            NECC.Tests.usecase.OutgoingMailings(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_PhoneContacts()
        {
            NECC.Tests.usecase.PhoneContacts(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_ProcessingNotes()
        {
            NECC.Tests.usecase.ProcessingNotes(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_HistoryCriteria()
        {
            Template.Tests.usecase.HistoryCriteria(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_HistoryFields()
        {
            Template.Tests.usecase.HistoryFields(test.driver, test.vars);
        }

        [TestMethod]
        public void KandP_ResetPassword()
        {
            NECC.Tests.usecase.ResetPassword(test.driver, test.vars);
        }
    }
}
