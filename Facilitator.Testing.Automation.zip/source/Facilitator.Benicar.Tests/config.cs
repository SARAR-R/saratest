﻿namespace Facilitator.KandP.Tests
{
    public class config : Facilitator.Template.config

    {

        public const string url = "https://f5.epiqclassactionqa.com/KandP";
        public const string acapiurl = "https://accesscontrol.epiqsystems.com/preview/AuthenticationService.svc";
        public const string connectionstring = "Data Source=D016ECASQLS01.epiqcorp.com,1433\\ECAKCDV01;Initial Catalog=CA8597_QA;Integrated Security=True";
        public const string document_type = "Medical Record";
        public const string reviewsteps = "Initial Review";
        public const string landing_page = "Standard Search";
        public const string plaintiff_claimant = "Plaintiff";
        public const string techconfigsetting =  "Access Control Authentication Service URL ";
       
		}
}
