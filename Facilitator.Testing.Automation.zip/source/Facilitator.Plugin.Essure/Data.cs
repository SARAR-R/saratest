﻿using System.Collections.Generic;
using System.Linq;
using Facilitator.Plugin.Essure.Database;
using System;

namespace Facilitator.Plugin.Essure
{
    public class Data
    {
        public static List<DeviceInformation> GetDeviceInformation()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DeviceInformations
                    select c;

                return query.ToList();
            }
        }

        public static List<DeviceInformation> GetDeviceInformation(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DeviceInformations
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<DevicePrescription> GetDevicePrescription()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DevicePrescriptions
                    select c;

                return query.ToList();
            }
        }

        public static List<DevicePrescription> GetDevicePrescription(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DevicePrescriptions
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<DeviceAdvice> GetDeviceAdvice()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DeviceAdvices
                    select c;

                return query.ToList();
            }
        }

        public static List<DeviceAdvice> GetDeviceAdvice(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DeviceAdvices
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<DeviceConfirmationTestResult> GetDeviceConfirmationTestResult()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DeviceConfirmationTestResults
                    select c;

                return query.ToList();
            }
        }

        public static List<DeviceConfirmationTestResult> GetDeviceConfirmationTestResult(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.DeviceConfirmationTestResults
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalRecordReviewDocument> GetMedicalRecordReviewDocument()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalRecordReviewDocuments
                    select c;
                return query.ToList();
            }
        }

        public static List<MedicalRecordReviewDocument> GetMedicalRecordReviewDocument(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalRecordReviewDocuments
                    where c.Tracking_Number == trackingNumber
                    select c;
                return query.ToList();
            }
        }

        public static List<MedicalRecordReviewDocument> GetMedicalRecordReviewDocument(int trackingNumber, int sectionId)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalRecordReviewDocuments
                    where c.Tracking_Number == trackingNumber && c.MedicalRecordReviewSectionId == sectionId
                    select c;
                return query.ToList();
            }
        }

        public static List<InjuryInformation> GetInjuryInformation(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.InjuryInformations
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<InjuryDetail> GetInjuryDetail(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.InjuryDetails
                    where c.Tracking_Number == trackingNumber
                    orderby c.InjuryType.DisplayOrder
                    select c;

                return query.ToList();
            }
        }

        public static List<InjuryType> GetInjuryType()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.InjuryTypes
                    select c;

                return query.ToList();
            }
        }

        public static InjuryType GetInjuryType(int injuryTypeId)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.InjuryTypes
                    where c.InjuryTypeId == injuryTypeId
                    select c;

                return query.FirstOrDefault();
            }
        }

        public static string GetInjuryTypeName(int? injuryTypeId)
        {
            if (injuryTypeId == null) return "";
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.InjuryTypes
                    where c.InjuryTypeId == injuryTypeId
                    select c;

                return query.FirstOrDefault()?.Name;
            }
        }

        public static List<SurgeryInformation> GetSurgeryInformation()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.SurgeryInformations
                    select c;

                return query.ToList();
            }
        }

        public static List<SurgeryInformation> GetSurgeryInformation(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.SurgeryInformations
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<SurgeryCommunication> GetSurgeryCommunication()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.SurgeryCommunications
                    select c;

                return query.ToList();
            }
        }

        public static List<SurgeryCommunication> GetSurgeryCommunication(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.SurgeryCommunications
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<SurgeryDetail> GetSurgeryDetail()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.SurgeryDetails
                    select c;

                return query.ToList();
            }
        }

        public static List<SurgeryDetail> GetSurgeryDetail(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.SurgeryDetails
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackground> GetMedicalBackground()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgrounds
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackground> GetMedicalBackground(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgrounds
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundBirth> GetMedicalBackgroundBirth()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundBirths
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundBirth> GetMedicalBackgroundBirth(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundBirths
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundPregnancy> GetMedicalBackgroundPregnancy()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundPregnancies
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundPregnancy> GetMedicalBackgroundPregnancy(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundPregnancies
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundChild> GetMedicalBackgroundChild()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundChilds
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundChild> GetMedicalBackgroundChild(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundChilds
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundCondition> GetMedicalBackgroundCondition()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundConditions
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundCondition> GetMedicalBackgroundCondition(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundConditions
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundMedication> GetMedicalBackgroundMedication()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundMedications
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundMedication> GetMedicalBackgroundMedication(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundMedications
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundPharmacy> GetMedicalBackgroundPharmacy()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundPharmacies
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundPharmacy> GetMedicalBackgroundPharmacy(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundPharmacies
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundInsurance> GetMedicalBackgroundInsurance()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundInsurances
                    select c;

                return query.ToList();
            }
        }

        public static List<MedicalBackgroundInsurance> GetMedicalBackgroundInsurance(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.MedicalBackgroundInsurances
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientInformation> GetPatientInformation()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientInformations
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientInformation> GetPatientInformation(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientInformations
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientAlia> GetPatientAlias()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientAlias
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientAlia> GetPatientAlias(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientAlias
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientChild> GetPatientChild()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientChilds
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientChild> GetPatientChild(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientChilds
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientEmploymentAbsence> GetPatientEmploymentAbsence()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientEmploymentAbsences
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientEmploymentAbsence> GetPatientEmploymentAbsence(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientEmploymentAbsences
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientBenefit> GetPatientBenefit()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientBenefits
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientBenefit> GetPatientBenefit(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientBenefits
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientInsurance> GetPatientInsurance()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientInsurances
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientInsurance> GetPatientInsurance(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientInsurances
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientLawsuit> GetPatientLawsuit()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientLawsuits
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientLawsuit> GetPatientLawsuit(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientLawsuits
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientBankruptcy> GetPatientBankruptcy()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientBankruptcies
                    select c;

                return query.ToList();
            }
        }

        public static List<PatientBankruptcy> GetPatientBankruptcy(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.PatientBankruptcies
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseInformation> GetCaseInformation()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.CaseInformations
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseInformation> GetCaseInformation(int trackingNumber)
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.CaseInformations
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<QuestionResponseType> GetQuestionResponseType()
        {
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.QuestionResponseTypes
                    select c;

                return query.ToList();
            }
        }

        public static string GetQuestionResponseTypeName(int? questionResponseTypeId)
        {
            if (questionResponseTypeId == null) return "";
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.QuestionResponseTypes
                    where c.QuestionResponseTypeId == questionResponseTypeId
                    select c;

                return query.First().Name;
            }
        }

        public static string GetPlaintiffAttorneys(int trackingNumber)
        {
            var result = "";
            using (var context = new Database.Essure())
            {
                var query =
                    from c in context.ClaimantToClaimantGroups
                    join d in context.ClaimantGroups
                    on c.ClaimantGroupId equals d.ClaimantGroupId
                    where c.Tracking_Number == trackingNumber
                    orderby d.Name ascending
                    select d;

                if (!query.Any()) return result;
                var count = query.Count();
                var index = 0;
                foreach (var record in query)
                {
                    index += 1;
                    result += record.Name;
                    if (index == count) continue;
                    result += Environment.NewLine;
                }
                return result;
            }
        }

    }
}
