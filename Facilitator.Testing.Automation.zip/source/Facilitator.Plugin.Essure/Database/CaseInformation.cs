namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.CaseInformation")]
    public partial class CaseInformation
    {
        public int CaseInformationId { get; set; }

        public int MedicalRecordReviewId { get; set; }

        public int Tracking_Number { get; set; }

        public int? AttorneyId { get; set; }

        [StringLength(100)]
        public string Caption { get; set; }

        [StringLength(100)]
        public string CourtName { get; set; }

        [StringLength(100)]
        public string DocketNumber { get; set; }

        [StringLength(100)]
        public string RepresentativeCapacity { get; set; }

        [StringLength(70)]
        public string RepresentativeAddress { get; set; }

        [StringLength(70)]
        public string RepresentativeAddress2 { get; set; }

        [StringLength(35)]
        public string RepresentativeCity { get; set; }

        [StringLength(2)]
        public string RepresentativeState { get; set; }

        [StringLength(9)]
        public string RepresentativePostalCode { get; set; }

        [StringLength(100)]
        public string RepresentativeAppointedState { get; set; }

        [StringLength(100)]
        public string RepresentativeAppointedCourt { get; set; }

        [StringLength(100)]
        public string RepresentativeAppointedCourtCaseNumber { get; set; }

        [StringLength(100)]
        public string RepresentativeRelationship { get; set; }

        [StringLength(100)]
        public string DeathLocation { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalRecordReview MedicalRecordReview { get; set; }
    }
}
