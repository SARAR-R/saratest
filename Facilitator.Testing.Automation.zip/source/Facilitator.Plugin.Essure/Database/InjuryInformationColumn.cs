namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.InjuryInformationColumn")]
    public partial class InjuryInformationColumn
    {
        public int InjuryInformationColumnId { get; set; }

        [Required]
        [StringLength(128)]
        public string ColumnName { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
