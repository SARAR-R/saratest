namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.MedicalBackgroundPregnancy")]
    public partial class MedicalBackgroundPregnancy
    {
        public int MedicalBackgroundPregnancyId { get; set; }

        public int MedicalBackgroundId { get; set; }

        public int Tracking_Number { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ConfirmedDate { get; set; }

        [StringLength(255)]
        public string PregnancyLearnedBy { get; set; }

        [StringLength(100)]
        public string PhysicianName { get; set; }

        [StringLength(70)]
        public string PhysicianAddress { get; set; }

        [StringLength(70)]
        public string PhysicianAddress2 { get; set; }

        [StringLength(35)]
        public string PhysicianCity { get; set; }

        [StringLength(2)]
        public string PhysicianState { get; set; }

        [StringLength(9)]
        public string PhysicianPostalCode { get; set; }

        [StringLength(255)]
        public string Outcome { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalBackground MedicalBackground { get; set; }
    }
}
