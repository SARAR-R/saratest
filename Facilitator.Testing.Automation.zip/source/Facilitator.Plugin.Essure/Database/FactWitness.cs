namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.FactWitness")]
    public partial class FactWitness
    {
        public int FactWitnessId { get; set; }

        public int MedicalRecordReviewId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(15)]
        public string MiddleName { get; set; }

        [StringLength(35)]
        public string LastName { get; set; }

        [StringLength(70)]
        public string Address { get; set; }

        [StringLength(70)]
        public string Address2 { get; set; }

        [StringLength(35)]
        public string City { get; set; }

        [StringLength(2)]
        public string State { get; set; }

        [StringLength(9)]
        public string PostalCode { get; set; }

        [StringLength(100)]
        public string Relationship { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalRecordReview MedicalRecordReview { get; set; }
    }
}
