namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.DevicePrescription")]
    public partial class DevicePrescription
    {
        public int DevicePrescriptionId { get; set; }

        public int DeviceInformationId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(100)]
        public string ContraceptionMethod { get; set; }

        [Column(TypeName = "date")]
        public DateTime? StartDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }

        [StringLength(100)]
        public string PrescriberName { get; set; }

        [StringLength(70)]
        public string PrescriberAddress { get; set; }

        [StringLength(70)]
        public string PrescriberAddress2 { get; set; }

        [StringLength(35)]
        public string PrescriberCity { get; set; }

        [StringLength(2)]
        public string PrescriberState { get; set; }

        [StringLength(9)]
        public string PrescriberPostalCode { get; set; }

        [StringLength(500)]
        public string UsageReason { get; set; }

        [StringLength(500)]
        public string DiscontinuedUsageReason { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual DeviceInformation DeviceInformation { get; set; }
    }
}
