namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.MedicalBackgroundInsurance")]
    public partial class MedicalBackgroundInsurance
    {
        public int MedicalBackgroundInsuranceId { get; set; }

        public int MedicalBackgroundId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(100)]
        public string Company { get; set; }

        [StringLength(20)]
        public string PolicyNumber { get; set; }

        [StringLength(100)]
        public string PolicyHolder { get; set; }

        [StringLength(255)]
        public string DatesOfCoverage { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalBackground MedicalBackground { get; set; }
    }
}
