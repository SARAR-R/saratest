namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.MedicalBackgroundPharmacyColumnChange")]
    public partial class MedicalBackgroundPharmacyColumnChange
    {
        public int MedicalBackgroundPharmacyColumnChangeId { get; set; }

        public int Id { get; set; }

        public DateTime ChangeDate { get; set; }

        [Required]
        [StringLength(128)]
        public string ColumnName { get; set; }

        public byte Action { get; set; }

        [StringLength(4000)]
        public string OldValue { get; set; }

        [StringLength(4000)]
        public string NewValue { get; set; }

        [StringLength(20)]
        public string UpdatedBy { get; set; }

        public int? Tracking_Number { get; set; }
    }
}
