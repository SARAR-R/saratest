namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.ClaimantPatientInformation")]
    public partial class ClaimantPatientInformation
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PatientInformationId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int MedicalRecordReviewId { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TrackingNumber { get; set; }

        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(15)]
        public string MiddleName { get; set; }

        [StringLength(30)]
        public string LastName { get; set; }

        [StringLength(70)]
        public string Address { get; set; }

        [StringLength(70)]
        public string Address2 { get; set; }

        [StringLength(35)]
        public string City { get; set; }

        [StringLength(2)]
        public string State { get; set; }

        [StringLength(9)]
        public string PostalCode { get; set; }

        [StringLength(45)]
        public string RepresentativeName { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public DateTime? DateOfDeath { get; set; }

        public int? IsMarriedResponseTypeId { get; set; }

        [StringLength(25)]
        public string SpouseFirstName { get; set; }

        [StringLength(15)]
        public string SpouseMiddleName { get; set; }

        [StringLength(30)]
        public string SpouseLastName { get; set; }

        [StringLength(70)]
        public string SpouseAddress { get; set; }

        [StringLength(70)]
        public string SpouseAddress2 { get; set; }

        [StringLength(35)]
        public string SpouseCity { get; set; }

        [StringLength(2)]
        public string SpouseState { get; set; }

        [StringLength(9)]
        public string SpousePostalCode { get; set; }

        public int? HasSpouseFiledOtherClaimResponseTypeId { get; set; }

        public int? IsEmployedResponseTypeId { get; set; }

        [StringLength(100)]
        public string EmployerName { get; set; }

        [StringLength(100)]
        public string Position { get; set; }

        public int? HasTakenEmploymentLeaveResponseTypeId { get; set; }

        public int? HasAppliedForBenefitsResponseTypeId { get; set; }

        public int? HasBeenDeniedInsuranceResponseTypeId { get; set; }

        public int? HasFiledOtherLawsuitResponseTypeId { get; set; }

        public int? HasFiledBankruptcyResponseTypeId { get; set; }

        public DateTime? InsertedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [MaxLength(8)]
        public byte[] PatientRowVersion { get; set; }

        [Key]
        [Column(Order = 3, TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ClaimantRowVersion { get; set; }
    }
}
