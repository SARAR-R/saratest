namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.DeviceConfirmationTestResult")]
    public partial class DeviceConfirmationTestResult
    {
        public int DeviceConfirmationTestResultId { get; set; }

        public int DeviceInformationId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(100)]
        public string Result { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ResultDate { get; set; }

        [StringLength(100)]
        public string ResultProviderInformation { get; set; }

        [StringLength(100)]
        public string ConfirmationTestProvider { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ResultCommunicationDate { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual DeviceInformation DeviceInformation { get; set; }
    }
}
