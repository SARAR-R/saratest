namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.MedicalBackground")]
    public partial class MedicalBackground
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public MedicalBackground()
        {
            MedicalBackgroundBirths = new HashSet<MedicalBackgroundBirth>();
            MedicalBackgroundChilds = new HashSet<MedicalBackgroundChild>();
            MedicalBackgroundConditions = new HashSet<MedicalBackgroundCondition>();
            MedicalBackgroundInsurances = new HashSet<MedicalBackgroundInsurance>();
            MedicalBackgroundMedications = new HashSet<MedicalBackgroundMedication>();
            MedicalBackgroundPharmacies = new HashSet<MedicalBackgroundPharmacy>();
            MedicalBackgroundPregnancies = new HashSet<MedicalBackgroundPregnancy>();
        }

        public int MedicalBackgroundId { get; set; }

        public int MedicalRecordReviewId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(14)]
        public string CurrentHeight { get; set; }

        public decimal? CurrentWeight { get; set; }

        public decimal? WeightAtPlacement { get; set; }

        public int? HasBeenPregnantResponseTypeId { get; set; }

        public int? NumberOfPregnancies { get; set; }

        public int? NumberOfBirths { get; set; }

        public int? HadPregnancyComplicationsResponseTypeId { get; set; }

        [StringLength(512)]
        public string PregnancyComplication { get; set; }

        [StringLength(512)]
        public string UnintendedPregnancyComplication { get; set; }

        [StringLength(512)]
        public string UnintendedPregnancyComplicationTreatment { get; set; }

        public int? HadBirthDefectsResponseTypeId { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalRecordReview MedicalRecordReview { get; set; }

        public virtual QuestionResponseType QuestionResponseType { get; set; }

        public virtual QuestionResponseType QuestionResponseType1 { get; set; }

        public virtual QuestionResponseType QuestionResponseType2 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MedicalBackgroundBirth> MedicalBackgroundBirths { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MedicalBackgroundChild> MedicalBackgroundChilds { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MedicalBackgroundCondition> MedicalBackgroundConditions { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MedicalBackgroundInsurance> MedicalBackgroundInsurances { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MedicalBackgroundMedication> MedicalBackgroundMedications { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MedicalBackgroundPharmacy> MedicalBackgroundPharmacies { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MedicalBackgroundPregnancy> MedicalBackgroundPregnancies { get; set; }
    }
}
