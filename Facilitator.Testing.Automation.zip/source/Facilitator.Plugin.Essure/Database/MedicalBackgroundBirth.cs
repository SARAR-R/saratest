namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.MedicalBackgroundBirth")]
    public partial class MedicalBackgroundBirth
    {
        public int MedicalBackgroundBirthId { get; set; }

        public int MedicalBackgroundId { get; set; }

        public int Tracking_Number { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DateOfBirth { get; set; }

        [StringLength(255)]
        public string LocationOfBirth { get; set; }

        [StringLength(70)]
        public string BirthAddress1 { get; set; }

        [StringLength(70)]
        public string BirthAddress2 { get; set; }

        [StringLength(35)]
        public string BirthCity { get; set; }

        [StringLength(2)]
        public string BirthState { get; set; }

        [StringLength(9)]
        public string BirthPostalCode { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalBackground MedicalBackground { get; set; }
    }
}
