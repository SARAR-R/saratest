namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.InjuryInformation")]
    public partial class InjuryInformation
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public InjuryInformation()
        {
            InjuryDetails = new HashSet<InjuryDetail>();
        }

        public int InjuryInformationId { get; set; }

        public int MedicalRecordReviewId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(100)]
        public string PainLocation { get; set; }

        [StringLength(100)]
        public string PainIntensity { get; set; }

        public int? HasWorsenedExistingInjuryResponseTypeId { get; set; }

        public int? WorsenedExistingInjuryTypeId { get; set; }

        public int? HasRecoveredFromExistingInjuryResponseTypeId { get; set; }

        [Column(TypeName = "date")]
        public DateTime? RecoveryDate { get; set; }

        public int? DidRemovalResolveExistingInjuryResponseTypeId { get; set; }

        [StringLength(500)]
        public string RecoveryDescription { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<InjuryDetail> InjuryDetails { get; set; }

        public virtual MedicalRecordReview MedicalRecordReview { get; set; }

        public virtual QuestionResponseType QuestionResponseType { get; set; }

        public virtual QuestionResponseType QuestionResponseType1 { get; set; }

        public virtual QuestionResponseType QuestionResponseType2 { get; set; }
    }
}
