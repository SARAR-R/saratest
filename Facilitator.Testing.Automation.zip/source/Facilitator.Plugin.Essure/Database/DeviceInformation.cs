namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.DeviceInformation")]
    public partial class DeviceInformation
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public DeviceInformation()
        {
            DeviceAdvices = new HashSet<DeviceAdvice>();
            DeviceConfirmationTestResults = new HashSet<DeviceConfirmationTestResult>();
            DevicePrescriptions = new HashSet<DevicePrescription>();
        }

        public int DeviceInformationId { get; set; }

        public int MedicalRecordReviewId { get; set; }

        public int Tracking_Number { get; set; }

        public DateTime? PlacementProcedureDate { get; set; }

        [StringLength(100)]
        public string LotNumbers { get; set; }

        [StringLength(100)]
        public string PhysicianName { get; set; }

        [StringLength(70)]
        public string PhysicianAddress { get; set; }

        [StringLength(70)]
        public string PhysicianAddress2 { get; set; }

        [StringLength(35)]
        public string PhysicianCity { get; set; }

        [StringLength(2)]
        public string PhysicianState { get; set; }

        [StringLength(9)]
        public string PhysicianPostalCode { get; set; }

        [StringLength(100)]
        public string FacilityName { get; set; }

        [StringLength(70)]
        public string FacilityAddress { get; set; }

        [StringLength(70)]
        public string FacilityAddress2 { get; set; }

        [StringLength(35)]
        public string FacilityCity { get; set; }

        [StringLength(2)]
        public string FacilityState { get; set; }

        [StringLength(9)]
        public string FacilityPostalCode { get; set; }

        public int? HadPlacementComplicationResponseTypeId { get; set; }

        [StringLength(500)]
        public string PlacementComplicationInfo { get; set; }

        [Column(TypeName = "date")]
        public DateTime? PlacementComplicationReceivedDate { get; set; }

        [StringLength(500)]
        public string PlacementComplicationInfoProvider { get; set; }

        public int? HadConfirmationTestResponseTypeId { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ConfirmationTestDate { get; set; }

        [StringLength(100)]
        public string ConfirmationTestType { get; set; }

        [StringLength(100)]
        public string ConfirmationTestPhysician { get; set; }

        [StringLength(70)]
        public string ConfirmationTestPhysicianAddress { get; set; }

        [StringLength(70)]
        public string ConfirmationTestPhysicianAddress2 { get; set; }

        [StringLength(35)]
        public string ConfirmationTestPhysicianCity { get; set; }

        [StringLength(2)]
        public string ConfirmationTestPhysicianState { get; set; }

        [StringLength(9)]
        public string ConfirmationTestPhysicianPostalCode { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<DeviceAdvice> DeviceAdvices { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<DeviceConfirmationTestResult> DeviceConfirmationTestResults { get; set; }

        public virtual MedicalRecordReview MedicalRecordReview { get; set; }

        public virtual QuestionResponseType QuestionResponseType { get; set; }

        public virtual QuestionResponseType QuestionResponseType1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<DevicePrescription> DevicePrescriptions { get; set; }
    }
}
