namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.InjuryExplanation")]
    public partial class InjuryExplanation
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public InjuryExplanation()
        {
            InjuryTypes = new HashSet<InjuryType>();
        }

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int InjuryExplanationId { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<InjuryType> InjuryTypes { get; set; }
    }
}
