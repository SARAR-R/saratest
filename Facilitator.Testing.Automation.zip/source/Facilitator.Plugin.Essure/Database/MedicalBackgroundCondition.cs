namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.MedicalBackgroundCondition")]
    public partial class MedicalBackgroundCondition
    {
        public int MedicalBackgroundConditionId { get; set; }

        public int MedicalBackgroundId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(100)]
        public string Condition { get; set; }

        [StringLength(100)]
        public string Treatment { get; set; }

        [StringLength(255)]
        public string DaysOfTreatment { get; set; }

        [StringLength(100)]
        public string PhysicianName { get; set; }

        [StringLength(70)]
        public string PhysicianAddress { get; set; }

        [StringLength(70)]
        public string PhysicianAddress2 { get; set; }

        [StringLength(35)]
        public string PhysicianCity { get; set; }

        [StringLength(2)]
        public string PhysicianState { get; set; }

        [StringLength(9)]
        public string PhysicianPostalCode { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalBackground MedicalBackground { get; set; }
    }
}
