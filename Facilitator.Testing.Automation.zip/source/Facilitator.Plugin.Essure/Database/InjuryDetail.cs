namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.InjuryDetail")]
    public partial class InjuryDetail
    {
        public int InjuryDetailId { get; set; }

        public int InjuryInformationId { get; set; }

        public int InjuryTypeId { get; set; }

        public int Tracking_Number { get; set; }

        [StringLength(150)]
        public string Description { get; set; }

        [Column(TypeName = "date")]
        public DateTime? OnsetDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DiagnosisDate { get; set; }

        public int? HadTreatmentResponseTypeId { get; set; }

        [StringLength(100)]
        public string PhysicianName { get; set; }

        [StringLength(70)]
        public string PhysicianAddress { get; set; }

        [StringLength(70)]
        public string PhysicianAddress2 { get; set; }

        [StringLength(35)]
        public string PhysicianCity { get; set; }

        [StringLength(2)]
        public string PhysicianState { get; set; }

        [StringLength(9)]
        public string PhysicianPostalCode { get; set; }

        [StringLength(100)]
        public string FacilityName { get; set; }

        [StringLength(70)]
        public string FacilityAddress { get; set; }

        [StringLength(70)]
        public string FacilityAddress2 { get; set; }

        [StringLength(35)]
        public string FacilityCity { get; set; }

        [StringLength(2)]
        public string FacilityState { get; set; }

        [StringLength(9)]
        public string FacilityPostalCode { get; set; }

        [StringLength(250)]
        public string TreatmentDescription { get; set; }

        [Column(TypeName = "date")]
        public DateTime? InjurySuspectedDate { get; set; }

        public int? WasComplicationPriorToPlacementResponseTypeId { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual InjuryInformation InjuryInformation { get; set; }

        public virtual InjuryType InjuryType { get; set; }

        public virtual QuestionResponseType QuestionResponseType { get; set; }

        public virtual QuestionResponseType QuestionResponseType1 { get; set; }
    }
}
