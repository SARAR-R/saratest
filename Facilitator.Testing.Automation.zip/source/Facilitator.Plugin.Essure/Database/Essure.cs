namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Essure : DbContext
    {
        public Essure()
            : base("name=Essure")
        {
        }

        public virtual DbSet<CaseInformation> CaseInformations { get; set; }
        public virtual DbSet<CaseInformationColumn> CaseInformationColumns { get; set; }
        public virtual DbSet<CaseInformationColumnChange> CaseInformationColumnChanges { get; set; }
        public virtual DbSet<Communication> Communications { get; set; }
        public virtual DbSet<CommunicationColumn> CommunicationColumns { get; set; }
        public virtual DbSet<CommunicationColumnChange> CommunicationColumnChanges { get; set; }
        public virtual DbSet<CommunicationContact> CommunicationContacts { get; set; }
        public virtual DbSet<CommunicationContactColumn> CommunicationContactColumns { get; set; }
        public virtual DbSet<CommunicationContactColumnChange> CommunicationContactColumnChanges { get; set; }
        public virtual DbSet<CommunicationDefendant> CommunicationDefendants { get; set; }
        public virtual DbSet<CommunicationDefendantColumn> CommunicationDefendantColumns { get; set; }
        public virtual DbSet<CommunicationDefendantColumnChange> CommunicationDefendantColumnChanges { get; set; }
        public virtual DbSet<CommunicationFda> CommunicationFdas { get; set; }
        public virtual DbSet<CommunicationFdaColumn> CommunicationFdaColumns { get; set; }
        public virtual DbSet<CommunicationFdaColumnChange> CommunicationFdaColumnChanges { get; set; }
        public virtual DbSet<CommunicationGroup> CommunicationGroups { get; set; }
        public virtual DbSet<CommunicationGroupColumn> CommunicationGroupColumns { get; set; }
        public virtual DbSet<CommunicationGroupColumnChange> CommunicationGroupColumnChanges { get; set; }
        public virtual DbSet<CommunicationSurvey> CommunicationSurveys { get; set; }
        public virtual DbSet<CommunicationSurveyColumn> CommunicationSurveyColumns { get; set; }
        public virtual DbSet<CommunicationSurveyColumnChange> CommunicationSurveyColumnChanges { get; set; }
        public virtual DbSet<CommunicationWebsite> CommunicationWebsites { get; set; }
        public virtual DbSet<CommunicationWebsiteColumn> CommunicationWebsiteColumns { get; set; }
        public virtual DbSet<CommunicationWebsiteColumnChange> CommunicationWebsiteColumnChanges { get; set; }
        public virtual DbSet<DeviceAdvice> DeviceAdvices { get; set; }
        public virtual DbSet<DeviceAdviceColumn> DeviceAdviceColumns { get; set; }
        public virtual DbSet<DeviceAdviceColumnChange> DeviceAdviceColumnChanges { get; set; }
        public virtual DbSet<DeviceConfirmationTestResult> DeviceConfirmationTestResults { get; set; }
        public virtual DbSet<DeviceConfirmationTestResultColumn> DeviceConfirmationTestResultColumns { get; set; }
        public virtual DbSet<DeviceConfirmationTestResultColumnChange> DeviceConfirmationTestResultColumnChanges { get; set; }
        public virtual DbSet<DeviceInformation> DeviceInformations { get; set; }
        public virtual DbSet<DeviceInformationColumn> DeviceInformationColumns { get; set; }
        public virtual DbSet<DeviceInformationColumnChange> DeviceInformationColumnChanges { get; set; }
        public virtual DbSet<DevicePrescription> DevicePrescriptions { get; set; }
        public virtual DbSet<DevicePrescriptionColumn> DevicePrescriptionColumns { get; set; }
        public virtual DbSet<DevicePrescriptionColumnChange> DevicePrescriptionColumnChanges { get; set; }
        public virtual DbSet<FactWitness> FactWitnesses { get; set; }
        public virtual DbSet<FactWitnessColumn> FactWitnessColumns { get; set; }
        public virtual DbSet<FactWitnessColumnChange> FactWitnessColumnChanges { get; set; }
        public virtual DbSet<InjuryDetail> InjuryDetails { get; set; }
        public virtual DbSet<InjuryDetailColumn> InjuryDetailColumns { get; set; }
        public virtual DbSet<InjuryDetailColumnChange> InjuryDetailColumnChanges { get; set; }
        public virtual DbSet<InjuryExplanation> InjuryExplanations { get; set; }
        public virtual DbSet<InjuryInformation> InjuryInformations { get; set; }
        public virtual DbSet<InjuryInformationColumn> InjuryInformationColumns { get; set; }
        public virtual DbSet<InjuryInformationColumnChange> InjuryInformationColumnChanges { get; set; }
        public virtual DbSet<InjuryType> InjuryTypes { get; set; }
        public virtual DbSet<MedicalBackground> MedicalBackgrounds { get; set; }
        public virtual DbSet<MedicalBackgroundBirth> MedicalBackgroundBirths { get; set; }
        public virtual DbSet<MedicalBackgroundBirthColumn> MedicalBackgroundBirthColumns { get; set; }
        public virtual DbSet<MedicalBackgroundBirthColumnChange> MedicalBackgroundBirthColumnChanges { get; set; }
        public virtual DbSet<MedicalBackgroundChild> MedicalBackgroundChilds { get; set; }
        public virtual DbSet<MedicalBackgroundChildColumn> MedicalBackgroundChildColumns { get; set; }
        public virtual DbSet<MedicalBackgroundChildColumnChange> MedicalBackgroundChildColumnChanges { get; set; }
        public virtual DbSet<MedicalBackgroundColumn> MedicalBackgroundColumns { get; set; }
        public virtual DbSet<MedicalBackgroundColumnChange> MedicalBackgroundColumnChanges { get; set; }
        public virtual DbSet<MedicalBackgroundCondition> MedicalBackgroundConditions { get; set; }
        public virtual DbSet<MedicalBackgroundConditionColumn> MedicalBackgroundConditionColumns { get; set; }
        public virtual DbSet<MedicalBackgroundConditionColumnChange> MedicalBackgroundConditionColumnChanges { get; set; }
        public virtual DbSet<MedicalBackgroundInsurance> MedicalBackgroundInsurances { get; set; }
        public virtual DbSet<MedicalBackgroundInsuranceColumn> MedicalBackgroundInsuranceColumns { get; set; }
        public virtual DbSet<MedicalBackgroundInsuranceColumnChange> MedicalBackgroundInsuranceColumnChanges { get; set; }
        public virtual DbSet<MedicalBackgroundMedication> MedicalBackgroundMedications { get; set; }
        public virtual DbSet<MedicalBackgroundMedicationColumn> MedicalBackgroundMedicationColumns { get; set; }
        public virtual DbSet<MedicalBackgroundMedicationColumnChange> MedicalBackgroundMedicationColumnChanges { get; set; }
        public virtual DbSet<MedicalBackgroundPharmacy> MedicalBackgroundPharmacies { get; set; }
        public virtual DbSet<MedicalBackgroundPharmacyColumn> MedicalBackgroundPharmacyColumns { get; set; }
        public virtual DbSet<MedicalBackgroundPharmacyColumnChange> MedicalBackgroundPharmacyColumnChanges { get; set; }
        public virtual DbSet<MedicalBackgroundPregnancy> MedicalBackgroundPregnancies { get; set; }
        public virtual DbSet<MedicalBackgroundPregnancyColumn> MedicalBackgroundPregnancyColumns { get; set; }
        public virtual DbSet<MedicalBackgroundPregnancyColumnChange> MedicalBackgroundPregnancyColumnChanges { get; set; }
        public virtual DbSet<MedicalRecordReview> MedicalRecordReviews { get; set; }
        public virtual DbSet<MedicalRecordReviewColumn> MedicalRecordReviewColumns { get; set; }
        public virtual DbSet<MedicalRecordReviewColumnChange> MedicalRecordReviewColumnChanges { get; set; }
        public virtual DbSet<MedicalRecordReviewDocument> MedicalRecordReviewDocuments { get; set; }
        public virtual DbSet<MedicalRecordReviewDocumentColumn> MedicalRecordReviewDocumentColumns { get; set; }
        public virtual DbSet<MedicalRecordReviewDocumentColumnChange> MedicalRecordReviewDocumentColumnChanges { get; set; }
        public virtual DbSet<MedicalRecordReviewSection> MedicalRecordReviewSections { get; set; }
        public virtual DbSet<PatientAlia> PatientAlias { get; set; }
        public virtual DbSet<PatientAliasColumn> PatientAliasColumns { get; set; }
        public virtual DbSet<PatientAliasColumnChange> PatientAliasColumnChanges { get; set; }
        public virtual DbSet<PatientBankruptcy> PatientBankruptcies { get; set; }
        public virtual DbSet<PatientBankruptcyColumn> PatientBankruptcyColumns { get; set; }
        public virtual DbSet<PatientBankruptcyColumnChange> PatientBankruptcyColumnChanges { get; set; }
        public virtual DbSet<PatientBenefit> PatientBenefits { get; set; }
        public virtual DbSet<PatientBenefitColumn> PatientBenefitColumns { get; set; }
        public virtual DbSet<PatientBenefitColumnChange> PatientBenefitColumnChanges { get; set; }
        public virtual DbSet<PatientChild> PatientChilds { get; set; }
        public virtual DbSet<PatientChildColumn> PatientChildColumns { get; set; }
        public virtual DbSet<PatientChildColumnChange> PatientChildColumnChanges { get; set; }
        public virtual DbSet<PatientEmploymentAbsence> PatientEmploymentAbsences { get; set; }
        public virtual DbSet<PatientEmploymentAbsenceColumn> PatientEmploymentAbsenceColumns { get; set; }
        public virtual DbSet<PatientEmploymentAbsenceColumnChange> PatientEmploymentAbsenceColumnChanges { get; set; }
        public virtual DbSet<PatientInformation> PatientInformations { get; set; }
        public virtual DbSet<PatientInformationColumn> PatientInformationColumns { get; set; }
        public virtual DbSet<PatientInformationColumnChange> PatientInformationColumnChanges { get; set; }
        public virtual DbSet<PatientInsurance> PatientInsurances { get; set; }
        public virtual DbSet<PatientInsuranceColumn> PatientInsuranceColumns { get; set; }
        public virtual DbSet<PatientInsuranceColumnChange> PatientInsuranceColumnChanges { get; set; }
        public virtual DbSet<PatientLawsuit> PatientLawsuits { get; set; }
        public virtual DbSet<PatientLawsuitColumn> PatientLawsuitColumns { get; set; }
        public virtual DbSet<PatientLawsuitColumnChange> PatientLawsuitColumnChanges { get; set; }
        public virtual DbSet<QuestionResponseType> QuestionResponseTypes { get; set; }
        public virtual DbSet<SurgeryCommunication> SurgeryCommunications { get; set; }
        public virtual DbSet<SurgeryCommunicationColumn> SurgeryCommunicationColumns { get; set; }
        public virtual DbSet<SurgeryCommunicationColumnChange> SurgeryCommunicationColumnChanges { get; set; }
        public virtual DbSet<SurgeryDetail> SurgeryDetails { get; set; }
        public virtual DbSet<SurgeryDetailColumn> SurgeryDetailColumns { get; set; }
        public virtual DbSet<SurgeryDetailColumnChange> SurgeryDetailColumnChanges { get; set; }
        public virtual DbSet<SurgeryInformation> SurgeryInformations { get; set; }
        public virtual DbSet<SurgeryInformationColumn> SurgeryInformationColumns { get; set; }
        public virtual DbSet<SurgeryInformationColumnChange> SurgeryInformationColumnChanges { get; set; }
        public virtual DbSet<ClaimantGroup> ClaimantGroups { get; set; }
        public virtual DbSet<ClaimantToClaimantGroup> ClaimantToClaimantGroups { get; set; }
        public virtual DbSet<ClaimantCaseInformation> ClaimantCaseInformations { get; set; }
        public virtual DbSet<ClaimantMedicalRecordReview> ClaimantMedicalRecordReviews { get; set; }
        public virtual DbSet<ClaimantPatientInformation> ClaimantPatientInformations { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.Caption)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.CourtName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.DocketNumber)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeCapacity)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeAddress)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeCity)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeState)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativePostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeAppointedState)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeAppointedCourt)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeAppointedCourtCaseNumber)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.RepresentativeRelationship)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.DeathLocation)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformation>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CaseInformationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseInformationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Communication>()
                .Property(e => e.LawsuitDiscoveryTimeExplanation)
                .IsUnicode(false);

            modelBuilder.Entity<Communication>()
                .Property(e => e.LawsuitDiscoveryMethodExplanation)
                .IsUnicode(false);

            modelBuilder.Entity<Communication>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Communication>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<Communication>()
                .HasMany(e => e.CommunicationContacts)
                .WithRequired(e => e.Communication)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Communication>()
                .HasMany(e => e.CommunicationDefendants)
                .WithRequired(e => e.Communication)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Communication>()
                .HasMany(e => e.CommunicationFdas)
                .WithRequired(e => e.Communication)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Communication>()
                .HasMany(e => e.CommunicationGroups)
                .WithRequired(e => e.Communication)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Communication>()
                .HasMany(e => e.CommunicationSurveys)
                .WithRequired(e => e.Communication)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Communication>()
                .HasMany(e => e.CommunicationWebsites)
                .WithRequired(e => e.Communication)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CommunicationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContact>()
                .Property(e => e.ContactInformation)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContact>()
                .Property(e => e.Relationship)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContact>()
                .Property(e => e.CommunicationMethod)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContact>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContact>()
                .Property(e => e.ContactExplanation)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContact>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContact>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CommunicationContactColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContactColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContactColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContactColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationContactColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendant>()
                .Property(e => e.CommunicationMethod)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendant>()
                .Property(e => e.RepresentativeName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendant>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendant>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendant>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CommunicationDefendantColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendantColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendantColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendantColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationDefendantColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFda>()
                .Property(e => e.CommunicationMethod)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFda>()
                .Property(e => e.RecipientName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFda>()
                .Property(e => e.Content)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFda>()
                .Property(e => e.Response)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFda>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFda>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CommunicationFdaColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFdaColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFdaColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFdaColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationFdaColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationGroup>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationGroup>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationGroup>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CommunicationGroupColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationGroupColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationGroupColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationGroupColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationGroupColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurvey>()
                .Property(e => e.Party)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurvey>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurvey>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurvey>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CommunicationSurveyColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurveyColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurveyColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurveyColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationSurveyColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationWebsite>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationWebsite>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationWebsite>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CommunicationWebsiteColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationWebsiteColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationWebsiteColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationWebsiteColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CommunicationWebsiteColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdvice>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdvice>()
                .Property(e => e.Source)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdvice>()
                .Property(e => e.Content)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdvice>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdvice>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<DeviceAdviceColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdviceColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdviceColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdviceColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceAdviceColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResult>()
                .Property(e => e.Result)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResult>()
                .Property(e => e.ResultProviderInformation)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResult>()
                .Property(e => e.ConfirmationTestProvider)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResult>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResult>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<DeviceConfirmationTestResultColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResultColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResultColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResultColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceConfirmationTestResultColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.LotNumbers)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PhysicianName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PhysicianAddress)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PhysicianAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PhysicianCity)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PhysicianState)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PhysicianPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.FacilityName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.FacilityAddress)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.FacilityAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.FacilityCity)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.FacilityState)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.FacilityPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PlacementComplicationInfo)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.PlacementComplicationInfoProvider)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ConfirmationTestType)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ConfirmationTestPhysician)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ConfirmationTestPhysicianAddress)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ConfirmationTestPhysicianAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ConfirmationTestPhysicianCity)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ConfirmationTestPhysicianState)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ConfirmationTestPhysicianPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformation>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<DeviceInformation>()
                .HasMany(e => e.DeviceAdvices)
                .WithRequired(e => e.DeviceInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<DeviceInformation>()
                .HasMany(e => e.DeviceConfirmationTestResults)
                .WithRequired(e => e.DeviceInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<DeviceInformation>()
                .HasMany(e => e.DevicePrescriptions)
                .WithRequired(e => e.DeviceInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<DeviceInformationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<DeviceInformationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.ContraceptionMethod)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.PrescriberName)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.PrescriberAddress)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.PrescriberAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.PrescriberCity)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.PrescriberState)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.PrescriberPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.UsageReason)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.DiscontinuedUsageReason)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescription>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<DevicePrescriptionColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescriptionColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescriptionColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescriptionColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<DevicePrescriptionColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.MiddleName)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.Address2)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.PostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.Relationship)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitness>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<FactWitnessColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitnessColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitnessColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitnessColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<FactWitnessColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.PhysicianName)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.PhysicianAddress)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.PhysicianAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.PhysicianCity)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.PhysicianState)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.PhysicianPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.FacilityName)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.FacilityAddress)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.FacilityAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.FacilityCity)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.FacilityState)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.FacilityPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.TreatmentDescription)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetail>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<InjuryDetailColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetailColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetailColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetailColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryDetailColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryExplanation>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformation>()
                .Property(e => e.PainLocation)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformation>()
                .Property(e => e.PainIntensity)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformation>()
                .Property(e => e.RecoveryDescription)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformation>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformation>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<InjuryInformation>()
                .HasMany(e => e.InjuryDetails)
                .WithRequired(e => e.InjuryInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<InjuryInformationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryInformationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryType>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<InjuryType>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<InjuryType>()
                .HasMany(e => e.InjuryDetails)
                .WithRequired(e => e.InjuryType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.CurrentHeight)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.CurrentWeight)
                .HasPrecision(6, 2);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.WeightAtPlacement)
                .HasPrecision(6, 2);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.PregnancyComplication)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.UnintendedPregnancyComplication)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.UnintendedPregnancyComplicationTreatment)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackground>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackground>()
                .HasMany(e => e.MedicalBackgroundBirths)
                .WithRequired(e => e.MedicalBackground)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackground>()
                .HasMany(e => e.MedicalBackgroundChilds)
                .WithRequired(e => e.MedicalBackground)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackground>()
                .HasMany(e => e.MedicalBackgroundConditions)
                .WithRequired(e => e.MedicalBackground)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackground>()
                .HasMany(e => e.MedicalBackgroundInsurances)
                .WithRequired(e => e.MedicalBackground)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackground>()
                .HasMany(e => e.MedicalBackgroundMedications)
                .WithRequired(e => e.MedicalBackground)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackground>()
                .HasMany(e => e.MedicalBackgroundPharmacies)
                .WithRequired(e => e.MedicalBackground)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackground>()
                .HasMany(e => e.MedicalBackgroundPregnancies)
                .WithRequired(e => e.MedicalBackground)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.LocationOfBirth)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.BirthAddress1)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.BirthAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.BirthCity)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.BirthState)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.BirthPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirth>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackgroundBirthColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirthColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirthColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirthColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundBirthColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChild>()
                .Property(e => e.ChildsFirstName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChild>()
                .Property(e => e.ChildsMiddleName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChild>()
                .Property(e => e.ChildsLastName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChild>()
                .Property(e => e.IssuesExperienced)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChild>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChild>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackgroundChildColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChildColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChildColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChildColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundChildColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.Condition)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.Treatment)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.DaysOfTreatment)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.PhysicianName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.PhysicianAddress)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.PhysicianAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.PhysicianCity)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.PhysicianState)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.PhysicianPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundCondition>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackgroundConditionColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundConditionColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundConditionColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundConditionColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundConditionColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsurance>()
                .Property(e => e.Company)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsurance>()
                .Property(e => e.PolicyNumber)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsurance>()
                .Property(e => e.PolicyHolder)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsurance>()
                .Property(e => e.DatesOfCoverage)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsurance>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsurance>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackgroundInsuranceColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsuranceColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsuranceColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsuranceColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundInsuranceColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.MedicationName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.ProviderName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.DatesOrYearsTaken)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.PharmacyName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.PharmacyAddress)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.PharmacyAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.PharmacyCity)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.PharmacyState)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.PharmacyPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.PharmacyPhone)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedication>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackgroundMedicationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedicationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedicationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedicationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundMedicationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.PharmacyName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.PharmacyAddress)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.PharmacyAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.PharmacyCity)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.PharmacyState)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.PharmacyPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.PharmacyPhone)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacy>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackgroundPharmacyColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacyColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacyColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacyColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPharmacyColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.PregnancyLearnedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.PhysicianName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.PhysicianAddress)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.PhysicianAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.PhysicianCity)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.PhysicianState)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.PhysicianPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.Outcome)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancy>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalBackgroundPregnancyColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancyColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancyColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancyColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalBackgroundPregnancyColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.CaseInformations)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.Communications)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.DeviceInformations)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.FactWitnesses)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.InjuryInformations)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.MedicalBackgrounds)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.MedicalRecordReviewDocuments)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.PatientInformations)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReview>()
                .HasMany(e => e.SurgeryInformations)
                .WithRequired(e => e.MedicalRecordReview)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MedicalRecordReviewColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewDocument>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewDocument>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewDocument>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MedicalRecordReviewDocumentColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewDocumentColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewDocumentColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewDocumentColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewDocumentColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewSection>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<MedicalRecordReviewSection>()
                .HasMany(e => e.MedicalRecordReviewDocuments)
                .WithRequired(e => e.MedicalRecordReviewSection)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientAlia>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<PatientAlia>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientAlia>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientAliasColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientAliasColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientAliasColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientAliasColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientAliasColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcy>()
                .Property(e => e.CourtName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcy>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcy>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcy>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientBankruptcyColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcyColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcyColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcyColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBankruptcyColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.ClaimType)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.ClaimDescription)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.ClaimOutcome)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.ClaimBasis)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.Agency)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.ClaimNumber)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefit>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientBenefitColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefitColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefitColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefitColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientBenefitColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChild>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChild>()
                .Property(e => e.MiddleName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChild>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChild>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChild>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientChildColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChildColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChildColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChildColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientChildColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientEmploymentAbsence>()
                .Property(e => e.Reason)
                .IsUnicode(false);

            modelBuilder.Entity<PatientEmploymentAbsence>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientEmploymentAbsence>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientEmploymentAbsenceColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientEmploymentAbsenceColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientEmploymentAbsenceColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientEmploymentAbsenceColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientEmploymentAbsenceColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpouseFirstName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpouseMiddleName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpouseLastName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpouseAddress)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpouseAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpouseCity)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpouseState)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.SpousePostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.EmployerName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.Position)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformation>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientInformation>()
                .HasMany(e => e.PatientAlias)
                .WithRequired(e => e.PatientInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientInformation>()
                .HasMany(e => e.PatientBankruptcies)
                .WithRequired(e => e.PatientInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientInformation>()
                .HasMany(e => e.PatientBenefits)
                .WithRequired(e => e.PatientInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientInformation>()
                .HasMany(e => e.PatientChilds)
                .WithRequired(e => e.PatientInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientInformation>()
                .HasMany(e => e.PatientEmploymentAbsences)
                .WithRequired(e => e.PatientInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientInformation>()
                .HasMany(e => e.PatientInsurances)
                .WithRequired(e => e.PatientInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientInformation>()
                .HasMany(e => e.PatientLawsuits)
                .WithRequired(e => e.PatientInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatientInformationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInformationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsurance>()
                .Property(e => e.CompanyName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsurance>()
                .Property(e => e.DenialReason)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsurance>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsurance>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientInsuranceColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsuranceColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsuranceColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsuranceColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientInsuranceColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuit>()
                .Property(e => e.CaseNature)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuit>()
                .Property(e => e.Parties)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuit>()
                .Property(e => e.CaseNumber)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuit>()
                .Property(e => e.CaseLocation)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuit>()
                .Property(e => e.AttorneyName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuit>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuit>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<PatientLawsuitColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuitColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuitColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuitColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<PatientLawsuitColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<QuestionResponseType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.Communications)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.HasCommunicationOtherResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.Communications1)
                .WithOptional(e => e.QuestionResponseType1)
                .HasForeignKey(e => e.HasCommunicationResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.Communications2)
                .WithOptional(e => e.QuestionResponseType2)
                .HasForeignKey(e => e.HasMadeComplaintResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.Communications3)
                .WithOptional(e => e.QuestionResponseType3)
                .HasForeignKey(e => e.HasTakenSurveyResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.Communications4)
                .WithOptional(e => e.QuestionResponseType4)
                .HasForeignKey(e => e.HasVisitedWebsiteResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.CommunicationContacts)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.IsProducingCommunicationResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.DeviceInformations)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.HadConfirmationTestResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.DeviceInformations1)
                .WithOptional(e => e.QuestionResponseType1)
                .HasForeignKey(e => e.HadPlacementComplicationResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.InjuryDetails)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.HadTreatmentResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.InjuryDetails1)
                .WithOptional(e => e.QuestionResponseType1)
                .HasForeignKey(e => e.WasComplicationPriorToPlacementResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.InjuryInformations)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.DidRemovalResolveExistingInjuryResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.InjuryInformations1)
                .WithOptional(e => e.QuestionResponseType1)
                .HasForeignKey(e => e.HasRecoveredFromExistingInjuryResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.InjuryInformations2)
                .WithOptional(e => e.QuestionResponseType2)
                .HasForeignKey(e => e.HasWorsenedExistingInjuryResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.MedicalBackgrounds)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.HadBirthDefectsResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.MedicalBackgrounds1)
                .WithOptional(e => e.QuestionResponseType1)
                .HasForeignKey(e => e.HadPregnancyComplicationsResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.MedicalBackgrounds2)
                .WithOptional(e => e.QuestionResponseType2)
                .HasForeignKey(e => e.HasBeenPregnantResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.PatientBenefits)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.IsClaimDeniedResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.PatientInformations)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.HasAppliedForBenefitsResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.PatientInformations1)
                .WithOptional(e => e.QuestionResponseType1)
                .HasForeignKey(e => e.HasTakenEmploymentLeaveResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.PatientInformations2)
                .WithOptional(e => e.QuestionResponseType2)
                .HasForeignKey(e => e.HasSpouseFiledOtherClaimResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.PatientInformations3)
                .WithOptional(e => e.QuestionResponseType3)
                .HasForeignKey(e => e.IsEmployedResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.PatientInformations4)
                .WithOptional(e => e.QuestionResponseType4)
                .HasForeignKey(e => e.IsMarriedResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.SurgeryInformations)
                .WithOptional(e => e.QuestionResponseType)
                .HasForeignKey(e => e.ComplicationsAdvisedResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.SurgeryInformations1)
                .WithOptional(e => e.QuestionResponseType1)
                .HasForeignKey(e => e.DeviceRemovalPlanResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.SurgeryInformations2)
                .WithOptional(e => e.QuestionResponseType2)
                .HasForeignKey(e => e.DeviceRemovedResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.SurgeryInformations3)
                .WithOptional(e => e.QuestionResponseType3)
                .HasForeignKey(e => e.DeviceRetainedResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.SurgeryInformations4)
                .WithOptional(e => e.QuestionResponseType4)
                .HasForeignKey(e => e.DeviceReturnedResponseTypeId);

            modelBuilder.Entity<QuestionResponseType>()
                .HasMany(e => e.SurgeryInformations5)
                .WithOptional(e => e.QuestionResponseType5)
                .HasForeignKey(e => e.RemovalCommunicationResponseTypeId);

            modelBuilder.Entity<SurgeryCommunication>()
                .Property(e => e.CommunicationWith)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryCommunication>()
                .Property(e => e.CommunicationContent)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryCommunication>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryCommunication>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<SurgeryCommunicationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryCommunicationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryCommunicationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryCommunicationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryCommunicationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ProviderName)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ProviderAddress1)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ProviderAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ProviderCity)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ProviderState)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ProviderPostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ProcedureUsed)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetail>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<SurgeryDetailColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetailColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetailColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetailColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryDetailColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformation>()
                .Property(e => e.DeviceRetainedLocation)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformation>()
                .Property(e => e.ComplicationsAdvisedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformation>()
                .Property(e => e.ComplicationsAdvisedCommunication)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformation>()
                .Property(e => e.DeviceRemovalPlanProvider)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformation>()
                .Property(e => e.DeviceRemovalPlanReason)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformation>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformation>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<SurgeryInformation>()
                .HasMany(e => e.SurgeryCommunications)
                .WithRequired(e => e.SurgeryInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<SurgeryInformation>()
                .HasMany(e => e.SurgeryDetails)
                .WithRequired(e => e.SurgeryInformation)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<SurgeryInformationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<SurgeryInformationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantGroup>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantGroup>()
                .Property(e => e.Right)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantGroup>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantGroup>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<ClaimantGroup>()
                .HasMany(e => e.ClaimantToClaimantGroups)
                .WithRequired(e => e.ClaimantGroup)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ClaimantToClaimantGroup>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.MiddleName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.Address2)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.PostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.Ssn)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.Caption)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.CourtName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.DocketNumber)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeCapacity)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeAddress)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeCity)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeState)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativePostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeAppointedState)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeAppointedCourt)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeAppointedCourtCaseNumber)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.RepresentativeRelationship)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.DeathLocation)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.CaseRowVersion)
                .IsFixedLength();

            modelBuilder.Entity<ClaimantCaseInformation>()
                .Property(e => e.ClaimantRowVersion)
                .IsFixedLength();

            modelBuilder.Entity<ClaimantMedicalRecordReview>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantMedicalRecordReview>()
                .Property(e => e.RowVersion)
                .IsFixedLength();

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.MiddleName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.Address2)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.PostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.RepresentativeName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpouseFirstName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpouseMiddleName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpouseLastName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpouseAddress)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpouseAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpouseCity)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpouseState)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.SpousePostalCode)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.EmployerName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.Position)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.PatientRowVersion)
                .IsFixedLength();

            modelBuilder.Entity<ClaimantPatientInformation>()
                .Property(e => e.ClaimantRowVersion)
                .IsFixedLength();
        }
    }
}
