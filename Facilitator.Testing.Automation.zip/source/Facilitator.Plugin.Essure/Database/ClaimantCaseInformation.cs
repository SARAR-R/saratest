namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.ClaimantCaseInformation")]
    public partial class ClaimantCaseInformation
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CaseInformationId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int MedicalRecordReviewId { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TrackingNumber { get; set; }

        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(15)]
        public string MiddleName { get; set; }

        [StringLength(30)]
        public string LastName { get; set; }

        [StringLength(70)]
        public string Address { get; set; }

        [StringLength(70)]
        public string Address2 { get; set; }

        [StringLength(35)]
        public string City { get; set; }

        [StringLength(2)]
        public string State { get; set; }

        [StringLength(9)]
        public string PostalCode { get; set; }

        [StringLength(45)]
        public string RepresentativeName { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public DateTime? DateOfDeath { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(1)]
        public string Ssn { get; set; }

        public int? AttorneyId { get; set; }

        [StringLength(100)]
        public string Caption { get; set; }

        [StringLength(100)]
        public string CourtName { get; set; }

        [StringLength(100)]
        public string DocketNumber { get; set; }

        [StringLength(100)]
        public string RepresentativeCapacity { get; set; }

        [StringLength(70)]
        public string RepresentativeAddress { get; set; }

        [StringLength(70)]
        public string RepresentativeAddress2 { get; set; }

        [StringLength(35)]
        public string RepresentativeCity { get; set; }

        [StringLength(2)]
        public string RepresentativeState { get; set; }

        [StringLength(9)]
        public string RepresentativePostalCode { get; set; }

        [StringLength(100)]
        public string RepresentativeAppointedState { get; set; }

        [StringLength(100)]
        public string RepresentativeAppointedCourt { get; set; }

        [StringLength(100)]
        public string RepresentativeAppointedCourtCaseNumber { get; set; }

        [StringLength(100)]
        public string RepresentativeRelationship { get; set; }

        [StringLength(100)]
        public string DeathLocation { get; set; }

        public DateTime? InsertedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [MaxLength(8)]
        public byte[] CaseRowVersion { get; set; }

        [Key]
        [Column(Order = 4, TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ClaimantRowVersion { get; set; }
    }
}
