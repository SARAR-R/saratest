namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.CommunicationFda")]
    public partial class CommunicationFda
    {
        public int CommunicationFdaId { get; set; }

        public int CommunicationId { get; set; }

        public int Tracking_Number { get; set; }

        [Column(TypeName = "date")]
        public DateTime? CommunicationDate { get; set; }

        [StringLength(100)]
        public string CommunicationMethod { get; set; }

        [StringLength(100)]
        public string RecipientName { get; set; }

        [StringLength(250)]
        public string Content { get; set; }

        [StringLength(250)]
        public string Response { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual Communication Communication { get; set; }
    }
}
