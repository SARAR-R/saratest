namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.MedicalBackgroundMedicationColumn")]
    public partial class MedicalBackgroundMedicationColumn
    {
        public int MedicalBackgroundMedicationColumnId { get; set; }

        [Required]
        [StringLength(128)]
        public string ColumnName { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
