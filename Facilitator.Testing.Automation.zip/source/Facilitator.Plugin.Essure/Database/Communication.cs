namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("essure.Communication")]
    public partial class Communication
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Communication()
        {
            CommunicationContacts = new HashSet<CommunicationContact>();
            CommunicationDefendants = new HashSet<CommunicationDefendant>();
            CommunicationFdas = new HashSet<CommunicationFda>();
            CommunicationGroups = new HashSet<CommunicationGroup>();
            CommunicationSurveys = new HashSet<CommunicationSurvey>();
            CommunicationWebsites = new HashSet<CommunicationWebsite>();
        }

        public int CommunicationId { get; set; }

        public int MedicalRecordReviewId { get; set; }

        public int Tracking_Number { get; set; }

        public int? HasCommunicationResponseTypeId { get; set; }

        public int? HasCommunicationOtherResponseTypeId { get; set; }

        public int? HasMadeComplaintResponseTypeId { get; set; }

        public int? HasTakenSurveyResponseTypeId { get; set; }

        public int? HasVisitedWebsiteResponseTypeId { get; set; }

        [StringLength(500)]
        public string LawsuitDiscoveryTimeExplanation { get; set; }

        [StringLength(500)]
        public string LawsuitDiscoveryMethodExplanation { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual MedicalRecordReview MedicalRecordReview { get; set; }

        public virtual QuestionResponseType QuestionResponseType { get; set; }

        public virtual QuestionResponseType QuestionResponseType1 { get; set; }

        public virtual QuestionResponseType QuestionResponseType2 { get; set; }

        public virtual QuestionResponseType QuestionResponseType3 { get; set; }

        public virtual QuestionResponseType QuestionResponseType4 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommunicationContact> CommunicationContacts { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommunicationDefendant> CommunicationDefendants { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommunicationFda> CommunicationFdas { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommunicationGroup> CommunicationGroups { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommunicationSurvey> CommunicationSurveys { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CommunicationWebsite> CommunicationWebsites { get; set; }
    }
}
