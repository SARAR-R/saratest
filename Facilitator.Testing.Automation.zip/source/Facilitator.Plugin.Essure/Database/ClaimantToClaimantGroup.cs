namespace Facilitator.Plugin.Essure.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fac.ClaimantToClaimantGroup")]
    public partial class ClaimantToClaimantGroup
    {
        public int ClaimantToClaimantGroupId { get; set; }

        public int ClaimantGroupId { get; set; }

        public int Tracking_Number { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(20)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual ClaimantGroup ClaimantGroup { get; set; }
    }
}
