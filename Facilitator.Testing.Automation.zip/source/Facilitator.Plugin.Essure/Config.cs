﻿using System.Configuration;

namespace Facilitator.Plugin.Essure
{
    public class config : Facilitator.Template.config
    {

        public const string casename = "Essure";
        public const string connectionstring = "Data Source=D016ECASQLS01.epiqcorp.com,1433\\ECAKCDV01;Initial Catalog=Essure_QA;Integrated Security=True";

        //public const string plugin_name = "Dynamic Form"; TODO: add
        public const string plugin_name = "Essure";

        //public static string CaseName = ConfigurationManager.AppSettings.Get("casename");
        public static int TrackingNumber = 10;
        public static int ValidationTrackingNumber = 11;


    }
}
