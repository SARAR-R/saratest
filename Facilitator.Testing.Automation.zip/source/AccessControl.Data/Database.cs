﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessControl.Data
{
    public class Database
    {
        public static List<AuditLog> GetAuditLogData()
        {
            using (var context = new AccessControlEntities())
            {
                var query =
                    from c in context.AuditLogs
                    select c;

                return query.ToList();
            }
        }
        public static List<Case> GetCaseData()
        {
            using (var context = new AccessControlEntities())
            {
                var query =
                    from c in context.Cases
                    select c;

                return query.ToList();
            }
        }
        public static List<Subsystem> GetSubsystemData()
        {
            using (var context = new AccessControlEntities())
            {
                var query =
                    from c in context.Subsystems
                    select c;

                return query.ToList();
            }
        }
        public static List<Subsystem> GetSubsystemDataByName(string casename)
        {
            using (var context = new AccessControlEntities())
            {
                var query =
                    from c in context.Subsystems
                    where c.Name == casename
                    select c;

                return query.ToList();
            }
        }
        public static List<User> GetUserData()
        {
            using (var context = new AccessControlEntities())
            {
                var query =
                    from c in context.Users
                    select c;

                return query.ToList();
            }
        }
        public static List<User> GetUserDataByUserName(string username)
        {
            using (var context = new AccessControlEntities())
            {
                var query =
                    from c in context.Users
                    where c.UserName == username
                    select c;

                return query.ToList();
            }
        }
        public static List<User> GetUserDataByUserNameNot(string username)
        {
            using (var context = new AccessControlEntities())
            {
                var query =
                    from c in context.Users
                    where c.UserName != username
                    select c;

                return query.ToList();
            }
        }
    }
}
