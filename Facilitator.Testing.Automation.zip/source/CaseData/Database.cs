﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case.Data
{
    public class Database
    {
        public static List<Claimant> GetClaimantData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Claimants
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }
        public static List<Claimant> GetClaimantData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Claimants
                    select c;

                return query.ToList();
            }
        }

        public static List<Mailing> GetMailingData(int trackingNnumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Mailings
                    where c.Tracking_Number == trackingNnumber
                    select c;

                return query.ToList();
            }
        }
        public static List<Mailing> GetMailingData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Mailings
                    select c;

                return query.ToList();
            }
        }
        public static List<Note> GetNoteData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Notes
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }
        public static List<Note> GetNoteData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Notes
                    select c;

                return query.ToList();
            }
        }
        public static List<AuditLog> GetAuditLogData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.AuditLogs
                    where c.TrackingNumber == trackingNumber
                    select c;

                return query.ToList();
            }
        }
        public static List<AuditLog> GetAuditLogData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.AuditLogs
                    select c;
                return query.ToList();
            }
        }
        public static List<AltAddress> GetAltAddressData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.AltAddresses
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }
        public static List<AltAddress> GetAltAddressData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.AltAddresses
                    select c;

                return query.ToList();
            }
        }
        public static List<AltAddressData> GetAltAddressDataData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.AltAddressDatas
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }
        public static List<AltAddressData> GetAltAddressDataData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.AltAddressDatas
                    select c;

                return query.ToList();
            }
        }
        public static List<PhoneLog> GetPhoneLogData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.PhoneLogs
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }
        public static List<PhoneLog> GetPhoneLogData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.PhoneLogs
                    select c;

                return query.ToList();
            }
        }
        public static List<Document> GetDocumentData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Documents
                    where c.Tracking_Number == trackingNumber
                    select c;

                return query.ToList();
            }
        }
        public static List<Document> GetDocumentData()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Documents
                    select c;

                return query.ToList();
            }
        }

        public static List<ClaimantEncryptedData_Result> GetClaimantEncryptedData(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query = context.ClaimantEncryptedData(trackingNumber);

                return query.ToList();
            }

        }

        public static List<Communication> GetCommunication()
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Communications
                    select c;

                return query.ToList();
            }
        }

        public static List<Communication> GetCommunication(int trackingNumber)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Communications
                    where c.TrackingNumber == trackingNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<Communication> GetCommunication(int trackingNumber, string entity)
        {
            using (var context = new CaseEntities())
            {
                var query =
                    from c in context.Communications
                    where c.TrackingNumber == trackingNumber && c.EntityType == entity
                    select c;

                return query.ToList();
            }
        }

        public static void UpdateClaimantByTN(int trackingNumber, Claimant claimantObject)
        {
            using (var context = new CaseEntities())
            {
                var result = context.Claimants.SingleOrDefault(c => c.Tracking_Number == trackingNumber);

                if (claimantObject.First_Name_1 != null)
                {
                    result.First_Name_1 = claimantObject.First_Name_1;
                }
                if (claimantObject.First_Name_2 != null)
                {
                    result.First_Name_2 = claimantObject.First_Name_2;
                }
                if (claimantObject.Middle_Name_1 != null)
                {
                    result.Middle_Name_1 = claimantObject.Middle_Name_1;
                }
                if (claimantObject.Middle_Name_2 != null)
                {
                    result.Middle_Name_2 = claimantObject.Middle_Name_2;
                }
                if (claimantObject.Last_Name_1 != null)
                {
                    result.Last_Name_1 = claimantObject.Last_Name_1;
                }
                if (claimantObject.Last_Name_2 != null)
                {
                    result.Last_Name_2 = claimantObject.Last_Name_2;
                }
                if (claimantObject.Business_Name != null)
                {
                    result.Business_Name = claimantObject.Business_Name;
                }
                if (claimantObject.Address_1 != null)
                {
                    result.Address_1 = claimantObject.Address_1;
                }
                if (claimantObject.Address_2 != null)
                {
                    result.Address_2 = claimantObject.Address_2;
                }
                if (claimantObject.City != null)
                {
                    result.City = claimantObject.City;
                }
                if (claimantObject.State != null)
                {
                    result.State = claimantObject.State;
                }
                if (claimantObject.Zipcode != null)
                {
                    result.Zipcode = claimantObject.Zipcode;
                }
                if (claimantObject.Day_Phone_Number != null)
                {
                    result.Day_Phone_Number = claimantObject.Day_Phone_Number;
                }
                if (claimantObject.Evening_Phone_Number != null)
                {
                    result.Evening_Phone_Number = claimantObject.Evening_Phone_Number;
                }
                if (claimantObject.Release_Signed_Flag != null)
                {
                    result.Release_Signed_Flag = claimantObject.Release_Signed_Flag;
                }
                if (claimantObject.Date_of_Birth_1 != null)
                {
                    result.Date_of_Birth_1 = claimantObject.Date_of_Birth_1;
                }
                if (result != null)
                {
                    context.SaveChanges();
                }
            }
        }
    }
}
