﻿
using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Automation;
using System.Configuration;


namespace Facilitator.NECC.Tests
{

    public static class incomingDocument
    {
        public static By _Type = By.XPath("//select[../label/text() = 'Document Type']");
        public static By _Note = By.XPath("//textarea[../label/text() = 'Document Note']");
        public static By _SelectFiles = By.XPath("//button[contains(., 'Select Files')]");
        public static By _UploadFiles = By.XPath("//a[contains(., 'Upload Files')]");
        public static By _Clear = By.XPath("//a[contains(., 'Clear')]");
        public static By _Edit = By.XPath("//a[contains(@ng-click, 'edit') and contains(@ng-click, 'document')]");
        public static By _Delete = By.XPath("//a[contains(@ng-click, 'delete') and contains(@ng-click, 'document')]");
        public static By _Move = By.XPath("//a[contains(@ng-click, 'move') and contains(@ng-click, 'document')]");
        public static By _Save = By.XPath("//button[contains(@ng-click, 'ok')]");
        public static By _Cancel = By.XPath("//button[contains(@ng-click, 'cancel') and contains(@ng-click, 'DocumentForm')]");
        public static By _ExcelExport = By.XPath("//document//button[@ng-click='excelExport()']");
        public static By _UploadSection = By.XPath("//uploader");
        public static By _UploadStatus = By.XPath("//uploader//ul//div/div[3]/span");
        //Edit Modal
        public static By _DocumentType = By.XPath("//select[@ng-model='document.documentTypeId']");
        public static By _DocumentStatus = By.XPath("//select[@ng-model='document.documentStatusId']");
        public static By _DocID = By.Name("docId");
        public static By _OriginalFileName = By.Name("originalFileName");
        public static By _EditNote = By.XPath("//textarea[@ng-model='document.note']");
        //Delete Modal
        public static By _ProcessingNote = By.XPath("//textarea[@ng-model='document.processingNote']");
        public static By _ModalDelete = By.XPath("//button[contains(@ng-click, 'delete')]");
    }
}
