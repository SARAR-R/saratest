﻿using System;
using Automation;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Facilitator.NECC.Tests
{
    public static class user
    {
        public static void ChangePassword(IWebDriver driver, string username, string old_password, string new_password)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Automation.config.TIMEOUT));

            test.WaitForPageToLoad(driver);

            Template.navigate.ChangePassword(driver);

            wait.Until(d => (d.FindElements(By.Name("currentPassword")).Count != 0));
            //wait.Until(d => (d.FindElement(By.XPath("//div[@ng-model='vm.user.newPassword']//div[@class='ng-binding']")).Text != "Password must be at least characters in length"));
            test.EditField(driver, By.Name("currentPassword"), old_password);
            test.EditField(driver, By.Name("newPassword"), new_password);
            test.EditField(driver, By.Name("confirmNewPassword"), new_password);
            test.EditField(driver, By.Name("securityQuestion"), "Question");
            test.EditField(driver, By.Name("securityAnswer"), "Answer");
            test.Click(driver, By.CssSelector("button.btn.btn-primary"));
        }

    }
}
