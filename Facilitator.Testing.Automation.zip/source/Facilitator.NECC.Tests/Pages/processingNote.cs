﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace Facilitator.NECC.Tests
{

    public static class processingNote
    {
        public static By _Type = By.XPath("//select[../label/text() = 'Type']");
        public static By _Note = By.XPath("//textarea[../label/text() = 'Processing Note']");

        public static By _Save = By.XPath("//button[@ng-disabled='addNoteForm.$invalid']");
        public static By _Edit = By.XPath("//a[contains(@ng-click, 'edit') and contains(@ng-click, 'note')]/span[contains(@class, 'pencil')]");
        public static By _View = By.XPath("//a[contains(@ng-click, 'edit') and contains(@ng-click, 'note')]/span[contains(@class, 'list')]");
        public static By _Delete = By.XPath("//a[contains(@ng-click, 'delete') and contains(@ng-click, 'note')]");
        public static By _EditNote = By.XPath("//textarea[@ng-model='note.description']");
        public static By _ModalSave = By.XPath("//button[@ng-click='ok()']");
        public static By _ModalDelete = By.XPath("//button[@ng-click='delete()']");
        public static By _Cancel = By.XPath("//button[contains(@ng-click, 'cancel') and contains(@ng-click, 'NoteForm')]");
        public static By _ExcelExport = By.XPath("//note//button[@ng-click='excelExport()']");
        public static By _CreateProcessingNoteSection = By.XPath("//note//div[contains(@ng-show, 'note-ui-c')]");
    } 
}
