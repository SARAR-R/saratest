﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using Automation;
using System.Configuration;

namespace Facilitator.NECC.Tests
{
    class worksheetReview
    {
        //Worksheets section
        public static By _createNew = By.XPath("//button[@ng-click='updateSuggestions()']");
        public static By _reviewerType = By.Name("reviewerType");
        public static By _compensationCategory = By.Name("compensationCategory");
        public static By _worksheetDocId = By.Name("suggestedDocId");
        public static By _create = By.XPath("//button[@ng-click='createNew()']");
        public static By _cancel = By.XPath("//button[text()=' Cancel']");
        //Review Information section
        public static By _status = By.Name("worksheetReviewStatus");
        public static By _notes = By.Name("selectedWorksheetNotes");
        public static By _save = By.XPath("//button[text()=' Save']");
 
        public static void selectWorksheet(string reviewerType, string worksheetDocId)
        {
            By selector = By.XPath("//div[@ng-style='rowStyle(row)' and descendant::node()[contains(., '" + reviewerType + "')]and descendant::node()[contains(., '" + worksheetDocId + "')]]");
            try
            {
                report.Action("Click", selector.ToString());
                test.Click(test.driver, selector);
            }
            catch (Exception e)
            {
                report.Fail("Unable to click " + selector.ToString(), e);
            }
            
        }

        public static void createNewWorksheet(string reviewerType, string compensationCategory, string worksheetDocId)
        {
            test.Click(test.driver, worksheetReview._createNew);
            test.SelectField(test.driver, worksheetReview._reviewerType, reviewerType);
            test.SelectField(test.driver, worksheetReview._compensationCategory, compensationCategory);
            test.SelectField(test.driver, worksheetReview._worksheetDocId, worksheetDocId);
            test.Click(test.driver, worksheetReview._create);
        }

        public static int verifyNewWorksheet(string reviewerType, string compensationCategory, string worksheetDocID)
        {
            string username = ConfigurationManager.AppSettings.Get("username");
            string date = DateTime.Now.ToString("M/d/yyyy");
            test.ScrollUp(test.driver);
            if (
                Template.grid.retrieveFirstValue("Reviewer Type", "eca-basic-grid") == reviewerType &&
                Template.grid.retrieveFirstValue("Compensation Category", "eca-basic-grid") == compensationCategory &&
                Template.grid.retrieveFirstValue("Status", "eca-basic-grid") == "In Progress" &&
                //Template.grid.retrieveFirstValue("Recommended Status", "eca-basic-grid") == recStatus &&  -Removed for now due to variability based on random choices.
                Template.grid.retrieveFirstValue("Worksheet Doc ID", "eca-basic-grid") == worksheetDocID &&
                Template.grid.retrieveFirstValue("Created By", "eca-basic-grid") == username &&
                Template.grid.retrieveFirstValue("Created Date", "eca-basic-grid").Contains(date) &&
                Template.grid.retrieveFirstValue("Updated By", "eca-basic-grid") == username &&
                Template.grid.retrieveFirstValue("Updated Date", "eca-basic-grid").Contains(date)
                )
            {
                report.Pass("New Worksheet Created");
                return 0;
            }
            else
            {
                report.Fail("New Worksheet Not Created Properly");
                return 1;
            }
        }

        public static void updateCategory1Worksheet(string status)
        {
            string username = ConfigurationManager.AppSettings.Get("username");
            string date = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            Random rnd = new Random();

            test.SelectField(test.driver, _status, status);
            test.EditField(test.driver, _notes, "Review updated by " + username + " on " + date);

            for (int i = 0; i <= 15; i++)
            {
                string iteration = i.ToString();
                SelectElement answer = new SelectElement(test.driver.FindElement(By.Name("questionAnswer" + iteration)));             
                test.SelectFieldByIndex(test.driver, By.Name("questionAnswer" + iteration), rnd.Next(1, answer.Options.Count()));
                test.EditField(test.driver, By.Name("comment" + iteration), "Comment" + iteration + " inserted by " + username + " on " + date);
                if (test.driver.FindElement(By.XPath("//input[@name = 'reviewPoints" + iteration + "']/..")).GetAttribute("class") != "ng-hide")
                {
                    test.EditField(test.driver, By.Name("reviewPoints" + iteration), rnd.Next(0, 5).ToString());
                }
                if (test.driver.FindElement(By.Name("denialReason" + iteration)).Enabled)
                {
                    test.SelectFieldByIndex(test.driver, By.Name("denialReason" + iteration), rnd.Next(1, 7));
                }
            }

            test.Click(test.driver, _save);
        }
        public static int verifyUpdatedWorksheet(string reviewStatus)
        {
            string username = ConfigurationManager.AppSettings.Get("username");
            string date = DateTime.Now.ToString("M/d/yyyy");
            test.ScrollUp(test.driver);
            if (
                Template.grid.retrieveFirstValue("Status", "eca-basic-grid") == reviewStatus &&
                Template.grid.retrieveFirstValue("Updated By", "eca-basic-grid") == username &&
                Template.grid.retrieveFirstValue("Updated Date", "eca-basic-grid").Contains(date)
                )
            {
                report.Pass("Worksheet Updated Successfully");
                return 0;
            }
            else
            {
                report.Fail("Worksheet Not Updated Successfully");
                return 1;
            }
        }
    }
}
