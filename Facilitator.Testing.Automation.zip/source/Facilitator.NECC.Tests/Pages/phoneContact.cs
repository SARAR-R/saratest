﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace Facilitator.NECC.Tests
{
    
    public static class phoneContact
    {
        public static By _Type = By.XPath("//select[../label/text() = 'Call Type']");
        public static By _Disposition = By.XPath("//select[../label/text() = 'Disposition Type']");
        public static By _Note = By.XPath("//textarea[../label/text() = 'Phone Note']");
        public static By _Save = By.XPath("//button[@ng-disabled='addCallForm.$invalid']");
        public static By _Edit = By.XPath("//a[contains(@ng-click, 'edit') and contains(@ng-click, 'phonecontact')]");
        public static By _Move = By.XPath("//a[contains(@ng-click, 'move') and contains(@ng-click, 'phonecontact')]");
        public static By _Delete = By.XPath("//a[contains(@ng-click, 'delete') and contains(@ng-click, 'phonecontact')]");
        public static By _EditNote = By.XPath("//textarea[@ng-model='contact.description']");
        public static By _ProcessingNote = By.XPath("//textarea[@ng-model='contact.processingNote']");
        public static By _ModalSave = By.XPath("//button[@ng-click='ok()']");
        public static By _ModalDelete = By.XPath("//button[@ng-click='delete()']");
        public static By _FindTN = By.XPath("//button[@ng-click='getTargetClaimant()']");
        public static By _Cancel = By.XPath("//button[contains(@ng-click, 'cancel') and contains(@ng-click, 'PhoneContactForm')]");
        public static By _ExcelExport = By.XPath("//phone-contact//button[@ng-click='excelExport()']");
        public static By _CreatePhoneContactSection = By.XPath("//phone-contact//div[contains(@ng-show, 'phlog-ui-c')]");
    }
}
