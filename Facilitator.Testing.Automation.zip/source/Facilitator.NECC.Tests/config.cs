﻿namespace Facilitator.NECC.Tests
{
    public class config : Facilitator.Template.config

    {

        public const string url = "https://f5.epiqclassactionqa.com/NECC";
        public const string acapiurl = "https://accesscontrol.epiqsystems.com/preview/AuthenticationService.svc";
        public const string connectionstring ="Data Source = D016ECASQLS01.epiqcorp.com,1433\\ECAKCDV01;Initial Catalog = CA8491_QA; Integrated Security = True";
        public const string landing_page = "Quick Search";
        public const string document_type = "CalQlator";
        public const string plaintiff_claimant = "Plaintiff";
        
        }
}
