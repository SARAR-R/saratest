﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;
using System.Configuration;
using System.Diagnostics;
using Facilitator.Template;
using System.Data;

namespace Facilitator.NECC.Tests
{
    public class usecase
    {
        public static void EditProfile(IWebDriver driver, testVars vars)
        {

            string sendtext;

            try
            {
                testHelper.Start(driver);

                report.Step("Verify page loads without error");
                Template.navigate.EditProfile(driver);
                vars.verify(test.VerifyNoErrorToasts(driver));

                report.Step("Verify update saves without error");
                sendtext = test.GetCurrentDateTime().Substring(14, 9);

                test.EditField(driver, By.Name("title"), sendtext);

                test.ScrollDown(driver);
                userProfile.Save(driver);
                vars.verify(test.VerifyNoErrorToasts(driver));

                Automation.navigate.Refresh(driver);
                vars.verify(test.VerifyEditFieldText(driver, By.Name("title"), "value", sendtext));

                testHelper.End(driver);
            }

            finally { }
        }
        public static void ChangePassword(IWebDriver driver, testVars vars)
        {

            try
            {

                try  //Change password for user "automation2"
                {
                    Template.user.Login(driver, ConfigurationManager.AppSettings.Get("username2"), ConfigurationManager.AppSettings.Get("password"));

                    report.Step("Verify user can change password without error");
                    user.ChangePassword(driver, ConfigurationManager.AppSettings.Get("username2"), ConfigurationManager.AppSettings.Get("password"), ConfigurationManager.AppSettings.Get("new_password"));
                    vars.verify(test.VerifyNoErrorToasts(driver));
                    Template.user.Logout(driver);
                    //IE neeeds double logout in order to be able to logon again
                    if (vars.browsername.Equals("internet explorer")) { Template.user.Logout(driver); }

                    //Reset password back to default
                    report.Step("Verify new password login without error");
                    Template.user.Login(driver, ConfigurationManager.AppSettings.Get("username2"), ConfigurationManager.AppSettings.Get("new_password"));
                    vars.verify(test.VerifyNoErrorToasts(driver));
                    user.ChangePassword(driver, ConfigurationManager.AppSettings.Get("username2"), ConfigurationManager.AppSettings.Get("new_password"), ConfigurationManager.AppSettings.Get("password"));
                    Template.user.Logout(driver);
                }
                catch (Exception e)  //most likely the user is stuck with the 2nd password hence changing it back to the default password
                {
                    Template.user.Login(driver, ConfigurationManager.AppSettings.Get("username2"), ConfigurationManager.AppSettings.Get("new_password"));
                    user.ChangePassword(driver, ConfigurationManager.AppSettings.Get("username2"), ConfigurationManager.AppSettings.Get("new_password"), ConfigurationManager.AppSettings.Get("password"));
                    Template.user.Logout(driver);
                    report.Fail("Password has been reset back to default.  Please run test again. ", e);
                    
                }

            }

            finally { }
        }

        public static void WorksheetReview(IWebDriver driver, testVars vars)
        {
            try
            {
                testHelper.Start(driver, int.Parse(ConfigurationManager.AppSettings.Get("tracking_number")));
                Automation.navigate.ByLinkText(driver, "Worksheet Review");

                test.WaitForElement(worksheetReview._createNew);
                if (test.driver.FindElement(worksheetReview._createNew).Enabled == false)
                {
                    report.Action("Updating current worksheet to", "Void");
                    test.SelectField(test.driver, worksheetReview._status, "Void");
                    test.Click(driver, worksheetReview._save);
                }

                report.Step("Upload a new worksheet");
                test.ToggleSection(driver, "Incoming Documents");
                Template.incomingDocument.UploadDocument(driver, "Worksheet Review uploaded by automation");
                Template.incomingDocument.VerifyUpload();
                string worksheetDocId = grid.retrieveFirstValue("Doc ID", "document");
                Automation.navigate.Refresh(driver);

                report.Step("Create New Plaintiff Worksheet");
                worksheetReview.createNewWorksheet("Plaintiff", "Category I", worksheetDocId);
                vars.verify(test.VerifyNoErrorToasts());
                vars.verify(worksheetReview.verifyNewWorksheet("Plaintiff", "Category I", worksheetDocId));

                report.Step("Update Plaintiff Worksheet");
                worksheetReview.updateCategory1Worksheet("Original");
                vars.verify(test.VerifyNoErrorToasts());
                vars.verify(worksheetReview.verifyUpdatedWorksheet("Original"));

                report.Step("Create New Reviewer 1 Worksheet");
                worksheetReview.createNewWorksheet("Reviewer 1", "Category I", worksheetDocId);
                vars.verify(test.VerifyNoErrorToasts());
                vars.verify(worksheetReview.verifyNewWorksheet("Reviewer 1", "Category I", worksheetDocId));

                report.Step("Update Reviewer 1 Worksheet");
                worksheetReview.updateCategory1Worksheet("Approved");
                vars.verify(test.VerifyNoErrorToasts());
                vars.verify(worksheetReview.verifyUpdatedWorksheet("Approved"));

            }

            finally { }
        }
        public static void IncomingDocuments(IWebDriver driver, testVars vars)
        {
            string conn = ConfigurationManager.AppSettings.Get("connectionstring");

            testHelper.Start(driver, int.Parse(ConfigurationManager.AppSettings.Get("tracking_number")));

            Template.navigate.CommunicationPlus(driver, "Incoming Documents");
            //Add
            string note = "This is a test record inserted by automation: " + test.GetCurrentDateTime();
            Template.incomingDocument.UploadDocument(driver, note);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(Template.incomingDocument.VerifyUpload());
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='document']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);
            //Edit
            note = "This is a test record updated by automation: " + test.GetCurrentDateTime();
            test.Click(driver, incomingDocument._Edit);
            //string docType = database.getrandomrecord(conn, "lkp_Document_Type", "DocumentTypeName", " WHERE SequenceStart IS NOT NULL");
            //test.SelectField(driver, incomingDocument._DocumentType, docType);
            string docStatus = database.getrandomrecord(conn, "lkp_Document_Status", "DocumentStatusName", "");
            test.SelectField(driver, incomingDocument._DocumentStatus, docStatus);
            //string docID = database.getnextdocid(conn, docType).ToString();
            //test.EditField(driver, Template.incomingDocument._DocID, docID);

            //test.EditField(driver, Template.incomingDocument._OriginalFileName, test.GetCurrentDateTime() + ".txt");
            test.EditField(driver, incomingDocument._EditNote, note);

            test.Click(driver, Template.incomingDocument._Save);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='document']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);

            ////Delete
            //note = "This is a test record deleted by automation: " + test.GetCurrentDateTime();
            //test.Click(driver, Template.incomingDocument._Delete);
            //test.EditField(driver, incomingDocument._ProcessingNote, note);
            //test.ClickandConfirm(driver, incomingDocument._ModalDelete);
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifySuccessToast(driver, "The document record has been successfully deleted!"));

            ////Verify deletion note
            //Automation.navigate.ByLinkText(driver, "Processing Notes");
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifyTextContains(driver, By.XPath("//div[@id='note']"), note));

            ////Reupload a document to recreate the DocID (Necessary to not have orphaned documents causing future upload failures).
            //Automation.navigate.ByLinkText(driver, "Incoming Documents");
            //Template.incomingDocument.UploadDocument(driver, note);

            testHelper.End(driver);
        }

        public static void OutgoingMailings(IWebDriver driver, testVars vars)
        {
            testHelper.Start(driver, int.Parse(ConfigurationManager.AppSettings.Get("tracking_number")));
            Template.navigate.CommunicationPlus(driver, "Outgoing Mailings");

            //Add
            string note = "This is a test record inserted by automation: " + test.GetCurrentDateTime();
            Template.outgoingMailing.AddOutgoingMailing("Email", note);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='mailing']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);
            //Edit
            note = "This is a test record updated by automation: " + test.GetCurrentDateTime();
            test.Click(driver, outgoingMailing._Edit);
            test.EditField(driver, outgoingMailing._EditNote, note);
            driver.FindElement(outgoingMailing._EditNote).SendKeys(Keys.Tab);  //Necessary for the IE webdriver to enable save button.
            test.Click(driver, outgoingMailing._ModalSave);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='mailing']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);
            //Delete
            //note = "This is a test record deleted by automation: " + test.GetCurrentDateTime();
            //test.Click(driver, outgoingMailing._Delete);
            //test.EditField(driver, outgoingMailing._ProcessingNote, note);
            //driver.FindElement(outgoingMailing._ProcessingNote).SendKeys(Keys.Tab);  //Necessary for the IE webdriver to enable save button.
            //test.ClickandConfirm(driver, outgoingMailing._ModalDelete);
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifySuccessToast(driver, "The mailing record has been successfully deleted!"));
            ////Verify Delete
            //Automation.navigate.ByLinkText(driver, "Processing Notes");
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifyTextContains(driver, By.XPath("//div[@id='note']"), note));

            testHelper.End(driver);
        }
        public static void PhoneContacts(IWebDriver driver, testVars vars)
        {
            int tn = int.Parse(ConfigurationManager.AppSettings.Get("tracking_number"));
            testHelper.Start(driver, tn);

            Template.navigate.CommunicationPlus(driver, "Phone Contacts");

            //Add
            string note = "This is a test record inserted by automation: " + test.GetCurrentDateTime();
            Template.phoneContact.AddPhoneContact(driver, "Status Inquiry", "Status Update", note);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='contact']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);
            //Edit
            note = "This is a test record updated by automation: " + test.GetCurrentDateTime();
            test.Click(driver, phoneContact._Edit);
            test.EditField(driver, phoneContact._EditNote, note);
            driver.FindElement(phoneContact._EditNote).SendKeys(Keys.Tab);  //Necessary for the IE webdriver to enable save button.
            test.Click(driver, phoneContact._ModalSave);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='contact']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);
            //Move
            //string originalnote = note;
            //note = "This is a test record moved by automation: " + test.GetCurrentDateTime();
            //test.Click(driver, phoneContact._Move);
            //test.EditField(driver, By.Name("targetTrackingNumber"), (tn + 1).ToString());
            //driver.FindElement(By.Name("targetTrackingNumber")).SendKeys(Keys.Tab);  //Necessary for the IE webdriver to enable save button.
            //test.Click(driver, phoneContact._FindTN);
            //test.EditField(driver, phoneContact._ProcessingNote, note);
            //driver.FindElement(phoneContact._ProcessingNote).SendKeys(Keys.Tab);  //Necessary for the IE webdriver to enable save button.
            //test.Click(driver, phoneContact._ModalSave);
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifySuccessToast(driver, "The phone contact record has been successfully moved!"));

            ////Verify Move Note on Original TN
            //Automation.navigate.ByLinkText(driver, "Processing Notes");
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifyTextContains(driver, By.XPath("//div[@id='note']"), note));

            ////Verify Note on New TN
            //Template.navigate.ClaimantByTN(driver, tn + 1);
            //Template.navigate.CommunicationPlus(driver, "Phone Contacts");
            //grid.WaitForGridData();
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifyText(driver, By.XPath("//div[@id='contact']//div[.='" + originalnote + "']"), originalnote));

            ////Verify Move Note on New TN
            //Automation.navigate.ByLinkText(driver, "Processing Notes");
            //Template.navigate.CommunicationPlus(driver, "Processing Notes");
            //grid.WaitForGridData();
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifyTextContains(driver, By.XPath("//div[@id='note']"), note));

            ////Delete
            //note = "This is a test record deleted by automation: " + test.GetCurrentDateTime();
            //Automation.navigate.ByLinkText(driver, "Phone Contacts");
            //test.Click(driver, phoneContact._Delete);
            //test.EditField(driver, phoneContact._ProcessingNote, note);
            //driver.FindElement(phoneContact._ProcessingNote).SendKeys(Keys.Tab);  //Necessary for the IE webdriver to enable save button.
            //test.ClickandConfirm(driver, phoneContact._ModalDelete);
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifySuccessToast(driver, "The phone contact record has been successfully deleted!"));

            ////Verify Delete Note
            //Automation.navigate.ByLinkText(driver, "Processing Notes");
            //vars.verify(test.VerifyNoErrorToasts(driver));
            //vars.verify(test.VerifyTextContains(driver, By.XPath("//div[@id='note']"), note));

            testHelper.End(driver);
        }

        public static void ProcessingNotes(IWebDriver driver, testVars vars)
        {
            testHelper.Start(driver, int.Parse(ConfigurationManager.AppSettings.Get("tracking_number")));
            Template.navigate.CommunicationPlus(driver, "Processing Notes");

            //Add
            string note = "This is a test record inserted by automation: " + test.GetCurrentDateTime();
            Template.processingNote.AddProcessingNote(driver, "Processing", note);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='note']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);
            //Edit
            note = "This is a test record updated by automation: " + test.GetCurrentDateTime();
            test.Click(driver, processingNote._Edit);
            test.EditField(driver, processingNote._EditNote, note);
            driver.FindElement(processingNote._EditNote).SendKeys(Keys.Tab);  //Necessary for the IE webdriver to enable save button.
            test.Click(driver, processingNote._ModalSave);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifyText(driver, By.XPath("//div[@id='note']//div[.='" + note + "']"), note));
            Automation.navigate.Refresh(driver);
            //Delete
            test.Click(driver, processingNote._Delete);
            test.ClickandConfirm(driver, processingNote._ModalDelete);
            vars.verify(test.VerifyNoErrorToasts(driver));
            vars.verify(test.VerifySuccessToast(driver, "The processing note record has been successfully deleted!"));

            testHelper.End(driver);
        }

        public static void ResetPassword(IWebDriver driver, testVars vars)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Automation.config.TIMEOUT));
            string username = ConfigurationManager.AppSettings.Get("username2");
            string password = ConfigurationManager.AppSettings.Get("password");

            try
            {
                driver.Navigate().GoToUrl(ConfigurationManager.AppSettings.Get("url"));
                driver.Manage().Window.Maximize();
                wait.Until(d => (d.FindElements(By.Name("username")).Count != 0));

                report.Step("Generate Reset Password Email");
                test.Click(driver, By.LinkText("Forgot your password?"));
                wait.Until(d => (d.FindElements(By.Name("username")).Count != 0));
                test.EditField(driver, By.Name("username"), username);
                System.Threading.Thread.Sleep(500);
                test.Click(driver, By.XPath("//button[@ng-click='checkUsername()']"));
                wait.Until(d => (d.FindElements(By.Name("securityAnswer")).Count != 0));
                test.EditField(driver, By.Name("securityAnswer"), "Answer");
                System.Threading.Thread.Sleep(500);
                test.Click(driver, By.XPath("//button[@ng-click='resetPassword()']"));
                vars.verify(test.VerifyPageSourceText(driver, "Your password has been reset. An email with a temporary password has been sent to the email address on file for the provided username.", true));

                System.Threading.Thread.Sleep(30000); //Wait for email to get to server.

                report.Step("Retrieve new password from email");
                email.gmail_login();
                email.gmail_open(By.XPath("//span/b[text()='Password Reset Request']"));
                System.Threading.Thread.Sleep(500);
                string message = driver.FindElement(By.XPath("(//div[contains(text(), 'Your password has been reset.')])[last()]")).Text;
                int startPos = message.LastIndexOf("New Password: ", StringComparison.Ordinal) + "New Password: ".Length;
                string newpassword = message.Substring(startPos, 14);
                email.gmail_logout();

                report.Step("Reset password");
                driver.Navigate().GoToUrl(ConfigurationManager.AppSettings.Get("url"));
                driver.Manage().Window.Maximize();
                wait.Until(d => (d.FindElements(By.Name("username")).Count != 0));

                report.Action("Login", username);
                test.EditField(driver, By.Name("username"), username);
                System.Threading.Thread.Sleep(500);
                test.EditField(driver, By.Name("password"), newpassword);
                test.Click(driver, By.CssSelector("button.btn.btn-primary"));
                test.WaitForElement(By.XPath("//div[text()='Change Password']"));
                vars.verify(test.VerifyPageSourceText(driver, "Your password is expired or temporary. Please update your security credentials."));

                test.EditField(driver, By.Name("currentPassword"), newpassword);
                test.EditField(driver, By.Name("newPassword"), password);
                test.EditField(driver, By.Name("confirmNewPassword"), password);
                test.EditField(driver, By.Name("securityQuestion"), "Question");
                test.EditField(driver, By.Name("securityAnswer"), "Answer");
                test.Click(driver, By.XPath("//button[@ng-click='updatePassword()']"));
                vars.verify(test.VerifyPageSourceText(driver, "Your password has been successfully changed. Please login with your new password to proceed."));

                report.Step("Verify new password login without error");
                Template.user.Login(driver, username, password);
                vars.verify(test.VerifyNoErrorToasts(driver));
                Template.user.Logout(driver);
            }

            finally { }
        }
    }
}
