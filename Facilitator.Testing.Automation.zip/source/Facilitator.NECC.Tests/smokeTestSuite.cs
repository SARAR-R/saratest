﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;
using System.Configuration;

namespace Facilitator.NECC.Tests
{

    [TestClass]
    public class NECCsmokeTestSuite
    {
        public TestContext TestContext { get; set; }

        void Main(string[] args) { }

        [TestInitialize]
        public void startup()
        {
            test.startup(TestContext);
        }

        [TestCleanup]
        public void teardown()
        {
            test.teardown();
        }

        [TestMethod]
        public void NECC_EditProfile()
        {
            usecase.EditProfile(test.driver, test.vars);
        }
        [TestMethod]
        public void NECC_ChangePassword()
        {
            usecase.ChangePassword(test.driver, test.vars);
        }
        [TestMethod]
        public void NECC_PhoneAgent()
        {
           Template.Tests.usecase.PhoneAgent(test.driver, test.vars, int.Parse(ConfigurationManager.AppSettings.Get("tracking_number")));
        }


        [TestMethod]
        public void NECC_Communication()
        {
            Template.Tests.usecase.Communication(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_UploadDownload()
        {
            Template.Tests.usecase.UploadDownload(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_Logon()
        {
            Template.Tests.usecase.Logon(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_Logout()
        {
            Template.Tests.usecase.Logout(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_ClaimantSave()
        {
            Template.Tests.usecase.ClaimantSave(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_Queries()
        {
            Template.Tests.usecase.Queries(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_TechConfig()
        {
            Template.Tests.usecase.TechConfig(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_Search()
        {
            Template.Tests.usecase.Search(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_LinkClaimant()
        {
            Template.Tests.usecase.LinkClaimant(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_History()
        {
            Template.Tests.usecase.History(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_Reports()
        {
            Template.Tests.usecase.Reports(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_AuditLog()
        {
            Template.Tests.usecase.AuditLog(test.driver, test.vars);
        }


    }
}
