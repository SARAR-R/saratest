﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;
using System.Configuration;

namespace Facilitator.NECC.Tests
{

    [TestClass]
    public class NECCregressionTestSuite
    {
        public TestContext TestContext { get; set; }

        void Main(string[] args) { }

        [TestInitialize]
        public void startup()
        {
            test.startup(TestContext);
        }

        [TestCleanup]
        public void teardown()
        {
            test.teardown();
        }

        [TestMethod]
        public void NECC_WorksheetReview()
        {
            usecase.WorksheetReview(test.driver, test.vars);
        }
        [TestMethod]
        public void NECC_QuickSearchAllFields()
        {
            Template.Tests.usecase.QuickSearchAllFields(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_StandardSearchAllFields()
        {
            Template.Tests.usecase.StandardSearchAllFields(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_StandardSearchCriteria()
        {
            Template.Tests.usecase.StandardSearchCriteria(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_AdvancedSearchFields()
        {
            Template.Tests.usecase.AdvancedSearchFields(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_AdvancedSearchCriteria()
        {
            Template.Tests.usecase.AdvancedSearchCriteria(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_ClaimantPersonalInfo()
        {
            Template.Tests.usecase.ClaimantPersonalInfo(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_ClaimantClaimInfo()
        {
            Template.Tests.usecase.ClaimantClaimInfo(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_CombinedCommunication()
        {
            Template.Tests.usecase.CombinedCommunication(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_IncomingDocuments()
        {
            usecase.IncomingDocuments(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_OutgoingMailings()
        {
            usecase.OutgoingMailings(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_PhoneContacts()
        {
            usecase.PhoneContacts(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_ProcessingNotes()
        {
            usecase.ProcessingNotes(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_HistoryCriteria()
        {
            Template.Tests.usecase.HistoryCriteria(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_HistoryFields()
        {
            Template.Tests.usecase.HistoryFields(test.driver, test.vars);
        }

        [TestMethod]
        public void NECC_ResetPassword()
        {
            usecase.ResetPassword(test.driver, test.vars);
        }
    }
}
