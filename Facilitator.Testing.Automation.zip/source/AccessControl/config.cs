﻿namespace AccessControl.Tests
{
    public class config : Facilitator.Template.config
    {
        public const string url = "https://f5.epiqclassactionqa.com/AccessControl20";
        public const string connectionstring = "Data Source=D016ECASQLS01.epiqcorp.com,1433\\ECAKCDV01;Initial Catalog=AccessControl20_QA;Integrated Security=True";
        public const string application = "Access Control";
        public const string user_search = "User Search";
        public const string create_user = "Create New User";
        public const string queries = "Account Queries";
        public const string landing_page = "User Search";
    }
}
