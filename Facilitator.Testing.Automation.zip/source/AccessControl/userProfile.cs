﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace AccessControl.Tests
{

    public class userProfile : Facilitator.Template.userProfile
    {

        static string _AvailableItemsXPath = "//div[@items='availableItems']//..//div[@class='assignmentItems ng-scope']";
        static string _AssignedItemsXPath = "//div[@items='assignedItems']//..//div[@class='assignmentItems ng-scope']";

        public static By _Assign = By.XPath("//button[@ng-click='addSelectedItems()']");
        public static By _Remove = By.XPath("//button[@ng-click='removeSelectedItems()']");
        
        public static By _AvailableItems = By.XPath(_AvailableItemsXPath);
        public static By _AssignedItems = By.XPath(_AssignedItemsXPath);

        public static void Assign(IWebDriver driver)
        {
            test.Click(driver, _Assign);
        }

        public static void Remove(IWebDriver driver)
        {
            test.Click(driver, _Remove);            
        }

        public static string AssignTopRole(IWebDriver driver)
        {
            string role = driver.FindElement(By.XPath(_AvailableItemsXPath + "//div//label")).Text;
            test.Click(driver, By.XPath(_AvailableItemsXPath + "//div//label"));
            Assign(driver);
            return role;
        }

        public static string RemoveTopRole(IWebDriver driver)
        {
            string role = driver.FindElement(By.XPath(_AssignedItemsXPath + "//div//label")).Text;
            test.Click(driver, By.XPath(_AssignedItemsXPath + "//div//label"));
            Remove(driver);
            return role;
        }
    
    }
}
