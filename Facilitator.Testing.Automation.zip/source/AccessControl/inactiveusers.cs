﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace AccessControl.Tests
{

    public class inactiveusers
    {

      //  private static By _AddNewCompany = By.XPath("//button[@ng-click='vm.add()']");

        public static By _userName = By.XPath("//input[@ng-model='vm.token']");

       // public static By _abbreviation = By.Name("abbreviation");
       // public static By _LinksAsText = By.Name("includeLinksAsTextInNotifications");

        private static By _Save = By.XPath("//button[@ng-click='vm.save()']");

        //private static By _ManageCompany = By.XPath("//i[@title='Manage Company']");
        //private static By _EditCompany = By.LinkText("Edit Company");
        //private static By _DeleteCompany = By.LinkText("Delete Company");
        //private static By _DeleteCompanyYes = By.XPath("//button[@ng-click='yes()']");

    

        public static void Save(IWebDriver driver)
        {
            test.Click(driver, _Save);
           

        }

       

    }
}
