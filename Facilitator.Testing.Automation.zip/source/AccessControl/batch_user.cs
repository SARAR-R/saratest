﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace AccessControl.Tests
{

    public class batch_user
    {

        public static void StandardImport()
        {
            test.SelectField(By.XPath("//select[@ng-model='vm.operationType']"), "Standard Import");
            Facilitator.Template.upload.Upload("C:\\Selenium\\ac_batch_user_update.txt");           
            
        }   
    }
}
