﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Linq;

namespace AccessControl.Tests
{
    public class navigate : Facilitator.Template.navigate
    {
        public static void CreateUser(IWebDriver driver)
        {
            navigate.ByLinkText(driver, ConfigurationManager.AppSettings.Get("create_user"));
        }

        public static void Company(IWebDriver driver)
        {
            navigate.ByLinkText(driver, "Company");
        }

        public static void BatchUser(IWebDriver driver)
        {
            navigate.ByLinkText(driver, "Batch User Operations");
        }

        public static void ManageUserTags(IWebDriver driver)
        {
            navigate.ByLinkText(driver, "Manage User Tags");
        }

        public static void Plugins(IWebDriver driver)
        {
            navigate.ByLinkText(driver, "Plugins");
        }

        public static new void Queries(IWebDriver driver)
        {
            navigate.ByLinkText(driver, ConfigurationManager.AppSettings.Get("queries"));
        }
    }
}
