﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace AccessControl.Tests
{

    public class company
    {

        private static By _AddNewCompany = By.XPath("//button[@ng-click='vm.add()']");

        public static By _CompanyName = By.Name("companyName");
        public static By _abbreviation = By.Name("abbreviation");
        public static By _LinksAsText = By.Name("includeLinksAsTextInNotifications");

        private static By _Save = By.XPath("//button[@ng-click='vm.save()']");

        private static By _ManageCompany = By.XPath("//i[@title='Manage Company']");
        private static By _EditCompany = By.LinkText("Edit Company");
        private static By _DeleteCompany = By.LinkText("Delete Company");
        private static By _DeleteCompanyYes = By.XPath("//button[@ng-click='yes()']");

        public static void Save(IWebDriver driver)
        {
            test.Click(driver, _Save);
        }

        public static void AddNewCompany(IWebDriver driver)
        {
            test.Click(driver, _AddNewCompany);
        }

        public static void EditCompany(IWebDriver driver)
        {
            test.Click(company._ManageCompany);
            test.Click(company._EditCompany);
        }

        public static void DeleteCompany(IWebDriver driver)
        {
            test.Click(company._ManageCompany);
            test.Click(company._DeleteCompany);
            test.Click(company._DeleteCompanyYes);
        }


    }
}
