﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Diagnostics;
using Automation;
using Facilitator.Template;
using AccessControl.Data;
using System.Linq;


namespace AccessControl.Tests
{
    public class usecase : Facilitator.Template.Tests.usecase
    {
        public static void UserSearch(IWebDriver driver, testVars vars)
        {

            try
            {
                testHelper.Start(driver);
                                
                report.Step("Verify User Search page loads without error");
                navigate.UserSearch(driver);
                test.VerifyNoErrorToasts(driver);

                report.Step("Verify User Search executes without error");

                if (ConfigurationManager.AppSettings.Get("performance_testing_enabled") == "true")
                {
                    search.UserSearch(driver, "aaa", "03. Search for aaa");
                    search.UserSearch(driver, "Aaron", "04. Search for Aaron");
                    search.UserSearch(driver, "Johnson", "05. Search for Johnson");
                }
                else
                {
                    string username = database.gettopfieldvalue(ConfigurationManager.AppSettings.Get("connectionstring"), "[User]", "Username");
                    //string username = Database.GetUserData().FirstOrDefault().UserName;
                    search.UserSearch(driver, username);
                    test.VerifyNoErrorToasts(driver);

                    report.Step("Verify User Search result selection occurs without error");
                    search.SelectSearchResult(driver, username);                    
                }
                test.VerifyNoErrorToasts(driver);

                
            }

            finally { }
        }

        public static void CreateUser(IWebDriver driver, testVars vars)
        {

            try
            {
                testHelper.Start(driver);

                string username = test.RandomString(20);
                string role;
                                
                report.Step("Verify Create User loads without error");
                test.startTime();
                navigate.CreateUser(driver);
                test.stopTime("03. Click Create New User link");
                test.VerifyNoErrorToasts(driver);

                test.SelectField(driver, userProfile._Company, "Epiq");
                test.EditField(driver, userProfile._Username, username);
                test.EditField(driver, userProfile._Firstname, "F" + username);
                test.EditField(driver, userProfile._Lastname, "L" + username);
                test.EditField(driver, userProfile._Email, "rdifalco@epiqsystems.com");

                role = userProfile.AssignTopRole(driver);
                
                test.startTime();
                userProfile.Save(driver);
                test.stopTime("04. Save New User");

                report.Step("Verify User saves without error");
                test.VerifyNoErrorToasts(driver);
                test.VerifySuccessToast(driver, "The user/role information has been successfully updated");
                                
                report.Step("Reload User");
                navigate.Refresh(driver);

                report.Step("Verify username");
                test.VerifyEditFieldText(driver, userProfile._Username, "value", username);
                report.Step("Verify Role is assigned");
                test.VerifyTextContains(driver, userProfile._AssignedItems, role);
                
                                
            }

            finally { }
        }

        public static void EditUser(IWebDriver driver, testVars vars)
        {

            try
            {
                string username;
                if (ConfigurationManager.AppSettings.Get("performance_testing_enabled") == "true")
                {
                    username = database.gettopfieldvaluewhere(ConfigurationManager.AppSettings.Get("connectionstring"), "[User]", "Username", "Username='testuser400'");
                    
                }
                else
                {
                    //username = database.gettopfieldvaluewhere(ConfigurationManager.AppSettings.Get("connectionstring"), "[User]", "Username", "Username not in ('testadmin','rdifalco') and email like 'rdifalco%'");
                    username = database.gettopfieldvaluewhere(ConfigurationManager.AppSettings.Get("connectionstring"), "[User]", "Username", "EmailConfirmed=0 and email like 'rdifalco%'");

                }
                string firstname = test.GetCurrentDateTime();
                string assignedrole1;
                string assignedrole2;
                string removedrole;

                testHelper.Start(driver);

                report.Step("Search for User");
                navigate.UserSearch(driver);
                test.startTime();
                search.UserSearch(driver, username);
                test.stopTime("03. Search for user");
                
                report.Step("Verify User loads without error");
                test.startTime();
                search.SelectSearchResult(driver, username);
                test.stopTime("04. Load user searched");
                test.VerifyNoErrorToasts(driver);

                report.Step("Assign a Role");
                assignedrole1 = userProfile.AssignTopRole(driver);
                report.Step("Verify Role is assigned without error");
                test.VerifyTextContains(driver, userProfile._AssignedItems, assignedrole1);
                test.VerifyNoErrorToasts(driver);

                report.Step("Assign a second Role");
                assignedrole2 = userProfile.AssignTopRole(driver);
                report.Step("Verify Role is assigned without error");
                test.VerifyTextContains(driver, userProfile._AssignedItems, assignedrole2);
                test.VerifyNoErrorToasts(driver);

                report.Step("Remove a Role");
                removedrole = userProfile.RemoveTopRole(driver);
                report.Step("Verify Role is removed without error");
                test.VerifyTextContains(driver, userProfile._AvailableItems, removedrole);
                test.VerifyNoErrorToasts(driver);

                report.Step("Edit a field and save");
                test.EditField(driver, userProfile._Firstname, firstname);
                test.ScrollUp(driver);
                test.startTime();
                userProfile.Save(driver);
                test.stopTime("05. Edit a field and save");

                report.Step("Verify User saves without error");
                test.VerifyNoErrorToasts(driver);
                test.VerifySuccessToast(driver, "The user/role information has been successfully updated");

                report.Step("Reload User");
                navigate.Refresh(driver);

                report.Step("Verify edited field saved");
                test.VerifyEditFieldText(driver, userProfile._Firstname, "value", firstname);
                report.Step("Verify Role is assigned");
                test.VerifyTextContains(driver, userProfile._AssignedItems, assignedrole1);
                report.Step("Verify Role is removed");
                test.VerifyTextContains(driver, userProfile._AvailableItems, removedrole);

                //reset all roles back to known state so the test can be repeated
                removedrole = userProfile.RemoveTopRole(driver);
                userProfile.Save(driver);
               
                
            }

            finally { }
        }

        public static void Company(IWebDriver driver, testVars vars)
        {

            try
            {
                testHelper.Start(driver);

                string companyname = "AAAutomation Test";
                string companyname2 = companyname + " 2";

                report.Step("Verify Company page loads without error");
                navigate.Company(driver);
                test.VerifyNoErrorToasts(driver);

                report.Step("Verify Add New Company");                
                company.AddNewCompany(driver);

                test.EditField(company._CompanyName, companyname);
                test.EditField(company._abbreviation, "auto/");
                test.SelectField(company._LinksAsText, "No");

                company.Save(driver);
                test.VerifyNoErrorToasts(driver);
                test.VerifySuccessToast(driver, "The company has been successfully saved");

                navigate.Refresh();
                company.EditCompany(driver);
                test.VerifyFieldValue(company._CompanyName, companyname);

                report.Step("Verify Edit Company");
                test.EditField(company._CompanyName, companyname2);
                company.Save(driver);
                test.VerifyNoErrorToasts(driver);
                test.VerifySuccessToast(driver, "The company has been successfully saved");

                navigate.Refresh();
                company.EditCompany(driver);
                test.VerifyFieldValue(company._CompanyName, companyname2);

                report.Step("Verify Delete Company");
                navigate.Refresh();
                company.DeleteCompany(driver);
                test.VerifyNoErrorToasts(driver);
                test.VerifySuccessToast(driver, "The company has been successfully deleted");
                test.VerifyElementDoesNotExist(By.XPath("//span[.='" +  companyname2 + "']"));               

            }

            finally { }
        }

        public static void BatchUser(IWebDriver driver, testVars vars)
        {

            try
            {
                testHelper.Start(driver);               

                report.Step("Verify page loads without error");
                navigate.BatchUser(driver);
                test.VerifyNoErrorToasts(driver);
                batch_user.StandardImport();
                report.Step("Verify Standard Import uploads without error");
                test.VerifyNoErrorToasts(driver);
                upload.VerifyUpload();

                //TODO: more testing

            }

            finally { }
        }

        public static void ManageUserTags(IWebDriver driver, testVars vars)
        {

            try
            {
                testHelper.Start(driver);

                report.Step("Verify page loads without error");
                navigate.ManageUserTags(driver);
                test.VerifyNoErrorToasts(driver);
                report.Step("Verify tags can be edited");
                user_tags.EditTagType(driver);
                test.EditField(user_tags._tagTypeDescription, "Updated by automation");
                user_tags.SaveTagType(driver);
                test.VerifySuccessToast(driver, "The tag type has been successfully saved");
                test.VerifyNoErrorToasts(driver);
                user_tags.EditUserTag(driver);
                test.EditField(user_tags._userTagDescription, "Updated by automation");
                user_tags.SaveUserTag(driver);
                test.VerifySuccessToast(driver, "The user tag has been successfully saved");
                test.VerifyNoErrorToasts(driver);

                //TODO: more testing

            }

            finally { }
        }

        public static void Load_All_Pages(IWebDriver driver, testVars vars)
        {
            testHelper.Start();

            try {
                navigate.CreateUser(driver);
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Create User", e);
                
            }

            try {
                navigate.UserSearch(driver);
                test.VerifyNoErrorToasts(driver);
                string username = "automation";
                search.UserSearch(driver, username);
                test.VerifyNoErrorToasts(driver);
                search.SelectSearchResult(driver, username);
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying User Search and User", e);
                
            }

            try {
                navigate.BatchUser(driver);
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Batch User", e);
                
            }

            try {
                navigate.Company(driver);
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Company", e);
                
            }

            try {
                navigate.Queries(driver);
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Queries", e);
                
            }

            try {
                navigate.ManageUserTags(driver);
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Manage User Tags", e);
                
            }

            try
            {
                navigate.Plugins(driver);
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Plugins", e);

            }

            navigate.TechConfig(driver);
            test.VerifyNoErrorToasts(driver);

        }

        public static void InActiveUsers(IWebDriver driver, testVars vars)
        {

            try
            {
                string inactiveuser = "Sam";
                testHelper.Start(driver);
                report.Step("Verify User Search page loads without error");
                navigate.UserSearch(driver);
                test.VerifyNoErrorToasts(driver);
                report.Step("Verify User Search executes without error");
                search.UserSearch(driver, inactiveuser);

                By gridby = By.XPath("//div[@ng-grid='vm.gridOptions']");
                test.WaitForElement(gridby);

                ngGrid grid = new ngGrid(test.driver.FindElement(gridby));

                report.Pass("count " + grid.rows.Count);

                foreach (IWebElement row in grid.getRowsByColumnValue("Active", "No"))

                {
                    test.VerifyTrue(row.FindElements(By.XPath(".//div[@class='ng-scope text-danger']")).Count != 0, true, "Inactive is red");
                    report.Pass("row in red " + row.Text);

                }

                foreach (IWebElement row in grid.getRowsByColumnValue("Active", "Yes"))

                {
                    test.VerifyTrue(row.FindElements(By.XPath(".//div[@class='ng-scope text-danger']")).Count == 0, true, "Active is not red");
                    report.Pass("row in white ");
                }

            }

            finally { }
        }

        public static void SupportEmailAddress(IWebDriver driver, testVars vars)
        {

            try
            {
                testHelper.Start(driver);
                report.Step("Verify User Search page loads without error");
                navigate.Company(driver);
                test.VerifyNoErrorToasts(driver);
                report.Step("Verify User Search executes without error");
                test.Click(By.XPath("//a[@ng-href='company']"));
                By gridby = By.XPath("//div[@ng-grid='vm.gridOptions']");
                test.WaitForElement(gridby);
                ngGrid grid1 = new ngGrid(test.driver.FindElement(gridby));
                report.Pass("count in new run" + grid1.rows.Count);
                //foreach (IWebElement row in grid1.getRowsByColumnName("Support Email Address"))
                foreach (IWebElement row in grid1.rows)
                {
                    row.FindElement(By.XPath(".//i[@class='fa fa-ellipsis-h fa-lg dropdown-toggle']")).Click();
                    test.Click(By.XPath("./html/body/ul/li[1]/a"));
                    test.WaitForElement(By.XPath(".//input[@name='supportEmailAddress']"));
                    string testvariable = driver.FindElement(By.XPath(".//input[@name='supportEmailAddress']")).GetAttribute("value");
                    if (testvariable == "")

                    {
                        grid.Equals("Support Email Address", "");
                        report.Pass("PASS");
                    }
                    else
                    {
                        grid.Equals("Suppport Email Address", testvariable);
                        report.Pass("Pass with the email");
                    }
                    test.Click(By.XPath("//button[@ng-click='vm.cancelEdit()']"));
                }
            }
            finally { }
        }

        public static void Save_All_Pages(IWebDriver driver, testVars vars)
        {
            testHelper.Start();

            try
            {
                navigate.CreateUser(driver);
                test.VerifyNoErrorToasts(driver);
                string username = test.RandomString(20);
                test.SelectField(driver, userProfile._Company, "Epiq");
                test.EditField(driver, userProfile._Username, username);
                test.EditField(driver, userProfile._Firstname, "F" + username);
                test.EditField(driver, userProfile._Lastname, "L" + username);
                test.EditField(driver, userProfile._Email, "rdifalco@epiqsystems.com");
                userProfile.AssignTopRole(driver);
                userProfile.Save(driver);
                test.VerifySuccessToast(driver, "The user/role information has been successfully updated");
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Create User", e);
                
            }

            try
            {
                navigate.UserSearch(driver);
                test.VerifyNoErrorToasts(driver);
                string username2 = "automation";
                search.UserSearch(driver, username2);
                test.VerifyNoErrorToasts(driver);
                search.SelectSearchResult(driver, username2);
                // Edit User
                test.VerifyNoErrorToasts(driver);
                test.EditField(userProfile._Extension, "zzz");
                userProfile.Save(driver);
                test.VerifySuccessToast(driver, "The user/role information has been successfully updated");
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying User Search and Edit User", e);
                
            }


            //TODO: User Deactivation
            try {
                navigate.BatchUser(driver);
                test.VerifyNoErrorToasts(driver);
                batch_user.StandardImport();
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Batch User", e);
                
            }

            try
            {
                navigate.Company(driver);
                test.VerifyNoErrorToasts(driver);
                company.EditCompany(driver);
                test.SelectFieldByIndex(company._LinksAsText, 0);
                test.SelectFieldByIndex(company._LinksAsText, 1);
                company.Save(driver);
                test.VerifySuccessToast(driver, "The company has been successfully saved");
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Company", e);
                
            }

            try
            {
                navigate.Queries(driver);
                test.VerifyNoErrorToasts(driver);
                queries.SelectQuery(driver, "User Audit");
                test.EditField(driver, By.Name("SubSystemName"), "Test Case");
                queries.Execute(driver);
                //no success toast
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Account Queries", e);
                
            }

            try
            {
                navigate.ManageUserTags(driver);
                test.VerifyNoErrorToasts(driver);
                user_tags.EditTagType(driver);
                test.EditField(user_tags._tagTypeDescription, "Updated by automation");
                user_tags.SaveTagType(driver);
                test.VerifySuccessToast(driver, "The tag type has been successfully saved");
                test.VerifyNoErrorToasts(driver);
                user_tags.EditUserTag(driver);
                test.EditField(user_tags._userTagDescription, "Updated by automation");
                user_tags.SaveUserTag(driver);
                test.VerifySuccessToast(driver, "The user tag has been successfully saved");
                test.VerifyNoErrorToasts(driver);
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Manage User Tags", e);
                
            }

            try
            {
                navigate.Plugins(driver);
                test.VerifyNoErrorToasts(driver);
                plugins.Edit(1);
                plugins.SetVersion(test.GetFieldValue(plugins._version));
                plugins.Save(driver);
                plugins.VerifyToastsOnSave();
            }
            catch (Exception e)
            {
                report.Fail("Error verifying Plugins", e);

            }

            //readonly
            navigate.TechConfig(driver);
            test.VerifyNoErrorToasts(driver);

        }
    }
}

