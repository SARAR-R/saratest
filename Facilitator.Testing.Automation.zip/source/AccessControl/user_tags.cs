﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace AccessControl.Tests
{

    public class user_tags
    {

        public static By _tagTypeName = By.Name("tagTypeName");
        public static By _tagTypeDescription = By.Name("tagTypeDescription");
        public static By _userTagName = By.Name("userTagName");
        public static By _userTagDescription = By.Name("userTagDescription");

        private static By _SaveTagType = By.XPath("//button[@ng-click='vm.save()']");
        private static By _SaveUserTag = By.XPath("//form[@name='vm.userTagForm']//button[@ng-click='vm.save()']");

        private static By _ManageTagType = By.XPath("//i[@title='Manage Tag Type']");
        private static By _EditTagType = By.LinkText("Edit Tag Type");
        private static By _ManageUserTag = By.XPath("//i[@title='Manage User Tag']");
        private static By _EditUserTag = By.LinkText("Edit User Tag");


        public static void SaveTagType(IWebDriver driver)
        {
            test.Click(driver, _SaveTagType);
        }

        public static void SaveUserTag(IWebDriver driver)
        {
            test.Click(driver, _SaveUserTag);
        }


        public static void EditTagType(IWebDriver driver)
        {
            test.Click(_ManageTagType);
            test.Click(_EditTagType);
        }

        public static void EditUserTag(IWebDriver driver)
        {
            test.Click(_ManageUserTag);
            test.Click(_EditUserTag);
        }
        
    }
}
