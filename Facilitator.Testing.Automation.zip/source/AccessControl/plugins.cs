﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;

namespace AccessControl.Tests
{

    public class plugins
    {
        public static By _version = By.Name("version");
        
        public static ngGrid PluginsGrid()
        {
            By gridby = By.XPath("//div[contains(@class,'ngGrid')]");
            test.WaitForElement(gridby);
            return new ngGrid(test.driver.FindElement(gridby));
        }

        public static void Edit(int row)
        {
            PluginsGrid().ClickRowIcon(row, By.XPath(".//span[@class='glyphicon glyphicon-pencil']"));
        }
        
        public static void SetVersion(string val)
        {
            test.EditField(_version, val);
        }
        
        public static void Save(IWebDriver driver)
        {
            test.Click(driver, By.XPath("//button[@ng-click='vm.save()']"));
        }

        public static void VerifyToastsOnSave()
        {
            test.VerifyNoErrorToasts();
            test.VerifySuccessToast();
        }

    }
}
