﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using Automation;
using System.Configuration;
using System.Diagnostics;


namespace AccessControl.Tests
{

    [TestClass]
    public class smokeTestSuite
    {
        public TestContext TestContext { get; set; }

        void Main(string[] args) { }

        [TestInitialize]
        public void startup()
        {           
            test.startup(TestContext);
        }

        [TestCleanup]
        public void teardown()
        {            
            test.teardown();
        }


        [TestCategory("Smoke"), TestMethod]
        public void AC_Logon()
        {            
            usecase.Logon(test.driver, test.vars);
        }

        [TestCategory("Smoke"), TestMethod]
        public void AC_Logout()
        {
            usecase.Logout(test.driver, test.vars);
        }

        [TestCategory("Smoke"), TestMethod]
        public void AC_TechConfig()
        {
            usecase.TechConfig(test.driver, test.vars);
        }

        [TestCategory("Smoke"), TestMethod]
        public void AC_Queries()
        {
            usecase.Queries(test.driver, test.vars);
        }

        [TestCategory("Smoke"), TestMethod]
        public void AC_AuditLog()
        {
            usecase.AuditLog(test.driver, test.vars);
        }

        [TestCategory("Smoke"), TestMethod]
        public void AC_UserSearch()
        {
            usecase.UserSearch(test.driver, test.vars);
        }

        [TestCategory("Smoke"), TestMethod]
        public void AC_CreateUser()
        {
            usecase.CreateUser(test.driver, test.vars);
        }

        [TestCategory("Smoke"), TestMethod]
        public void AC_EditUser()
        {
            usecase.EditUser(test.driver, test.vars);
        }

        [TestMethod]
        public void AC_Company()
        {
            usecase.Company(test.driver, test.vars);
        }

        [TestMethod]
        public void AC_BatchUser()
        {
            usecase.BatchUser(test.driver, test.vars);
        }

        [TestMethod]
        public void AC_ManageUserTags()
        {
            usecase.ManageUserTags(test.driver, test.vars);
        }

        [TestMethod]
        public void AC_LoadAllPages()
        {
            usecase.Load_All_Pages(test.driver, test.vars);
        }

        [TestMethod]
        public void AC_SaveAllPages()
        {
            usecase.Save_All_Pages(test.driver, test.vars);
        }
        [TestMethod]
        public void AC_InActiveUsers()
        {
            usecase.InActiveUsers(test.driver, test.vars);
        }
        [TestMethod]
        public void AC_SupportEmailAddress()
        {
            usecase.SupportEmailAddress(test.driver, test.vars);
        }
    }
}
