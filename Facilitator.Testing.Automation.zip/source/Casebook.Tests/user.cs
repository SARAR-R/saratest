﻿using System;
using Automation;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Casebook
{
    public class user : Facilitator.Template.user
    {
        public new static void ChangePassword(IWebDriver driver, string username, string old_password, string new_password)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Automation.config.TIMEOUT));
            test.WaitForPageToLoad(driver);
            test.Click(By.CssSelector("a.dropdown-toggle > span.ng-binding"));
            test.Click(By.LinkText("Change Password"));

            wait.Until(d => (d.FindElement(By.XPath("//div[@ng-model='vm.user.newPassword']//div[@class='ng-binding']")).Text != "Password must be at least characters in length"));
            test.EditField(driver, By.Name("currentPassword"), old_password);
            test.EditField(driver, By.Name("newPassword"), new_password);
            test.EditField(driver, By.Name("confirmNewPassword"), new_password);
            test.Click(driver, By.CssSelector("button.btn.btn-primary"));
        }

        public static void Logout()
        {
            test.Click(By.CssSelector("a.dropdown-toggle > span.ng-binding"));
            test.Click(By.LinkText("Logout"));
        }
    }
}
