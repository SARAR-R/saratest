﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Automation;
using Casebook.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Casebook
{
    public class caseinfo
    {
        #region Variables
        #region General
        public static By _CaseNameBanner = By.XPath("//caseinfonavbar//span[@ng-bind='caseName']");
        public static By _BillingCodeBanner = By.XPath("//caseinfonavbar//span[@ng-bind='billingCode']");
        public static By _CaseStatusBanner = By.XPath("//caseinfonavbar//span[@ng-bind='caseStatus']");
        public static By _ErrorPanel = By.XPath("//ul[@class='panel-error']//span");
        public static By _ModalSave = By.XPath("//div[@class='modal-footer']//button[@ng-click='vm.ok()']");
        public static By _ModalCancel = By.XPath("//div[@class='modal-footer']//button[contains(@ng-click, 'vm.cancel')]");
        public static By _ModalTitle = By.XPath("//div[contains(@class, 'panel-primary')]/div[@class='panel-heading']");
        public static By _SaveAll = By.XPath("//div[contains(@class, 'active')]//button[@ng-click='vm.saveAll()']");
        public static By _SaveAllDF = By.XPath("//div[contains(@class, 'active')]//button[@ng-click='vm.saveAllDF()']");
        public static By _AlertMessage = By.XPath("//div[contains(@class,'alert')]");
        public static By _ErrorMessage = By.XPath("//div[contains(@ng-show,'vm.validationErrors')]//span");
        #endregion
        #region Summary tab
        public static By _AddIncident = By.XPath("//button[@ng-click='vm.addIncident()']");
        //public static By _Save = By.XPath("//button[@ng-click='vm.ok()']");                     //DEL original
        public static By _Save = By.XPath("//button[@ng-click='vm.saveAll()']");                 //DEL  changed with build 1.0.480 moved Save, Cancel, Incident buttons up, changed name
        public static By _SaveOK = By.XPath("//button[@ng-click='vm.ok()']");                     //DEL Create New Case still uses old button, changing name to _SaveOK
        public static By _Cancel = By.XPath("//button[contains(@ng-click, 'vm.cancel')]");
        public static string _Court = "//div[@ng-model='vm.caseDetail.courtName' and not(contains(@class, 'ng-hide'))]";
        public static By _CourtSelect = By.XPath(_Court);
        public static By _CaseTypeSelect = By.XPath("//select[@ng-model='vm.caseDetail.caseTypeId' and not(contains(@class, 'ng-hide'))]");
        public static By _StatusSelect = By.XPath("//select[@ng-model='vm.caseDetail.caseStatusId' and not(contains(@class, 'ng-hide'))]");
        public static By _BusinessLineSelect = By.XPath("//select[@ng-model='vm.caseDetail.businessLineId' and not(contains(@class, 'ng-hide'))]");
        public static By _PreliminaryApprovalGranted = By.XPath("//label[contains(., 'Preliminary Approval Granted')]//following-sibling::input");
        public static By _InitialNoticeMailing = By.XPath("//label[contains(., 'Initial Notice Mailing')]//following-sibling::input");
        public static By _OptOutDeadline = By.XPath("//label[contains(., 'Opt Out Deadline')]//following-sibling::input");
        public static By _ObjectionDeadline = By.XPath("//label[contains(., 'Objection Deadline')]//following-sibling::input");
        public static By _ClaimsDeadline = By.XPath("//label[contains(., 'Claims Deadline')]//following-sibling::input");
        public static By _FinalApprovalHearing = By.XPath("//label[contains(., 'Final Approval Hearing')]//following-sibling::input");
        public static By _InitialDistribution = By.XPath("//label[contains(., 'Initial Distribution')]//following-sibling::input");
        #endregion
        #region Detail tab
        public static string _AllocatedHours = "//allocated-hour";
        public static By _BusinessLineFilter = By.XPath("//allocated-hour//select[@ng-model='vm.selected']");
        public static By _TotalAllocatedHours = By.XPath("//allocated-hour//input[@ng-model='vm.totalAllocatedHours']");
        public static By _HoursAdd = By.XPath("//allocated-hour//button[@ng-click='vm.addAllocatedHour()']");
        public static By _HoursExport = By.XPath("//allocated-hour//button[@ng-click='vm.excelExport()']");
        public static By _HoursView = By.XPath("//allocated-hour//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-eye')]");
        public static By _HoursEdit = By.XPath("//allocated-hour//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-pencil')]");    
        public static By _HoursDelete = By.XPath("//allocated-hour//a[contains(@ng-click , 'vm.delete')]");
        public static By _HoursSave = By.XPath("//div[@class='modal-footer']//button[@ng-click='vm.ok()']");
        public static By _NoticeAndClaimFormFormat = By.XPath("//*[@name='noticeAndClaimFormFormat' and not(contains(@class, 'ng-hide'))]");
        public static By _ApplicationName = By.XPath("//*[@name='applicationName' and not(contains(@class, 'ng-hide'))]");
        public static By _AddressResearchProtocol = By.XPath("//*[@name='addressResearchProtocol' and not(contains(@class, 'ng-hide'))]");
        public static By _Environment = By.XPath("//*[@name='environment' and not(contains(@class, 'ng-hide'))]");
        public static By _NotesForMailings= By.XPath("//*[@name='notesForMailings' and not(contains(@class, 'ng-hide'))]");
        public static By _NotesForEblast= By.XPath("//*[@name='notesForEblast' and not(contains(@class, 'ng-hide'))]");
        public static By _NotesForDisbursements= By.XPath("//*[@name='notesForDisbursements' and not(contains(@class, 'ng-hide'))]");
        public static By _NotesForPublication= By.XPath("//*[@name='notesForPublication' and not(contains(@class, 'ng-hide'))]");
        public static By _NotesForClaims= By.XPath("//*[@name='notesForClaims' and not(contains(@class, 'ng-hide'))]");
        public static By _SupportedLanguages= By.XPath("//*[@name='supportedLanguages' and not(contains(@class, 'ng-hide'))]");
        public static By _NotesForDataServices= By.XPath("//*[@name='notesForDataServices' and not(contains(@class, 'ng-hide'))]");
        public static By _SpecialInstructions= By.XPath("//*[@name='specialInstructions' and not(contains(@class, 'ng-hide'))]");
        public static By _NotesForDocumentControl= By.XPath("//*[@name='notesForDocumentControl' and not(contains(@class, 'ng-hide'))]");
        public static By _RequestedImports= By.XPath("//*[@name='requestedImports' and not(contains(@class, 'ng-hide'))]");
        public static By _BusinessLine = By.XPath("//form[@name='vm.form.allocatedHoursForm']//select[@name='businessLineId' and not(contains(@class, 'ng-hide'))]");
        //public static By _ClaimantRecords = By.XPath("//*[@name='claimantRecords' and not(contains(@class, 'ng-hide'))]");
        public static By _ClaimantRecords = By.XPath("//*[@ng-model='vm.shutdownAndRetention.claimantRecordsOptionsId' and not(contains(@class, 'ng-hide'))]");       
        public static By _ClaimantRecordsNumMonths = By.XPath("//*[@name='claimantRecordsNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _MailingsInventory = By.XPath("//*[@ng-model='vm.shutdownAndRetention.mailingsInventoryOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _MailingsInventoryNumMonths = By.XPath("//*[@name='mailingsInventoryNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _AdministrativeRecords = By.XPath("//*[@ng-model='vm.shutdownAndRetention.administrativeRecordsOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _AdministrativeRecordsNumMonths = By.XPath("//*[@name='administrativeRecordsNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _DistributionRecords = By.XPath("//*[@ng-model='vm.shutdownAndRetention.distributionRecordsOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _DistributionRecordsNumMonths = By.XPath("//*[@name='distributionRecordsNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _ExternalPortableMedia = By.XPath("//*[@ng-model='vm.shutdownAndRetention.externalPortableMediaOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _ExternalPortableMediaNumMonths = By.XPath("//*[@name='externalPortableMediaNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _EpiqOwnedMedia = By.XPath("//*[@ng-model='vm.shutdownAndRetention.epiqOwnedMediaOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _EpiqOwnedMediaNumMonths = By.XPath("//*[@name='epiqOwnedMediaNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _DigitalImages = By.XPath("//*[@ng-model='vm.shutdownAndRetention.digitalImagesOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _DigitalImagesNumMonths = By.XPath("//*[@name='digitalImagesNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _DisableWebsite = By.XPath("//*[@ng-model='vm.shutdownAndRetention.disableWebsiteOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _DisableWebsiteNumMonths = By.XPath("//*[@name='disableWebsiteNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _DisableIVRTollFreeNumber = By.XPath("//*[@ng-model='vm.shutdownAndRetention.disableIVROptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _DisableIVRTollFreeNumberNumMonths = By.XPath("//*[@name='disableIVRNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _CloseDisbursementAccounts = By.XPath("//*[@ng-model='vm.shutdownAndRetention.closeDisbursementAccountsOptionsId' and not(contains(@class, 'ng-hide'))]");
        public static By _CloseDisbursementAccountsNumMonths = By.XPath("//*[@name='closeDisbursementAccountsNonStandardNumberOfMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _NonStandardExplanation = By.XPath("//*[@name='nonStandardExplanation' and not(contains(@class, 'ng-hide'))]");
        public static By _AllocatedHoursAlert = By.XPath("//allocated-hour//div[contains(@class, 'alert')]");
        #endregion
        #region Dates tab
        public static string _Dates = "//div[@id='date']"; //tab identifier
        public static By _DatesTextFilter = By.XPath(_Dates + "//input[@ng-model='vm.searchText']");
        public static By _DatesCourtOrderedFilter = By.XPath(_Dates + "//input[@ng-model='vm.filterCourtOrdered']");
        public static By _DatesRequiredDateFilter = By.XPath(_Dates + "//input[@ng-model='vm.filterRequired']");
        public static By _DatesAdd = By.XPath(_Dates + "//button[@ng-click='vm.addMilestone()']");
        public static By _DatesExport = By.XPath(_Dates + "//button[@ng-click='vm.excelExport()']");
        public static By _DatesView = By.XPath(_Dates + "//a[contains(@ng-click, 'edit')]/i[contains(@class, 'fa-eye')]");
        public static By _DatesEdit = By.XPath(_Dates + "//a[contains(@ng-click, 'edit')]/i[contains(@class, 'fa-pencil')]");
        public static By _DatesDelete = By.XPath(_Dates + "//a[contains(@ng-click, 'delete')]");
        public static By _DatesTotal = By.XPath(_Dates + "//div[@class='ui-grid-footer-item-counts']//span");
        public static By _AssociateSr = By.XPath("//button[text()=' Associate SR']");
        public static string _DatesCombo = "//div[contains(@class, 'milestone-name')]";
        public static By _DatesComboVisibility = By.XPath("//div[contains(@ng-show, 'mlestn-e')]");
        public static By _DatesName = By.XPath("//label[text()='Name']/following-sibling::input");
        public static By _DueDate = By.XPath("//label[text()='Date']/..//input");
        public static By _CourtOrdered = By.XPath("//*[@ng-model='vm.milestone.courtOrdered' and not(contains(@class, 'ng-hide'))]");
        public static By _RequiredDate = By.XPath("//*[@ng-model='vm.milestone.requiredDate' and not(contains(@class, 'ng-hide'))]");
        public static By _ClientOrdered = By.XPath("//*[@ng-model='vm.milestone.clientOrdered' and not(contains(@class, 'ng-hide'))]");
        public static By _NotApplicable = By.XPath("//*[@ng-model='vm.milestone.notApplicable' and not(contains(@class, 'ng-hide'))]");
        public static By _DatePending = By.XPath("//*[@ng-model='vm.milestone.datePending' and not(contains(@class, 'ng-hide'))]");
        public static By _RelatedSr = By.XPath("//*[@ng-model='vm.milestone.relatedSR' and not(contains(@class, 'ng-hide'))]");
        public static By _DatesOwner = By.XPath("//*[@ng-model='vm.milestone.owner' and not(contains(@class, 'ng-hide'))]");
        public static By _DatesOrder = By.XPath("//*[@ng-model='vm.milestone.sortOrder' and not(contains(@class, 'ng-hide'))]");
        public static By _SrStatus = By.Name("srStatus");
        public static By _SrDueDate = By.Name("srDueDate");
        public static By _SrCreateDate = By.Name("srCreateDate");
        public static By _DatesNote = By.XPath("//*[@ng-model='vm.milestone.note' and not(contains(@class, 'ng-hide'))]");
        public static By _SrLookup = By.XPath("//button[@ng-click='vm.openSrLookup($event)']");
        public static By _SrSearch = By.XPath("//button[@ng-click='vm.search()']");
        public static By _SrCancel = By.XPath("//button[@ng-click='vm.cancel(vm.srLookupForm)']");
        public static By _PrimaryClient = By.XPath("//input[@ng-model='vm.sr.primaryClientName'");
        #endregion
        #region Contacts tab
        public static string _Contacts = "//div[contains(@ng-controller, 'caseContact')]";
        public static string _ContactOrg = "//div[@ng-controller = 'ContactOrganizationController as vm']";
        public static By _ContactsTab = By.XPath("//section[@id='content']//a[text()='Contacts']");
        public static By _ContactsTextFilter = By.XPath(_Contacts + "//input[@ng-model='vm.filterOptions.filterText']");
        public static By _ContactsAdd = By.XPath(_Contacts + "//button[@ng-click='vm.add()']");
        public static string _ContactsAddModal = "//form[@name='vm.form.addContactForm']";
        public static By _ContactsAddFilter = By.XPath(_ContactsAddModal + "//input[@ng-model='vm.filterOptions.filterText']");
        public static By _ContactsAddAssociate = By.XPath(_ContactsAddModal + "//a[contains(@ng-click , 'vm.add')]");
        public static By _ContactsPendingRemove = By.XPath("//div[@ng-if='vm.hasAddedContacts']//a[contains(@ng-click , 'vm.delete')]");
        public static By _ContactsAddTotal = By.XPath(_ContactsAddModal + "//div[@class='ngTotalSelectContainer']//span");
        public static By _ContactsExport = By.XPath(_Contacts + "//button[@ng-click='vm.excelExport()']");
        public static By _ContactsView = By.XPath(_Contacts + "//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-eye')]");
        public static By _ContactsEdit = By.XPath(_Contacts + "//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-pencil')]");
        public static string _ContactsEditModal = "//form[@name='vm.form.editContactForm']";
        public static By _ContactsEditRole = By.XPath(_ContactsEditModal + "//select[@name='projectRoleId']");
        public static By _ContactsEditStart = By.XPath(_ContactsEditModal + "//input[@name='startDate']");
        public static By _ContactsEditEnd = By.XPath(_ContactsEditModal + "//input[@name='endDate']");
        public static By _ContactsDelete = By.XPath(_Contacts + "//a[contains(@ng-click , 'vm.delete')]");
        public static By _ContactsTotal = By.XPath(_Contacts + "//div[@class='ngTotalSelectContainer']//span");
        #endregion
        #region Ops tab
     
        public static string _MailingsSection = "//div[@form-id='Mailing']";
        public static By _MailingAdd = By.XPath(_MailingsSection + "//button[@ng-click='vm.add()']");
        public static By _MailingCancel = By.XPath(_MailingsSection + "//button[@ng-click='vm.cancel()']");
        public static By _MailingDelete = By.XPath(_MailingsSection + "//button[@ng-click='vm.delete()']");
        #region Claims
        public static By _EmailProcessing = By.XPath("//*[@ng-model='vm.claim.emailProcessing' and not(contains(@class, 'ng-hide'))]");
        public static By _ClaimProcessing = By.XPath("//*[@ng-model='vm.claim.claimProcessing' and not(contains(@class, 'ng-hide'))]");
        public static By _OverallProcessingDueDate = By.XPath("//*[@name='overallProcessingDueDate' and not(contains(@class, 'ng-hide'))]");
        public static By _SpecialServicing = By.XPath("//*[@ng-model='vm.claim.specialServicing' and not(contains(@class, 'ng-hide'))]");
        public static By _SpecialSlaForClaims = By.XPath("//*[@ng-model='vm.claim.specialSlaForClaims' and not(contains(@class, 'ng-hide'))]");
        public static By _SpecialServicingComments = By.XPath("//*[@name='specialServicingComments' and not(contains(@class, 'ng-hide'))]");
        public static By _SlaServicingComments = By.XPath("//*[@name='slaServicingComments' and not(contains(@class, 'ng-hide'))]");
        public static By _RangerEnvironment = By.XPath("//*[@name='rangerEnvironment' and not(contains(@class, 'ng-hide'))]");
        public static By _ReissueSchedule = By.XPath("//*[@name='reissueSchedule' and not(contains(@class, 'ng-hide'))]");
        public static By _ManualClearSearch = By.XPath("//*[@ng-model='vm.claim.manualClearSearch' and not(contains(@class, 'ng-hide'))]");
        public static By _TranslationPreferences = By.XPath("//*[@name='translationPreferences' and not(contains(@class, 'ng-hide'))]");
        public static By _Qa = By.XPath("//*[@ng-model='vm.claim.qa' and not(contains(@class, 'ng-hide'))]");
        public static By _ClearSearch = By.XPath("//*[@ng-model='vm.claim.clearSearch' and not(contains(@class, 'ng-hide'))]");
        public static By _Correspondence = By.XPath("//*[@ng-model='vm.claim.correspondence' and not(contains(@class, 'ng-hide'))]");
        public static By _SubmitViaFax = By.XPath("//*[@ng-model='vm.claim.submitViaFax' and not(contains(@class, 'ng-hide'))]");
        public static By _SubmitViaEmail = By.XPath("//*[@ng-model='vm.claim.submitViaEmail' and not(contains(@class, 'ng-hide'))]");
        public static By _SubmitViaPaper = By.XPath("//*[@ng-model='vm.claim.submitViaPaper' and not(contains(@class, 'ng-hide'))]");
        public static By _SubmitViaWeb = By.XPath("//*[@ng-model='vm.claim.submitViaWeb' and not(contains(@class, 'ng-hide'))]");
        public static By _FormsAvailableMailOnly = By.XPath("//*[@ng-model='vm.claim.formsAvailableMailOnly' and not(contains(@class, 'ng-hide'))]");
        public static By _FormsAvailableOnRequest = By.XPath("//*[@ng-model='vm.claim.formsAvailableOnRequest' and not(contains(@class, 'ng-hide'))]");
        public static By _FormsAvailablePrintedOffWeb = By.XPath("//*[@ng-model='vm.claim.formsAvailablePrintedOffWeb' and not(contains(@class, 'ng-hide'))]");
        public static By _DefectLetterNotifications = By.XPath("//*[@ng-model='vm.claim.defectLetterNotifications' and not(contains(@class, 'ng-hide'))]");
        public static By _DefectLetterNotificationsTiming = By.XPath("//*[@ng-model='vm.claim.defectLetterNotificationsTiming' and not(contains(@class, 'ng-hide'))]");
        public static By _SupportedLanguagesForClaims = By.XPath("//*[@ng-model='vm.claim.supportedLanguagesForClaims' and not(contains(@class, 'ng-hide'))]");
        public static By _DisbursementDateExceptions = By.XPath("//*[@ng-model='vm.claim.disbursementDateExceptions' and not(contains(@class, 'ng-hide'))]");
        #endregion
        #region Contact Center
     
        public static By _OptionSuite = By.XPath("//*[@name='optionSuite' and not(contains(@class, 'ng-hide'))]");                  //DEL text changed
        // public static By _OptionSuite = By.XPath("//*[@name='OptionSuite' and not(contains(@class, 'ng-hide'))]");                //DEL ORIGINAL

        public static By _AgentGoLiveDate = By.XPath("//*[@name='agentGoLiveDate' and not(contains(@class, 'ng-hide'))]");          //DEL text changed
        //public static By _AgentGoLiveDate = By.XPath("//*[@name='PhoneLineGoLiveDate' and not(contains(@class, 'ng-hide'))]");     //DEL ORIGINAL

        public static By _WebsiteGoLiveDate = By.XPath("//*[@name='websiteLaunchDate' and not(contains(@class, 'ng-hide'))]");          //DEL text changed
        //public static By _WebsiteGoLiveDate = By.XPath("//*[@name='WebsiteGoLiveDate' and not(contains(@class, 'ng-hide'))]");          //DEL ORIGINAL

        public static By _ForeignLanguageIvr = By.XPath("//*[@name='foreignLanguageIvr' and not(contains(@class, 'ng-hide'))]");            //DEL text changed
        //public static By _ForeignLanguageIvr = By.XPath("//*[@name='ForeignLanguageIvr' and not(contains(@class, 'ng-hide'))]");       //DEL ORIGINAL

        public static By _CaseNameinCMX = By.XPath("//*[@name='caseNameinCmx' and not(contains(@class, 'ng-hide'))]");                 //DEL text changed
        //public static By _CaseNameinCMX = By.XPath("//*[@name='CaseNameinCMX' and not(contains(@class, 'ng-hide'))]");                //DEL ORIGINAL

        public static By _ForeignLanguageCallCenter = By.XPath("//*[@name='foreignLanguageCallCenter' and not(contains(@class, 'ng-hide'))]");                //DEL text changed
        //public static By _ForeignLanguageCallCenter = By.XPath("//*[@name='ForeignLanguageCallCenter' and not(contains(@class, 'ng-hide'))]");             //DEL ORIGINAL

        public static By _Agents = By.XPath("//*[@name='agents' and not(contains(@class, 'ng-hide'))]");            //DEL text changed
        //public static By _Agents = By.XPath("//*[@name='Agents' and not(contains(@class, 'ng-hide'))]");           //DEL ORIGINAL

        public static By _ContractSlaForAsa = By.XPath("//*[@label='Contractual SLA' and not(contains(@class, 'ng-hide'))]");    //DEL text changed
        //public static By _ContractSlaForAsa = By.XPath("//*[@name='ContractSlaForAsa' and not(contains(@class, 'ng-hide'))]");    //DEL ORIGINAL

        public static By _ContractSlaForAsaNote = By.XPath("//*[@name='ContractSlaForAsaNote' and not(contains(@class, 'ng-hide'))]");
        public static By _CustomCallRouting = By.XPath("//*[@name='CustomCallRouting' and not(contains(@class, 'ng-hide'))]");
        public static By _BilingualAgents = By.XPath("//*[@name='BilingualAgents' and not(contains(@class, 'ng-hide'))]");
        public static By _Chat = By.XPath("//*[@name='Chat' and not(contains(@class, 'ng-hide'))]");
        #endregion
        #region Disbursements
        public static By _InitialDistributionDate = By.XPath("//*[@name='initialDistributionDate' and not(contains(@class, 'ng-hide'))]");
        public static By _AwardType = By.XPath("//*[@name='awardType' and not(contains(@class, 'ng-hide'))]");
        public static By _TaxReporting = By.XPath("//*[@name='taxReporting' and not(contains(@class, 'ng-hide'))]");
        public static By _TaxVendor = By.XPath("//*[@name='taxVendor' and not(contains(@class, 'ng-hide'))]");
        public static By _DistributionSchedule = By.XPath("//*[@name='distributionSchedule' and not(contains(@class, 'ng-hide'))]");
        public static By _ResidualFund = By.XPath("//*[@name='residualFund' and not(contains(@class, 'ng-hide'))]");
        public static By _ForeignAddresses = By.XPath("//*[@ng-model='vm.disbursements.foreignAddresses' and not(contains(@class, 'ng-hide'))]");
        public static By _Deminimis = By.XPath("//*[@ng-model='vm.disbursements.deminimis' and not(contains(@class, 'ng-hide'))]");
        public static By _Householding = By.XPath("//*[@ng-model='vm.disbursements.householding' and not(contains(@class, 'ng-hide'))]");
        public static By _Withholding = By.XPath("//*[@ng-model='vm.disbursements.withholding' and not(contains(@class, 'ng-hide'))]");
        public static By _Qsf = By.XPath("//*[@ng-model='vm.disbursements.qsf' and not(contains(@class, 'ng-hide'))]");
        public static By _CustomEnvelope = By.XPath("//*[@ng-model='vm.disbursements.customEnvelope' and not(contains(@class, 'ng-hide'))]");
        public static By _InsertWithCheck = By.XPath("//*[@ng-model='vm.disbursements.insertWithCheck' and not(contains(@class, 'ng-hide'))]");
        public static By _AttorneyPayment = By.XPath("//*[@ng-model='vm.disbursements.attorneyPayment' and not(contains(@class, 'ng-hide'))]");
        public static By _NamedPlaintiffAwards = By.XPath("//*[@ng-model='vm.disbursements.namedPlaintiffAwards' and not(contains(@class, 'ng-hide'))]");
        public static By _ReserveHoldback = By.XPath("//*[@ng-model='vm.disbursements.reserveHoldback' and not(contains(@class, 'ng-hide'))]");
        public static By _CustomReporting = By.XPath("//*[@ng-model='vm.disbursements.customReporting' and not(contains(@class, 'ng-hide'))]");
        public static By _EpiqInvoicesPaidFromFund = By.XPath("//*[@ng-model='vm.disbursements.epiqInvoicesPaidFromFund' and not(contains(@class, 'ng-hide'))]");
        #endregion
        #region Document Processing
        public static string _DocumentProcessingSection = "//document-processing";
        public static By _DocumentAdd = By.XPath(_DocumentProcessingSection + "//button[@ng-click='vm.addIncomingDocument()']");
        public static string DocumentView = "//a[@ng-click='grid.appScope.edit(row)']/i[contains(@class, 'fa-eye')]";
        public static string DocumentEdit = "//document-processing//a[@ng-click='grid.appScope.edit(row)']/i[contains(@class, 'fa-pencil')]";   //DEL only Document section
        //public static string DocumentEdit = "//a[@ng-click='grid.appScope.edit(row)']/i[contains(@class, 'fa-pencil')]";  //DEL original went to all grids on page
        public static string DocumentDelete = "//document-processing//a[@ng-click='grid.appScope.delete(row)']";
        //public static string DocumentDelete = "//a[@ng-click='grid.appScope.delete(row)']";   //DEL original went to all grids on page
        public static By _DeType = By.XPath("//*[@name='deType' and not(contains(@class, 'ng-hide'))]");
        public static By _DcSla = By.XPath("//*[@name='dcSla' and not(contains(@class, 'ng-hide'))]");
        public static By _DeSla = By.XPath("//*[@name='deSla' and not(contains(@class, 'ng-hide'))]");
        public static By _IntakeType = By.XPath("//*[@name='intakeType' and not(contains(@class, 'ng-hide'))]");
        public static By _UndeliverableCheck = By.XPath("//*[@name='undeliverableChecks' and not(contains(@class, 'ng-hide'))]");
        public static By _NonStandardMonths = By.XPath("//*[@name='nonStandardMonths' and not(contains(@class, 'ng-hide'))]");
        public static By _BoxStorageBillable = By.XPath("//*[@ng-model='vm.documentProcessing.boxStorageBillable' and not(contains(@class, 'ng-hide'))]");
        public static By _IvrTranscription = By.XPath("//*[@ng-model='vm.documentProcessing.ivrTranscription' and not(contains(@class, 'ng-hide'))]");
        public static By _NomineeClaimProcessing = By.XPath("//*[@ng-model='vm.documentProcessing.nomineeClaimProcessing' and not(contains(@class, 'ng-hide'))]");
        public static By _Remails = By.XPath("//*[@ng-model='vm.documentProcessing.remails' and not(contains(@class, 'ng-hide'))]");
        public static By _SecuredPhysicalStorageRequired = By.XPath("//*[@ng-model='vm.documentProcessing.securedPhysicalStorageRequired' and not(contains(@class, 'ng-hide'))]");
        public static By _Undeliverables = By.XPath("//*[@ng-model='vm.documentProcessing.undeliverables' and not(contains(@class, 'ng-hide'))]");
        public static By _BrokerListProcessing = By.XPath("//*[@ng-model='vm.documentProcessing.brokerListProcessing' and not(contains(@class, 'ng-hide'))]");
        public static By _DcSpecialInstructions = By.XPath("//*[@ng-model='vm.documentProcessing.dcSpecialInstructions' and not(contains(@class, 'ng-hide'))]");
        public static By _DeSpecialInstructions = By.XPath("//*[@ng-model='vm.documentProcessing.deSpecialInstructions' and not(contains(@class, 'ng-hide'))]");
        public static By _SpecialReportingRequirements = By.XPath("//*[@ng-model='vm.documentProcessing.specialReportingRequirements' and not(contains(@class, 'ng-hide'))]");
        public static By _FaxInboxEmail = By.XPath("//*[@ng-model='vm.documentProcessing.faxInboxEmail' and not(contains(@class, 'ng-hide'))]");
        public static By _IncomingDocumentType = By.XPath("//select[@ng-model='vm.incomingDocument.incomingDocumentTypeOptionsId']");
        public static By _ProcessingType =       By.XPath("//select[@ng-model='vm.incomingDocument.processingTypeOptionsId']");
        public static By _DocumentProcessingRow = By.XPath("//document-processing//div[@ui-grid-row= 'row']");
        #endregion
        #region HR

        public static By _HrToggle = By.XPath("//span[text()='HR Requirements']");
        public static By _DrugTesting = By.XPath("//*[@ng-model='vm.humanResources.drugTesting']");
        public static By _BankruptcyScreening = By.XPath("//*[@ng-model='vm.humanResources.bankruptcyScreening']");
        public static By _CreditCheck = By.XPath("//*[@ng-model='vm.humanResources.creditCheck']");
        public static By _CriminalBackground = By.XPath("//*[@ng-model='vm.humanResources.criminalBackground']");
        public static By _AnnualComplianceTraining = By.XPath("//*[@ng-model='vm.humanResources.annualComplianceTraining']");
        public static By _FingerPrint = By.XPath("//*[@ng-model='vm.humanResources.fingerPrint']");

        #endregion
        #region Mailings
        public static By _PoBoxType = By.XPath("//*[@name='poBoxType' and not(contains(@class, 'ng-hide'))]");          //DEL text changed
        //public static By _PoBoxType = By.XPath("//*[@name='PoBoxType' and not(contains(@class, 'ng-hide'))]");        //DEL ORIGINAL

        public static By _Description = By.XPath("//*[@name='Description' and not(contains(@class, 'ng-hide'))]");
        public static By _DropDate = By.XPath("//*[@name='DropDate' and not(contains(@class, 'ng-hide'))]");
        public static By _MailingPopulation = By.XPath("//*[@name='MailingPopulation' and not(contains(@class, 'ng-hide'))]");
        public static By _MailingFulfillmentFrequency = By.XPath("//*[@name='MailingFulfillmentFrequency' and not(contains(@class, 'ng-hide'))]");
        public static By _PackageContent = By.XPath("//*[@name='PackageContent' and not(contains(@class, 'ng-hide'))]");
        public static By _BrmPermittingRequired = By.XPath("//*[@name='BrmPermittingRequired' and not(contains(@class, 'ng-hide'))]");
        public static By _IsDynamicImageCount = By.XPath("//*[@name='IsDynamicImageCount' and not(contains(@class, 'ng-hide'))]");
        public static By _IsForeign = By.XPath("//*[@name='IsForeign' and not(contains(@class, 'ng-hide'))]");
        public static By _IsOutsourced = By.XPath("//*[@name='IsOutsourced' and not(contains(@class, 'ng-hide'))]");
        public static By _DropSchedule = By.XPath("//*[@name='DropSchedule' and not(contains(@class, 'ng-hide'))]");
        public static By _EstimatedPostageRate = By.XPath("//*[@name='EstimatedPostageRate' and not(contains(@class, 'ng-hide'))]");
        public static By _AssignedPostageRate = By.XPath("//*[@name='AssignedPostageRate' and not(contains(@class, 'ng-hide'))]");
        #endregion
        #endregion
        #region Documents
        public static string _Documents = "//span[text()='Documents']/../..";
        public static By _DocumentsFilter = By.XPath(_Documents + "//input[@ng-model='vm.filterOptions.filterText']");
        public static By _DocumentsExport = By.XPath(_Documents + "//button[@ng-click='vm.excelExport()']");
        public static By _DocumentsAdd = By.XPath(_Documents + "//button[@ng-click='vm.addDocument()']");
        public static By _DocumentsView = By.XPath(_Documents + "//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-eye')]");
        public static By _DocumentsEdit = By.XPath(_Documents + "//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-pencil')]");
        public static By _DocumentsDelete = By.XPath(_Documents + "//a[contains(@ng-click , 'vm.delete')]");
        public static By _DocumentsType = By.XPath("//*[@ng-model='vm.document.documentTypeId' and not(contains(@class, 'ng-hide'))]");
        public static By _DocumentsNote = By.XPath("//*[@ng-model='vm.document.note' and not(contains(@class, 'ng-hide'))]");
        public static By _DocumentsSelectFiles = By.XPath("//uploader//button[@pl-instance='uploader']");
        public static By _DocumentsUploadFiles = By.XPath("//uploader//a[@ng-click='doUpload()']");
        public static By _UploadStatus = By.XPath("//uploader//ul//div/div[3]/span");
        public static By _DocumentsClear = By.XPath("//uploader//a[@ng-click='clear()']");
        #endregion
        #region Stats
        public static string _Stats = "//div[@id='stats']";
        #endregion
        #region Health Status
        public static string _Health = "//statusupdate";
        public static By _HealthAdd = By.XPath(_Health + "//button[@ng-click='vm.add()']");
        public static By _HealthExport = By.XPath(_Health + "//button[@ng-click='vm.excelExport()']");
        public static By _HealthView = By.XPath(_Health + "//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-eye')]");
        public static By _HealthEdit = By.XPath(_Health + "//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-pencil')]");
        public static By _HealthDelete = By.XPath(_Health + "//a[contains(@ng-click , 'vm.delete')]");
        public static By _HealthDate = By.XPath("//form//label[text()='Date']/..//input");
        public static By _KeyStats = By.XPath("//*[@ng-model='vm.statusupdate.keyStats' and not(contains(@class, 'ng-hide'))]");
        public static By _HealthRating = By.XPath("//*[@ng-model='vm.statusupdate.rating' and not(contains(@class, 'ng-hide'))]");
        public static By _HealthComment = By.XPath("//*[@ng-model='vm.statusupdate.comment' and not(contains(@class, 'ng-hide'))]");
        public static string _Invoice = "//invoice";
        public static By _InvoiceView = By.XPath(_Invoice + "//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-eye')]");
        public static By _InvoiceDate = By.XPath("//input[@name='invoiceDate']");
        public static By _InvoiceAmount = By.XPath("//input[@name='amount']");
        #endregion
        #region Risk Matrix
        public static string RiskMatrix = "//div[@id='risk-matrix']";
        public static By _RiskAdd = By.XPath("//button[@ng-click='vm.addRisk()']");
        public static By _RiskExport = By.XPath("//button[@ng-click='vm.exportRiskMatrix()']");
        public static By _RiskFilter = By.XPath("//input[@ng-model='vm.searchText']");
        public static By _RiskView = grid._View;
        public static By _RiskEdit = grid._Edit;
        public static By _RiskDelete = grid._Delete;
        public static List<grid.ColumnDetails> RiskColumns
            = new List<grid.ColumnDetails>
            {
                new grid.ColumnDetails {Label = "Department"},
                new grid.ColumnDetails {Label = "No", Type = "numeric"},
                new grid.ColumnDetails {Label = "Description"},
                new grid.ColumnDetails {Label = "Date Added"},
                new grid.ColumnDetails {Label = "Risk Category"},
                new grid.ColumnDetails {Label = "Description Of Consequence"},
                new grid.ColumnDetails {Label = "Probability", Type = "numeric"},
                new grid.ColumnDetails {Label = "Impact", Type = "numeric"},
                new grid.ColumnDetails {Label = "Risk Value", Type = "numeric"},
                new grid.ColumnDetails {Label = "Mitigation Plan"},
                new grid.ColumnDetails {Label = "Date Last Updated"}
            };
        public static By _Department = By.XPath("//select[@ng-model='vm.risk.departmentId']");
        public static By _Owner = By.Name("owner");
        public static By _Number = By.XPath("//input[@ng-value='vm.risk.riskNumber']");
        public static By _DateAdded = By.XPath("//input[contains(@ng-value, 'vm.risk.insertedDate')]");
        public static By _RiskCategory = By.XPath("//select[@ng-model='vm.risk.riskCategoryId']");
        public static By _NoRiskIdentified = By.XPath("//input[@ng-model='vm.risk.noRiskIdentified']");
        public static By _RiskDescription = By.XPath("//textarea[@ng-model='vm.risk.riskDescription']");
        public static By _DescriptionOfConsequences = By.XPath("//textarea[@ng-model='vm.risk.descriptionOfConsequence']");
        public static By _Probability = By.XPath("//select[@ng-model='vm.risk.probability']");
        public static By _Impact = By.XPath("//select[@ng-model='vm.risk.impact']");
        public static By _RiskValue = By.XPath("//input[@ng-model='vm.riskValue']");
        public static By _MitigationPlan = By.XPath("//textarea[@ng-model='vm.risk.mitigationPlan']");
        public static string RiskSummaryDirective = "//div[@id='risk-summary']";
        #endregion
        #endregion
        public static void EditField(By by ,string text)
        {
            try
            {
                report.Action("Edit", by.ToString(), text.Length + " characters");
                var text1 = text.Substring(0, text.Length - 1);
                var text2 = text.Substring(text.Length - 1, 1);
                var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
                var element = test.driver.FindElement(by);
                wait.Until(d => d.FindElement(by).Enabled);
                test.WaitForPageToLoad();
                element.Clear();
                ((IJavaScriptExecutor) test.driver).ExecuteScript("arguments[0].value = arguments[1]",
                    element, text1);
                element.SendKeys(text2 + OpenQA.Selenium.Keys.Tab);
                test.WaitForPageToLoad();
            }
            catch (Exception e)
            {
                report.Fail("Unable to add the following text into " + by + ": " + text);
                Console.WriteLine("Error: " + e.Message);
            }
        }

        public static void SelectTab(string tabname)
        {
            test.Click(By.XPath("//li[@role='presentation']//a[text()='" + tabname + "']"));
        }

        public static void ExpandAllSections()
        {
            var sections = test.driver.FindElements(By.XPath("//div[contains(@ng-click, 'collapse')]//span[not(contains(@class, 'ng-hide'))]"));
            //var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
            foreach (var section in sections)
            {
                test.WaitForPageToLoad();
                if (test.driver.FindElement(By.XPath("//div[contains(@ng-click, 'collapse')]//span[text()='" +
                                                     section.Text + "']/..//following-sibling::div"))
                    .GetAttribute("class")
                    .Contains("in")) continue;
                test.ToggleSection(section.Text);
            }
        }

        public static string AssociatedBusinesses(int contactId)
        {
            var businesses = Data.GetOrganizationByContact(contactId);

            if (!businesses.Any())
            {
                return "";
            }
            return businesses.Count > 1 ? "Multiple Organizations" : businesses.First().OrganizationName;
            
        }

        public static int VerifyParentVisibility(By by, bool expected)
        {
            try
            {
                test.WaitForElement(by);

                if (!test.driver.FindElement(by).FindElement(By.XPath("..")).GetAttribute("class").Contains("ng-hide") == expected)
                {
                    switch (expected)
                    {
                        case true:
                            report.Pass("The parent element of " + by + " is visible as was expected");
                            break;
                        case false:
                            report.Pass("The parent element of " + by + " is hidden as was expected");
                            break;
                    }
                    return 0;
                }
                switch (expected)
                {
                    case true:
                        report.Fail("The parent element of " + by + " is hidden which is not expected");
                        break;
                    case false:
                        report.Fail("The parent element of " + by + " is visible which is not expected");
                        break;
                }
                return 1;
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while determining element visibility: " + e.Message);
                return 1;
            }
        }

        public static void SortByColumnAndSection(string section, string columnName)
        {
            test.Click(test.driver, By.XPath(section + "//*[text()='" + columnName + "']"));
        }

        public static int VerifyValueBySectionandColumn(string section, string columnname, string expectedvalue)
        {
            try
            {
                var col = test.driver.FindElement(By.XPath(section + "//div[text()='" + columnname + "']")).GetAttribute("class");
                var attributes = col.Split(' ');
                return test.VerifyTextContains(test.driver, By.XPath(section + "//div[contains(@class, '" + attributes[2] + "')]//div[contains(@class, 'ngCellText')]"), expectedvalue);
            }
            catch (Exception e)
            {
                report.Fail("Result not loaded: " + e);
                return 1;
            }
        }

        public static int VerifyHrefBySectionAndColumn(string section, string columnname, string expectedvalue)
        {
            try
            {
                var col = test.driver.FindElement(By.XPath("//div[text()='" + columnname + "']")).GetAttribute("class");
                var attributes = col.Split(' ');
                var cell = By.XPath(section + "//div[contains(@class, 'ngCell')  and contains(@class, '" + attributes[2] + "')]//a");
                Assert.IsTrue(test.driver.FindElement(cell).Text.Contains(expectedvalue));
                report.Pass("Element (" + cell + ") contains " + expectedvalue);
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Result not loaded: " + e);
                return 1;
            }
        }

        public static int VerifyGridValue(string section, string columnname, string expectedvalue)
        {
            try
            {
                var col = test.driver.FindElement(By.XPath(section + "//span[text()='" + columnname + "']/../../..")).GetAttribute("class");
                var attributes = col.Split(' ');
                var element = By.XPath(section + "//div[contains(@class, '" + attributes[4] +
                                       "') and contains(@class, 'ui-grid-cell')]//div");
                
                var js = (IJavaScriptExecutor)test.driver;
                js.ExecuteScript("arguments[0].scrollIntoView()", test.driver.FindElement(element));
                var result = test.VerifyTextContains(test.driver, element, expectedvalue);
                js.ExecuteScript("arguments[0].scrollIntoView()", test.driver.FindElement(By.XPath("//div[contains(@class, 'ui-grid-coluiGrid') and contains(@class, 'ui-grid-cell')]")));
                return result;
            }
            catch (Exception e)
            {
                report.Fail("Result not loaded: " + e);
                return 1;
            }
        }

        public static void WaitForPageLoad()
        {
            //test.WaitForElement(By.XPath("//button[@ng-click='vm.ok()']"));       //DEL button name changed to vm.saveAll() in 1.0.0.480-beta
            test.WaitForElement(By.XPath("//button[@ng-click='vm.saveAll()']"));    //DEL update button name
        }

        public static string SelectRandomOption(By by)
        {
            test.WaitForElement(by);

            var select = new SelectElement(test.driver.FindElement(by));
            var count = select.Options.Count;
            var rnd = new Random().Next(1, count);
            return select.Options.Skip(rnd).First()?.Text;
        }

        public static int VerifyCheckBoxValue(string fieldname, string expectedvalue)
        {
            return VerifyCheckBoxValue(test.driver, By.Name(fieldname), expectedvalue);
        }

        public static int VerifyCheckBoxValue(IWebDriver driver, By by, string expectedvalue)
        {

            var expectedclass = "";
            switch (expectedvalue)
            {
                case "True":
                    expectedclass = "ng-not-empty";
                    break;
                case "False":
                    expectedclass = "ng-empty";
                    break;
                default:
                    Assert.Fail("Expected value is not valid: " + expectedvalue);
                    break;
            }

            try
            {
                if (driver.FindElement(by).GetAttribute("class").Contains(expectedclass))
                {
                    report.Pass(by + " contains: " + expectedvalue);
                    return 0;
                }
                else
                {
                    report.Fail(by + " does not contain " + expectedvalue);
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail("Unable to verify: " + e);
                return 1;
            }
        }

        public static int VerifyCaseBanner(string name, string code, string status)
        {
            try
            {
                var actName = test.driver.FindElement(_CaseNameBanner).Text;
                var billingCode = test.driver.FindElement(_BillingCodeBanner).Text;
                var actStatus = test.driver.FindElement(_CaseStatusBanner).Text;

                if (actName == name && billingCode == code && actStatus == status)
                {
                    report.Pass("Case bar is accurately populated");
                    return 0;
                }
                else
                {
                    report.Fail("Case bar is not accurately populated.  Name: " + actName + ", Billing Code: " + billingCode + ", Status: " + actStatus);
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail("Case Banner not found: " + e);
                return 1;
            }

        }

        public static void ValidateRequiredField(string fieldName)
        {
            var text = "";            
            var tag = test.driver.FindElement(By.Name(fieldName)).TagName;
            test.VerifyClassExists(By.XPath("//*[@name='" + fieldName + "']//preceding-sibling::label"), "required");
            switch (tag)
            {
                case "input":
                case "textarea":
                    text = test.driver.FindElement(By.Name(fieldName)).GetAttribute("value");
                    test.ClearField(By.Name(fieldName));
                    break;
                case "select":
                    text = new SelectElement(test.driver.FindElement(By.Name(fieldName))).SelectedOption.Text;                   
                    test.SelectField(By.Name(fieldName), "");
                    break;
            }
            System.Threading.Thread.Sleep(500);
            test.vars.verify(test.VerifyElementEnabled(_Save, false));
            test.vars.verify(test.VerifyElementVisibility(By.XPath("//*[@name='" + fieldName + "']//following-sibling::span[contains(@ng-show, 'required')]"), true));
            switch (tag)
            {
                case "input":
                case "textarea":
                    test.EditField(By.Name(fieldName), text);
                    break;
                case "select":
                    test.SelectField(By.Name(fieldName), text);
                    break;
            }
        }

        public static void ValidateDateRequiredField(string fieldName)
        {
            var text = test.driver.FindElement(By.XPath("//*[@name='" + fieldName + "']")).GetAttribute("value");
            test.VerifyClassExists(By.XPath("//*[@name='" + fieldName + "']/../preceding-sibling::label"), "required");
            test.ClearField(By.Name(fieldName));
            System.Threading.Thread.Sleep(500);
            test.vars.verify(test.VerifyElementEnabled(_Save, false));
            test.vars.verify(test.VerifyElementVisibility(By.XPath("//*[@name='" + fieldName + "']/../following-sibling::span[contains(@ng-show, 'required')]"), true));
            EditField(By.Name(fieldName), text);
        }

        public static string GenerateString(int size)
        {
            var rand = new Random();
            const string alphabet = "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var chars = new char[size];
            for (var i = 0; i < size; i++)
            {
                chars[i] = alphabet[rand.Next(alphabet.Length)];
            }
            return new string(chars);
        }

        public static string GenerateNumberString(int size)
        {
            var rand = new Random();
            const string alphabet = "0123456789";
            var chars = new char[size];
            chars[0] = alphabet[rand.Next(1, alphabet.Length)];  //Ensure string doesn't start with a zero
            for (var i = 1; i < size; i++)
            {
                chars[i] = alphabet[rand.Next(alphabet.Length)];
            }
            return new string(chars);
        }

        public static DateTime GenerateDate()
        {
            var rnd = new Random();
            var start = new DateTime(1995, 1, 1);
            var range = (DateTime.Today - start).Days;
            return start.AddDays(rnd.Next(range));
        }

        public class FieldDetail
        {
            public string Type { get; set; }
            public string Label { get; set; }
            public int Length { get; set; }
            public string InvalidText { get; set; }
            public string ValidText { get; set; }
            public string ValidationType { get; set; }
            public By Field { get; set; }
            public By Validation { get; set; }
        }       

        public static void ValidateFields(List<FieldDetail> fields)
        {
             ValidateFields(fields, false, null);
        }

        public static void ValidateFields(List<FieldDetail> fields, bool modal, By open)
        {
            var save = _Save;
            if (modal)
            {
                save = _ModalSave;
                test.Click(open);
            }
            else
            {
                ExpandAllSections();
            }
            foreach (var field in fields)
            {
                if (field.ValidText == null)
                {
                    switch (field.Type)
                    {
                        case "date":
                            field.ValidText = GenerateDate().ToString("MM/dd/yyyy");
                            break;
                        case "numeric":
                            field.ValidText = GenerateNumberString(field.Length);
                            break;
                        default:
                            field.ValidText = GenerateString(field.Length);
                            break;
                    }
                }
                if (field.InvalidText == null) field.InvalidText = field.ValidText + "a";
                if (field.ValidationType == null)
                    field.ValidationType = field.Type == "date" ? "$error.date" : "$error.maxlength";
                if (field.Field == null) 
                    field.Field = By.XPath("//label[text()='" + field.Label +
                                           "']//following-sibling::div//input | //label[text()='" +
                                           field.Label + "']//following-sibling::input | //label[text()='" + field.Label +
                                           "']//following-sibling::textarea");
                if (field.Validation == null)
                    field.Validation = By.XPath("//label[text()='" + field.Label +
                                                "']//following-sibling::span[contains(@ng-show, '" + field.ValidationType + "')]");
                System.Threading.Thread.Sleep(100);
            }
            foreach (var field in fields)
            {
                test.WaitForElement(field.Field);
                EditField(field.Field, field.InvalidText); 
                System.Threading.Thread.Sleep(500);
                test.vars.verify(test.VerifyElementVisibility(field.Validation, true)); //Validation messaging showing
                test.vars.verify(test.VerifyElementEnabled(save, false)); //Save disabled
                EditField(field.Field, field.ValidText);
                System.Threading.Thread.Sleep(500);
                test.vars.verify(test.VerifyElementVisibility(field.Validation, false)); //Validation messaging not showing
                test.vars.verify(test.VerifyElementEnabled(save, true)); //Save reenabled
            }
            test.Click(save);
            if (modal)
            {
                test.vars.verify(test.VerifyNoErrorToasts());
                test.Click(open);
            }
            else
            {
                navigate.Refresh();
                ExpandAllSections();
            }
            foreach (var field in fields)
            {
                test.WaitForElement(field.Field);
                test.vars.verify(test.VerifyFieldValue(field.Field, field.ValidText));
            }
            if (modal) test.Click(_ModalCancel);
        }

        public static void ValidateDynamicFields(List<FieldDetail> fields, bool modal, string open)
        {
            ExpandAllSections();
            if (modal) grid.SelectRowByText(open);
            
            foreach (var field in fields)
            {
                if (field.ValidText == null)
                {
                    switch (field.Type)
                    {
                        case "date":
                            field.ValidText = GenerateDate().ToString("MM/dd/yyyy");
                            break;
                        case "numeric":
                            field.ValidText = GenerateNumberString(field.Length);
                            break;
                        default:
                            field.ValidText = GenerateString(field.Length);
                            break;
                    }
                }
                if (field.InvalidText == null) field.InvalidText = field.ValidText + "a";
                if (field.ValidationType == null)
                    field.ValidationType = field.Type == "date" ? "$error.date" : "$error.maxlength";
                if (field.Field == null)
                    field.Field = By.XPath("//label[text()='" + field.Label +
                                           "']//following-sibling::div//input | //label[text()='" +
                                           field.Label + "']//following-sibling::input | //label[text()='" + field.Label +
                                           "']//following-sibling::textarea");
                if (field.Validation == null)
                    field.Validation = By.XPath("//label[text()='" + field.Label +
                                                "']//following-sibling::span[contains(@ng-show, '" + field.ValidationType + "')]");
                System.Threading.Thread.Sleep(100);
            }
            foreach (var field in fields)
            {
                test.WaitForElement(field.Field);
                EditField(field.Field, field.InvalidText);
                System.Threading.Thread.Sleep(500);
                test.vars.verify(test.VerifyElementVisibility(field.Validation, true)); //Validation messaging showing
                test.vars.verify(test.VerifyElementEnabled(_SaveAll, false)); //Save disabled
                EditField(field.Field, field.ValidText);
                System.Threading.Thread.Sleep(500);
                test.vars.verify(test.VerifyElementVisibility(field.Validation, false)); //Validation messaging not showing
                test.vars.verify(test.VerifyElementEnabled(_SaveAll, true)); //Save reenabled
            }
            test.Click(_SaveAll);
            navigate.Refresh();
            ExpandAllSections();
            if (modal) grid.SelectRowByText(open);
            
            foreach (var field in fields)
            {
                test.WaitForElement(field.Field);
                test.vars.verify(test.VerifyFieldValue(field.Field, field.ValidText));
            }
        }

        public static CaseDetail GenerateNewCase()
        {
            var append = DateTime.Now.ToString("fff");
            var caseDetailId = Data.GetCaseData().Max(i => i.CaseDetailId) + 1;  //get next id

            var newBillingCode = "CA" + (Data.GetCaseData().Where(b => !string.IsNullOrEmpty(b.BillingCode)).Max(c => int.Parse(c.BillingCode.Substring(2))) + 1);
            if (newBillingCode.Length > 6)
                throw new Exception("Billing codes are already at max value (xx9999). Please update or remove the highest billing code(s).");

            var result = new CaseDetail
            {
                CaseDetailId = caseDetailId,
                CaseName = "Case Name " + append,
                CourtName = "US Court of Federal Claims",
                CaseTypeId = new Random().Next(1, Data.GetCaseType().Count),
                CaseStatusId = new Random().Next(1, Data.GetCaseStatus().Count),
                BusinessLineId = new Random().Next(1, Data.GetBusinessLine().Count),
                SapContractCode = 40000000 + caseDetailId,
                BillingCode= newBillingCode,
                ClassPeriodFrom = DateTime.Now.AddDays(-int.Parse(append)),
                ClassPeriodTo = DateTime.Now.AddDays(int.Parse(append)),
                EstimatedNumberOfClaims = 1000 + int.Parse(append),
                ClassSize = 10000 + int.Parse(append),
                PhoneNumber = "+1 555 666 0" + append,
                POBox = "PO Box" + append,
                ZipCode = "97" + append,
                Url = "http://www.address" + append + ".com",
                CaseFolder = @"\\casename\" + append,
                CaseEmail = "email" + append + "@mail.com",
                CaseDescription = "This is a case description " + append,
                CourtCaption = "This is a Court Caption " + append,
                SettlementAmountBenefit = "This is the benefit " + append,
                ImportantMessage = "This is very important " + append
            };
            return result;
        }

        public static CaseDetail GenerateOverviewData(int caseDetailId)
        {
            var append = DateTime.Now.ToString("fff");

            var newBillingCode = "CA" + (Data.GetCaseData().Where(b => !string.IsNullOrEmpty(b.BillingCode)).Max(c => int.Parse(c.BillingCode.Substring(2))) + 1);
            if (newBillingCode.Length > 6)
                throw new Exception("Billing codes are already at max value (xx9999). Please update or remove the highest billing code(s).");

            var result = new CaseDetail
            {
                CaseDetailId = caseDetailId,
                CaseName = "Case Name " + append,
                CourtName = "US Court of Federal Claims",
                CaseTypeId = new Random().Next(1, Data.GetCaseType().Count),
                CaseStatusId = new Random().Next(1, Data.GetCaseStatus().Count),
                BusinessLineId = new Random().Next(1, Data.GetBusinessLine().Count),
                SapContractCode = 40000000 + caseDetailId,
                BillingCode = newBillingCode,
                ClassPeriodFrom = DateTime.Now.AddDays(-int.Parse(append)),
                ClassPeriodTo =  DateTime.Now.AddDays(int.Parse(append)),
                EstimatedNumberOfClaims = 1000 + int.Parse(append),
                ClassSize = 10000 + int.Parse(append),
                PhoneNumber = "+1 555 666 0" + append,
                POBox = "PO Box" + append,
                ZipCode = "97" + append,
                Url = "http://www.address" + append +".com",
                CaseFolder = @"\\casename\" + append,
                CaseEmail = "email" + append + "@mail.com",
                CaseDescription = "This is a case description " + append,
                CourtCaption = "This is a Court Caption " + append,
                SettlementAmountBenefit = "This is the benefit " + append,
                ImportantMessage = "This is very important " + append,
                SpecialReporting = RandomBoolean(),
                //SignedAgreementPricing = RandomBoolean(),          //DEL removed story 276773
                FLSA = RandomBoolean(),
                HIPAA = RandomBoolean(),
                FISMA = RandomBoolean(),
                //CappedCase = RandomBoolean(),                      //DEL removed story 276773
                //SpecialSLAs = RandomBoolean(),                         //DEL removed story 276773
                StrategicCase = RandomBoolean(),
                SendInterestLetter = RandomBoolean(),
                LiveOperator = RandomBoolean()
            };
            return result;
        }

        public static void UpdateOverviewData(CaseDetail record)
        {
            test.EditField(By.Name("caseName"), record.CaseName ?? "");
            EditCombo(_Court, record.CourtName);
            test.SelectField(By.Name("caseTypeId"), Data.GetCaseType(record.CaseTypeId).First().Name ?? "");
            test.SelectField(By.Name("caseStatusId"), Data.GetCaseStatus(record.CaseStatusId).First().Name ?? "");
            test.SelectField(By.Name("businessLineId"), Data.GetBusinessLine(record.BusinessLineId).First().Name ?? "");
            test.EditField(By.Name("sapContractCode"), record.SapContractCode.ToString());
            test.EditField(By.Name("billingCode"), record.BillingCode);
            test.EditField(By.Name("classPeriodFrom"), record.ClassPeriodFrom?.ToString("MM/dd/yyyy") ?? "");
            test.EditField(By.Name("classPeriodTo"), record.ClassPeriodTo?.ToString("MM/dd/yyyy") ?? "");
            test.EditField(By.Name("estimatedNumberOfClaims"), record.EstimatedNumberOfClaims.ToString());
            test.EditField(By.Name("classSize"), record.ClassSize.ToString());
            test.EditField(By.Name("phoneNumber"), record.PhoneNumber ?? "");
            test.EditField(By.Name("poBox"), record.POBox ?? "");
            test.EditField(By.Name("zipCode"), record.ZipCode ?? "");
            test.EditField(By.Name("url"), record.Url ?? "");
            test.EditField(By.Name("caseFolder"), record.CaseFolder ?? "");
            test.EditField(By.Name("caseEmail"), record.CaseEmail ?? "");
            test.EditField(By.Name("caseDescription"), record.CaseDescription ?? "");
            test.EditField(By.Name("courtCaption"), record.CourtCaption ?? "");
            test.EditField(By.Name("settlementAmountBenefit"), record.SettlementAmountBenefit ?? "");
            test.EditField(By.Name("importantMessage"), record.ImportantMessage ?? "");
            test.SetCheckbox(By.Name("specialReporting"), record.SpecialReporting);
            //test.SetCheckbox(By.Name("signedAgreementPricing"), record.SignedAgreementPricing);        //DEL removed story 276773
            test.SetCheckbox(By.Name("flsa"), record.FLSA);
            test.SetCheckbox(By.Name("hipaa"), record.HIPAA);
            test.SetCheckbox(By.Name("fisma"), record.FISMA);
            //test.SetCheckbox(By.Name("cappedCase"), record.CappedCase);                                //DEL removed story 276773
            //test.SetCheckbox(By.Name("specialSLAs"), record.SpecialSLAs);                              //DEL removed story 276773
            test.SetCheckbox(By.Name("strategicCase"), record.StrategicCase);           //DEL bug 288367 permission changed, automation user can't write to checkbox
            test.SetCheckbox(By.Name("sendInterestLetter"), record.SendInterestLetter);
            test.SetCheckbox(By.Name("liveOperator"), record.LiveOperator);
        }

        public static void ValidateOverviewData(CaseDetail caseDetail)
        {
            test.vars.verify(test.VerifyFieldValueById(test.driver, "caseName", caseDetail.CaseName ?? ""));
            test.vars.verify(VerifyComboValue(_Court, caseDetail.CourtName ?? ""));
            test.vars.verify(test.VerifySelectedValue(_CaseTypeSelect, Data.GetCaseType(caseDetail.CaseTypeId).First().Name ?? ""));
            test.vars.verify(test.VerifySelectedValue (_StatusSelect, Data.GetCaseStatus(caseDetail.CaseStatusId).First().Name ?? ""));
            test.vars.verify(test.VerifySelectedValue(_BusinessLineSelect, Data.GetBusinessLine(caseDetail.BusinessLineId).First().Name ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "sapContractCode", caseDetail.SapContractCode.ToString()));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "billingCode", caseDetail.BillingCode ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "classPeriodFrom", caseDetail.ClassPeriodFrom?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "classPeriodTo", caseDetail.ClassPeriodTo?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "estimatedNumberOfClaims", caseDetail.EstimatedNumberOfClaims.ToString()));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "classSize", caseDetail.ClassSize.ToString()));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "phoneNumber", caseDetail.PhoneNumber ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "poBox", caseDetail.POBox ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "zipCode", caseDetail.ZipCode ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "url", caseDetail.Url ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "caseFolder", caseDetail.CaseFolder ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "caseEmail", caseDetail.CaseEmail ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "caseDescription", caseDetail.CaseDescription ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "courtCaption", caseDetail.CourtCaption ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "settlementAmountBenefit", caseDetail.SettlementAmountBenefit ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "importantMessage", caseDetail.ImportantMessage ?? ""));
            test.vars.verify(VerifyCheckBoxValue("specialReporting", caseDetail.SpecialReporting.ToString()));
            //test.vars.verify(VerifyCheckBoxValue("signedAgreementPricing", caseDetail.SignedAgreementPricing.ToString()));         //DEL removed story 276773
            test.vars.verify(VerifyCheckBoxValue("flsa", caseDetail.FLSA.ToString()));
            test.vars.verify(VerifyCheckBoxValue("hipaa", caseDetail.HIPAA.ToString()));
            test.vars.verify(VerifyCheckBoxValue("fisma", caseDetail.FISMA.ToString()));
            //test.vars.verify(VerifyCheckBoxValue("cappedCase", caseDetail.CappedCase.ToString()));                                 //DEL removed story 276773
            //test.vars.verify(VerifyCheckBoxValue("specialSLAs", caseDetail.SpecialSLAs.ToString()));                                //DEL removed story 276773
            test.vars.verify(VerifyCheckBoxValue("strategicCase", caseDetail.StrategicCase.ToString()));
            test.vars.verify(VerifyCheckBoxValue("sendInterestLetter", caseDetail.SendInterestLetter.ToString()));
            test.vars.verify(VerifyCheckBoxValue("liveOperator", caseDetail.LiveOperator.ToString()));           
            test.vars.verify(VerifyDateSummary(_PreliminaryApprovalGranted, Data.GetMilestone(caseDetail.CaseDetailId, "Preliminary Approval Granted").First()));
            test.vars.verify(VerifyDateSummary(_InitialNoticeMailing, Data.GetMilestone(caseDetail.CaseDetailId, "Initial Notice Mailing").First()));
            test.vars.verify(VerifyDateSummary(_OptOutDeadline, Data.GetMilestone(caseDetail.CaseDetailId, "Opt Out Deadline").First()));
            test.vars.verify(VerifyDateSummary(_ObjectionDeadline, Data.GetMilestone(caseDetail.CaseDetailId, "Objection Deadline").First()));
            test.vars.verify(VerifyDateSummary(_ClaimsDeadline, Data.GetMilestone(caseDetail.CaseDetailId, "Claims Deadline").First()));
            test.vars.verify(VerifyDateSummary(_FinalApprovalHearing, Data.GetMilestone(caseDetail.CaseDetailId, "Final Approval Hearing").First()));
            test.vars.verify(VerifyDateSummary(_InitialDistribution, Data.GetMilestone(caseDetail.CaseDetailId, "Initial Distribution").First()));
        }

        public static void ValidateOverviewRequiredFields()
        {
            ValidateRequiredField("caseName");
            ValidateRequiredField("caseTypeId");
            ValidateRequiredField("caseStatusId");
            ValidateRequiredField("businessLineId");
            ValidateRequiredField("sapContractCode");
            // ValidateRequiredField("billingCode");   //DEL removed because this is not a required field//
            ValidateRequiredField("caseDescription");
        }

        public static void ValidateOverviewFieldValidation()
        {
            var date = GenerateDate();
            var phone = "+2" + GenerateNumberString(13);
            var zip = GenerateString(10);
            var url = "http://" + GenerateString(239) + ".com";

            var fields = new List<FieldDetail>
            {
                new FieldDetail
                {
                    Label = "Case Name",
                    Length = 500
                },
                new FieldDetail
                {
                  Label = "SAP Contract Code",
                  Length = 8,
                  Type = "numeric",
                  ValidationType = "$error.pattern"
                },
                new FieldDetail
                {
                    Label = "Class Period Start",
                    Type = "date",
                    ValidText = date.ToString("MM/dd/yyyy"),
                    ValidationType = "$error.date"
                },
                new FieldDetail
                {
                    Label = "Class Period End",
                    Type = "date",
                    ValidText = date.AddDays(30).ToString("MM/dd/yyyy"),
                    ValidationType = "$error.date"
                },
                new FieldDetail
                {
                    Label = "Estimated # of Claims",
                    Length = 9,
                    Type = "numeric",
                    ValidationType = "$error.pattern"
                },
                new FieldDetail
                {
                    Label = "Class Size",
                    Length = 9,
                    Type = "numeric",
                    ValidationType = "$error.pattern"
                },
                new FieldDetail
                {
                    Label = "Phone Number",
                    Length = 15,
                    ValidText = phone
                },
                new FieldDetail
                {
                    Label = "Phone Number",
                    Length = 4,
                    InvalidText = "+2" + GenerateNumberString(2),
                    ValidText = phone,
                    ValidationType = "$error.minlength"
                },
                new FieldDetail
                {
                    Label = "Phone Number",
                    Length = 15,
                    InvalidText = GenerateString(15),
                    ValidText = phone,
                    ValidationType = "$error.phoneFormat"
                },
                new FieldDetail
                {
                    Label = "PO Box",
                    Length = 30
                },
                new FieldDetail
                {
                    Label = "Zip",
                    Length = 10,
                    ValidText = zip
                },
                new FieldDetail
                {
                    Label = "Zip",
                    Length = 10,
                    InvalidText = GenerateString(9) + "!",
                    ValidText = zip,
                    ValidationType = "$error.pattern"
                },
                new FieldDetail
                {
                    Label = "Case URL",
                    Length = 250,
                    ValidText = url
                },
                new FieldDetail
                {
                    Label = "Case URL",
                    Length = 250,
                    ValidText = url,
                    InvalidText = GenerateString(250),
                    ValidationType = "$error.pattern"
                },
                new FieldDetail
                {
                    Label = "Case Folder",
                    Length = 256
                }
            };
            ValidateOverviewRequiredFields();
            ValidateFields(fields);
        }

        public static void ValidateProjectTeamData (int caseDetailId)
        {
            var team = Data.GetProjectTeamByCase(caseDetailId).OrderBy(l => l.LastName).ThenBy(i => i.ContactId);


            if (!team.Any())
            {
                test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There are no contacts that match the currently entered filter."));
            }
            else
            { 
                test.vars.verify(test.VerifyText(test.driver, Facilitator.Template.grid._Total, "Total Items: " + team.Count()));
                test.vars.verify(VerifyValueBySectionandColumn("//project-team", "Last Name", team.First().LastName ?? ""));
                test.vars.verify(VerifyValueBySectionandColumn("//project-team", "First Name", team.First().FirstName ?? ""));
                test.vars.verify(VerifyValueBySectionandColumn("//project-team", "Phone 1", team.First().Phone1 ?? ""));
                test.vars.verify(VerifyValueBySectionandColumn("//project-team", "Email", team.First().Email ?? ""));
                test.vars.verify(VerifyValueBySectionandColumn("//project-team", "Project Role", Data.GetProjectRoleByContact(caseDetailId, team.First().ContactId).First().Name ?? ""));
            }
        }

        public static int RandomCaseKickoffDetailsOptionId(List<CaseKickoffDetailsOption> options, string type)
        {
            var min = options.Where(t => t.Type == type).Min(m => m.CaseKickoffDetailsOptionId) - 1;
            var max = options.Where(t => t.Type == type).Max(m => m.CaseKickoffDetailsOptionId);
            System.Threading.Thread.Sleep(100); //Ensure each call produces a different number
            return options[new Random().Next(min, max)].CaseKickoffDetailsOptionId;
        }

        public static CaseKickoffDetail GenerateCaseKickoffData()
        {
            var append = DateTime.Now.ToString("fff");
            var options = Data.GetCaseKickoffDetailOption();
            var result = new CaseKickoffDetail
            {
            NoticeAndClaimFormFormatOptionsId = RandomCaseKickoffDetailsOptionId(options, "NoticeAndClaimFormFormat"),
            ApplicationNameOptionsId = RandomCaseKickoffDetailsOptionId(options, "ApplicationName"),
            AddressResearchProtocolOptionsId = RandomCaseKickoffDetailsOptionId(options, "AddressResearchProtocol"),
            EnvironmentOptionsId = RandomCaseKickoffDetailsOptionId(options, "Environment"),
            NotesForMailings = "NotesForMailings " + append,
            NotesForEblast = "NotesForEblast " + append,
            NotesForDisbursements = "NotesForDisbursements " + append,
            NotesForPublication = "NotesForPublication " + append,
            NotesForClaims = "NotesForClaims " + append,
            SupportedLanguages = "SupportedLanguages " + append,
            NotesForDataServices = "NotesForDataServices " + append,
            SpecialInstructions = "SpecialInstructions " + append,
            NotesForDocumentControl = "NotesForDocumentControl " + append,
            RequestedImports = "RequestedImports " + append
            };
            return result;
        }

        public static void UpdateCaseKickoffData(CaseKickoffDetail record)
        {
            var options = Data.GetCaseKickoffDetailOption();
            var noticeAndClaimFormFormat = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.NoticeAndClaimFormFormatOptionsId)?.Name ?? "";
            var applicationName = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.ApplicationNameOptionsId)?.Name ?? "";
            var addressResearchProtocol = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.AddressResearchProtocolOptionsId)?.Name ?? "";
            var environment = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.EnvironmentOptionsId)?.Name ?? "";


            test.SelectField(_NoticeAndClaimFormFormat, noticeAndClaimFormFormat);
            test.SelectField(_ApplicationName, applicationName);
            test.SelectField(_AddressResearchProtocol, addressResearchProtocol);
            test.SelectField(_Environment, environment);
            test.EditField(_NotesForMailings, record.NotesForMailings ?? "");
            test.EditField(_NotesForEblast, record.NotesForEblast ?? "");
            test.EditField(_NotesForDisbursements, record.NotesForDisbursements ?? "");
            test.EditField(_NotesForPublication, record.NotesForPublication ?? "");
            test.EditField(_NotesForClaims, record.NotesForClaims ?? "");
            test.EditField(_SupportedLanguages, record.SupportedLanguages ?? "");
            test.EditField(_NotesForDataServices, record.NotesForDataServices ?? "");
            test.EditField(_SpecialInstructions, record.SpecialInstructions ?? "");
            test.EditField(_NotesForDocumentControl, record.NotesForDocumentControl ?? "");
            test.EditField(_RequestedImports, record.RequestedImports ?? "");
        }

        public static void ValidateCaseKickoffData(CaseKickoffDetail record)
        {
            var options = Data.GetCaseKickoffDetailOption();
            var noticeAndClaimFormFormat = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.NoticeAndClaimFormFormatOptionsId)?.Name ?? "";
            var applicationName = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.ApplicationNameOptionsId)?.Name ?? "";
            var addressResearchProtocol = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.AddressResearchProtocolOptionsId)?.Name ?? "";
            var environment = options.FirstOrDefault(i => i.CaseKickoffDetailsOptionId == record.EnvironmentOptionsId)?.Name ?? "";

            report.Step("Validate Case Kickoff Data");
            test.vars.verify(test.VerifySelectedValue(_NoticeAndClaimFormFormat, noticeAndClaimFormFormat));
            test.vars.verify(test.VerifySelectedValue(_ApplicationName, applicationName));
            test.vars.verify(test.VerifySelectedValue(_AddressResearchProtocol, addressResearchProtocol));
            test.vars.verify(test.VerifySelectedValue(_Environment, environment));
            test.vars.verify(test.VerifyFieldValue(_NotesForMailings, record.NotesForMailings ?? ""));
            test.vars.verify(test.VerifyFieldValue(_NotesForEblast, record.NotesForEblast ?? ""));
            test.vars.verify(test.VerifyFieldValue(_NotesForDisbursements, record.NotesForDisbursements ?? ""));
            test.vars.verify(test.VerifyFieldValue(_NotesForPublication, record.NotesForPublication ?? ""));
            test.vars.verify(test.VerifyFieldValue(_NotesForClaims, record.NotesForClaims ?? ""));
            test.vars.verify(test.VerifyFieldValue(_SupportedLanguages, record.SupportedLanguages ?? ""));
            test.vars.verify(test.VerifyFieldValue(_NotesForDataServices, record.NotesForDataServices ?? ""));
            test.vars.verify(test.VerifyFieldValue(_SpecialInstructions, record.SpecialInstructions ?? ""));
            test.vars.verify(test.VerifyFieldValue(_NotesForDocumentControl, record.NotesForDocumentControl ?? ""));
            test.vars.verify(test.VerifyFieldValue(_RequestedImports, record.RequestedImports ?? ""));
        }

        public static void ValidateCaseDetailFieldValidation()
        {
            test.WaitForTextInElement(_NotesForMailings);
            var fields = new List<FieldDetail>
            {
                new FieldDetail
                {
                    Label = "Notes For Mailings",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Notes For eBlast",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Notes For Disbursements",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Notes For Publication",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Notes For Claims",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Supported Languages",
                    Length = 8000
                },                new FieldDetail
                {
                    Label = "Notes For Data Services",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Special Instructions",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Notes For Document Control",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Requested Imports",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Non Standard Explanation",
                    Length = 8000
                }
            };
            ValidateDynamicFields(fields, false, null);
        }

        public static void ValidateAllocatedHoursData (Data.GetReportData_EVAEstimates_Result record)
        {
            report.Step("Validate Allocated Hours Data");
            if (record == null)
            {
                test.vars.verify(test.VerifyText(_AllocatedHoursAlert, "Allocated Hours cannot be displayed for cases stored in a Ranger Environment."));
            }
            else
            {
                test.vars.verify(VerifyGridValue(_AllocatedHours, "EstimateLineItem", record.EstimateLineItem));
                test.vars.verify(VerifyGridValue(_AllocatedHours, "AllocatedHours", record.AllocatedHours));
            }
        }

        public static int RandomShutdownAndRetentionOptionId(string type)
        {
            var options = Data.GetShutdownAndRetentionOption();
            var min = options.Where(t => t.Type == type).Min(m => m.ShutdownAndRetentionOptionId) - 1;
            var max = options.Where(t => t.Type == type).Max(m => m.ShutdownAndRetentionOptionId);
            System.Threading.Thread.Sleep(100); //Ensure each call produces a different number
            return options[new Random().Next(min, max)].ShutdownAndRetentionOptionId;
        }

        public static ShutdownAndRetention GenerateShutdownAndRetentionData()
        {
            var append = DateTime.Now.ToString("fff");
            
            var result = new ShutdownAndRetention
            {
                ClaimantRecordsOptionsId = RandomShutdownAndRetentionOptionId("Claimant Records"),
                ClaimantRecordsNonStandardNumberOfMonths = new Random().Next(1, 10),
                MailingsInventoryOptionsId = RandomShutdownAndRetentionOptionId("Mailings Inventory"),
                MailingsInventoryNonStandardNumberOfMonths = new Random().Next(11,20),
                AdministrativeRecordsOptionsId = RandomShutdownAndRetentionOptionId("Administrative Records"),
                AdministrativeRecordsNonStandardNumberOfMonths = new Random().Next(21, 30),
                DistributionRecordsOptionsId = RandomShutdownAndRetentionOptionId("Distribution Records"),
                DistributionRecordsNonStandardNumberOfMonths = new Random().Next(31, 40),
                ExternalPortableMediaOptionsId = RandomShutdownAndRetentionOptionId("External Portable Media"),
                ExternalPortableMediaNonStandardNumberOfMonths = new Random().Next(41, 50),
                EpiqOwnedMediaOptionsId = RandomShutdownAndRetentionOptionId("Epiq Owned Media"),
                EpiqOwnedMediaNonStandardNumberOfMonths = new Random().Next(51, 60),
                DigitalImagesOptionsId = RandomShutdownAndRetentionOptionId("Digital Images"),
                DigitalImagesNonStandardNumberOfMonths = new Random().Next(61, 70),
                DisableWebsiteOptionsId = RandomShutdownAndRetentionOptionId("Disable Website"),
                DisableWebsiteNonStandardNumberOfMonths = new Random().Next(71, 80),
                DisableIVROptionsId = RandomShutdownAndRetentionOptionId("Disable IVR"),
                DisableIVRNonStandardNumberOfMonths = new Random().Next(81, 90),
                CloseDisbursementAccountsOptionsId = RandomShutdownAndRetentionOptionId("Close Disbursement Accounts"),
                CloseDisbursementAccountsNonStandardNumberOfMonths = new Random().Next(1, 72),
                NonStandardExplanation = "NonStandardExplanation " + append
            };
            return result;
        }

        public static void UpdateShutdownRetentionData(ShutdownAndRetention record)
        {
            var options = Data.GetShutdownAndRetentionOption();
            var claimantRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.ClaimantRecordsOptionsId)?.Name ?? "";
            var mailingsInventory = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.MailingsInventoryOptionsId)?.Name ?? "";
            var administrativeRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.AdministrativeRecordsOptionsId)?.Name ?? "";
            var distributionRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DistributionRecordsOptionsId)?.Name ?? "";
            var externalPortableMedia = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.ExternalPortableMediaOptionsId)?.Name ?? "";
            var epiqOwnedMedia = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.EpiqOwnedMediaOptionsId)?.Name ?? "";
            var digitalImages = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DigitalImagesOptionsId)?.Name ?? "";
            var disableWebsite = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DisableWebsiteOptionsId)?.Name ?? "";
            var disableIvr = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DisableIVROptionsId)?.Name ?? "";
            var closeDisbursementAccounts = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.CloseDisbursementAccountsOptionsId)?.Name ?? "";

            test.SelectField(_ClaimantRecords, claimantRecords);
            if (claimantRecords == "Non Standard") test.EditField(_ClaimantRecordsNumMonths, record.ClaimantRecordsNonStandardNumberOfMonths.ToString());
            test.SelectField(_MailingsInventory, mailingsInventory);
            if (mailingsInventory == "Non Standard") test.EditField(_MailingsInventoryNumMonths, record.MailingsInventoryNonStandardNumberOfMonths.ToString());
            test.SelectField(_AdministrativeRecords, administrativeRecords);
            if (administrativeRecords == "Non Standard") test.EditField(_AdministrativeRecordsNumMonths, record.AdministrativeRecordsNonStandardNumberOfMonths.ToString());
            test.SelectField(_DistributionRecords, distributionRecords);
            if (distributionRecords == "Non Standard") test.EditField(_DistributionRecordsNumMonths, record.DistributionRecordsNonStandardNumberOfMonths.ToString());
            test.SelectField(_ExternalPortableMedia, externalPortableMedia);
            if (externalPortableMedia == "Non Standard") test.EditField(_ExternalPortableMediaNumMonths, record.ExternalPortableMediaNonStandardNumberOfMonths.ToString());
            test.SelectField(_EpiqOwnedMedia, epiqOwnedMedia);
            if (epiqOwnedMedia == "Non Standard") test.EditField(_EpiqOwnedMediaNumMonths, record.EpiqOwnedMediaNonStandardNumberOfMonths.ToString());
            test.SelectField(_DigitalImages, digitalImages);
            if (digitalImages == "Non Standard") test.EditField(_DigitalImagesNumMonths, record.DigitalImagesNonStandardNumberOfMonths.ToString());
            test.SelectField(_DisableWebsite, disableWebsite);
            if (disableWebsite == "Non Standard") test.EditField(_DisableWebsiteNumMonths, record.DisableWebsiteNonStandardNumberOfMonths.ToString());
            test.SelectField(_DisableIVRTollFreeNumber, disableIvr);
            if (disableIvr == "Non Standard") test.EditField(_DisableIVRTollFreeNumberNumMonths, record.DisableIVRNonStandardNumberOfMonths.ToString());
            test.SelectField(_CloseDisbursementAccounts, closeDisbursementAccounts);
            if (closeDisbursementAccounts == "Non Standard") test.EditField(_CloseDisbursementAccountsNumMonths, record.CloseDisbursementAccountsNonStandardNumberOfMonths.ToString());
            if (claimantRecords == "Non Standard" || mailingsInventory == "Non Standard" || administrativeRecords == "Non Standard" || distributionRecords == "Non Standard"
                || externalPortableMedia == "Non Standard" || epiqOwnedMedia == "Non Standard" || digitalImages == "Non Standard" || disableWebsite == "Non Standard"
                || disableIvr == "Non Standard" || closeDisbursementAccounts == "Non Standard")
                test.EditField(_NonStandardExplanation, record.NonStandardExplanation);
        }

        public static void ValidateShutdownRetentionData(ShutdownAndRetention record)
        {
            report.Step("Validate Shutdown And Retention Data");
            var options = Data.GetShutdownAndRetentionOption();
            var claimantRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.ClaimantRecordsOptionsId)?.Name ?? "";
            var mailingsInventory = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.MailingsInventoryOptionsId)?.Name ?? "";
            var administrativeRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.AdministrativeRecordsOptionsId)?.Name ?? "";
            var distributionRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DistributionRecordsOptionsId)?.Name ?? "";
            var externalPortableMedia = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.ExternalPortableMediaOptionsId)?.Name ?? "";
            var epiqOwnedMedia = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.EpiqOwnedMediaOptionsId)?.Name ?? "";
            var digitalImages = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DigitalImagesOptionsId)?.Name ?? "";
            var disableWebsite = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DisableWebsiteOptionsId)?.Name ?? "";
            var disableIvr = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DisableIVROptionsId)?.Name ?? "";
            var closeDisbursementAccounts = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.CloseDisbursementAccountsOptionsId)?.Name ?? "";
            
            test.vars.verify(test.VerifySelectedValue(_ClaimantRecords, claimantRecords));
            test.vars.verify(claimantRecords == "Non Standard"
                ? test.VerifyFieldValue(_ClaimantRecordsNumMonths,
                    record.ClaimantRecordsNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_ClaimantRecordsNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_MailingsInventory, mailingsInventory));
            test.vars.verify(mailingsInventory == "Non Standard"
                ? test.VerifyFieldValue(_MailingsInventoryNumMonths,
                    record.MailingsInventoryNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_MailingsInventoryNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_AdministrativeRecords, administrativeRecords));
            test.vars.verify(administrativeRecords == "Non Standard"
                ? test.VerifyFieldValue(_AdministrativeRecordsNumMonths,
                    record.AdministrativeRecordsNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_AdministrativeRecordsNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_DistributionRecords, distributionRecords));
            test.vars.verify(distributionRecords == "Non Standard"
                ? test.VerifyFieldValue(_DistributionRecordsNumMonths,
                    record.DistributionRecordsNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_DistributionRecordsNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_ExternalPortableMedia, externalPortableMedia));
            test.vars.verify(externalPortableMedia == "Non Standard"
                ? test.VerifyFieldValue(_ExternalPortableMediaNumMonths,
                    record.ExternalPortableMediaNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_ExternalPortableMediaNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_EpiqOwnedMedia, epiqOwnedMedia));
            test.vars.verify(epiqOwnedMedia == "Non Standard"
                ? test.VerifyFieldValue(_EpiqOwnedMediaNumMonths,
                    record.EpiqOwnedMediaNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_EpiqOwnedMediaNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_DigitalImages, digitalImages));
            test.vars.verify(digitalImages == "Non Standard"
                ? test.VerifyFieldValue(_DigitalImagesNumMonths,
                    record.DigitalImagesNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_DigitalImagesNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_DisableWebsite, disableWebsite));
            test.vars.verify(disableWebsite == "Non Standard"
                ? test.VerifyFieldValue(_DisableWebsiteNumMonths,
                    record.DisableWebsiteNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_DisableWebsiteNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_DisableIVRTollFreeNumber, disableIvr));
            test.vars.verify(disableIvr == "Non Standard"
                ? test.VerifyFieldValue(_DisableIVRTollFreeNumberNumMonths,
                    record.DisableIVRNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_DisableIVRTollFreeNumberNumMonths, false));
            test.vars.verify(test.VerifySelectedValue(_CloseDisbursementAccounts, closeDisbursementAccounts));
            test.vars.verify(closeDisbursementAccounts == "Non Standard"
                ? test.VerifyFieldValue(_CloseDisbursementAccountsNumMonths,
                    record.CloseDisbursementAccountsNonStandardNumberOfMonths.ToString())
                : VerifyParentVisibility(_CloseDisbursementAccountsNumMonths, false));
            if (claimantRecords == "Non Standard" || mailingsInventory == "Non Standard" ||
                administrativeRecords == "Non Standard" || distributionRecords == "Non Standard"
                || externalPortableMedia == "Non Standard" || epiqOwnedMedia == "Non Standard" ||
                digitalImages == "Non Standard" || disableWebsite == "Non Standard"
                || disableIvr == "Non Standard" || closeDisbursementAccounts == "Non Standard")
            {
                test.vars.verify(test.VerifyFieldValue(_NonStandardExplanation, record.NonStandardExplanation ?? ""));
            }
            else
            {
                test.vars.verify(VerifyParentVisibility(_NonStandardExplanation, false));
            }

        }

        public static void ValidateShutdownRetentionEditability(ShutdownAndRetention record, bool edit)
        {
            report.Step("Validate Shutdown And Retention Editability");
            var options = Data.GetShutdownAndRetentionOption();
            var claimantRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.ClaimantRecordsOptionsId)?.Name ?? "";
            var mailingsInventory = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.MailingsInventoryOptionsId)?.Name ?? "";
            var administrativeRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.AdministrativeRecordsOptionsId)?.Name ?? "";
            var distributionRecords = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DistributionRecordsOptionsId)?.Name ?? "";
            var externalPortableMedia = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.ExternalPortableMediaOptionsId)?.Name ?? "";
            var epiqOwnedMedia = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.EpiqOwnedMediaOptionsId)?.Name ?? "";
            var digitalImages = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DigitalImagesOptionsId)?.Name ?? "";
            var disableWebsite = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DisableWebsiteOptionsId)?.Name ?? "";
            var disableIvr = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.DisableIVROptionsId)?.Name ?? "";
            var closeDisbursementAccounts = options.FirstOrDefault(i => i.ShutdownAndRetentionOptionId == record.CloseDisbursementAccountsOptionsId)?.Name ?? "";

            test.vars.verify(test.VerifyElementEnabled(_ClaimantRecords, edit));
            test.vars.verify(claimantRecords == "Non Standard"
                ? test.VerifyElementEnabled(_ClaimantRecordsNumMonths, edit)
                : VerifyParentVisibility(_ClaimantRecordsNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_MailingsInventory, edit));
            test.vars.verify(mailingsInventory == "Non Standard"
                ? test.VerifyElementEnabled(_MailingsInventoryNumMonths, edit)
                : VerifyParentVisibility(_MailingsInventoryNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_AdministrativeRecords, edit));
            test.vars.verify(administrativeRecords == "Non Standard"
                ? test.VerifyElementEnabled(_AdministrativeRecordsNumMonths, edit)
                : VerifyParentVisibility(_AdministrativeRecordsNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_DistributionRecords, edit));
            test.vars.verify(distributionRecords == "Non Standard"
                ? test.VerifyElementEnabled(_DistributionRecordsNumMonths, edit)
                : VerifyParentVisibility(_DistributionRecordsNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_ExternalPortableMedia, edit));
            test.vars.verify(externalPortableMedia == "Non Standard"
                ? test.VerifyElementEnabled(_ExternalPortableMediaNumMonths, edit)
                : VerifyParentVisibility(_ExternalPortableMediaNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_EpiqOwnedMedia, edit));
            test.vars.verify(epiqOwnedMedia == "Non Standard"
                ? test.VerifyElementEnabled(_EpiqOwnedMediaNumMonths, edit)
                : VerifyParentVisibility(_EpiqOwnedMediaNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_DigitalImages, edit));
            test.vars.verify(digitalImages == "Non Standard"
                ? test.VerifyElementEnabled(_DigitalImagesNumMonths, edit)
                : VerifyParentVisibility(_DigitalImagesNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_DisableWebsite, edit));
            test.vars.verify(disableWebsite == "Non Standard"
                ? test.VerifyElementEnabled(_DisableWebsiteNumMonths, edit)
                : VerifyParentVisibility(_DisableWebsiteNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_DisableIVRTollFreeNumber, edit));
            test.vars.verify(disableIvr == "Non Standard"
                ? test.VerifyElementEnabled(_DisableIVRTollFreeNumberNumMonths, edit)
                : VerifyParentVisibility(_DisableIVRTollFreeNumberNumMonths, false));
            test.vars.verify(test.VerifyElementEnabled(_CloseDisbursementAccounts, edit));
            test.vars.verify(closeDisbursementAccounts == "Non Standard"
                ? test.VerifyElementEnabled(_CloseDisbursementAccountsNumMonths, edit)
                : VerifyParentVisibility(_CloseDisbursementAccountsNumMonths, false));
            if (claimantRecords == "Non Standard" || mailingsInventory == "Non Standard" ||
                administrativeRecords == "Non Standard" || distributionRecords == "Non Standard"
                || externalPortableMedia == "Non Standard" || epiqOwnedMedia == "Non Standard" ||
                digitalImages == "Non Standard" || disableWebsite == "Non Standard"
                || disableIvr == "Non Standard" || closeDisbursementAccounts == "Non Standard")
            {
                test.vars.verify(test.VerifyElementEditability(_NonStandardExplanation, edit));
            }
            else
            {
                test.vars.verify(VerifyParentVisibility(_NonStandardExplanation, false));
            }

        }

        public static void ValidateContactsData (Contact contact, int caseDetailId)
        {
            var caseDetailContact = Data.GetCaseDetailContact(contact.ContactId, caseDetailId).First();

            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Active", GetContactStatus(caseDetailContact.StartDate, caseDetailContact.EndDate)));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Project Role", Data.GetProjectRoleByContact(caseDetailId, contact.ContactId).First().Name ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Last Name", contact.LastName ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "First Name", contact.FirstName ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Key", test.ToYesNoString(contact.KeyContact)));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Organization Name", AssociatedBusinesses(contact.ContactId) ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Phone 1", contact.Phone1 ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Email", contact.Email ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Contacts, "Contact Type", Data.GetContactType(contact.ContactTypeId).First().Name ?? ""));
        }

        public static Milestone GenerateMilestoneData(int caseDetailId)
        {
            var append = DateTime.Now.ToString("fff");
            var result = new Milestone
            {
                CaseDetailId = caseDetailId,
                Name = "Date Name " + append,
                SortOrder = 1,
                CourtOrdered = RandomBoolean(),
                ClientOrdered = RandomBoolean(),
                RequiredDate = false,
                NotApplicable = false,
                DatePending = false,
                DueDate = DateTime.Now,
                Owner = "Owner " + append,
                RelatedSR = "100001",
                SRDueDate = DateTime.Parse("06/18/2009 5:00AM"),
                SRStatus = "Closed",
                SRCreateDate = DateTime.Parse("06/17/2009 1:28PM"),
                Note = "Note " + append
            };
            return result;
        }

        public static void UpdateMilestoneData(Milestone record)
        {
            EditCombo(_DatesCombo, record.Name ?? "");
            test.EditField(_DueDate, record.DueDate?.ToString("MM/dd/yyyy") ?? "");
            test.SetCheckbox(_CourtOrdered, record.CourtOrdered);
            test.SetCheckbox(_RequiredDate, record.RequiredDate);
            test.SetCheckbox(_ClientOrdered, record.ClientOrdered);
            if (test.driver.FindElement(_NotApplicable).Enabled)
            {
                test.SetCheckbox(_NotApplicable, record.NotApplicable);
            }
            test.EditField(_DatesOwner, record.Owner ?? "");
            test.EditField(_DatesOrder, record.SortOrder.ToString());
            test.EditField(_DatesNote, record.Note ?? "");
            try
            {
                test.Click(_SrLookup);
                test.EditField(By.Name("serviceRequestNumber"), record.RelatedSR);
                test.Click(_SrSearch);
                test.Click(_AssociateSr);
            }
            catch
            {
                test.Click(_SrCancel);
                report.Fail("Unable to associate an SR");
                
            }
            
        }

        public static void ValidateMilestoneData(Milestone record)
        {
            test.vars.verify(test.VerifyFieldValue(_DatesName, record.Name ?? ""));
            test.vars.verify(test.VerifyFieldValue(_DatesOrder, record.SortOrder.ToString()));
            test.vars.verify(test.VerifyCheckBoxValue(_CourtOrdered, record.CourtOrdered));
            test.vars.verify(test.VerifyCheckBoxValue(_RequiredDate, record.RequiredDate));
            test.vars.verify(test.VerifyCheckBoxValue(_ClientOrdered, record.ClientOrdered));
            test.vars.verify(test.VerifyCheckBoxValue(_NotApplicable, record.NotApplicable));
            test.vars.verify(test.VerifyFieldValue(_DueDate, record.DueDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValue(_DatesOwner, record.Owner ?? ""));
            test.vars.verify(test.VerifyFieldValue(_RelatedSr, record.RelatedSR ?? ""));
            if (test.driver.FindElement(_ModalTitle).Text == "Add/Edit Date")  //Fields only present when adding/editing
            {
                test.vars.verify(test.VerifyFieldValue(_SrDueDate, record.SRDueDate?.ToString("MM/dd/yyyy") ?? ""));
                test.vars.verify(test.VerifyFieldValue(_SrStatus, record.SRStatus ?? ""));
                test.vars.verify(test.VerifyFieldValue(_SrCreateDate, record.SRCreateDate?.ToString("MM/dd/yyyy") ?? ""));
            }
            test.vars.verify(test.VerifyFieldValue(_DatesNote, record.Note ?? ""));
        }

        public static void ValidateMilestoneRequiredFields()
        {
            test.Click(_DatesEdit);
            ValidateRequiredField("sortOrder");
            test.Click(_ModalCancel);
        }

        public static void ValidateMilestoneFieldValidation()
        {
            var fields = new List<FieldDetail>
            {
                new FieldDetail
                {
                    Label = "Owner",
                    Length = 256
                },
                new FieldDetail
                {
                    Label = "Date",
                    Type = "date"
                }
            };
            ValidateMilestoneRequiredFields();
            ValidateFields(fields, true, _DatesEdit);
        }

        public static void ValidateMilestoneGridData (Milestone record)
        {
            test.vars.verify(VerifyGridValue(_Dates, "Name", record.Name ?? ""));
            test.vars.verify(VerifyGridValue(_Dates, "Order", record.SortOrder.ToString()));
            test.vars.verify(VerifyGridValue(_Dates, "Court Ordered", test.ToYesNoString(record.CourtOrdered)));
            test.vars.verify(VerifyGridValue(_Dates, "Required Date", test.ToYesNoString(record.RequiredDate)));
            test.vars.verify(VerifyGridValue(_Dates, "Client Ordered", test.ToYesNoString(record.ClientOrdered)));
            test.vars.verify(VerifyGridValue(_Dates, "Not Applicable", test.ToYesNoString(record.NotApplicable)));
            test.vars.verify(VerifyGridValue(_Dates, "Date", record.DueDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(VerifyGridValue(_Dates, "Owner", record.Owner ?? ""));
            test.vars.verify(VerifyGridValue(_Dates, "Related SR", record.RelatedSR ?? ""));
            test.vars.verify(VerifyGridValue(_Dates, "SR Due Date", record.SRDueDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(VerifyGridValue(_Dates, "SR Status", record.SRStatus ?? ""));
            test.vars.verify(VerifyGridValue(_Dates, "SR Create Date", record.SRCreateDate?.ToString("MM/dd/yyyy") ?? ""));
        }

        public static void ValidateContactsModalData(Contact contact, int caseDetailId)
        {
            var caseDetailContact = Data.GetCaseDetailContact(contact.ContactId, caseDetailId).First();
            
            test.vars.verify(test.VerifySelectedValueById("projectRoleId", Data.GetProjectRoleByContact(caseDetailId, contact.ContactId).First().Name ?? ""));
            test.vars.verify(test.VerifyFieldValue(By.XPath("//input[@ng-model='vm.contact.caseStartDate']"), caseDetailContact.StartDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValue(By.XPath("//input[@ng-model='vm.contact.caseEndDate']"), caseDetailContact.EndDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifySelectedValueById("contactTypeId", Data.GetContactType(contact.ContactTypeId).First().Name ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "firstName", contact.FirstName ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "middleInitial", contact.MiddleInitial ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "lastName", contact.LastName ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "phone1", contact.Phone1 ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "phone2", contact.Phone2 ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "phone3", contact.Phone3 ?? ""));
            test.vars.verify(VerifyCheckBoxValue("keyContact", contact.KeyContact.ToString()));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "emailAddress", contact.Email ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "address1", contact.Address1 ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "address2", contact.Address2 ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "city", contact.City ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "state", contact.State ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "zipcode", contact.Zipcode ?? ""));
            test.vars.verify(test.VerifyFieldValueById(test.driver, "country", contact.Country ?? ""));
        }

        public static void ValidateContactOrgGrid(Contact contact)
        {
            var organizations = Data.GetOrganizationByContact(contact.ContactId).OrderBy(n => n.OrganizationName);
            if (!organizations.Any())
            {
                test.vars.verify(test.VerifyPageSourceText(test.driver, "There are no Organizations that match the currently entered filter."));
            }
            else
            {
                var organization = organizations.First();
                var contactToOrganization = Data.GetContactToOrganization().First(i => i.OrganizationId == organization.OrganizationId && i.ContactId == contact.ContactId);

                test.vars.verify(VerifyValueBySectionandColumn(_ContactOrg, "Organization Name", organization?.OrganizationName ?? ""));
                test.vars.verify(VerifyHrefBySectionAndColumn(_ContactOrg, "Web Address", organization?.WebAddress ?? ""));
                test.vars.verify(VerifyValueBySectionandColumn(_ContactOrg, "Start Date", contactToOrganization.StartDate?.ToString("MM/dd/yyyy") ?? ""));
                test.vars.verify(VerifyValueBySectionandColumn(_ContactOrg, "End Date", contactToOrganization.EndDate?.ToString("MM/dd/yyyy") ?? ""));
            }
        }

        public static Mailing GenerateMailingsData()
        {
            var result = new Mailing
            {
                PoBoxOptionsId = Data.GetMailingOption().OrderBy(x => Guid.NewGuid()).FirstOrDefault(t => t.Type == "PoBox").MailingOptionId //DEL ER
            };
            return result;
        }

        public static void UpdateMailingsData(Mailing record)
        {
            test.SelectField(_PoBoxType, record.MailingOption.Name); //DEL gets the PoBox
        }

        public static void ValidateMailingsData(Mailing record)
        {
            if (record == null)
            {
                report.Step("There is no Mailing data for this case.");
                return;
            }
            //Workaround until dynamic forms removed.
            var retry = 0;
            while (test.driver.FindElements(_PoBoxType).Count == 0 && retry < 5)
            {
                var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(10));
                try
                {
                    wait.Until(d => (d.FindElements(_PoBoxType)).Count > 0);
                }
                catch (WebDriverTimeoutException)
                {
                    report.Fail("Section failed to load. Refreshing.");
                    navigate.Refresh();
                    retry++;
                }
            }
            //
            test.vars.verify(test.VerifyFieldValue(_PoBoxType, record.MailingDetails.FirstOrDefault().MailingDetailOption?.Name));   //DEL
        }

        public static MailingDetail GenerateMailingDetailData()
        {
            var append = DateTime.Now.ToString("fff");
            var result = new MailingDetail
            {
                Description = "AAA Description" + append,
                DropDate = DateTime.Now,
                MailingPopulation = 1000 + int.Parse(append),
                PackageContent = "PackageContent" + append,
                MailingFulfillmentFrequencyOptionsId = Data.GetMailingOption().OrderBy(x => Guid.NewGuid()).FirstOrDefault(t => t.Type == "MailingFulfillmentFrequency").MailingOptionId,  //DEL
                EstimatedPostageRate = "Estimated Rate: " + append,
                AssignedPostageRateOptionsId = Data.GetMailingOption().OrderBy(x => Guid.NewGuid()).FirstOrDefault(t => t.Type == "AssignedPostageRate").MailingOptionId,  //DEL
                DynamicImageCount = RandomBoolean(), //DEL
                Outsourced = RandomBoolean(),  //DEL
                BrmPermittingRequired = RandomBoolean(),
                Foreign = RandomBoolean(), //DEL
                DropSchedule = "DropSchedule" + append
            };
            return result;
        }       

        public static void UpdateMailingDetailData(MailingDetail record)
        {
            test.EditField(_Description, record.Description ?? "");
            test.EditField(_DropDate, record.DropDate?.ToString("MM/dd/yyyy") ?? "");
            test.EditField(_MailingPopulation, record.MailingPopulation.ToString());
            test.EditField(_PackageContent, record.PackageContent ?? "");
            test.SelectField(_MailingFulfillmentFrequency, record.MailingDetailOption?.Name ?? "");  //DEL
            test.EditField(_EstimatedPostageRate, record.EstimatedPostageRate ?? "");
            test.SelectField(_AssignedPostageRate, record.MailingDetailOption.Name ?? "");  //DEL
            test.SetCheckbox(_IsDynamicImageCount, record.DynamicImageCount ?? false);  //DEL
            test.SetCheckbox(_IsOutsourced, record.Outsourced ?? false);  //DEL
            test.SetCheckbox(_BrmPermittingRequired, record.BrmPermittingRequired ?? false);
            test.SetCheckbox(_IsForeign, record.Foreign ?? false);  //DEL
            test.EditField(_DropSchedule, record.DropSchedule ?? "");
        }

        public static void ValidateMailingDetailData(MailingDetail record)
        {
            test.vars.verify(test.VerifyFieldValue(_Description, record.Description ?? ""));
            //test.vars.verify(test.VerifyFieldValue(_DropDate, record.DropDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValue(_DropDate, record.DropDate?.ToString("yyyy-MM-ddT00:00:00") ?? ""));
            test.vars.verify(test.VerifyFieldValue(_MailingPopulation, record.MailingPopulation.ToString()));
            test.vars.verify(test.VerifyFieldValue(_MailingFulfillmentFrequency, record.Mailing.MailingOption?.Name ?? "")); //DEL
            test.vars.verify(test.VerifyFieldValue(_PackageContent, record.PackageContent ?? ""));
            test.vars.verify(test.VerifyFieldValue(_EstimatedPostageRate, record.EstimatedPostageRate ?? ""));
            test.vars.verify(test.VerifyFieldValue(_AssignedPostageRate, record.Mailing.MailingOption?.Name ?? ""));    //DEL
            test.vars.verify(VerifyCheckBoxValue("IsDynamicImageCount", record.DynamicImageCount.ToString()));  //DEL
            test.vars.verify(VerifyCheckBoxValue("IsOutsourced", record.Outsourced.ToString()));   //DEL
            test.vars.verify(VerifyCheckBoxValue("BrmPermittingRequired", record.BrmPermittingRequired.ToString()));
            test.vars.verify(VerifyCheckBoxValue("IsForeign", record.Foreign.ToString()));  //DEL
            test.vars.verify(test.VerifyFieldValue(_DropSchedule, record.DropSchedule ?? ""));
        }

        public static void ValidateMailingDetailGridData(MailingDetail mailingDetail)
        {
            if (test.driver.FindElement(By.XPath("//div[text()='Description']/..")).GetAttribute("class").Contains("ngSorted") == false)
            {
                Facilitator.Template.grid.SortByColumn(test.driver, "Description");
            }
            test.vars.verify(VerifyValueBySectionandColumn(_MailingsSection, "Description", mailingDetail.Description ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_MailingsSection, "Drop Date", mailingDetail.DropDate?.ToString("MM/dd/yyyy")));
            test.vars.verify(VerifyValueBySectionandColumn(_MailingsSection, "Mailing Population", mailingDetail.MailingPopulation.ToString()));
            if (mailingDetail.BrmPermittingRequired != null)test.vars.verify(VerifyValueBySectionandColumn(_MailingsSection, "BRM Permitting Required?", test.ToYesNoString((bool)mailingDetail.BrmPermittingRequired)));
            if (mailingDetail.Foreign != null)test.vars.verify(VerifyValueBySectionandColumn(_MailingsSection, "Foreign?", test.ToYesNoString((bool)mailingDetail.Foreign)));  //DEL
            test.vars.verify(VerifyValueBySectionandColumn(_MailingsSection, "Estimated Postage Rate", mailingDetail.EstimatedPostageRate));
            test.vars.verify(VerifyValueBySectionandColumn(_MailingsSection, "Assigned Postage Rate", mailingDetail.MailingDetailOption?.Name));   //DEL
        }

        public static int RandomClaimOptionId(string type)
        {
            var options = Data.GetClaimOption();
            var min = options.Where(t => t.Type == type).Min(m => m.ClaimOptionId) - 1;
            var max = options.Where(t => t.Type == type).Max(m => m.ClaimOptionId);
            System.Threading.Thread.Sleep(100); //Ensure each call produces a different number
            return options[new Random().Next(min, max)].ClaimOptionId;
        }

        public static Claim GenerateClaimsData()
        {
            var append = DateTime.Now.ToString("fff");
            var record = new Claim
            {
                EmailProcessing = RandomBoolean(),
                ClaimProcessing = RandomBoolean(),
                OverallProcessingDueDate = DateTime.Now,
                SpecialServicing = RandomBoolean(),
                SpecialServicingComments = "SpecialServicingComments" + append,
                SpecialSlaForClaims = RandomBoolean(),
                SlaServicingComments = "SlaComments" + append,
                ManualClearSearch = RandomBoolean(),
                TranslationPreferencesOptionsId = RandomClaimOptionId("TranslationPreferences"),
                RangerEnvironmentOptionsId = RandomClaimOptionId("RangerEnvironment"), 
                ReissueScheduleOptionsId = RandomClaimOptionId("ReissueSchedule"),
                Qa = RandomBoolean(),
                ClearSearch = RandomBoolean(),
                Correspondence = RandomBoolean(),
                SubmitViaFax = RandomBoolean(),
                SubmitViaEmail = RandomBoolean(),
                SubmitViaPaper = RandomBoolean(),
                SubmitViaWeb = RandomBoolean(),
                FormsAvailableMailOnly = RandomBoolean(),
                FormsAvailableOnRequest = RandomBoolean(),
                FormsAvailablePrintedOffWeb = RandomBoolean(),
                DefectLetterNotifications = RandomBoolean(),
                DefectLetterNotificationsTiming = "DefectLetterNotificationsTiming" + append,
                SupportedLanguagesForClaims = "SupportedLanguagesForClaims" + append,
                DisbursementDateExceptions = "DisbursementDateExceptions" + append,
            };
            return record;
        }

        public static void UpdateClaimsData(Claim record)
        {
            var options = Data.GetClaimOption();
            test.SetCheckbox(_EmailProcessing, record.EmailProcessing ?? false);
            test.SetCheckbox(_ClaimProcessing, record.ClaimProcessing ?? false);
            test.EditField(_OverallProcessingDueDate, record.OverallProcessingDueDate?.ToString("MM/dd/yyyy"));
            test.SelectField(_SpecialServicing, test.ToYesNoString(record.SpecialServicing));
            test.SelectField(_SpecialSlaForClaims, test.ToYesNoString(record.SpecialSlaForClaims));
            test.EditField(_SpecialServicingComments, record.SpecialServicingComments ?? "");
            test.EditField(_SlaServicingComments, record.SlaServicingComments ?? "");
            test.SelectField(_RangerEnvironment, options.FirstOrDefault(i => i.ClaimOptionId == record.RangerEnvironmentOptionsId)?.Name ?? "");
            test.SelectField(_ReissueSchedule, options.FirstOrDefault(i => i.ClaimOptionId == record.ReissueScheduleOptionsId)?.Name ?? "");
            test.SelectField(_ManualClearSearch, test.ToYesNoString(record.ManualClearSearch));
            test.SelectField(_TranslationPreferences, options.FirstOrDefault(i => i.ClaimOptionId == record.TranslationPreferencesOptionsId)?.Name ?? "");
            test.SetCheckbox(_Qa, record.Qa ?? false);
            test.SetCheckbox(_ClearSearch, record.ClearSearch ?? false);
            test.SetCheckbox(_Correspondence, record.Correspondence ?? false);
            test.SetCheckbox(_SubmitViaFax, record.SubmitViaFax ?? false);
            test.SetCheckbox(_SubmitViaEmail, record.SubmitViaEmail ?? false);
            test.SetCheckbox(_SubmitViaPaper, record.SubmitViaPaper ?? false);
            test.SetCheckbox(_SubmitViaWeb, record.SubmitViaWeb ?? false);
            test.SetCheckbox(_FormsAvailableMailOnly, record.FormsAvailableMailOnly ?? false);
            test.SetCheckbox(_FormsAvailableOnRequest, record.FormsAvailableOnRequest ?? false);
            test.SetCheckbox(_FormsAvailablePrintedOffWeb, record.FormsAvailablePrintedOffWeb ?? false);
            test.SelectField(_DefectLetterNotifications, test.ToYesNoString(record.DefectLetterNotifications));
            test.EditField(_DefectLetterNotificationsTiming, record.DefectLetterNotificationsTiming ?? "");
            test.EditField(_SupportedLanguagesForClaims, record.SupportedLanguagesForClaims ?? "");
            test.EditField(_DisbursementDateExceptions, record.DisbursementDateExceptions ?? "");
        }

        public static void ValidateClaimsData(Claim record)
        {
            if (record == null)
            {
                report.Step("There is no Claim data for this case.");
                return;
            }

            var options = Data.GetClaimOption();
            if (record.OverallProcessingDueDate != null) test.WaitForTextInElement(_OverallProcessingDueDate);
            test.vars.verify(VerifyCheckBoxValue(test.driver, _EmailProcessing, record.EmailProcessing.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _ClaimProcessing, record.ClaimProcessing.ToString()));
            test.vars.verify(test.VerifyFieldValue(_OverallProcessingDueDate, record.OverallProcessingDueDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifySelectedValue(_SpecialServicing, test.ToYesNoString(record.SpecialServicing)));
            test.vars.verify(test.VerifySelectedValue(_SpecialSlaForClaims, test.ToYesNoString(record.SpecialSlaForClaims)));
            test.vars.verify(test.VerifyFieldValue(_SpecialServicingComments, record.SpecialServicingComments ?? ""));
            test.vars.verify(test.VerifyFieldValue(_SlaServicingComments, record.SlaServicingComments ?? ""));
            test.vars.verify(test.VerifySelectedValue(_RangerEnvironment, options.FirstOrDefault(i => i.ClaimOptionId == record.RangerEnvironmentOptionsId)?.Name ?? ""));
            test.vars.verify(test.VerifySelectedValue(_ReissueSchedule, options.FirstOrDefault(i => i.ClaimOptionId == record.ReissueScheduleOptionsId)?.Name ?? ""));
            test.vars.verify(test.VerifySelectedValue(_ManualClearSearch, test.ToYesNoString(record.ManualClearSearch)));
            test.vars.verify(test.VerifySelectedValue(_TranslationPreferences, options.FirstOrDefault(i => i.ClaimOptionId == record.TranslationPreferencesOptionsId)?.Name ?? ""));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _Qa, record.Qa.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _ClearSearch, record.ClearSearch.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _Correspondence, record.Correspondence.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _SubmitViaFax, record.SubmitViaFax.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _SubmitViaEmail, record.SubmitViaEmail.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _SubmitViaPaper, record.SubmitViaPaper.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _SubmitViaWeb, record.SubmitViaWeb.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _FormsAvailableMailOnly, record.FormsAvailableMailOnly.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _FormsAvailableOnRequest, record.FormsAvailableOnRequest.ToString()));
            test.vars.verify(VerifyCheckBoxValue(test.driver, _FormsAvailablePrintedOffWeb, record.FormsAvailablePrintedOffWeb.ToString()));
            test.vars.verify(test.VerifySelectedValue(_DefectLetterNotifications, test.ToYesNoString(record.DefectLetterNotifications)));
            test.vars.verify(test.VerifyFieldValue(_DefectLetterNotificationsTiming, record.DefectLetterNotificationsTiming ?? ""));
            test.vars.verify(test.VerifyFieldValue(_SupportedLanguagesForClaims, record.SupportedLanguagesForClaims ?? ""));
            test.vars.verify(test.VerifyFieldValue(_DisbursementDateExceptions, record.DisbursementDateExceptions ?? ""));
        }

        public static ContactCenter GenerateContactCenterData(int caseDetailId)
        {
            var append = DateTime.Now.ToString("fff");

            var result = new ContactCenter
            {
                OptionSuiteOptionsId = Data.GetContactCenterOption().OrderBy(x => Guid.NewGuid()).FirstOrDefault(t => t.Type == "OptionSuite").ContactCenterOptionId, //DEL
                ForeignLanguageIvrOptionsId = Data.GetContactCenterOption().OrderBy(x => Guid.NewGuid()).FirstOrDefault(t => t.Type == "ForeignLanguageIvr").ContactCenterOptionId, //DEL
                CaseNameinCMX = "CaseNameinCMX" + append,
                ForeignLanguageCallCenterOptionsId = Data.GetContactCenterOption().OrderBy(x => Guid.NewGuid()).FirstOrDefault(t => t.Type == "ForeignLanguageCallCenter").ContactCenterOptionId, //DEL
                AgentsOptionsId = Data.GetContactCenterOption().OrderBy(x => Guid.NewGuid()).FirstOrDefault(t => t.Type == "Agents").ContactCenterOptionId, //DEL
                ContractSla = RandomBoolean(), //DEL
                ContractSlaNote = "ContractSlaNote: " + append, //DEL
                CustomCallRouting = RandomBoolean(),
                BilingualAgents = RandomBoolean(),
                Chat = RandomBoolean()
            };
            return result;
        }

        public static void UpdateContactCenterData(ContactCenter record)
        {
            test.SelectField(By.Name("OptionSuite"), record.ContactCenterOption.Name ?? ""); //DEL
            test.SelectField(By.Name("ForeignLanguageIvr"), record.ContactCenterOption.Name  ?? ""); //DEL
            test.EditField(By.Name("CaseNameinCMX"), record.CaseNameinCMX ?? "");
            test.SelectField(By.Name("ForeignLanguageCallCenter"), record.ContactCenterOption.Name ?? ""); //DEL
            test.SelectField(By.Name("Agents"), record.ContactCenterOption.Name ?? "");  //DEL
            if (record.ContractSla != null) test.SelectField(By.Name("ContractSla"), test.ToYesNoString((bool)record.ContractSla));  //DEL
            test.EditField(By.Name("ContractSlaNote"), record.ContractSlaNote ?? "");  //DEL
            test.SetCheckbox(By.Name("CustomCallRouting"), record.CustomCallRouting ?? false);
            test.SetCheckbox(By.Name("BilingualAgents"), record.BilingualAgents ?? false);
            test.SetCheckbox(By.Name("Chat"), record.Chat ?? false);
        }

        public static void ValidateContactCenterData(ContactCenter record)
        {
            if (record == null)
            {
                report.Step("There is no Contact Center data for this case.");
                return;
            }
            //Workaround until dynamic forms removed.
            var retry = 0;
            while (test.driver.FindElements(_OptionSuite).Count == 0 && retry < 5)
            {
                var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(10));
                try
                {
                    wait.Until(d => (d.FindElements(_OptionSuite)).Count > 0);
                }
                catch (WebDriverTimeoutException)
                {
                    report.Fail("Section failed to load. Refreshing.");
                    navigate.Refresh();
                    retry++;
                }
            }
            //
            var agentGoLiveDate = Data.GetMilestone(record.CaseDetailId, "Agent Go Live").First().DueDate;
            var websiteLaunchDate = Data.GetMilestone(record.CaseDetailId, "Website Launch Date").First().DueDate;
            test.vars.verify(test.VerifyFieldValue(_OptionSuite, record.ContactCenterOption.Name ?? "")); //DEL modified _OptionSuite 
            test.vars.verify(test.VerifyDateFieldByOperator(test.driver, _AgentGoLiveDate, "=", agentGoLiveDate?.ToString("MM/dd/yyyy") ?? ""));
            //test.vars.verify(test.VerifyFieldValue(_ForeignLanguageIvr, record.ContactCenterOption.Name ?? "")); //DEL Original
            test.vars.verify(test.VerifyFieldValue(_ForeignLanguageIvr, record.ForeignLanguageIvrOptionsId.ToString())); //DEL changed when ops page redesigned
            test.vars.verify(test.VerifyDateFieldByOperator(test.driver, _WebsiteGoLiveDate, "=", websiteLaunchDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValue(_CaseNameinCMX, record.CaseNameinCMX ?? ""));
            test.vars.verify(test.VerifyFieldValue(_ForeignLanguageCallCenter, record.ContactCenterOption.Name ?? "")); //DEL
            test.vars.verify(test.VerifyFieldValue(_Agents, record.ContactCenterOption.Name ?? "")); //DEL
            test.vars.verify(test.VerifySelectedValue(_ContractSlaForAsa, test.ToYesNoString(record.ContractSla != null && (bool)record.ContractSla) ?? "No"));  //DEL
            test.vars.verify(test.VerifyFieldValue(_ContractSlaForAsaNote, record.ContactCenterOption.Name ?? ""));  //DEL
            test.vars.verify(VerifyCheckBoxValue("CustomCallRouting", record.CustomCallRouting.ToString()));
            test.vars.verify(VerifyCheckBoxValue("BilingualAgents", record.BilingualAgents.ToString()));
            test.vars.verify(VerifyCheckBoxValue("Chat", record.Chat.ToString()));
        }

        public static int RandomDisbursementsOptionId(string type)
        {
            var options = Data.GetDisbursementsOption();
            var min = options.Where(t => t.Type == type).Min(m => m.DisbursementsOptionId) - 1;
            var max = options.Where(t => t.Type == type).Max(m => m.DisbursementsOptionId);
            System.Threading.Thread.Sleep(100); //Ensure each call produces a different number
            return options[new Random().Next(min, max)].DisbursementsOptionId;
        }

        public static Disbursement GenerateDisbursementData(int caseDetailId)
        {
           return new Disbursement
            {
                CaseDetailId = caseDetailId,
                AwardTypeOptionsId = RandomDisbursementsOptionId("AwardType"),
                TaxReportingOptionsId = RandomDisbursementsOptionId("TaxReporting"),
                TaxVendorOptionsId = RandomDisbursementsOptionId("TaxVendor"),
                DistributionScheduleOptionsId = RandomDisbursementsOptionId("DistributionSchedule"),
                ResidualFundOptionsId = RandomDisbursementsOptionId("ResidualFund"),
                ForeignAddresses = RandomBoolean(),
                Deminimis = RandomBoolean(),
                Householding = RandomBoolean(),
                Withholding = RandomBoolean(),
                Qsf = RandomBoolean(),
                CustomEnvelope = RandomBoolean(),
                InsertWithCheck = RandomBoolean(),
                AttorneyPayment = RandomBoolean(),
                NamedPlaintiffAwards = RandomBoolean(),
                ReserveHoldback = RandomBoolean(),
                CustomReporting = RandomBoolean(),
                EpiqInvoicesPaidFromFund = RandomBoolean()
            };
        }

        public static void UpdateDisbursementData(Disbursement record)
        {
            var options = Data.GetDisbursementsOption();
            test.SelectField(_AwardType, options.First(i => i.DisbursementsOptionId == record.AwardTypeOptionsId).Name);
            test.SelectField(_TaxReporting, options.First(i => i.DisbursementsOptionId == record.TaxReportingOptionsId).Name);
            test.SelectField(_TaxVendor, options.First(i => i.DisbursementsOptionId == record.TaxVendorOptionsId).Name);
            test.SelectField(_DistributionSchedule, options.First(i => i.DisbursementsOptionId == record.DistributionScheduleOptionsId).Name);
            test.SelectField(_ResidualFund, options.First(i => i.DisbursementsOptionId == record.ResidualFundOptionsId).Name);
            if (record.ForeignAddresses != null) test.SelectField(_ForeignAddresses, test.ToYesNoString((bool)record.ForeignAddresses));
            if (record.Deminimis != null) test.SelectField(_Deminimis, test.ToYesNoString((bool)record.Deminimis));
            if (record.Householding != null) test.SelectField(_Householding, test.ToYesNoString((bool)record.Householding));
            if (record.Withholding != null) test.SelectField(_Withholding, test.ToYesNoString((bool)record.Withholding));
            if (record.Qsf != null)test.SelectField(_Qsf, test.ToYesNoString((bool)record.Qsf));
            if (record.CustomEnvelope != null) test.SelectField(_CustomEnvelope, test.ToYesNoString(record.CustomEnvelope != null && (bool)record.CustomEnvelope));
            if (record.InsertWithCheck != null) test.SelectField(_InsertWithCheck, test.ToYesNoString((bool)record.InsertWithCheck));
            if (record.AttorneyPayment != null) test.SelectField(_AttorneyPayment, test.ToYesNoString((bool)record.AttorneyPayment));
            if (record.NamedPlaintiffAwards != null) test.SelectField(_NamedPlaintiffAwards, test.ToYesNoString((bool)record.NamedPlaintiffAwards));
            if (record.ReserveHoldback != null) test.SelectField(_ReserveHoldback, test.ToYesNoString((bool)record.ReserveHoldback));
            if (record.CustomReporting != null) test.SelectField(_CustomReporting, test.ToYesNoString((bool)record.CustomReporting));
            if (record.EpiqInvoicesPaidFromFund != null) test.SelectField(_EpiqInvoicesPaidFromFund, test.ToYesNoString((bool)record.EpiqInvoicesPaidFromFund));
        }

        public static void ValidateDisbursementsData(Disbursement record)
        {
            if (record == null)
            {
                report.Step("There is no Disbursement data for this case.");
                return;
            }
            var options = Data.GetDisbursementsOption();
            var initialDistributionDate = Data.GetMilestone(record.CaseDetailId, "Initial Distribution").First().DueDate;
            test.vars.verify(test.VerifyFieldValue(_InitialDistributionDate, initialDistributionDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifySelectedValue(_AwardType, options.FirstOrDefault(i => i.DisbursementsOptionId == record.AwardTypeOptionsId)?.Name ?? ""));
            test.vars.verify(test.VerifySelectedValue(_TaxReporting, options.FirstOrDefault(i => i.DisbursementsOptionId == record.TaxReportingOptionsId)?.Name ?? ""));
            test.vars.verify(test.VerifySelectedValue(_TaxVendor, options.FirstOrDefault(i => i.DisbursementsOptionId == record.TaxVendorOptionsId)?.Name ?? ""));
            test.vars.verify(test.VerifySelectedValue(_DistributionSchedule, options.FirstOrDefault(i => i.DisbursementsOptionId == record.DistributionScheduleOptionsId)?.Name ?? ""));
            test.vars.verify(test.VerifySelectedValue(_ResidualFund, options.FirstOrDefault(i => i.DisbursementsOptionId == record.ResidualFundOptionsId)?.Name ?? ""));
            if (record.ForeignAddresses != null) test.vars.verify(test.VerifySelectedValue(_ForeignAddresses, test.ToYesNoString((bool)record.ForeignAddresses)));
            if (record.Deminimis != null) test.vars.verify(test.VerifySelectedValue(_Deminimis, test.ToYesNoString((bool)record.Deminimis)));
            if (record.Householding != null) test.vars.verify(test.VerifySelectedValue(_Householding, test.ToYesNoString((bool)record.Householding)));
            if (record.Withholding != null) test.vars.verify(test.VerifySelectedValue(_Withholding, test.ToYesNoString((bool)record.Withholding)));
            if (record.Qsf != null) test.vars.verify(test.VerifySelectedValue(_Qsf, test.ToYesNoString((bool)record.Qsf)));
            if (record.CustomEnvelope != null) test.vars.verify(test.VerifySelectedValue(_CustomEnvelope, test.ToYesNoString((bool)record.CustomEnvelope)));
            if (record.InsertWithCheck != null) test.vars.verify(test.VerifySelectedValue(_InsertWithCheck, test.ToYesNoString((bool)record.InsertWithCheck)));
            if (record.AttorneyPayment != null) test.vars.verify(test.VerifySelectedValue(_AttorneyPayment, test.ToYesNoString((bool)record.AttorneyPayment)));
            if (record.NamedPlaintiffAwards != null) test.vars.verify(test.VerifySelectedValue(_NamedPlaintiffAwards, test.ToYesNoString((bool)record.NamedPlaintiffAwards)));
            if (record.ReserveHoldback != null) test.vars.verify(test.VerifySelectedValue(_ReserveHoldback, test.ToYesNoString((bool)record.ReserveHoldback)));
            if (record.CustomReporting != null) test.vars.verify(test.VerifySelectedValue(_CustomReporting, test.ToYesNoString((bool)record.CustomReporting)));
            if (record.EpiqInvoicesPaidFromFund != null) test.vars.verify(test.VerifySelectedValue(_EpiqInvoicesPaidFromFund, test.ToYesNoString((bool)record.EpiqInvoicesPaidFromFund)));
        }

        public static int RandomDocumentProcessingOptionId(string type)
        {
            var options = Data.GetDocumentProcessingOption();
            var min = options.Where(t => t.Type == type).Min(m => m.DocumentProcessingOptionId) - 1;
            var max = options.Where(t => t.Type == type).Max(m => m.DocumentProcessingOptionId);
            System.Threading.Thread.Sleep(100); //Ensure each call produces a different number
            return options[new Random().Next(min, max)].DocumentProcessingOptionId;
        }

        public static DocumentProcessing GenerateDocumentProcessingData()
        {
            var append = DateTime.Now.ToString("fff");
            var record = new DocumentProcessing
            {
                DeTypeOptionsId = RandomDocumentProcessingOptionId("DEType"),
                DcSlaOptionsId = RandomDocumentProcessingOptionId("DCSLA"),
                DeSlaOptionsId = RandomDocumentProcessingOptionId("DESLA"),
                IntakeTypeOptionsId = RandomDocumentProcessingOptionId("IntakeType"),
                UndeliverableCheckOptionsId = RandomDocumentProcessingOptionId("UndeliverableCheck"),
                NonStandardMonths = "NonStnd" + append,
                BoxStorageBillable = RandomBoolean(),
                IvrTranscription = RandomBoolean(),
                NomineeClaimProcessing = RandomBoolean(),
                Remails = RandomBoolean(),
                SecuredPhysicalStorageRequired = RandomBoolean(),
                Undeliverables = RandomBoolean(),
                BrokerListProcessing = RandomBoolean(),
                DcSpecialInstructions = "DcSpecialInstructions" + append,
                DeSpecialInstructions = "DeSpecialInstructions" + append,
                SpecialReportingRequirements = "SpecialReportingRequirements" + append,
                FaxInboxEmail = "FaxInboxEmail" + append
            };
            return record;
        }

        public static void UpdatedDocumentProcessingData(DocumentProcessing record)
        {
            var options = Data.GetDocumentProcessingOption();
            test.SelectField(_DeType, options.First(i => i.DocumentProcessingOptionId == record.DeTypeOptionsId).Name);
            test.SelectField(_DcSla, options.First(i => i.DocumentProcessingOptionId == record.DcSlaOptionsId).Name);
            test.SelectField(_DeSla, options.First(i => i.DocumentProcessingOptionId == record.DeSlaOptionsId).Name);
            test.SelectField(_IntakeType, options.First(i => i.DocumentProcessingOptionId == record.IntakeTypeOptionsId).Name);
            test.SelectField(_UndeliverableCheck, options.First(i => i.DocumentProcessingOptionId == record.UndeliverableCheckOptionsId).Name);
            test.EditField(_NonStandardMonths, record.NonStandardMonths ?? "");            
            test.SetCheckbox(_BoxStorageBillable, record.BoxStorageBillable ?? false);
            test.SetCheckbox(_IvrTranscription, record.IvrTranscription ?? false);
            test.SetCheckbox(_NomineeClaimProcessing, record.NomineeClaimProcessing ?? false);
            test.SetCheckbox(_Remails, record.Remails ?? false);
            test.SetCheckbox(_SecuredPhysicalStorageRequired, record.SecuredPhysicalStorageRequired ?? false);
            test.SetCheckbox(_Undeliverables, record.Undeliverables ?? false);
            test.SetCheckbox(_BrokerListProcessing, record.BrokerListProcessing ?? false);
            test.EditField(_DcSpecialInstructions, record.DcSpecialInstructions ?? "");
            test.EditField(_DeSpecialInstructions, record.DeSpecialInstructions ?? "");
            test.EditField(_SpecialReportingRequirements, record.SpecialReportingRequirements ?? "");
            test.EditField(_FaxInboxEmail, record.FaxInboxEmail ?? "");
        }

        public static void ValidateDocumentProcessingData(DocumentProcessing record)
        {
            if (record == null)
            {
                report.Step("There is no Document Processing data for this case.");
                return;
            }
            var options = Data.GetDocumentProcessingOption();
            test.vars.verify(test.VerifySelectedValue(_DeType, options.First(i => i.DocumentProcessingOptionId == record.DeTypeOptionsId).Name));
            test.vars.verify(test.VerifySelectedValue(_DcSla, options.First(i => i.DocumentProcessingOptionId == record.DcSlaOptionsId).Name));
            test.vars.verify(test.VerifySelectedValue(_DeSla, options.First(i => i.DocumentProcessingOptionId == record.DeSlaOptionsId).Name));
            test.vars.verify(test.VerifySelectedValue(_IntakeType, options.First(i => i.DocumentProcessingOptionId == record.IntakeTypeOptionsId).Name));
            test.vars.verify(test.VerifySelectedValue(_UndeliverableCheck, options.First(i => i.DocumentProcessingOptionId == record.UndeliverableCheckOptionsId).Name));
            test.vars.verify(test.VerifyFieldValue(_NonStandardMonths, record.NonStandardMonths ?? ""));
            test.vars.verify(test.VerifyCheckBoxValue(_BoxStorageBillable, record.BoxStorageBillable));
            test.vars.verify(test.VerifyCheckBoxValue(_IvrTranscription, record.IvrTranscription));
            test.vars.verify(test.VerifyCheckBoxValue(_NomineeClaimProcessing, record.NomineeClaimProcessing));
            test.vars.verify(test.VerifyCheckBoxValue(_Remails, record.Remails));
            test.vars.verify(test.VerifyCheckBoxValue(_SecuredPhysicalStorageRequired, record.SecuredPhysicalStorageRequired));      
            test.vars.verify(test.VerifyCheckBoxValue(_Undeliverables, record.Undeliverables));
            test.vars.verify(test.VerifyCheckBoxValue(_BrokerListProcessing, record.BrokerListProcessing));
            test.vars.verify(test.VerifyFieldValue(_DcSpecialInstructions, record.DcSpecialInstructions ?? ""));
            test.vars.verify(test.VerifyFieldValue(_DeSpecialInstructions, record.DeSpecialInstructions ?? ""));
            test.vars.verify(test.VerifyFieldValue(_SpecialReportingRequirements, record.SpecialReportingRequirements ?? ""));
            test.vars.verify(test.VerifyFieldValue(_FaxInboxEmail, record.FaxInboxEmail ?? ""));
        }

        public static int RandomIncomingDocumentOptionId(string type)
        {

            // the table IncomingDocumentOptionId table changed and the ProcessingTypes are embedded at 23 to 25  //DEL
            // really need to recode this with IncomingDocumentOptionId.Name as the test in case table changes    //DEL
            var options = Data.GetIncomingDocumentOptions();
            int min;                                                                                    //DEL
            int max;                                                                                    //DEL
            int result;                                                                                 //DEL

                 min = options.Where(t => t.Type == type).Min(m => m.IncomingDocumentOptionId) - 1;      //DEL
                 max = options.Where(t => t.Type == type).Max(m => m.IncomingDocumentOptionId);          //DEL
                System.Threading.Thread.Sleep(100); //Ensure each call produces a different number          //DEL
          

            while ((result= options[new Random().Next(min, max)].IncomingDocumentOptionId)  > 22 && result < 26 && result != 12 )                //DEL
            { }                                                                                          //DEL



            return result;                                                                            //DEL

            //var options = Data.GetIncomingDocumentOptions();                                              //DEL
            //var min = options.Where(t => t.Type == type).Min(m => m.IncomingDocumentOptionId) - 1;        //DEL
            //var max = options.Where(t => t.Type == type).Max(m => m.IncomingDocumentOptionId);            //DEL
            //System.Threading.Thread.Sleep(100); //Ensure each call produces a different number            //DEL
            //return options[new Random().Next(min, max)].IncomingDocumentOptionId;                         //DEL
        }

        public static IncomingDocument GenerateIncomingDocumentData()
        {
            var append = DateTime.Now.ToString("fff"); 
            var other = Data.GetIncomingDocumentOptions().First(n => n.Name == "Other").IncomingDocumentOptionId;

            var result = new IncomingDocument
            {
                IncomingDocumentTypeOptionsId = RandomIncomingDocumentOptionId("IncomingDocumentType")
             };
            if (result.IncomingDocumentTypeOptionsId != other)
            {
                //result.ProcessingTypeOptionsId = RandomIncomingDocumentOptionId("ProcessingType");    //DEL why dip back in after test?
            }
            else
            {
                result.IncomingDocumentTypeOther = "Processing Type Text " + append;
                // here we need to add a value for the new text field     //DEL
            }
            return result;
        }

        public static void UpdateIncomingDocumentData(IncomingDocument record)
        {
            var allProcessingTypes = Data.GetIncomingDocumentOptions().Where(x => x.Type == "ProcessingType"); //DEL

            //int randomDocumentType;         //DEL
            //int randomDocumentProcessingType;       //DEL

            //randomDocumentType = RandomDocumentProcessingOptionId("IncomingDocumentType");                  //DEL
            //randomDocumentProcessingType = RandomDocumentProcessingOptionId("ProcessingType");              //DEL

            var options = Data.GetIncomingDocumentOptions();

            //test.SelectField(test.driver, _IncomingDocumentType, options.First(i => i.IncomingDocumentOptionId == record.randomDocument).Name);         //DEL

            test.SelectField(test.driver, _IncomingDocumentType, options.First(i => i.IncomingDocumentOptionId == record.IncomingDocumentTypeOptionsId &&   //DEL
                (record.IncomingDocumentTypeOptionsId <= 22 || record.IncomingDocumentTypeOptionsId >= 26)).Name);                                         //DEL                


            //test.SelectField(test.driver, _IncomingDocumentType, options.First(i => i.IncomingDocumentOptionId == record.IncomingDocumentTypeOptionsId).Name); //DEL
            //test.SelectField(test.driver, _ProcessingType, options.First(i => i.IncomingDocumentOptionId == record.ProcessingTypeOptionsId).Name);  //DEL

            test.SelectField(test.driver, _ProcessingType, allProcessingTypes.First().Name);  //DEL
        }

        public static void ValidateIncomingDocumentsGridData(List<IncomingDocument> records)
        {
            var options = Data.GetIncomingDocumentOptions();
            var row = 0;
            const int maxRows = 20;
            test.vars.verify(grid.VerifyRowCount(_DocumentProcessingRow, records.Count, maxRows));
            foreach (var record in records)
            {
                if (++row >= maxRows)
                {
                    report.Step("Only the first " + maxRows + " rows are verified.");
                    break;
                }
                var incomingDocumentType = options.First(i => i.IncomingDocumentOptionId == record.IncomingDocumentTypeOptionsId).Name;
               
                test.vars.verify(grid.VerifyCellContents(_DocumentProcessingSection, "Incoming Document Type",
                    incomingDocumentType, row));
                
                var incomingProcessingType = options.First(i => i.IncomingDocumentOptionId == record.ProcessingTypeOptionsId ).Name;    //DEL

                test.vars.verify(grid.VerifyCellContents(_DocumentProcessingSection, "Processing Type",                     //DEL
                    incomingProcessingType, row));                                                                          //DEL    
            }
        }

        public static HumanResource GenerateHrData()
        {
            var record = new HumanResource
            {
                DrugTesting = RandomBoolean(),
                BankruptcyScreening = RandomBoolean(),
                CreditCheck = RandomBoolean(),
                CriminalBackground = RandomBoolean(),
                AnnualComplianceTraining = RandomBoolean(),
                FingerPrint = RandomBoolean()
            };
            return record;
        }

        public static void UpdateHrData(HumanResource record)
        {
            test.SelectField(_DrugTesting, test.ToYesNoString(record.DrugTesting));
            test.SelectField(_BankruptcyScreening, test.ToYesNoString(record.BankruptcyScreening));
            test.SelectField(_CreditCheck, test.ToYesNoString(record.CreditCheck));
            test.SelectField(_CriminalBackground, test.ToYesNoString(record.CriminalBackground));
            test.SelectField(_AnnualComplianceTraining, test.ToYesNoString(record.AnnualComplianceTraining));
            test.SelectField(_FingerPrint, test.ToYesNoString(record.FingerPrint));

        }

        public static void ValidateHrData(HumanResource record)
        {
            if (record == null)
            {
                report.Step("There is no HR data for this case.");
                return;
            }

                test.vars.verify(test.VerifySelectedValue(_DrugTesting, test.ToYesNoString(record.DrugTesting)));
                test.vars.verify(test.VerifySelectedValue(_BankruptcyScreening,
                    test.ToYesNoString(record.BankruptcyScreening)));
                test.vars.verify(test.VerifySelectedValue(_CreditCheck, test.ToYesNoString(record.CreditCheck)));
                test.vars.verify(test.VerifySelectedValue(_CriminalBackground,
                    test.ToYesNoString(record.CriminalBackground)));
                test.vars.verify(test.VerifySelectedValue(_AnnualComplianceTraining,
                    test.ToYesNoString(record.AnnualComplianceTraining)));
                test.vars.verify(test.VerifySelectedValue(_FingerPrint, test.ToYesNoString(record.FingerPrint)));
        }

        public static void ValidateOpsFieldValidation(int caseDetailId)
        {
            var fields = new List<FieldDetail>
            {
                new FieldDetail
                {
                    Label = "Overall Processing Due Date",
                    Type = "date"
                },
                new FieldDetail
                {
                    Label = "Special Servicing Comments",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "SLA Servicing Comments",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Defect Letter Notifications (Timing)",
                    Length = 500
                },
                new FieldDetail
                {
                    Label = "Supported Languages For Claims",
                    Length = 500
                },
                new FieldDetail
                {
                    Label = "Disbursement Date Exceptions",
                    Length = 500
                },
                //new FieldDetail
                //{
                //    Label = "Case Name in CMX",
                //    Length = 256
                //},
                //new FieldDetail
                //{
                //    Label = "Contractual SLA Note",
                //    Length = 250
                //},
                new FieldDetail
                {
                    Label = "Non Standard No of Months",
                    Length = 10
                },
                new FieldDetail
                {
                    Label = "DC Special Instructions",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "DE Special Instructions",
                    Length = 8000
                },
                new FieldDetail
                {
                    Label = "Special Reporting Requirements",
                    Length = 100
                },
                new FieldDetail
                {
                    Label = "Fax Inbox Email",
                    Length = 100
                }
            };
            ValidateFields(fields, false, null);
            
            //var mailingDescription = Data.GetMailingDetail()
            //    .First(i => i.MailingId == Data.GetMailing().First(c => c.CaseDetailId == caseDetailId).MailingId)
            //    .Description;
            //fields = new List<FieldDetail>
            //{
            //    new FieldDetail
            //    {
            //        Label = "Description",
            //        Length = 500,
            //        ValidText = mailingDescription
            //    },
            //    new FieldDetail
            //    {
            //        Label = "Drop Date",
            //        Type = "date"
            //    },
            //    new FieldDetail
            //    {
            //        Label = "Package Content",
            //        Length = 4000
            //    },
            //    new FieldDetail
            //    {
            //        Label = "Estimated Postage Rate",
            //        Length = 100
            //    },
            //    new FieldDetail
            //    {
            //        Label = "Drop Schedule",
            //        Length = 500
            //    }
            //};
            //ValidateDynamicFields(fields, true, mailingDescription);
        }

        public static Document GenerateDocumentsRecord(string filename)
        {
            var append = DateTime.Now.ToString("fff");
            var record = new Document
            {
                DocumentTypeId = new Random().Next(1, Data.GetDocumentType().Count),
                UploadedDate = DateTime.Now,
                DisplayName = filename,
                Owner = test.driver.FindElement(By.XPath("//span[@ng-bind='username()']")).Text,
                Note = "Document Note " + append,
                UpdatedDate = DateTime.Now
            };
            return record;
        }

        public static void UpdateDocumentsData(Document record)
        {
            report.Step("Update Documents Record");
            test.SelectField(_DocumentsType, Data.GetDocumentType().First(i => i.DocumentTypeId == record.DocumentTypeId)?.Name ?? "");
            test.EditField(_DocumentsNote, record.Note ?? "");
        }

        public static void ValidateDocumentsGridData(Document record)
        {
            report.Step("Validate Documents Grid");
            test.vars.verify(VerifyValueBySectionandColumn(_Documents, "Type", Data.GetDocumentType().First(i => i.DocumentTypeId == record.DocumentTypeId)?.Name ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Documents, "Date Uploaded", record.UploadedDate.ToString("MM/dd/yyyy")));
            test.vars.verify(VerifyHrefBySectionAndColumn(_Documents, "File Name", record.DisplayName ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Documents, "Owner", record.Owner ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Documents, "Document Note", record.Note ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Documents, "Date Updated", record.UpdatedDate.ToString("MM/dd/yyyy")));
        }

        public static void ValidateDocumentsData(Document record)
        {
            report.Step("Validate Documents Record");
            test.vars.verify(test.VerifySelectedValue(_DocumentsType, Data.GetDocumentType().First(i => i.DocumentTypeId == record.DocumentTypeId)?.Name ?? ""));
            test.vars.verify(test.VerifyFieldValue(_DocumentsNote, record.Note ?? ""));
        }

        public static void ValidateDocumentsRequiredFields()
        {
            test.Click(_DocumentsEdit);
            ValidateRequiredField("documentTypeId");
            test.Click(_ModalCancel);
        }

        public static int VerifyDocumentDownload(string displayName)
        {
            test.Click(By.LinkText(displayName));
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(5));
            var by = By.XPath("//div[@class='toast toast-error']//div[@class='toast-message']");

            try
            {
                wait.Until(d => (d.FindElements(by).Count != 0));
                report.Fail("Error toasts returned: " + test.driver.FindElement(by).Text);
                test.driver.FindElement(by).Click();
                return 1;
            }
            catch (Exception)
            {
                report.Pass("No Error toasts returned");
                return 0;
            }

        }

        public static void ValidateStatisticsData(Data.GetReportData_WAR_Result record)
        {
            if (record == null)
            {
                test.vars.verify(test.VerifyPageSourceText(test.driver, "Statistics cannot be displayed for cases stored in a Ranger Environment."));
            }
            else
            {
                test.vars.verify(VerifyGridValue(_Stats, "ReportCategory", record.ReportCategory ?? ""));
                test.vars.verify(VerifyGridValue(_Stats, "MetricName", record.MetricName ?? ""));
                test.vars.verify(VerifyGridValue(_Stats, "CumulativeCount", record.CumulativeCount ?? ""));
            }
        }

        public static StatusUpdate GenerateHealthData(int caseDetailId, string rating)
        {
            var append = DateTime.Now.ToString("fff");
            var record = new StatusUpdate
            {
                CaseDetailId = caseDetailId,
                StatusDate = DateTime.Now.AddDays(new Random().Next(60, 120)), 
                Comment = "Comment " + append,
                KeyStats = "Action Pending " + append,
                Rating = rating
            };
            return record;
        }

        public static void UpdateHealthData(StatusUpdate record)
        {
            test.EditField(_HealthDate, record.StatusDate?.ToString("MM/dd/yyyy") ?? "");
            test.EditField(_KeyStats, record.KeyStats ?? "");
            test.Click(By.XPath("//div[@ng-model='vm.statusupdate.rating']"));
            test.Click(By.XPath("//div[@ng-model='vm.statusupdate.rating']//span[text()='" + record.Rating + "']"));
            test.EditField(_HealthComment, record.Comment);
        }

        public static void ValidateHealthGridData(StatusUpdate record)
        {
            report.Step("Validate Health Grid Data");
            test.vars.verify(VerifyValueBySectionandColumn(_Health, "Date", record.StatusDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Health, "Issue/Comment", record.Comment ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Health, "Key Stats", record.KeyStats ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Health, "Rating", record.Rating ?? ""));
        }

        public static void ValidateHealthData(StatusUpdate record)
        {
            report.Step("Validate Health Modal Data");
            test.vars.verify(test.VerifyFieldValue(_HealthDate, record.StatusDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValue(_KeyStats, record.KeyStats ?? ""));
            test.vars.verify(test.driver.FindElement(_HealthRating).GetAttribute("readonly") == null
                ? test.VerifyText(_HealthRating, record.Rating ?? "")
                : test.VerifyFieldValue(_HealthRating, record.Rating ?? ""));
            test.vars.verify(test.VerifyFieldValue(_HealthComment, record.Comment ?? ""));
        }

        public static void ValidateHealthRequiredFields()
        {
            test.Click(_HealthEdit);
            ValidateDateRequiredField("statusDate");
            ValidateRequiredField("actionPending");
            ValidateRequiredField("comment");
            test.Click(_ModalCancel);
        }

        public static void ValidateHealthFieldValidation()
        {
            var fields = new List<FieldDetail>
            {
                new FieldDetail
                {
                    Label = "Date",
                    Type = "date",
                    ValidText = DateTime.Now.AddDays(30).ToString("MM/dd/yyyy")
                },
                new FieldDetail
                {
                    Label = "Key Stats",
                    Length = 255
                },
                new FieldDetail
                {
                    Label = "Issue/Comment",
                    Length = 2048
                }
            };
            ValidateHealthRequiredFields();
            ValidateFields(fields, true, _HealthEdit);
        }

        public static void ValidateInvoiceGridData(Invoice record)
        {
            report.Step("Validate Invoice Grid Data");
            test.vars.verify(VerifyValueBySectionandColumn(_Invoice, "Date", record.InvoiceDate?.ToString("MM/yy") ?? ""));
            test.vars.verify(VerifyValueBySectionandColumn(_Invoice, "Invoice Amount", record.Amount?.ToString("C", new CultureInfo("en-US")) ?? ""));
        }

        public static void ValidateInvoiceData(Invoice record)
        {
            report.Step("Validate Invoice Modal Data");
            test.vars.verify(test.VerifyFieldValue(_InvoiceDate, record.InvoiceDate?.ToString("MM/yy") ?? ""));
            test.vars.verify(test.VerifyFieldValue(_InvoiceAmount, record.Amount?.ToString("C", new CultureInfo("en-US")) ?? ""));
        }

        public static int RandomRiskMatrixOptionId(List<RiskMatrixOption> options, string type)
        {
            var min = options.Where(t => t.Type == type).Min(m => m.RiskMatrixOptionId);
            var max = options.Where(t => t.Type == type).Max(m => m.RiskMatrixOptionId);
            System.Threading.Thread.Sleep(100); //Ensure each call produces a different number
            return options[new Random().Next(min - 1, max - 1)].RiskMatrixOptionId;
        }

        public static RiskMatrix GenerateRiskMatrixData(bool noRiskIdentified, int? departmentId = null)
        {
            var append = DateTime.Now.ToString("fff");
            var options = Data.GetRiskMatrixOption();
            var result = new RiskMatrix
            {
                DepartmentId = departmentId ?? RandomRiskMatrixOptionId(options, "Department"),
                NoRiskIdentified = noRiskIdentified,
                InsertedDate = DateTime.Now,
                UpdatedDate = DateTime.Now
            };
            if (noRiskIdentified) return result;
            result.Owner = "Owner" + append;
            result.RiskCategoryId = RandomRiskMatrixOptionId(options, "Risk Category");
            result.RiskDescription = "AAARiskDescription" + append;
            result.DescriptionOfConsequence = "DescriptionOfConsequence" + append;
            result.Probability = new Random().Next(1, 5);
            System.Threading.Thread.Sleep(100);
            result.Impact = new Random().Next(1, 5);
            result.MitigationPlan = "MitigationPlan" + append;
            return result;
        }

        public static void UpdateRiskMatrixData(RiskMatrix record)
        {
            report.Step("Update Risk Matrix record");
            test.SelectField(_Department, Data.GetRiskMatrixOptionName(record.DepartmentId));
            test.SetCheckbox(_NoRiskIdentified, record.NoRiskIdentified);
            if (record.NoRiskIdentified) return;
            test.EditField(_Owner, record.Owner);
            test.SelectField(_RiskCategory, Data.GetRiskMatrixOptionName(record.RiskCategoryId));
            test.EditField(_RiskDescription, record.RiskDescription);
            test.EditField(_DescriptionOfConsequences, record.DescriptionOfConsequence);
            test.SelectField(_Probability, record.Probability.ToString());
            test.SelectField(_Impact, record.Impact.ToString());
            test.EditField(_MitigationPlan, record.MitigationPlan);
        }

        public static void ValidateRiskMatrixData(RiskMatrix record)
        {
            report.Step("Validate Risk Matrix record");
            test.vars.verify(test.VerifySelectedValue(_Department,Data.GetRiskMatrixOptionName(record.DepartmentId)));
            test.vars.verify(test.VerifyFieldValue(_Owner, record.Owner));
            test.vars.verify(test.VerifyFieldValue(_Number, record.RiskNumber.ToString()));
            test.vars.verify(test.VerifyFieldValue(_DateAdded, record.InsertedDate.ToString("MM/dd/yyyy")));
            test.vars.verify(test.VerifySelectedValue(_RiskCategory, Data.GetRiskMatrixOptionName(record.RiskCategoryId)));
            test.vars.verify(test.VerifyCheckBoxValue(_NoRiskIdentified, record.NoRiskIdentified));
            test.vars.verify(test.VerifyFieldValue(_RiskDescription, record.RiskDescription));
            test.vars.verify(test.VerifyFieldValue(_DescriptionOfConsequences, record.DescriptionOfConsequence));
            test.vars.verify(test.VerifySelectedValue(_Probability, record.Probability.ToString()));
            test.vars.verify(test.VerifySelectedValue(_Impact, record.Impact.ToString()));
            test.vars.verify(test.VerifyFieldValue(_RiskValue, (record.Probability * record.Impact).ToString()));
            test.vars.verify(test.VerifyFieldValue(_MitigationPlan, record.MitigationPlan));
        }

        public static void ValidateRiskMatrixGridData(List<RiskMatrix> records)
        {
            var row = 0;
            const int maxRows = 20;
            foreach (var record in records)
            {
                if (++row >= maxRows)
                {
                    report.Step("Only the first " + maxRows + " rows are verified.");
                    break;
                }

                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Department", Data.GetRiskMatrixOptionName(record.DepartmentId), row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "No", record.RiskNumber.ToString(), row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Description", record.RiskDescription, row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Date Added", record.InsertedDate.ToString("MM/dd/yyyy"), row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Risk Category", Data.GetRiskMatrixOptionName(record.RiskCategoryId), row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Description Of Consequence", record.DescriptionOfConsequence, row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Probability", record.Probability.ToString(), row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Impact", record.Impact.ToString(), row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Risk Value", record.NoRiskIdentified ? "" : (record.Probability * record.Impact).ToString(), row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Mitigation Plan", record.MitigationPlan, row));
                test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Date Last Updated", record.UpdatedDate.ToString("MM/dd/yyyy"), row));
            }
        }

        public static void ValidateRiskMatrixGridData(RiskMatrix record)
        {
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Department", Data.GetRiskMatrixOptionName(record.DepartmentId)));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "No", record.RiskNumber.ToString()));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Description", record.RiskDescription));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Date Added", record.InsertedDate.ToString("MM/dd/yyyy")));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Risk Category", Data.GetRiskMatrixOptionName(record.RiskCategoryId)));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Description Of Consequence", record.DescriptionOfConsequence));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Probability", record.Probability.ToString()));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Impact", record.Impact.ToString()));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Risk Value", (record.Probability * record.Impact).ToString()));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Mitigation Plan", record.MitigationPlan));
            test.vars.verify(grid.VerifyCellContents(RiskMatrix, "Date Last Updated", record.UpdatedDate.ToString("MM/dd/yyyy")));
        }

        public static void ValidateRiskSummary(List<RiskMatrix> records)
        {
            var departments = Data.GetRiskMatrixOption().Where(t => t.Type == "Department").OrderBy(n => n.Name);
            var i = 0;
            foreach (var department in departments)
            {
                i++;
                test.vars.verify(grid.VerifyCellContents(RiskSummaryDirective, "Department", department.Name, i));
                test.vars.verify(grid.VerifyCellContents(RiskSummaryDirective, "Summary", GetSummaryText(department.RiskMatrixOptionId, records), i));
                test.vars.verify(grid.VerifyCellContents(RiskSummaryDirective, "Total Risk Value", GetSummaryRiskValue(department.RiskMatrixOptionId, records), i));
            }
            
        }

        public static string GetSummaryText(int departmentId, List<RiskMatrix> records)
        {
            if (records.Count(d => d.DepartmentId  == departmentId) == 0) return "No Response";
            if (records.Where(d => d.DepartmentId == departmentId).Any(n => n.NoRiskIdentified)) return "No Risk Identified";
            if (records.Count(d => d.DepartmentId == departmentId) == 1) return "1 Risk";
            return records.Count(d => d.DepartmentId == departmentId) + " Risks";
        }

        public static string GetSummaryRiskValue(int departmentId, List<RiskMatrix> records)
        {
            var result = records.Where(d => d.DepartmentId == departmentId).Sum(n => n.Probability * n.Impact);
            return (result > 0) ? result.ToString() : "";
        }

        public static void FileSelect(string path)
        {
            System.Threading.Thread.Sleep(2000);
            SendKeys.SendWait(path);
            test.WaitForFF(test.driver, 4500);
            SendKeys.SendWait("{ENTER}");
            System.Threading.Thread.Sleep(2000);
        }

        public static void EditCombo(string field, string text)
        {
            var box = By.XPath(field + "//div[contains(@class, 'ui-select-match')]");
            var input = By.XPath(field + "//input");

            report.Action("Edit Combo", field, text);
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
            wait.Until(d => d.FindElement(box).Enabled);
            test.WaitForPageToLoad(test.driver);
            test.ScrollTo(test.driver, box);
            test.driver.FindElement(box).Click();
            test.driver.FindElement(input).SendKeys(text + OpenQA.Selenium.Keys.Tab);
            test.WaitForPageToLoad(test.driver);
        }

        public static int VerifyComboValue(string field, string expected)
        {
            var selected = By.XPath(field + "//span[@ng-bind='$select.selected']");

            return test.VerifyText(test.driver, selected, expected);
        }

        public static string GetContactStatus(DateTime? startDate, DateTime? endDate)
        {
            if (startDate == null)
            {
                if (endDate == null)
                {
                    return "Yes";
                }
                if (endDate <= DateTime.Now.Date)
                {
                    return "No";
                }
                if (endDate > DateTime.Now.Date)
                {
                    return "Yes";
                }
            }
            else
            {
                if (endDate == null)
                {
                    return startDate.Value.Date <= DateTime.Now.Date ? "Yes" : "No";
                }
                if (startDate.Value.Date <= DateTime.Now.Date && endDate.Value.Date > DateTime.Now.Date)
                {
                    return "Yes";
                }
            }
            return "No";
        }

        public static void DeleteContactByValue(string value)
        {
            var xPath = _Contacts + "//span[text() = '" + value + "']/ancestor::node()[4]//a[contains(@ng-click, 'vm.delete')]";

            test.Click(By.XPath(xPath));
            test.ClickandConfirm(test.driver, _ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
        }

        public static int VerifyMissingRole(string role)
        {
                try
                {
                    test.WaitForPageToLoad(test.driver);
                    test.driver.FindElement(By.XPath("//div[@ng-show='vm.showMissingRolesMessage']//span[text()='" + role + "']"));
                    report.Pass("Missing role is displayed for:  " + role);
                    return 0;
                }
                catch (Exception e)
                {
                    report.Fail("Missing role is not displayed for:  " + role, e);
                    return 1;
                }
        }

        public static int VerifyNoMissingRoles()
        {
            try
            {
                test.WaitForPageToLoad(test.driver);
                Assert.IsFalse(test.driver.FindElements(By.XPath("//div[@ng-show='vm.showMissingRolesMessage']//span")).Any());
                report.Pass("Case has no missing roles");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Case has missing roles", e);
                return 1;
            }
        }

        public static bool RandomBoolean()
        {
            return incidents.RandomBoolean();
        }

        public static int VerifyUpload()
        {
            try
            {
                var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
                wait.Until(d => (d.FindElement(_UploadStatus)).Text != "Queued" && (d.FindElement(_UploadStatus)).Text != "Uploading");

                var status = test.driver.FindElement(_UploadStatus).Text;
                if (status == "Done")
                {
                    report.Pass("Upload Succeeded");
                    return 0;
                }
                else
                {
                    report.Fail("Upload Failed with a status of: " + status);
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail("Upload Timed out.", e);
                return 1;
            }
        }

        public static int VerifySectionLoad(string section, By field)
        {
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(10)); 
            
            try
            {
                wait.Until(d => d.FindElement(By.XPath("//span[text()='" + section + "']")).Displayed);
                report.Pass(section + " section is present.");
                test.ToggleSection(section);
                test.ToggleSection(section); //DEL added - the toggle was closing the section we wanted to see!

                try
                {
                    test.VerifyNoErrorToasts();
                    wait.Until(d => d.FindElement(field).Displayed);
                    report.Pass(section + " section details are present.");
                    return 0;
                }
                catch (Exception e)
                {
                    report.Fail(section + " section details are not present: " + e.Message);
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail(section + " section is not present: " + e.Message);
                return 1;
            }
        }

        public static void ValidatePageLoad(string name, By fieldToVerify, bool isGrid)
        {
            var xpath = "//a[text()='" + name + "']/parent::li";
            try
            {
                switch (name)
                {
                    case "Summary":
                    case "Detail":
                    case "Dates":
                    case "Contacts":
                    case "Ops/Shared Services":
                    case "Documents":
                    case "Statistics":
                    case "Health Status":
                    case "Risk Matrix":
                        test.Click(navigate._CaseInformation);
                        test.Click(By.XPath("//a[text()='Case Information']//following-sibling::ul" + xpath));
                        break;
                    case "Organization/Entity":
                        test.Click(navigate._Administration);
                        test.Click(navigate._AdminOrganization);
                        break;
                    case "AdminContacts":
                        test.Click(navigate._Administration);
                        test.Click(navigate._AdminContacts);
                        break;
                    default:
                        test.Click(By.XPath(xpath));
                        break;
                }
                test.vars.verify(test.VerifyNoErrorToasts());
                if (name == "Create New Case") return;
                if (isGrid)
                {
                    grid.WaitForGridData();
                }
                else
                {
                    if (name == "Ops/Shared Services")
                    {
                        navigate.Refresh();
                        test.ToggleSection("Claims");

                    }
                    test.WaitForElement(fieldToVerify);
                    test.vars.verify(test.VerifyFieldPopulation(fieldToVerify, true));
                }
            }
            catch(Exception e)
            {
                report.Fail(name + " failed to load: " + e);
                
            }      
        }

        public static int VerifyDateSummary(By by, Milestone record)
        {            
            if (record.NotApplicable) return test.VerifyFieldValue(by, "Not Applicable");
            if (record.DatePending) return test.VerifyFieldValue(by, "Date Pending");
            if (record?.DueDate == null) return test.VerifyFieldValue(by, "Date Missing");
            return test.VerifyDateFieldByOperator(test.driver, by, "=", record.DueDate?.ToString("MM/dd/yyyy"));

        }

        public static int VerifyElementDisplayed(By field)
        {
            try
            {
                var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(10));
                wait.Until(d => d.FindElement(field).Displayed);
                report.Pass(field + " is displaying.");
                return 0;
            }
            catch
            {
                report.Fail(field + " is failing to display.");
                return 1;
            }
        }
    }
}
