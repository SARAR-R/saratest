﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using Casebook.Database;
using OpenQA.Selenium;

namespace Casebook
{
    public static class incidents
    {
        //Main Page
        public static By _Total = By.XPath("//div[@class='ngTotalSelectContainer']//span");
        public static By _Add = By.XPath("//button[@ng-click='vm.addIncident()']");
        public static By _Export = By.XPath("//button[@ng-click='vm.excelExport()']");
        public static By _View = By.XPath("//a[@ng-click='vm.edit(row)']/i[contains(@class, 'fa-eye')]");
        public static By _Edit = By.XPath("//a[@ng-click='vm.edit(row)']/i[contains(@class, 'fa-pencil')]");
        public static By _Delete = By.XPath("//a[@ng-click='vm.delete(row)']");
        //Modal
        public static By _Number = By.XPath("//input[@ng-model='vm.incident.incidentNumber']");
        public static By _Name = By.XPath("//input[@ng-model='vm.incident.name']");
        public static By _DateOfIncident = By.XPath("//form//label[text()='Date of Incident Report']/..//input");
        public static By _EstDateOfIncident = By.XPath("//form//label[text()='Est Date of Incident']/..//input");
        public static By _ActualCost = By.XPath("//form//label[text()='Actual Cost']/following-sibling::input");
        public static By _Owner = By.XPath("//input[@ng-model='vm.incident.owner']");
        public static By _Status = By.XPath("//select[@ng-model='vm.incident.incidentStatusId']");
        public static By _LessonsLearnedMtg = By.XPath("//select[@ng-model='vm.incident.lessonsLearnedMeeting']");
        public static By _ClaimsOps = By.XPath("//input[@ng-model='vm.incident.claimsOperationsResponsible']");
        public static By _ClientServices = By.XPath("//input[@ng-model='vm.incident.clientServicesResponsible']");
        public static By _ContactCenter = By.XPath("//input[@ng-model='vm.incident.contactCenterResponsible']");
        public static By _CorporateServices = By.XPath("//input[@ng-model='vm.incident.corporateServicesResponsible']");
        public static By _DataEntry = By.XPath("//input[@ng-model='vm.incident.dataEntryResponsible']");
        public static By _DataServices = By.XPath("//input[@ng-model='vm.incident.dataServicesResponsible']");
        public static By _Disbursements = By.XPath("//input[@ng-model='vm.incident.disbursementsResponsible']");
        public static By _DocumentControl = By.XPath("//input[@ng-model='vm.incident.documentControlResponsible']");
        public static By _FileProcessing = By.XPath("//input[@ng-model='vm.incident.fileProcessingResponsible']");
        public static By _IT = By.XPath("//input[@ng-model='vm.incident.itResponsible']");
        public static By _LegalNoticing = By.XPath("//input[@ng-model='vm.incident.legalNoticingResponsible']");
        public static By _Mailings = By.XPath("//input[@ng-model='vm.incident.mailingsResponsible']");
        public static By _PrintOps = By.XPath("//input[@ng-model='vm.incident.printOperationsResponsible']");
        public static By _PrintServices = By.XPath("//input[@ng-model='vm.incident.printServicesResponsible']");
        public static By _Sales = By.XPath("//input[@ng-model='vm.incident.salesDirectorResponsible']");
        public static By _SoftwareEngineering = By.XPath("//input[@ng-model='vm.incident.softwareEngineeringResponsible']");
        public static By _TechnicalProjectManagement = By.XPath("//input[@ng-model='vm.incident.technicalProjectManagementResponsible']");
        public static By _Vendor = By.XPath("//input[@ng-model='vm.incident.vendorResponsible']");
        public static By _ApplicationDefect= By.XPath("//input[@ng-model='vm.incident.applicationDefectRootCause']");
        public static By _ApplicationFunctionality= By.XPath("//input[@ng-model='vm.incident.applicationFunctionalityRootCause']");
        public static By _Communication= By.XPath("//input[@ng-model='vm.incident.communicationRootCause']");
        public static By _HardwareInfrastructure= By.XPath("//input[@ng-model='vm.incident.hardwareInfrastructureRootCause']");
        public static By _ManagementSupervision= By.XPath("//input[@ng-model='vm.incident.managementSupervisionRootCause']");
        public static By _MaterialHandlingControl= By.XPath("//input[@ng-model='vm.incident.materialHandlingControlRootCause']");
        public static By _NonIssue= By.XPath("//input[@ng-model='vm.incident.nonIssueRootCause']");
        public static By _Oversight= By.XPath("//input[@ng-model='vm.incident.oversightRootCause']");
        public static By _PoliciesProcedures= By.XPath("//input[@ng-model='vm.incident.policiesProceduresRootCause']");
        public static By _ProcessNotFollowed= By.XPath("//input[@ng-model='vm.incident.processNotFollowedRootCause']");
        public static By _SkillLevel= By.XPath("//input[@ng-model='vm.incident.skillLevelRootCause']");
        public static By _ToolsEquipment= By.XPath("//input[@ng-model='vm.incident.toolsEquipmentRootCause']");
        public static By _TrainingKnowledgeTransfer= By.XPath("//input[@ng-model='vm.incident.trainingKnowledgeTransferRootCause']");
        public static By _WorkPlanning= By.XPath("//input[@ng-model='vm.incident.workPlanningRootCause']");
        public static By _ShortDescription = By.Id("rootCause");
        public static By _ClientResolution = By.Name("clientResolution");
        public static By _InternalResolution = By.Name("internalResolution");
        public static By _HardCost = By.XPath("//select[@ng-model='vm.incident.hardCostId']");
        public static By _ImpactToClient = By.Id("impactToClientId");
        public static By _Score = By.XPath("//input[@ng-model='vm.score']");
        public static By _Trend = By.XPath("//input[@ng-model='vm.incident.indicatesTrend']");
        public static By _ImpactGreater = By.XPath("//input[@ng-model='vm.incident.impactWouldBeGreaterIf']");
        public static By _Subjective = By.XPath("//input[@ng-model='vm.incident.subjectivePoint']");
        public static By _ModalSave = By.XPath("//button[@ng-click='vm.ok()']");
        public static By _ModalCancel = By.XPath("//button[contains(@ng-click, 'vm.cancel')]");
        public static By _ModalDelete = By.XPath("//button[@ng-click='vm.ok()']");      
        public static void ValidateIncidentsGrid(Incident record)
        {
            test.vars.verify(VerifyValueByColumn("Incident Number", record.IncidentNumber.ToString()));
            test.vars.verify(VerifyValueByColumn("Incident Name", record.Name.Replace("  ", " ")));
            test.vars.verify(VerifyValueByColumn("Date of Incident Report", record.IncidentDate.ToString("MM/dd/yyyy")));
            test.vars.verify(VerifyValueByColumn("Est Date of Incident", record.EstimatedIncidentDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(VerifyValueByColumn("Responsible Departments", GetReponsibleDepartments(record) ?? ""));
            test.vars.verify(VerifyValueByColumn("Actual Cost", record.ActualCost.HasValue ? "$" + record.ActualCost.Value.ToString("0.00") : ""));
            test.vars.verify(VerifyValueByColumn("Short Description", record.RootCauseDescription ?? ""));
            test.vars.verify(VerifyValueByColumn("Client Resolution", record.ClientResolution ?? ""));
            test.vars.verify(VerifyValueByColumn("Internal Resolution", record.InternalResolution ?? ""));
            test.vars.verify(VerifyValueByColumn("Owner", record.Owner ?? ""));
            test.vars.verify(VerifyValueByColumn("Lessons Learned Mtg", record.LessonsLearnedMeeting.HasValue ? test.ToYesNoString((bool)record.LessonsLearnedMeeting) : ""));
            test.vars.verify(VerifyValueByColumn("Status", record.IncidentStatusId.HasValue ? Data.GetLookupValue((int)record.IncidentStatusId).First().Name : ""));
            test.vars.verify(VerifyValueByColumn("Score", GetScore(record)));
        }
        public static void ValidateIncidentsModal(Incident record)
        {
            test.vars.verify(test.VerifyFieldValue(_Name, record.Name.Replace("  ", " ")));
            test.vars.verify(test.VerifyFieldValue(_DateOfIncident, record.IncidentDate.ToString("MM/dd/yyyy")));
            test.vars.verify(test.VerifyFieldValue(_EstDateOfIncident, record.EstimatedIncidentDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(test.VerifyFieldValue(_Owner, record.Owner ?? ""));
            test.vars.verify(test.VerifySelectedValue(_Status, Data.GetLookupValue(record.IncidentStatusId ?? 0).First()?.Name ?? ""));          
            test.vars.verify(test.VerifyFieldValue(_ActualCost, record.ActualCost.ToString()));
            test.vars.verify(test.VerifySelectedValue(_LessonsLearnedMtg, test.ToYesNoString(record.LessonsLearnedMeeting ?? false)));
            test.vars.verify(test.VerifyCheckBoxValue(_ClaimsOps, record.ClaimsOperationsResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_ClientServices, record.ClientServicesResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_ContactCenter, record.ContactCenterResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_CorporateServices, record.CorporateServicesResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_DataEntry, record.DataEntryResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_DataServices, record.DataServicesResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_Disbursements, record.DisbursementsResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_DocumentControl, record.DocumentControlResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_FileProcessing, record.FileProcessingResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_IT, record.ITResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_LegalNoticing, record.LegalNoticingResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_Mailings, record.MailingsResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_PrintOps, record.PrintOperationsResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_PrintServices, record.PrintServicesResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_Sales, record.SalesDirectorResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_SoftwareEngineering, record.SoftwareEngineeringResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_TechnicalProjectManagement, record.TechnicalProjectManagementResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_Vendor, record.VendorResponsible ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_ApplicationDefect, record.ApplicationDefectRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_ApplicationFunctionality, record.ApplicationFunctionalityRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_Communication, record.CommunicationRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_HardwareInfrastructure, record.HardwareInfrastructureRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_ManagementSupervision, record.ManagementSupervisionRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_MaterialHandlingControl, record.MaterialHandlingControlRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_NonIssue, record.NonIssueRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_Oversight, record.OversightRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_PoliciesProcedures, record.PoliciesProceduresRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_ProcessNotFollowed, record.ProcessNotFollowedRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_SkillLevel, record.SkillLevelRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_ToolsEquipment, record.ToolsEquipmentRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_TrainingKnowledgeTransfer, record.TrainingKnowledgeTransferRootCause));
            test.vars.verify(test.VerifyCheckBoxValue(_WorkPlanning, record.WorkPlanningRootCause));
            test.vars.verify(test.VerifyFieldValue(_ShortDescription, record.RootCauseDescription ?? ""));
            test.vars.verify(test.VerifyFieldValue(_ClientResolution, record.ClientResolution ?? ""));
            test.vars.verify(test.VerifyFieldValue(_InternalResolution, record.InternalResolution ?? ""));
            test.vars.verify(test.VerifySelectedValue(_HardCost, Data.GetHardCost(record.HardCostId ?? 0).First().Name));
            test.vars.verify(test.VerifySelectedValue(_ImpactToClient, Data.GetImpactToClient(record.ImpactToClientId ?? 0).First().Name));
            test.vars.verify(test.VerifyCheckBoxValue(_Trend, record.IndicatesTrend ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_ImpactGreater, record.ImpactWouldBeGreaterIf ?? false));
            test.vars.verify(test.VerifyCheckBoxValue(_Subjective, record.SubjectivePoint ?? false));

        }
        public static void ValidateIncidentsRequiredFields()
        {
            test.Click(_Edit);
            caseinfo.ValidateRequiredField("name");
            caseinfo.ValidateDateRequiredField("incidentDate");
            caseinfo.ValidateRequiredField("owner");
            caseinfo.ValidateRequiredField("rootCauseDescription");
            caseinfo.ValidateRequiredField("clientResolution");
            caseinfo.ValidateRequiredField("internalResolution");
            test.Click(_ModalCancel);
        }
        public static void ValidateIncidentsFieldValidation()
        {
            var fields = new List<caseinfo.FieldDetail>()
            {  
                new caseinfo.FieldDetail
                {
                    Label = "Name",
                    Length = 256
                },
                new caseinfo.FieldDetail
                {
                    Label = "Date of Incident Report",
                    Type = "date"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Est Date of Incident",
                    Type = "date"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Owner",
                    Length = 256
                }
            };
            ValidateIncidentsRequiredFields();
            caseinfo.ValidateFields(fields, true, _Edit);
        }
        public static void UpdateIncident(Incident record)
        {
            test.EditField(_Name, record.Name ?? "");
            //test.EditField(_DateOfIncident, record.IncidentDate.ToShortDateString());                 //DEL ORIGINAL

            test.EditField(_DateOfIncident, record.IncidentDate.ToString("MM/dd/yyyy"));                //DEL bug 287866 requires full MM/dd/yyyy format
            //test.EditField(_EstDateOfIncident, record.EstimatedIncidentDate?.ToShortDateString() ?? "");          //DEL ORIGINAL
            test.EditField(_EstDateOfIncident, record.EstimatedIncidentDate?.ToString("MM/dd/yyyy") ?? "");         //DEL bug 287866 requires full MM/dd/yyyy format

            test.EditField(_Owner, record.Owner ?? "");
            test.SelectField(_Status, Data.GetLookupValue(record.IncidentStatusId ?? 0).First()?.Name ?? "");
            test.EditField(_ActualCost, record.ActualCost.ToString());
            test.SelectField(_LessonsLearnedMtg, test.ToYesNoString(record.LessonsLearnedMeeting ?? false));
            test.SetCheckbox(_ClaimsOps, record.ClaimsOperationsResponsible ?? false);
            test.SetCheckbox(_ClientServices, record.ClientServicesResponsible ?? false);
            test.SetCheckbox(_ContactCenter, record.ContactCenterResponsible ?? false);
            test.SetCheckbox(_CorporateServices, record.CorporateServicesResponsible ?? false);
            test.SetCheckbox(_DataEntry, record.DataEntryResponsible ?? false);
            test.SetCheckbox(_DataServices, record.DataServicesResponsible ?? false);
            test.SetCheckbox(_Disbursements, record.DisbursementsResponsible ?? false);
            test.SetCheckbox(_DocumentControl, record.DocumentControlResponsible ?? false);
            test.SetCheckbox(_FileProcessing, record.FileProcessingResponsible ?? false);
            test.SetCheckbox(_IT, record.ITResponsible ?? false);
            test.SetCheckbox(_LegalNoticing, record.LegalNoticingResponsible ?? false);
            test.SetCheckbox(_Mailings, record.MailingsResponsible ?? false);
            test.SetCheckbox(_PrintOps, record.PrintOperationsResponsible ?? false);
            test.SetCheckbox(_PrintServices, record.PrintServicesResponsible ?? false);
            test.SetCheckbox(_Sales, record.SalesDirectorResponsible ?? false);
            test.SetCheckbox(_SoftwareEngineering, record.SoftwareEngineeringResponsible ?? false);
            test.SetCheckbox(_TechnicalProjectManagement, record.TechnicalProjectManagementResponsible ?? false);
            test.SetCheckbox(_Vendor, record.VendorResponsible ?? false);
            test.SetCheckbox(_ApplicationDefect, record.ApplicationDefectRootCause);
            test.SetCheckbox(_ApplicationFunctionality, record.ApplicationFunctionalityRootCause);
            test.SetCheckbox(_Communication, record.CommunicationRootCause);
            test.SetCheckbox(_HardwareInfrastructure, record.HardwareInfrastructureRootCause);
            test.SetCheckbox(_ManagementSupervision, record.ManagementSupervisionRootCause);
            test.SetCheckbox(_MaterialHandlingControl, record.MaterialHandlingControlRootCause);
            test.SetCheckbox(_NonIssue, record.NonIssueRootCause);
            test.SetCheckbox(_Oversight, record.OversightRootCause);
            test.SetCheckbox(_PoliciesProcedures, record.PoliciesProceduresRootCause);
            test.SetCheckbox(_ProcessNotFollowed, record.ProcessNotFollowedRootCause);
            test.SetCheckbox(_SkillLevel, record.SkillLevelRootCause);
            test.SetCheckbox(_ToolsEquipment, record.ToolsEquipmentRootCause);
            test.SetCheckbox(_TrainingKnowledgeTransfer, record.TrainingKnowledgeTransferRootCause);
            test.SetCheckbox(_WorkPlanning, record.WorkPlanningRootCause);
            test.EditField(_ShortDescription, record.RootCauseDescription ?? "");
            test.EditField(_ClientResolution, record.ClientResolution ?? "");
            test.EditField(_InternalResolution, record.InternalResolution ?? "");
            test.SelectFieldByIndex(_HardCost, record.HardCostId ?? 0);
            test.SelectField(_ImpactToClient, Data.GetImpactToClient(record.ImpactToClientId ?? 0).First().Name);
            test.SetCheckbox(_Trend, record.IndicatesTrend ?? false);
            test.SetCheckbox(_ImpactGreater, record.ImpactWouldBeGreaterIf ?? false);
            test.SetCheckbox(_Subjective, record.SubjectivePoint ?? false);
        }
        public static int VerifyValueByColumn(string columnname, string expectedvalue)
        {
            try
            {
                var col = test.driver.FindElement(By.XPath("//div[text()='" + columnname + "']")).GetAttribute("class");
                var attributes = col.Split(' ');
                return test.VerifyTextContains(test.driver, By.XPath("//div[contains(@class, 'ngCell')  and contains(@class, '" + attributes[2] + "')]"), expectedvalue.Replace("  ", " "));
            }
            catch (Exception e)
            {
                report.Fail("Unable to verify value by column: " + e);
                return 1;
            }
        }
        public static string GetReponsibleDepartments(Incident incident)
        {
            IList<string> strings = new List<string>();

            if (incident.ClaimsOperationsResponsible == true)
            {
                strings.Add("Claims Operations");
            }
            if (incident.ClientServicesResponsible == true)
            {
                strings.Add("Client Services");
            }
            if (incident.ContactCenterResponsible == true)
            {
                strings.Add("Contact Center");
            }
            if (incident.CorporateServicesResponsible == true)
            {
                strings.Add("Corporate Services");
            }
            if (incident.DataEntryResponsible == true)
            {
                strings.Add("Data Entry");
            }
            if (incident.DataServicesResponsible == true)
            {
                strings.Add("Data Services");
            }
            if (incident.DisbursementsResponsible == true)
            {
                strings.Add("Disbursements");
            }
            if (incident.DocumentControlResponsible == true)
            {
                strings.Add("Document Control");
            }
            if (incident.FileProcessingResponsible == true)
            {
                strings.Add("File Processing");
            }
            if (incident.ITResponsible == true)
            {
                strings.Add("IT");
            }
            if (incident.LegalNoticingResponsible == true)
            {
                strings.Add("Legal Noticing");
            }
            if (incident.MailingsResponsible == true)
            {
                strings.Add("Mailings");
            }
            if (incident.PrintOperationsResponsible == true)
            {
                strings.Add("Print Operations");
            }
            if (incident.PrintServicesResponsible == true)
            {
                strings.Add("Print Services");
            }
            if (incident.SalesDirectorResponsible == true)
            {
                strings.Add("Sales");
            }
            if (incident.SoftwareEngineeringResponsible == true)
            {
                strings.Add("Software Engineering");
            }
            if (incident.TechnicalProjectManagementResponsible == true)
            {
                strings.Add("Technical Project Management");
            }
            if (incident.VendorResponsible == true)
            {
                strings.Add("Vendor");
            }

            var result = string.Join(", ", strings);
            return result;
        }
        public static string GetScore(Incident incident)
        {
            var hardCost = incident.HardCostId == null ? 0 : Data.GetHardCost(incident.HardCostId.GetValueOrDefault()).First().Points;
            var impact = incident.ImpactToClientId == null ? 0 : Data.GetImpactToClient(incident.ImpactToClientId.GetValueOrDefault()).First().Points;
            var trend = incident.IndicatesTrend == true ? 1 : 0;
            var greater = incident.ImpactWouldBeGreaterIf == true ? 1 : 0;
            var subjective = incident.SubjectivePoint == true ? 1 : 0;
            var score = hardCost + impact + trend + greater + subjective;
            return score.ToString();
        }
        public static bool RandomBoolean()
        {
            System.Threading.Thread.Sleep(100);
            var rnd = new Random();
            return (rnd.NextDouble() > .5);
        }
        public static Incident GenerateIncidentRecord()
        {
            var rnd = new Random();
            var timestamp = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            var incidentStatus = Data.GetLookupByType("Incident Status");
            var hardCost = Data.GetHardCost();
            var impactToClient = Data.GetImpactToClient();

            var result = new Incident
            {
                Name = "Automation Incident " + timestamp,
                IncidentDate = DateTime.Now,
                EstimatedIncidentDate = DateTime.Now.AddDays(-1),
                Owner = "Joe Automatic " + timestamp,
                IncidentStatusId = incidentStatus.Skip(rnd.Next(0, incidentStatus.Count)).First().LookupId,
                ActualCost = Convert.ToDecimal(timestamp.Substring(13, 4))/100,
                LessonsLearnedMeeting = RandomBoolean(),
                ClaimsOperationsResponsible = RandomBoolean(),
                ClientServicesResponsible = RandomBoolean(),
                ContactCenterResponsible = RandomBoolean(),
                CorporateServicesResponsible = RandomBoolean(),
                DataEntryResponsible = RandomBoolean(),
                DataServicesResponsible = RandomBoolean(),
                DisbursementsResponsible = RandomBoolean(),
                DocumentControlResponsible = RandomBoolean(),
                FileProcessingResponsible = RandomBoolean(),
                ITResponsible = RandomBoolean(),
                LegalNoticingResponsible = RandomBoolean(),
                MailingsResponsible = RandomBoolean(),
                PrintOperationsResponsible = RandomBoolean(),
                PrintServicesResponsible = RandomBoolean(),
                SalesDirectorResponsible = RandomBoolean(),
                SoftwareEngineeringResponsible = RandomBoolean(),
                TechnicalProjectManagementResponsible = RandomBoolean(),
                VendorResponsible = RandomBoolean(),
                ApplicationDefectRootCause = RandomBoolean(),
                ApplicationFunctionalityRootCause = RandomBoolean(),
                CommunicationRootCause = RandomBoolean(),
                HardwareInfrastructureRootCause = RandomBoolean(),
                ManagementSupervisionRootCause = RandomBoolean(),
                MaterialHandlingControlRootCause = RandomBoolean(),
                NonIssueRootCause = RandomBoolean(),
                OversightRootCause = RandomBoolean(),
                PoliciesProceduresRootCause = RandomBoolean(),
                ProcessNotFollowedRootCause = RandomBoolean(),
                SkillLevelRootCause = RandomBoolean(),
                ToolsEquipmentRootCause = RandomBoolean(),
                TrainingKnowledgeTransferRootCause = RandomBoolean(),
                WorkPlanningRootCause = RandomBoolean(),
                RootCauseDescription = "Root Cause " + timestamp,
                ClientResolution = "Client Resolution " + timestamp,
                InternalResolution = "Internal Resolution " + timestamp,
                HardCostId = hardCost.Skip(rnd.Next(0, hardCost.Count)).First().HardCostId,
                ImpactToClientId = impactToClient.Skip(rnd.Next(0, impactToClient.Count)).First().ImpactToClientId,
                IndicatesTrend = RandomBoolean(),
                ImpactWouldBeGreaterIf = RandomBoolean(),
                SubjectivePoint = RandomBoolean()
            };
            return result;
        }
        public static void ValidateIncidentModalEditability (bool expected)
        {
            test.vars.verify(test.VerifyElementEditability(_Number, false));
            test.vars.verify(test.VerifyElementEditability(_Name, expected));
            test.vars.verify(test.VerifyElementEditability(_DateOfIncident, expected));
            test.vars.verify(test.VerifyElementEditability(_EstDateOfIncident, expected));
            test.vars.verify(test.VerifyElementEditability(_Owner, expected));
            test.vars.verify(test.VerifyElementEnabled(_Status, expected));
            test.vars.verify(test.VerifyElementEditability(_ActualCost, expected));
            test.vars.verify(test.VerifyElementEnabled(_LessonsLearnedMtg, expected));
            test.vars.verify(test.VerifyElementEnabled(_ClaimsOps, expected));
            test.vars.verify(test.VerifyElementEnabled(_ClientServices, expected));
            test.vars.verify(test.VerifyElementEnabled(_ContactCenter, expected));
            test.vars.verify(test.VerifyElementEnabled(_CorporateServices, expected));
            test.vars.verify(test.VerifyElementEnabled(_DataEntry, expected));
            test.vars.verify(test.VerifyElementEnabled(_DataServices, expected));
            test.vars.verify(test.VerifyElementEnabled(_Disbursements, expected));
            test.vars.verify(test.VerifyElementEnabled(_DocumentControl, expected));
            test.vars.verify(test.VerifyElementEnabled(_FileProcessing, expected));
            test.vars.verify(test.VerifyElementEnabled(_IT, expected));
            test.vars.verify(test.VerifyElementEnabled(_LegalNoticing, expected));
            test.vars.verify(test.VerifyElementEnabled(_Mailings, expected));
            test.vars.verify(test.VerifyElementEnabled(_PrintOps, expected));
            test.vars.verify(test.VerifyElementEnabled(_PrintServices, expected));
            test.vars.verify(test.VerifyElementEnabled(_Sales, expected));
            test.vars.verify(test.VerifyElementEnabled(_SoftwareEngineering, expected));
            test.vars.verify(test.VerifyElementEnabled(_TechnicalProjectManagement, expected));
            test.vars.verify(test.VerifyElementEnabled(_Vendor, expected));
            test.vars.verify(test.VerifyElementEnabled(_ApplicationDefect, expected));
            test.vars.verify(test.VerifyElementEnabled(_ApplicationFunctionality, expected));
            test.vars.verify(test.VerifyElementEnabled(_Communication, expected));
            test.vars.verify(test.VerifyElementEnabled(_HardwareInfrastructure, expected));
            test.vars.verify(test.VerifyElementEnabled(_ManagementSupervision, expected));
            test.vars.verify(test.VerifyElementEnabled(_MaterialHandlingControl, expected));
            test.vars.verify(test.VerifyElementEnabled(_NonIssue, expected));
            test.vars.verify(test.VerifyElementEnabled(_Oversight, expected));
            test.vars.verify(test.VerifyElementEnabled(_PoliciesProcedures, expected));
            test.vars.verify(test.VerifyElementEnabled(_ProcessNotFollowed, expected));
            test.vars.verify(test.VerifyElementEnabled(_SkillLevel, expected));
            test.vars.verify(test.VerifyElementEnabled(_ToolsEquipment, expected));
            test.vars.verify(test.VerifyElementEnabled(_TrainingKnowledgeTransfer, expected));
            test.vars.verify(test.VerifyElementEnabled(_WorkPlanning, expected));
            test.vars.verify(test.VerifyElementEditability(_ShortDescription, expected));
            test.vars.verify(test.VerifyElementEditability(_ClientResolution, expected));
            test.vars.verify(test.VerifyElementEditability(_InternalResolution, expected));
            test.vars.verify(test.VerifyElementEnabled(_HardCost, expected));
            test.vars.verify(test.VerifyElementEnabled(_ImpactToClient, expected));
            test.vars.verify(test.VerifyElementEditability(_Score, false));
            test.vars.verify(test.VerifyElementEnabled(_Trend, expected));
            test.vars.verify(test.VerifyElementEnabled(_ImpactGreater, expected));
            test.vars.verify(test.VerifyElementEnabled(_Subjective, expected));
        }
    }
}
