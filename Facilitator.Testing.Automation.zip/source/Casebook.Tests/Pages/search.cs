﻿using System;
using Automation;
using Casebook.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;

namespace Casebook
{
    public class search : Facilitator.Template.search
    {
        public static By _StandardOperatorCaseType = By.XPath("//label[contains(., 'Case Type')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterCaseType = By.XPath("//label[contains(., 'Case Type')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorBusinessLine = By.XPath("//label[contains(., 'Business Line')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterBusinessLine = By.XPath("//label[contains(., 'Business Line')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorClassSize = By.XPath("//label[contains(., 'Class Size')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterClassSize = By.Name("cs");
        public static By _StandardOperatorCourtCaption = By.XPath("//label[contains(., 'Court Caption')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterCourtCaption = By.Name("cc");
        public new static By _StandardOperatorStatus = By.XPath("//label[contains(., 'Status')]//following-sibling::div[1]//div//select");
        public new static By _StandardFilterStatus = By.XPath("//label[contains(., 'Status')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorSettlement = By.XPath("//label[contains(., 'Settlement Amount Benefits')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterSettlement = By.Name("sab");
        public static By _StandardOperatorEstimated = By.XPath("//label[contains(., 'Estimated # of Claims')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterEstimated = By.Name("ec");
        public static By _StandardOperatorSAP = By.XPath("//label[contains(., 'SAP Contract Code')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterSAP = By.Name("sbc");
        public static By _StandardOperatorSignedAgreementPricing = By.XPath("//label[contains(., 'Signed Agreement Pricing')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterSignedAgreementPricing = By.XPath("//label[contains(., 'Signed Agreement Pricing')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorFLSA = By.XPath("//label[contains(., 'FLSA')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterFLSA = By.XPath("//label[contains(., 'FLSA')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorHIPAA = By.XPath("//label[contains(., 'HIPAA')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterHIPAA = By.XPath("//label[contains(., 'HIPAA')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorFISMA = By.XPath("//label[contains(., 'FISMA')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterFISMA = By.XPath("//label[contains(., 'FISMA')]//following-sibling::div[1]//div[2]//select");
        //public static By _StandardOperatorCappedCase = By.XPath("//label[contains(., 'Capped Case')]//following-sibling::div[1]//div//select");       //DEL removed story 276773
        //public static By _StandardFilterCappedCase = By.XPath("//label[contains(., 'Capped Case')]//following-sibling::div[1]//div[2]//select");       //DEL removed story 276773
        //public static By _StandardOperatorSpecialSLAs = By.XPath("//label[contains(., 'Special SLA')]//following-sibling::div[1]//div//select");       //DEL removed story 276773
        //public static By _StandardFilterSpecialSLAs = By.XPath("//label[contains(., 'Special SLA')]//following-sibling::div[1]//div[2]//select");      //DEL removed story 276773
        public static By _StandardOperatorCaseName = By.XPath("//label[contains(., 'Case Name')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterCaseName = By.Name("cn");
        public static By _StandardOperatorCaseNumber = By.XPath("//label[contains(., 'Case Number')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterCaseNumber = By.Name("cnum");
        public static By _StandardOperatorUrl = By.XPath("//label[contains(., 'Case URL')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterUrl = By.Name("cu");
        public static By _StandardOperatorBilling = By.XPath("//label[contains(., 'Billing Code')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterBilling = By.Name("nc");
        public static By _StandardOperatorCaseFolder = By.XPath("//label[contains(., 'Case Folder')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterCaseFolder = By.Name("cf");
        public static By _StandardOperatorContactName = By.XPath("//label[contains(., 'Contact Name')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterContactName = By.Name("cnt");
        public static By _StandardOperatorProjectRole = By.XPath("//label[contains(., 'Contact Project Role')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterProjectRole = By.XPath("//label[contains(., 'Contact Project Role')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorInitialNoticeMailing = By.XPath("//label[contains(., 'Initial Notice Mailing')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterInitialNoticeMailing = By.Name("insd");
        public static By _StandardOperatorOptOutDeadline = By.XPath("//label[contains(., 'Opt')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterOptOutDeadline = By.Name("oodd");
        public static By _StandardOperatorInitialDistribution = By.XPath("//label[contains(., 'Initial Distribution')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterInitialDistribution = By.Name("dd");
        public static By _StandardOperatorClaimsDeadline = By.XPath("//label[contains(., 'Claims Deadline')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterClaimsDeadline = By.Name("cdd");
        public static By _StandardOperatorPreliminaryApprovalGranted = By.XPath("//label[contains(., 'Preliminary Approval Granted')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterPreliminaryApprovalGranted = By.Name("pcd");
        public static By _StandardOperatorObjectionDeadline = By.XPath("//label[contains(., 'Objection Deadline')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterObjectionDeadline = By.Name("od");
        public static By _StandardOperatorFinalApprovalHearing = By.XPath("//label[contains(., 'Final Approval Hearing')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterFinalApprovalHearing = By.Name("fah");
        public static By _StandardOperatorOrganizationName = By.XPath("//label[contains(., 'Organization Name')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterOrganizationName = By.Name("co");
        public static By _StandardOperatorTaxVendor = By.XPath("//label[contains(., 'Tax Vendor')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterTaxVendor = By.XPath("//label[contains(., 'Tax Vendor')]//following-sibling::div[1]//div[2]//select");
        public static By _StandardOperatorTaxReporting = By.XPath("//label[contains(., 'Tax Reporting')]//following-sibling::div[1]//div//select");
        public static By _StandardFilterTaxReporting = By.XPath("//label[contains(., 'Tax Reporting')]//following-sibling::div[1]//div[2]//select");
        public new static By _QuickPageCriteria = By.XPath("//input[@ng-model='criteria']");
        public new static By _QuickPageSubmit= By.XPath("//button[@ng-click='searchClick()']");

        public static By _AlertMessage = By.XPath("//div[contains(@class,'alert')]");

        public static void SelectResultByIndex(int index)
        {
            if (test.driver.Url.Contains("/casesummary") == false)
            {
                try
                {
                    report.Step("Select result row " + index + ".");
                    test.driver.FindElement(By.XPath("(//div[@class='ngCellText ng-scope col1 colt1'])[" + index + "]"))
                        .Click();
                    test.WaitForPageToLoad(test.driver);
                }
                catch (Exception e)
                {
                    report.Fail("Unable to select result row " + index + ".", e);
                    
                }
            }
        }
        public new static int VerifySearchResultByField(IWebDriver driver, string fieldname, string columnname, string expectedvalue)
        {
            try
            {
                if (driver.Url.Contains("/casesummary"))
                {
                    caseinfo.WaitForPageLoad();
                    Assert.IsTrue(test.VerifyFieldValueById(driver, fieldname, expectedvalue) == 0);
                    return 0;
                }
                else
                {
                    Facilitator.Template.grid.SortByColumn(driver, columnname);
                    return Facilitator.Template.grid.VerifyValueByColumn(driver, columnname, expectedvalue);
                }
            }
            catch (Exception e)
            {
                report.Fail("Search Result not loaded: " + e);
                return 1;
            }
        }
        public new static int VerifySearchResultEval(IWebDriver driver, string fieldname, string columnname, string operand, string expectedvalue)
        {
            try
            {
                if (driver.Url.Contains("/casesummary"))
                {
                    caseinfo.WaitForPageLoad();
                    return test.VerifyFieldByOperator(driver, By.Name(fieldname), operand, expectedvalue);
                }
                else
                {
                    return VerifyResultSetByColumn(driver, columnname, operand, expectedvalue);
                }
            }
            catch (Exception e)
            {
                report.Fail("Search Result not loaded: " + e);
                return 1;
            }
        }
        public static void NewQuickSearch()
        {
            if (!test.driver.Url.Contains("/quicksearch"))
            {
                test.Click(navigate._Search);
                test.Click(navigate._QuickSearch);
            }
            else
            {
                if (test.driver.FindElement(By.XPath("//span[text()='Filter Criteria & Available Columns']/../following-sibling::div")).GetAttribute("class").Contains("collapse in") == false)
                {
                    test.ToggleSection("Filter Criteria & Available Columns");
                }
            }
        }
        public static void NewStandardSearch()
        {
            if (test.driver.Url.Contains("/standardsearch"))
            {
                if (test.driver.FindElement(By.XPath("//span[text()='Filter Criteria & Available Columns']/../following-sibling::div")).GetAttribute("class").Contains("collapse in") == false)
                {
                    test.ToggleSection("Filter Criteria & Available Columns");
                }
                test.Click(_Reset);
            }
            else
            {
                test.Click(navigate._Search);
                test.Click(navigate._StandardSearch);
            }
        }
        public static void ValidateQuickSearch(string fieldName, string displayName, string value, bool selectColumn)
        {
            ValidateQuickSearch(fieldName, displayName, value, selectColumn, false);
        }
        public static void ValidateQuickSearch(string fieldName, string displayName, string value, bool selectColumn, bool selectResult)
        {
            report.Step("Verify Quick Search by " + displayName);
            NewQuickSearch();
            if (selectColumn)
            {
                SelectColumn(test.driver, displayName);
            }
            test.EditField(_QuickPageCriteria, "\"" + value + "\"");
            test.Click(_QuickPageSubmit);
            test.vars.verify(test.VerifyNoErrorToasts());
            if (selectResult)
            {
                if (test.driver.Url.Contains("/casesummary") == false)
                {
                    SelectResultByIndex(1);
                    test.vars.verify(test.VerifyNoErrorToasts());
                }
            }
            test.vars.verify(VerifySearchResultByField(test.driver, fieldName, displayName, value));

        }
        public static void ValidateStandardSearchInput(string fieldName, string displayName, By standardOperator, By standardFilter, string operand, string value, bool selectColumn)
        {
            ValidateStandardSearchInput(fieldName, displayName, standardOperator, standardFilter, operand, value, selectColumn, false, false);
        }
        public static void ValidateStandardSearchInput(string fieldName, string displayName, By standardOperator, By standardFilter, string operand, string value, bool selectColumn, bool selectResult, bool expectNoMatch)
        {
            try
            {
                report.Step("Verify Standard Search by " + displayName);
                NewStandardSearch();
                System.Threading.Thread.Sleep(5000); //DEL works in debug, fails in run mode - add sleep
                if (selectColumn)
                {
                    SelectColumn(test.driver, displayName);
                }
                StandardSearch(test.driver, standardOperator, standardFilter, operand, value);
                test.vars.verify(test.VerifyNoErrorToasts());
                if (expectNoMatch)
                {
                    test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There were no matches for the selected search criteria."));
                }
                else
                {
                    if (selectResult)
                    {
                        SelectResultByIndex(1);
                    }

                    test.vars.verify(VerifySearchResultByField(test.driver, fieldName, displayName, value));
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Standard Search failed due to: " + e.Message);
                
            }
        }
        public static void ValidateStandardSearchList(string fieldName, string displayName, By standardOperator, By standardFilter, string operand, string value, bool selectColumn)
        {
            ValidateStandardSearchList(fieldName, displayName, standardOperator, standardFilter, operand, value, selectColumn, false, false);
        }
        public static void ValidateStandardSearchList(string fieldName, string displayName, By standardOperator, By standardFilter, string operand, string value, bool selectColumn, bool selectResult, bool expectNoMatch)
                                {
            try
            {
                report.Step("Verify Standard Search by " + displayName);
                NewStandardSearch();
                if (selectColumn)
                {
                    SelectColumn(test.driver, displayName);
                }
                StandardSearchList(test.driver, standardOperator, standardFilter, operand, value);
                test.vars.verify(test.VerifyNoErrorToasts());
                if (expectNoMatch)
                {
                    test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There were no matches for the selected search criteria."));
                }
                else
                {
                    if (selectResult)
                    {
                        SelectResultByIndex(1);
                    }

                    test.vars.verify(VerifySearchResultByField(test.driver, fieldName, displayName, value));
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Standard Search failed due to: " + e.Message);
                
            }
        }
        public static void ValidateStandardSearchBool(string fieldName, By standardOperator, By standardFilter, string operand, string value, bool expectnomatch)
        {
            try
            {
                var expected = "";
                NewStandardSearch();

                switch (operand)
                {
                    case "=":
                        expected = value;
                        break;
                    case "Does not equal":
                        switch (value)
                        {
                            case "True":
                                expected = "False";
                                break;
                            case "False":
                                expected = "True";
                                break;
                            default:
                                Assert.Fail("Value is not valid: " + value);
                                break;
                        }
                        break;
                    case "Is null":
                        expected = "False";
                        break;
                }
                StandardSearchList(test.driver, standardOperator, standardFilter, operand, value);
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));
                if (expectnomatch)
                {
                    test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There were no matches for the selected search criteria."));
                }
                else
                {
                    SelectResultByIndex(1);
                    caseinfo.WaitForPageLoad();
                    test.vars.verify(caseinfo.VerifyCheckBoxValue(fieldName, expected));
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Standard Search failed due to: " + e.Message);
                
            }
        }
        public static void ValidateStandardSearchInputEval(string fieldName, string displayName, By standardOperator, By standardFilter, string operand, string value, bool selectColumn, bool selectResult, bool expectNoMatch)
        {
            try
            {
                NewStandardSearch();
                if (selectColumn)
                {
                    SelectColumn(test.driver, displayName);
                }
                StandardSearch(test.driver, standardOperator, standardFilter, operand, value);
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));
                if (expectNoMatch)
                {
                    test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There were no matches for the selected search criteria."));
                }
                else
                {
                    if (selectResult && test.driver.Url.Contains("standardsearch"))     //DEL ORIGINAL
                    {
                        SelectResultByIndex(1);
                    }
                    if (selectResult && selectColumn && test.driver.Url.Contains("standardsearch"))     //DEL  don't display if not selectColumn
                    {                                                                                                   //DEL
                        test.vars.verify(VerifySearchResultEval(test.driver, fieldName, displayName, operand, value));  //DEL
                    }                                                                                                   //DEL

                    //test.vars.verify(VerifySearchResultEval(test.driver, fieldName, displayName, operand, value)); //DEL ORIGINAL
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Standard Search failed due to: " + e.Message);
                
            }

        }
        public static void ValidateStandardSearchListEval(string fieldName, string displayName, By standardOperator, By standardFilter, string operand, string value, bool selectColumn, bool selectResult, bool expectNoMatch)
        {
            try
            {
                NewStandardSearch();
                if (selectColumn)
                {
                    SelectColumn(test.driver, displayName);
                }
                StandardSearchList(test.driver, standardOperator, standardFilter, operand, value);
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));
                if (expectNoMatch)
                {
                    test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There were no matches for the selected search criteria."));
                }
                else
                {
                    if (selectResult)
                    {
                        SelectResultByIndex(1);
                    }
                    test.vars.verify(VerifySearchResultEval(test.driver, fieldName, displayName, operand, value));
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Standard Search failed due to: " + e.Message);
                
            }

        }
        public static void ValidateStandardSearchDateEval(By field, By standardOperator, By standardFilter, string operand, string value, bool expectNoMatch)
        {
            try
            {
                NewStandardSearch();
                StandardSearch(test.driver, standardOperator, standardFilter, operand, value);
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));
                if (expectNoMatch)
                {
                    test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There were no matches for the selected search criteria."));
                }
                else
                {
                    SelectResultByIndex(1);
                    test.vars.verify(test.VerifyDateFieldByOperator(test.driver, field, operand, value));
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Standard Search failed due to: " + e.Message);
                
            }
        }
        public static void ValidateStandardSearchAllTextOperators(string fieldName, string displayName, By standardOperator, By standardFilter, string value, bool selectColumn, bool selectResult, bool allowsNull)
        {
            report.Step("Verify Standard Search by " + displayName);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Equals", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Includes", value.Substring(1, 3).TrimEnd(), selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Begins with", value.Substring(0, 3).TrimEnd(), selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Does not equal", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Is null", "", selectColumn, selectResult, !allowsNull);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Is not null", "", selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Is empty", "", selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Is not empty", "", selectColumn, selectResult, false);
        }
        public static void ValidateStandardSearchAllNumberOperators(string fieldName, string displayName, By standardOperator, By standardFilter, string value, bool selectColumn, bool selectResult, bool allowsNull)
        {
            report.Step("Verify Standard Search by " + displayName);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "=", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, ">", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "<", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "<>", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, ">=", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "<=", value, selectColumn, selectResult, false);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Is null", "", selectColumn, selectResult, !allowsNull);
            ValidateStandardSearchInputEval(fieldName, displayName, standardOperator, standardFilter, "Is not null", "", selectColumn, selectResult, false);

        }
        public static void ValidateStandardSearchAllListOperators(string fieldName, string displayName, By standardOperator, By standardFilter, string value, bool selectColumn, bool selectResult, bool allowsNull)
        {
            report.Step("Verify Standard Search by " + displayName);
            ValidateStandardSearchListEval(fieldName, displayName, standardOperator, standardFilter, "Equals", value, selectColumn, selectResult, false);
            ValidateStandardSearchListEval(fieldName, displayName, standardOperator, standardFilter, "Does not equal", value, selectColumn, selectResult, false);
            ValidateStandardSearchListEval(fieldName, displayName, standardOperator, standardFilter, "Is null", "", selectColumn, selectResult, !allowsNull);
            ValidateStandardSearchListEval(fieldName, displayName, standardOperator, standardFilter, "Is not null", "", selectColumn, selectResult, false);
            ValidateStandardSearchListEval(fieldName, displayName, standardOperator, standardFilter, "Is empty", "", selectColumn, selectResult, true);
         ValidateStandardSearchListEval(fieldName, displayName, standardOperator, standardFilter, "Is not empty", "", selectColumn, selectResult, false);
        }
        public static void ValidateStandardSearchAllDateOperators(By field, By standardOperator, By standardFilter, string value, bool allowsNull)
        {
            report.Step("Verify Standard Search by " + field);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, "=", value, false);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, ">", value, false);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, "<", value, false);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, "<>", value, false);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, ">=", value, false);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, "<=", value, false);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, "Is null", "", !allowsNull);
            ValidateStandardSearchDateEval(field, standardOperator, standardFilter, "Is not null", "", false);
        }
        public static void ValidateStandardSearchAllBoolOperators(string fieldName, By standardOperator, By standardFilter, string value)
        {
            report.Step("Verify Standard Search by " + fieldName);
            ValidateStandardSearchBool(fieldName, standardOperator, standardFilter, "=", value, false);
            ValidateStandardSearchBool(fieldName, standardOperator, standardFilter, "Does not equal", value, false);
            ValidateStandardSearchBool(fieldName, standardOperator, standardFilter, "Is null", "", true);
            NewStandardSearch();
            var count = Data.GetCaseData().Count.ToString();
            StandardSearchList(test.driver, standardOperator, standardFilter, "Is not null", "");
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyText(test.driver, By.XPath("//span[@ng-show='actualServerItems > totalServerItems']"), "- This search returned " + count + " rows. You will only have access to the first 100 rows sorted by Case Name."));
        }    
        public static void ValidateStandardSearchContactName(string operand, string firstName, string lastName)
        {
            report.Step("Verify Standard Search by " + "Contact name " + firstName + " " + lastName);
            NewStandardSearch();
            StandardSearch(test.driver, _StandardOperatorContactName, _StandardFilterContactName, operand, firstName);
            test.vars.verify(test.VerifyNoErrorToasts());
            SelectResultByIndex(1);
            caseinfo.WaitForPageLoad();
            test.Click(caseinfo._ContactsTab);
            grid.WaitForGridData();
            if (operand == "Is null" | operand == "Is empty")
            {
                test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There are no contacts that match the currently entered filter."));
            }
            else
            {
                test.EditField(caseinfo._ContactsTextFilter, firstName);
                test.vars.verify(operand == "Does not equal"
                    ? test.VerifyText(test.driver, _AlertMessage,
                        "There are no contacts that match the currently entered filter.")
                    : Facilitator.Template.grid.VerifyValueByColumnEval("First Name", operand, firstName));

                NewStandardSearch();
                StandardSearch(test.driver, _StandardOperatorContactName, _StandardFilterContactName, operand, lastName);
                test.vars.verify(test.VerifyNoErrorToasts());
                SelectResultByIndex(1);
                caseinfo.WaitForPageLoad();
                test.Click(caseinfo._ContactsTab);
                grid.WaitForGridData();
                test.EditField(caseinfo._ContactsTextFilter, lastName);
                test.vars.verify(operand == "Does not equal"
                    ? test.VerifyText(test.driver, _AlertMessage,
                        "There are no contacts that match the currently entered filter.")
                    : Facilitator.Template.grid.VerifyValueByColumnEval("Last Name", operand, lastName));
                if (operand == "Equals" | operand == "Does not equal")
                {
                    NewStandardSearch();
                    StandardSearch(test.driver, _StandardOperatorContactName, _StandardFilterContactName, operand, firstName + " " + lastName);
                    test.vars.verify(test.VerifyNoErrorToasts());
                    SelectResultByIndex(1);
                    test.Click(caseinfo._ContactsTab);
                    grid.WaitForGridData();
                    test.EditField(caseinfo._ContactsTextFilter, lastName);
                    if (operand == "Does not equal")
                    {
                        test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There are no contacts that match the currently entered filter."));
                    }
                    else
                    {
                        test.Click(By.XPath(caseinfo._Contacts + "//div[text()='First Name']"));
                        test.vars.verify(Facilitator.Template.grid.VerifyValueByColumnEval("First Name", operand, firstName));
                        test.vars.verify(Facilitator.Template.grid.VerifyValueByColumnEval("Last Name", operand, lastName));
                    }
                }
            }
         }
        public static void ValidateStandardSearchAllContactName(Contact record)
        {
            report.Step("Verify Standard Search by " + "allcontactname");
            ValidateStandardSearchContactName("Equals", record.FirstName, record.LastName);
            ValidateStandardSearchContactName("Includes", record.FirstName.Substring(1, 3).TrimEnd(), record.LastName.Substring(1, 3).TrimEnd());
            ValidateStandardSearchContactName("Begins with", record.FirstName.Substring(0, 3).TrimEnd(), record.LastName.Substring(0, 3).TrimEnd());
            ValidateStandardSearchContactName("Does not equal", record.FirstName, record.LastName);
            ValidateStandardSearchContactName("Is null", "", "");
            ValidateStandardSearchContactName("Is not null", "", "");
            ValidateStandardSearchContactName("Is empty", "", "");
            ValidateStandardSearchContactName("Is not empty", "", "");
        }
        public static void ValidateStandardSearchOrganizationName(string operand, string orgName)
        {
            report.Step("Verify Standard Search by " + "organization name " + orgName);
            NewStandardSearch();
            SelectColumn(test.driver, "Organization Name");
            StandardSearch(test.driver, _StandardOperatorOrganizationName, _StandardFilterOrganizationName, operand, orgName);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(VerifyResultSetByColumn(test.driver, "Organization Name", operand, orgName));
        }
        public static void ValidateStandardSearchAllOrganizationName(string value)
        {
            report.Step("Verify Standard Search by " + "organization name " + value);
            ValidateStandardSearchOrganizationName("Includes", value);
            ValidateStandardSearchOrganizationName("Does not include", value);
            ValidateStandardSearchOrganizationName("Is null", "");
            ValidateStandardSearchOrganizationName("Is not null", "");
            ValidateStandardSearchOrganizationName("Is empty", "");
            ValidateStandardSearchOrganizationName("Is not empty", "");
        }
        public static void ValidateStandardSearchProjectRole(string operand, string role)
        {
            report.Step("Verify Standard Search by " + "project role " + role);
            NewStandardSearch();
            StandardSearchList(test.driver, _StandardOperatorProjectRole, _StandardFilterProjectRole, operand, role);
            test.vars.verify(test.VerifyNoErrorToasts());
            SelectResultByIndex(1);
            caseinfo.WaitForPageLoad();
            test.Click(caseinfo._ContactsTab);
            grid.WaitForGridData();
            if (operand == "Is null" | operand == "Is empty")
            {
                test.vars.verify(test.VerifyText(test.driver, _AlertMessage, "There are no contacts that match the currently entered filter."));
            }
            else
            {
                Facilitator.Template.grid.SortByColumn("Project Role");
                Facilitator.Template.grid.VerifyValueByColumnEval("Project Role", operand, role);
            }
        }
        public static void ValidateStandardSearchAllProjectRole(string role)
        {
            report.Step("Verify Standard Search by " + "all project role " + role);
            ValidateStandardSearchProjectRole("Equals", role);
            ValidateStandardSearchProjectRole("Does not equal", role);
            ValidateStandardSearchProjectRole("Is null", "");
            ValidateStandardSearchProjectRole("Is not null", "");
            ValidateStandardSearchProjectRole("Is empty", "");
            ValidateStandardSearchProjectRole("Is not empty", "");
        }

    }
}
