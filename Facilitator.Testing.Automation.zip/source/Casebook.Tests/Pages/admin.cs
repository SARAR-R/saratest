﻿using System;
using System.Collections.Generic;
using System.Linq;
using Automation;
using Casebook.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;

namespace Casebook
{
    public class admin 
    {
        public static By _Add = By.XPath("//button[contains(@ng-click, 'vm.add')]");
        public static By _Export = By.XPath("//button[@ng-click='vm.excelExport()']");
        public static By _TextFilter = By.XPath("//input[@ng-model='vm.filterOptions.filterText']");
        public static By _Edit = By.XPath("//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-pencil')]");
        public static By _View = By.XPath("//a[contains(@ng-click , 'vm.edit')]/i[contains(@class, 'fa-list')]");
        public static By _Delete = By.XPath("//a[contains(@ng-click , 'vm.delete')]");
        public static By _ModalSave = By.XPath("//div[@class='modal-footer']//button[contains(@ng-click, 'vm.ok')]");
        public static By _ModalCancel = By.XPath("//div[@class='modal-footer']//button[contains(@ng-click,'vm.cancel')]");
        public static By _TotalItems = By.XPath("//div[@class='ngTotalSelectContainer']//span");
        //Org
        public static By _OrganizationName = By.XPath("//input[@ng-model='vm.organization.organizationName']");
        public static By _WebAddress = By.XPath("//input[@ng-model='vm.organization.webAddress']");
        public static By _StrategicClient = By.XPath("//input[@ng-model='vm.organization.strategicClient']");
        //Contact
        public static By _AddOrg = By.XPath("//button[@ng-click = 'vm.addOrganization()']");
        public static By _EditOrg = By.XPath("//contact-organization//a[contains(@ng-click , 'vm.edit')]");
        public static By _SaveOrg = By.XPath("//contact-organization//button[contains(@ng-click , 'vm.addOrganizationToGrid') and not(contains(@class, 'ng-hide'))]");
        public static By _DeleteOrg = By.XPath("//contact-organization//a[contains(@ng-click , 'vm.delete')]");
        public static By _ContactOrganizationName = By.XPath("//div[@ng-model='vm.newOrganization.organizationId']");
        public static By _ContactOrganizationNameInput = By.XPath("//div[@ng-model='vm.newOrganization.organizationId']//input");
        public static By _LinkToContact = By.XPath("//button[@ng-click = 'vm.addOrganizationToGrid()']");
        public static By _Alert = By.XPath("//div[contains(@class,'alert')]");
        
        public static int VerifyHrefByColumn(string columnname, string expectedvalue)
        {
            try
            {
                var col = test.driver.FindElement(By.XPath("//div[text()='" + columnname + "']")).GetAttribute("class");
                var attributes = col.Split(' ');
                var cell = By.XPath("//div[contains(@class, 'ngCell')  and contains(@class, '" + attributes[2] + "')]//a");
                Assert.IsTrue(test.driver.FindElement(cell).Text.Contains(expectedvalue));
                report.Pass("Element (" + cell + ") contains " + expectedvalue);
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Result not loaded: " + e);
                return 1;
            }
        }
        public static int VerifyValueByColumn(string columnname, string expectedvalue)
        {
            try
            {
                var col = test.driver.FindElement(By.XPath("//div[text()='" + columnname + "']")).GetAttribute("class");
                var attributes = col.Split(' ');
                Assert.IsTrue(test.VerifyTextContains(test.driver, By.XPath("//div[contains(@class, '" + attributes[2] + "')]//div[contains(@class, 'ngCell')]"), expectedvalue) == 0);
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Result not loaded: " + e);
                return 1;
            }
        }
        public static int VerifyValueNotByColumn(string columnname, string expectedvalue)
        {
            try
            {
                var col = test.driver.FindElement(By.XPath("//div[text()='" + columnname + "']")).GetAttribute("class");
                var attributes = col.Split(' ');
                return test.VerifyTextDoesNotEqual(test.driver, By.XPath("//div[contains(@class, '" + attributes[2] + "')]//div[contains(@class, 'ngCell')]"), expectedvalue);
            }
            catch (Exception e)
            {
                report.Fail("Result not loaded: " + e);
                return 1;
            }
        }
        public static void ValidateOrgGrid(Organization record)
        {
            test.vars.verify(VerifyValueByColumn("Name", record.OrganizationName));
            test.vars.verify(VerifyHrefByColumn("Web Address", record.WebAddress));
            test.vars.verify(VerifyValueByColumn("Strategic Client", test.ToYesNoString(record.StrategicClient)));
        }
        public static void ValidateOrganizationRequiredFields()
        {
            test.Click(_Edit);
            caseinfo.ValidateRequiredField("organizationName");
            test.Click(_ModalCancel);
        }
        public static void ValidateOrganizationFieldValidation()
        {
            var name = Data.GetOrganizations().OrderByDescending(s => s.OrganizationName.Length).First().OrganizationName;
            if (name.Length != 50)
            {
                name = caseinfo.GenerateString(50);
                test.Click(_Edit);
                test.EditField(By.Name("lastName"), name);
                test.Click(_ModalSave);
            }
            test.EditField(_TextFilter, name);
            var url = "http://www." + caseinfo.GenerateString(135) + ".com";

            var fields = new List<caseinfo.FieldDetail>
            {
                new caseinfo.FieldDetail
                {
                    Label = "Organization Name",
                    Length = 100,
                    ValidText = name,
                    InvalidText = caseinfo.GenerateString(51)
                },
                new caseinfo.FieldDetail
                {
                    Label = "Web Address",
                    ValidText = url
                },
                new caseinfo.FieldDetail
                {
                    Label = "Web Address",
                    ValidText = url,
                    InvalidText = caseinfo.GenerateString(150),
                    ValidationType = "$error.pattern"
                }
            };
            ValidateOrganizationRequiredFields();
            caseinfo.ValidateFields(fields, true, _Edit);
        }
        public static void ValidateContactGrid(Contact record)
        {
            test.vars.verify(VerifyValueByColumn("Last Name", record.LastName));
            test.vars.verify(VerifyValueByColumn("First Name", record.FirstName));
            test.vars.verify(VerifyValueByColumn("Email", record.Email));
        }
        public static Contact GenerateContactRecord()
        {
            return GenerateContactRecord(null);
        }
        public static Contact GenerateContactRecord(int? contactId)
        {
            var append = DateTime.Now.ToString("fff");
            if (contactId == null)
            {
                var result = new Contact
                {
                    FirstName = "First" + append,
                    MiddleInitial = "M",
                    LastName = "AAALast" + append,
                    ContactTypeId = new Random().Next(1, Data.GetContactType().Count),
                    KeyContact = caseinfo.RandomBoolean(),
                    Phone1 = "+1 333 444 5" + append,
                    Phone2 = "+1 444 555 6" + append,
                    Phone3 = "+1 555 666 7" + append,
                    Email = "email" + append + "@mail.com",
                    Address1 = "address1_" + append,
                    Address2 = "address2_" + append,
                    City = "city" + append,
                    State = "CA",
                    Zipcode = "99" + append,
                    Country = "USA"

                };
                return result;
            }
            else
            {
                var result = new Contact
                {
                    ContactId = (int)contactId,
                    FirstName = "First" + append,
                    MiddleInitial = "M",
                    LastName = "AAALast" + append,
                    ContactTypeId = new Random().Next(1, Data.GetContactType().Count),
                    KeyContact = caseinfo.RandomBoolean(),
                    Phone1 = "+1 333 444 5" + append,
                    Phone2 = "+1 444 555 6" + append,
                    Phone3 = "+1 555 666 7" + append,
                    Email = "email" + append + "@mail.com",
                    Address1 = "address1_" + append,
                    Address2 = "address2_" + append,
                    City = "city" + append,
                    State = "CA",
                    Zipcode = "99" + append,
                    Country = "USA"

                };
                return result;
            }      
        }
        public static void UpdateContactRecord(Contact record)
        {
            test.EditField(By.Name("firstName"), record.FirstName ?? "");
            test.EditField(By.Name("middleInitial"), record.MiddleInitial ?? "");
            test.EditField(By.Name("lastName"), record.LastName ?? "");
            test.SelectFieldByIndex(By.Name("contactTypeId"), record.ContactTypeId);
            test.SetCheckbox(By.Name("keyContact"), record.KeyContact);
            test.EditField(By.Name("phone1"), record.Phone1);
            test.EditField(By.Name("phone2"), record.Phone2);
            test.EditField(By.Name("phone3"), record.Phone3);
            test.EditField(By.Name("emailAddress"), record.Email);
            test.EditField(By.Name("address1"), record.Address1);
            test.EditField(By.Name("address2"), record.Address2);
            test.EditField(By.Name("city"), record.City);
            test.SelectFieldByValue(By.Name("state"), "string:" + record.State);
            test.EditField(By.Name("zipcode"), record.Zipcode);
            test.SelectFieldByValue(By.Name("country"), "string:" + record.Country);
        }
        public static void ValidateContactAndOrgRecords(Contact contactRecord, Organization orgRecord)
        {
            ValidateContactRecord(contactRecord);
            ValidateContactOrgRecord(contactRecord, orgRecord);
        }   
        public static void ValidateContactRecord(Contact record)
        {
            test.vars.verify(test.VerifyFieldValueByName("firstName", record.FirstName ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("middleInitial", record.MiddleInitial ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("lastName", record.LastName ?? ""));
            test.vars.verify(test.VerifySelectedValue(By.Name("contactTypeId"), Data.GetContactType(record.ContactTypeId).First().Name));
            test.vars.verify(caseinfo.VerifyCheckBoxValue("keyContact", record.KeyContact.ToString()));
            test.vars.verify(test.VerifyFieldValueByName("phone1", record.Phone1 ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("phone2", record.Phone2 ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("phone3", record.Phone3 ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("emailAddress", record.Email ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("address1", record.Address1 ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("address2", record.Address2 ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("city", record.City ?? ""));
            test.vars.verify(test.VerifySelectedOptionByValue(By.Name("state"), record.State ?? ""));
            test.vars.verify(test.VerifyFieldValueByName("zipcode", record.Zipcode ?? ""));
            test.vars.verify(test.VerifySelectedOptionByValue(By.Name("country"), record.Country ?? ""));
        }
        public static void ValidateContactRequiredFields()
        {
            test.Click(_Edit);
            caseinfo.ValidateRequiredField("firstName");
            caseinfo.ValidateRequiredField("lastName");
            caseinfo.ValidateRequiredField("contactTypeId");
            caseinfo.ValidateRequiredField("emailAddress");
            test.Click(_ModalCancel);
        }
        public static void ValidateContactFieldValidation()
        {
            var name = Data.GetContactData().OrderByDescending(s => s.LastName.Length).First().LastName;
            if (name.Length != 25)
            {
                name = caseinfo.GenerateString(25);
                test.Click(_Edit);
                test.EditField(By.Name("lastName"), name);
                test.Click(_ModalSave);
            }

            test.EditField(_TextFilter, name);
            var phone1 = "+2" + caseinfo.GenerateNumberString(13);
            var phone2 = "+2" + caseinfo.GenerateNumberString(13);
            var phone3 = "+2" + caseinfo.GenerateNumberString(13);
            var email = caseinfo.GenerateString(54) + "@epiqsystems.com";

            var fields = new List<caseinfo.FieldDetail>()
            {
                new caseinfo.FieldDetail
                {
                    Label = "First Name",
                    Length = 25
                },
                new caseinfo.FieldDetail
                {
                    Label = "Middle Initial",
                    Length =  1
                },
                new caseinfo.FieldDetail
                {
                    Label = "Last Name",
                    Length =  25, 
                    ValidText = name,
                    InvalidText = caseinfo.GenerateString(26)
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 1",
                    Length = 15,
                    ValidText = phone1
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 1",
                    Length = 4,
                    InvalidText = "+2" + caseinfo.GenerateNumberString(2),
                    ValidText = phone1,
                    ValidationType = "$error.minlength"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 1",
                    Length = 15,
                    InvalidText = caseinfo.GenerateString(15),
                    ValidText = phone1,
                    ValidationType = "$error.phoneFormat"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 2",
                    Length = 15,
                    ValidText = phone2
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 2",
                    Length = 4,
                    InvalidText = "+2" + caseinfo.GenerateNumberString(2),
                    ValidText = phone2,
                    ValidationType = "$error.minlength"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 2",
                    Length = 15,
                    InvalidText = caseinfo.GenerateString(15),
                    ValidText = phone2,
                    ValidationType = "$error.phoneFormat"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 3",
                    Length = 15,
                    ValidText = phone3
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 3",
                    Length = 4,
                    InvalidText = "+2" + caseinfo.GenerateNumberString(2),
                    ValidText = phone3,
                    ValidationType = "$error.minlength"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Phone 3",
                    Length = 15,
                    InvalidText = caseinfo.GenerateString(15),
                    ValidText = phone3,
                    ValidationType = "$error.phoneFormat"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Email Address",
                    Length = 70,
                    ValidText = email
                },
                new caseinfo.FieldDetail
                {
                    Label = "Email Address",
                    Length = 70,
                    InvalidText = caseinfo.GenerateString(70),
                    ValidText = email,
                    ValidationType = "$error.pattern"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Email Address",
                    Length = 70,
                    InvalidText = Data.GetContactData().First(e => e.Email != null).Email,
                    ValidText = email,
                    ValidationType = "showEmailInUseMsg"
                },
                new caseinfo.FieldDetail
                {
                    Label = "Address 1",
                    Length =  70
                },
                new caseinfo.FieldDetail
                {
                    Label = "Address 2",
                    Length =  70
                },
                new caseinfo.FieldDetail
                {
                    Label = "City",
                    Length =  35
                },
                new caseinfo.FieldDetail
                {
                    Label = "Postal Code",
                    Length =  9
                },
            };
            ValidateContactRequiredFields();
            caseinfo.ValidateFields(fields, true, _Edit);
        }
        public static void AddContactOrgRecord(Organization record)
        {
            test.Click(_ContactOrganizationName);
            test.EditField (_ContactOrganizationNameInput, record.OrganizationName);
            test.EditField(By.Name("startDate"), DateTime.Now.AddDays(-60).ToString("MM/dd/yyyy"));
            test.EditField(By.Name("endDate"), DateTime.Now.AddDays(60).ToString("MM/dd/yyyy"));
        }
        public static void UpdateContactOrgRecord()
        {
            test.EditField(By.Name("startDate"), DateTime.Now.AddDays(-30).ToString("MM/dd/yyyy"));
            test.EditField(By.Name("endDate"), DateTime.Now.AddDays(30).ToString("MM/dd/yyyy"));
        }
        public static void ValidateContactOrgRecord(Contact contactRecord, Organization orgRecord)
        {
            var contactToOrganization = Data.GetContactToOrganization().First(c => c.ContactId == contactRecord.ContactId && c.OrganizationId == orgRecord.OrganizationId);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn("//contact-organization", "Organization Name", orgRecord.OrganizationName ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn("//contact-organization", "Web Address", orgRecord.WebAddress ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn("//contact-organization", "Start Date", contactToOrganization.StartDate?.ToString("MM/dd/yyyy") ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn("//contact-organization", "End Date", contactToOrganization.EndDate?.ToString("MM/dd/yyyy") ?? ""));
        }
    }
}
