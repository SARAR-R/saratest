﻿using System;
using System.Configuration;
using Automation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Casebook
{
    public class reports
    {
        public static void ValidateReport(string reportname, string url)
        {
            var by = By.XPath("//a[text()='" + reportname + "']");
            report.Action("Click", by.ToString());
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));

            try
            {
                wait.Until(d => d.FindElement(by).Enabled);
                wait.Until(ExpectedConditions.ElementToBeClickable(by));
                test.WaitForPageToLoad(test.driver);
                test.ScrollTo(test.driver, by); //Chrome requires element onscreen to click
                test.dismissToasts(test.driver);
                test.driver.FindElement(by).Click();
            }
            catch (Exception e)
            {
                report.Fail("Unable to click element " + by, e);
                Assert.Fail(e.ToString());
            }
            
            try
            {
                var alert = new WebDriverWait(test.driver, TimeSpan.FromSeconds(5));
                if (alert.Until(ExpectedConditions.AlertIsPresent()) != null) 
                {
                    test.driver.SwitchTo().Alert().Dismiss();
                }
            }
            catch (WebDriverTimeoutException)
            {
                //Do nothing if not present
            }
            test.vars.verify(test.VerifyURL(test.driver, url));
            test.driver.Navigate().Back();
        }
    }
}
