﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using Casebook.Database;

namespace Casebook
{
    public class Data
    {
        public static List<CaseDetail> GetCaseDataByNumber(int caseNumber)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseDetails
                    where c.CaseNumber == caseNumber
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseDetail> GetCaseDataById(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseDetails
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseDetail> GetCaseData()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseDetails
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseType> GetCaseType()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseTypes
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseType> GetCaseType(int caseTypeId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseTypes
                    where c.CaseTypeId == caseTypeId
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseStatu> GetCaseStatus()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseStatus
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseStatu> GetCaseStatus(int caseStatusId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseStatus
                    where c.CaseStatusId == caseStatusId
                    select c;

                return query.ToList();
            }
        }

        public static List<Contact> GetContactData()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Contacts
                    select c;

                return query.ToList();
            }
        }

        public static List<Contact> GetContactDataByCase(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Contacts
                    join cdc in context.CaseDetailContacts on c.ContactId equals cdc.ContactId
                    join cd in context.CaseDetails on cdc.CaseDetailId equals cd.CaseDetailId
                    where cd.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<Contact> GetContactDataUnassociated(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Contacts
                    where !(from d in context.CaseDetailContacts
                            where d.CaseDetailId == caseDetailId
                            select d.ContactId).Contains(c.ContactId)
                            &&
                            !(from e in context.Contacts
                              join f in context.CaseDetailContacts on e.ContactId equals f.ContactId
                              where f.CaseDetailId == caseDetailId
                              select e.LastName).Contains(c.LastName)
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseDetailContact> GetCaseDetailContact()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseDetailContacts
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseDetailContact> GetCaseDetailContact(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseDetailContacts
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseDetailContact> GetCaseDetailContact(int contactId, int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseDetailContacts
                    where c.ContactId == contactId && c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<Organization> GetOrganizations()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from b in context.Organizations
                    select b;

                return query.ToList();
            }
        }

        public static List<ContactToOrganization> GetContactToOrganization()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from ctb in context.ContactToOrganizations
                    select ctb;

                return query.ToList();
            }
        }

        public static List<Organization> GetOrganizationByContact(int contactId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from b in context.Organizations
                    join cb in context.ContactToOrganizations on b.OrganizationId equals cb.OrganizationId
                    where cb.ContactId == contactId
                    select b;

                return query.ToList();
            }
        }

        public static List<Lookup> GetLookupValue(int lookupId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Lookups
                    where c.LookupId == lookupId
                    select c;

                return query.ToList();
            }
        }

        public static List<Lookup> GetLookupByType(string type)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Lookups
                    where c.LookupType == type
                    select c;

                return query.ToList();
            }
        }

        public static List<BusinessLine> GetBusinessLine()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.BusinessLines
                    select c;
                return query.ToList();
            }
        }

        public static List<BusinessLine> GetBusinessLine(int businessLineId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.BusinessLines
                    where c.BusinessLineId == businessLineId
                    select c;
                return query.ToList();
            }
        }

        public static List<Milestone> GetMilestone (int caseDetailId, string name)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Milestones
                    where c.CaseDetailId == caseDetailId
                    && c.Name == name
                    select c;

                return query.ToList();
            }
        }

        public static List<Milestone> GetMilestone(string name)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Milestones
                    where c.Name == name
                    select c;

                return query.ToList();
            }
        }

        public static List<Milestone> GetMilestones(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Milestones
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<Milestone> GetMilestones()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Milestones
                    select c;

                return query.ToList();
            }
        }

        public static List<ShutdownAndRetention> GetShutdownAndRetention()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ShutdownAndRetentions
                    select c;

                return query.ToList();
            }
        }

        public static List<ShutdownAndRetention> GetShutdownAndRetention(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ShutdownAndRetentions
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<ShutdownAndRetentionOption> GetShutdownAndRetentionOption()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ShutdownAndRetentionOptions
                    select c;

                return query.ToList();
            }
        }

        public static List<ShutdownAndRetentionOption> GetShutdownAndRetentionOption(int shutdownAndRetentionOptionId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ShutdownAndRetentionOptions
                    where c.ShutdownAndRetentionOptionId == shutdownAndRetentionOptionId
                    select c;

                return query.ToList();
            }
        }

        public static List<ShutdownAndRetentionOption> GetShutdownAndRetentionOption(string type)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ShutdownAndRetentionOptions
                    where c.Type == type
                    select c;

                return query.ToList();
            }
        }

        public static List<ClaimOption> GetClaimOption()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ClaimOptions
                    select c;

                return query.ToList();
            }
        }

        public static List<Claim> GetClaim()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Claims
                    select c;

                return query.ToList();
            }
        }

        public static List<Claim> GetClaim(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Claims
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<ContactCenter> GetContactCenter()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ContactCenters
                    select c;

                return query.ToList();
            }
        }

        public static List<ContactCenterOption> GetContactCenterOption() //DEL
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ContactCenterOptions
                    select c;

                return query.ToList();
            }
        }
        public static List<ContactCenter> GetContactCenter(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ContactCenters
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseKickoffDetail> GetCaseKickoffDetail()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseKickoffDetails
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseKickoffDetail> GetCaseKickoffDetail(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseKickoffDetails
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseKickoffDetailsOption> GetCaseKickoffDetailOption()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseKickoffDetailsOptions
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseKickoffDetailsOption> GetCaseKickoffDetailOption(int caseKickoffDetailsOptionId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseKickoffDetailsOptions
                    where c.CaseKickoffDetailsOptionId == caseKickoffDetailsOptionId
                    select c;

                return query.ToList();
            }
        }

        public static List<CaseKickoffDetailsOption> GetCaseKickoffDetailOption(string type)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.CaseKickoffDetailsOptions
                    where c.Type == type
                    select c;

                return query.ToList();
            }
        }

        public static List<Disbursement> GetDisbursement()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Disbursements
                    select c;

                return query.ToList();
            }
        }

        public static List<Disbursement> GetDisbursement(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Disbursements
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<DisbursementsOption> GetDisbursementsOption()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.DisbursementsOptions
                    select c;

                return query.ToList();
            }
        }

        public static List<DocumentProcessing> GetDocumentProcessing()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.DocumentProcessings
                    select c;

                return query.ToList();
            }
        }

        public static List<DocumentProcessing> GetDocumentProcessing(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.DocumentProcessings
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<DocumentProcessingOption> GetDocumentProcessingOption()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.DocumentProcessingOptions
                    select c;

                return query.ToList();
            }
        }

        public static List<HumanResource> GetHr()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.HumanResources
                    select c;

                return query.ToList();
            }
        }

        public static List<HumanResource> GetHr(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.HumanResources
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<IncomingDocument> GetIncomingDocument()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.IncomingDocuments
                    select c;

                return query.ToList();
            }
        }

        public static List<IncomingDocument> GetIncomingDocument(int documentProcessingId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.IncomingDocuments
                    where c.DocumentProcessingId == documentProcessingId
                    select c;

                return query.ToList();
            }
        }

        public static List<IncomingDocumentOption> GetIncomingDocumentOptions()   // this returns all possible options from database
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.IncomingDocumentOptions
                    select c;

                return query.ToList();
            }
        }

        public static List<Mailing> GetMailing()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Mailings
                    select c;

                return query.ToList();
            }
        }

        public static List<Mailing> GetMailing(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Mailings
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }


        //public static List<MailingDetail> GetMailingDetail(int caseDetailId, int MailingId) //DEL modified        EXPERIMENT
        //{
        //    using (var context = new Database.Casebook())
        //    {
        //        var query =
        //            from c in context.MailingDetails
        //            select c;

        //        return query.ToList();
        //    }
        //}



        public static List<MailingDetail> GetMailingDetail(int caseDetailId, int MailingId) //DEL modified
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.MailingDetails
                    where c.MailingId == MailingId
                    select c;

                return query.ToList();
            }
        }






        //public static List<MailingDetail> GetMailingDetail() //DEL ORIGINAL UNUSED
        //{
        //    using (var context = new Database.Casebook())
        //    {
        //        var query =
        //            from c in context.MailingDetails
        //            select c;

        //        return query.ToList();
        //    }
        //}

        public static List<MailingDetail> GetMailingDetail(int mailingId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.MailingDetails
                    where c.MailingId == mailingId
                    select c;

                return query.ToList();
            }
        }





        public static List<MailingOption> GetMailingOption()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.MailingOptions
                    select c;

                return query.ToList();
            }
        }


        public static List<ContactType> GetContactType()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ContactTypes
                    select c;

                return query.ToList();
            }
        }

        public static List<ContactType> GetContactType(int contactTypeId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ContactTypes
                    where c.ContactTypeId == contactTypeId
                    select c;

                return query.ToList();
            }
        }

        public static List<ProjectRole> GetProjectRole()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from pr in context.ProjectRoles
                    select pr;

                return query.ToList();
            }
        }

        public static List<ProjectRole> GetProjectRoleByContact(int caseDetailId, int contactId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from pr in context.ProjectRoles
                    join cdc in context.CaseDetailContacts on pr.ProjectRoleId equals cdc.ProjectRoleId
                    where cdc.ContactId == contactId
                    && cdc.CaseDetailId == caseDetailId
                    select pr;

                return query.ToList();
            }
        }

        public static List<Contact> GetProjectTeamByCase(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Contacts
                    join cdc in context.CaseDetailContacts on c.ContactId equals cdc.ContactId
                    join pr in context.ProjectRoles on cdc.ProjectRoleId equals pr.ProjectRoleId
                    where cdc.CaseDetailId == caseDetailId
                    && pr.Internal
                    select c;

                return query.ToList();
            }
        }

        public static List<Incident> GetIncidents()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Incidents
                    select c;

                return query.ToList();
            }
        }

        public static List<Document> GetDocument(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.Documents
                    where c.CaseDetailId == caseDetailId
                    select c;

                return query.ToList();
            }
        }

        public static List<HardCost> GetHardCost()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.HardCosts
                    select c;

                return query.ToList();
            }
        }

        public static List<HardCost> GetHardCost(int hardCostId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.HardCosts
                    where c.HardCostId == hardCostId
                    select c;

                return query.ToList();
            }
        }

        public static List<ImpactToClient> GetImpactToClient()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ImpactToClients
                    select c;

                return query.ToList();
            }
        }

        public static List<ImpactToClient> GetImpactToClient(int impactToClientId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.ImpactToClients
                    where c.ImpactToClientId == impactToClientId
                    select c;

                return query.ToList();
            }
        }

        public static List<Report> GetReports()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                                   from c in context.Reports
                                   select c;

                return query.ToList();
            }
        }

        public static List<StatusUpdate> GetStatusUpdate(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                                   from c in context.StatusUpdates
                                   where c.CaseDetailId == caseDetailId
                                   select c;

                return query.ToList();
            }
        }

        public static List<Invoice> GetInvoice(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                                   from c in context.Invoices
                                   where c.CaseDetailId == caseDetailId
                                   select c;

                return query.ToList();
            }
        }

        public static List<Document> GetDocuments(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                                   from c in context.Documents
                                   where c.CaseDetailId == caseDetailId
                                   select c;
                return query.ToList();
            }
        }

        public static List<DocumentType> GetDocumentType()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                                   from c in context.DocumentTypes
                                   select c;
                return query.ToList();
            }
        }

        public class GetReportData_EVAEstimates_Result
        {
            public string EstimateLineItem { get; set; }
            public string AllocatedHours { get; set; }
        
        }

        public static List<GetReportData_EVAEstimates_Result> ExecuteGetReportData_EVAEstimates_Result(int sapContractCode)
        {
            using (var context = new Database.Casebook())
            {
                var sapContract = new SqlParameter("@SAPContractCode", sapContractCode);
                return (context.Database.SqlQuery<GetReportData_EVAEstimates_Result>("rpt.GetReportData_EVAEstimates @SAPContractCode", sapContract)).ToList();
            }
        }

        public class GetReportData_WAR_Result
        {
            public string ReportCategory { get; set; }
            public string MetricName { get; set; }
            public string CumulativeCount { get; set; }
        }

        public static List<GetReportData_WAR_Result> ExecuteGetReportData_WAR_Result(int sapContractCode)
        {
            using (var context = new Database.Casebook())
            {
                var sapContract = new SqlParameter("@SAPContract", sapContractCode);
                return (context.Database.SqlQuery<GetReportData_WAR_Result>("rpt.GetReportData_WAR @SAPContract", sapContract)).ToList();
            }
        }

        public class AllDates
        {
            public int CaseDetailId { get; set; }
            public string InitialNoticeMailing { get; set; }
            public string OptOutDeadline { get; set; }
            public string InitialDistribution { get; set; }
            public string ClaimsDeadline { get; set; }
            public string PreliminaryApprovalGranted { get; set; }
            public string ObjectionDeadline { get; set; }
            public string FinalApprovalHearing { get; set; }
        }

        public static AllDates GetAllDates(int caseDetailId)
        {
            var result = new AllDates
            {
                CaseDetailId = caseDetailId,
                InitialNoticeMailing = GetMilestone(caseDetailId, "Initial Notice Mailing").First().DueDate?.ToString("MM/dd/yyyy") ?? "",
                OptOutDeadline = GetMilestone(caseDetailId, "Opt Out Deadline").First().DueDate?.ToString("MM/dd/yyyy") ?? "",
                InitialDistribution = GetMilestone(caseDetailId, "Initial Distribution").First().DueDate?.ToString("MM/dd/yyyy") ?? "",
                ClaimsDeadline  = GetMilestone(caseDetailId, "Claims Deadline").First().DueDate?.ToString("MM/dd/yyyy") ?? "",
                PreliminaryApprovalGranted = GetMilestone(caseDetailId, "Preliminary Approval Granted").First().DueDate?.ToString("MM/dd/yyyy") ?? "",
                ObjectionDeadline = GetMilestone(caseDetailId, "Objection Deadline").First().DueDate?.ToString("MM/dd/yyyy") ?? "",
                FinalApprovalHearing = GetMilestone(caseDetailId, "Final Approval Hearing").First().DueDate?.ToString("MM/dd/yyyy") ?? ""
            };
            return result;    
        }

        public static List<RiskMatrix> GetRiskMatrix()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.RiskMatrices
                    select c;
                return query.ToList();
            }
        }

        public static List<RiskMatrix> GetRiskMatrix(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.RiskMatrices
                    where c.CaseDetailId == caseDetailId
                    select c;
                return query.ToList();
            }
        }

        public static List<RiskMatrixOption> GetRiskMatrixOption()
        {
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.RiskMatrixOptions
                    select c;
                return query.ToList();
            }
        }

        public static string GetRiskMatrixOptionName(int? riskMatrixOptionId)
        {
            if (riskMatrixOptionId == null) return "";
            using (var context = new Database.Casebook())
            {
                var query =
                    from c in context.RiskMatrixOptions
                    where c.RiskMatrixOptionId == riskMatrixOptionId
                    select c;
                return query.FirstOrDefault()?.Name;
            }
        }

        public static void PopulateQuickSearchFields(int caseDetailId)
        {
            RandomizeMockData();
            var caseDetail = GetCaseDataById(caseDetailId);
 
            using (var context = new Database.Casebook())
            {
                var caseData = context.CaseDetails.Single(c => c.CaseDetailId == caseDetailId);

                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.CaseName))
                {
                    caseData.CaseName = "Automation Case";
                }
                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.Url))
                {
                    caseData.Url = "http://www.automation.com/TestCase";
                }
                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.BillingCode))
                {
                    caseData.BillingCode = "CA1234";
                }
                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.CaseFolder))
                {
                    caseData.CaseFolder = @"C:\AutomationCase";
                }
                if (!context.ChangeTracker.HasChanges()) return;
                caseData.UpdatedBy = "automation";
                context.SaveChanges();
            }
        }

        public static void PopulateStandardSearchFields(int caseDetailId)
        {
            PopulateQuickSearchFields(caseDetailId);
            GenerateNullCase();
            //GenerateEmptyCase();    //DEL removed for debugging
            PopulateMilestones(caseDetailId);

            var caseDetail = GetCaseDataById(caseDetailId);
            var rnd = new Random();

            using (var context = new Database.Casebook())
            {
                var caseData = context.CaseDetails.Single(c => c.CaseDetailId == caseDetailId);

                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.CaseName) | caseDetail.FirstOrDefault()?.CaseName.Length < 5)
                {
                    caseData.CaseName = "Automation Test Case";
                }
                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.CourtCaption) | caseDetail.FirstOrDefault()?.CourtCaption.Length < 5)
                {
                    caseData.CourtCaption = "Plaintiff v Defendant Test Case";
                }
                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.SettlementAmountBenefit) | caseDetail.FirstOrDefault()?.CourtCaption.Length < 5)
                {
                    caseData.SettlementAmountBenefit = "Settlement Amount Benefit";
                }
                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.Url) | caseDetail.FirstOrDefault()?.CourtCaption.Length < 5)
                {
                    caseData.Url = "http://www.caseurl.com/";
                }
                if (string.IsNullOrEmpty(caseDetail.FirstOrDefault()?.CaseFolder) | caseDetail.FirstOrDefault()?.CourtCaption.Length < 5)
                {
                    caseData.CaseFolder = @"C:\CaseFolder\";
                }
                if (caseDetail.FirstOrDefault()?.ClassSize == null)
                {
                    caseData.ClassSize = rnd.Next(1, 999999);
                }
                if (caseDetail.FirstOrDefault()?.EstimatedNumberOfClaims == null)
                {
                    caseData.EstimatedNumberOfClaims = rnd.Next(1, 99999);
                }
                if (caseData == null) return;
                caseData.UpdatedBy = "automation";
                context.Entry(caseData).Property(x => x.UpdatedBy).IsModified = true; //Force update of username due to triggers
                try
                {
                    context.SaveChanges();
                }
                catch (DbEntityValidationException ex)
                {
                    // Retrieve the error messages as a list of strings.
                    var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                    // Join the list to a single string.
                    var fullErrorMessage = string.Join("; ", errorMessages);

                    // Combine the original exception message with the new one.
                    var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                    // Throw a new DbEntityValidationException with the improved exception message.
                    throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                }
            }
        }

        public static void GenerateNullCase()
        {
            var caseDetail = GetCaseData().Where(n => n.CaseName == "Null Test Case");

            if (!caseDetail.Any())
            {
                using (var context = new Database.Casebook())
                {
                    var record = new CaseDetail
                    {
                        CaseTypeId = 3,
                        CaseStatusId  = 3,
                        BusinessLineId = 3,
                        CaseName = "Null Test Case",
                        CourtCaption = "null?", //DEL
                        SettlementAmountBenefit = null,
                        Url = "http://null", //DEL
                        SapContractCode = 0,
                        CaseNumber = null,
                        BillingCode = "CA9000",
                        CaseDescription = "null?", //DEL
                        AllowMultipleEmails = false,
                        //SignedAgreementPricing = false,       //DEL removed story 276773
                        FLSA = false,
                        HIPAA = false,
                        FISMA = false,
                        SpecialReporting = false,
                        //CappedCase = false,                    //DEL removed story 276773
                        //SpecialSLAs = false,                   //DEL removed story 276773
                        StrategicCase = false,
                        SendInterestLetter = false,
                        LiveOperator = false,
                        ImportantMessage = "null?", //DEL
                        CaseFolder = null,
                        ClassSize = null,
                        EstimatedNumberOfClaims = null,
                        InsertedDate = DateTime.Now,
                        UpdatedBy = "automation",
                        UpdatedDate = DateTime.Now,
                    };
                    context.CaseDetails.Add(record);
                    context.SaveChanges();
                }
            }
        }

        public static void GenerateEmptyCase()
        {
            var caseDetail = GetCaseData().Where(n => n.CaseName == "");

            if (!caseDetail.Any())
            {
                using (var context = new Database.Casebook())
                {
                    var record = new CaseDetail
                    {
                        CaseTypeId = 2,
                        CaseStatusId = 2,
                        BusinessLineId = 2,
                        CaseName = " ",  //DEL data validation error, can't be empty
                        CourtCaption = " ", //DEL data validation error, can't be empty
                        SettlementAmountBenefit = "",
                        Url = "httpe://a.com",  //DEL data validation error, can't be empty
                        SapContractCode = 0,
                        CaseNumber = null,
                        BillingCode = "",
                        CaseDescription = " ",  //DEL data validation error, can't be empty
                        AllowMultipleEmails = true,
                        //SignedAgreementPricing = true,             //DEL removed story 276773
                        FLSA = true,
                        HIPAA = true,
                        FISMA = true,
                        SpecialReporting = true,
                        //CappedCase = true,                             //DEL removed story 276773
                        //SpecialSLAs = true,                            //DEL removed story 276773
                        StrategicCase = true,
                        SendInterestLetter = true,
                        LiveOperator = true,
                        ImportantMessage = "",
                        CaseFolder = "",
                        ClassSize = 0,
                        EstimatedNumberOfClaims = 0,
                        InsertedDate = DateTime.Now,
                        UpdatedBy = "automation",
                        UpdatedDate = DateTime.Now,
                    };
                    context.CaseDetails.Add(record);
                    SaveChanges(context);
                }
            }
        }

        public static void PopulateIncomingDocuments(int caseDetailId)
        {

            var documentProcessing = GetDocumentProcessing(caseDetailId);
            if (documentProcessing.Count == 0)
            {
                using (var context = new Database.Casebook())
                {
                    var docProcessing = new DocumentProcessing
                    {
                        CaseDetailId = caseDetailId,
                        DeTypeOptionsId = 4,
                        DcSlaOptionsId = 9,
                        DeSlaOptionsId = 14,
                        IntakeTypeOptionsId = 17,
                        UndeliverableCheckOptionsId = 19,
                        Remails = true,
                        Undeliverables = true,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.DocumentProcessings.Add(docProcessing);
                    context.SaveChanges();
                }
                documentProcessing = GetDocumentProcessing(caseDetailId);
            }
            var documentProcessingId = documentProcessing.First().DocumentProcessingId;
            var incomingDocuments = GetIncomingDocument(documentProcessingId);
            var options = GetIncomingDocumentOptions();

            using (var context = new Database.Casebook())
            {
                if (incomingDocuments.Count(i => i.IncomingDocumentTypeOptionsId == options.First(n => n.Name == "Claim Form").IncomingDocumentOptionId) == 0)
                {
                    var doc = new IncomingDocument
                    {
                        DocumentProcessingId = documentProcessingId,
                        IncomingDocumentTypeOptionsId = options.First(n => n.Name == "Claim Form").IncomingDocumentOptionId,
                        ProcessingTypeOptionsId = options.First(n => n.Name == "Data Entry Required").IncomingDocumentOptionId,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.IncomingDocuments.Add(doc);
                }
                if (incomingDocuments.Count(i => i.IncomingDocumentTypeOptionsId == options.First(n => n.Name == "Correspondence").IncomingDocumentOptionId) == 0)  //DEL remove space
                {
                    var doc = new IncomingDocument
                    {
                        DocumentProcessingId = documentProcessingId,
                        IncomingDocumentTypeOptionsId = options.First(n => n.Name == "Correspondence").IncomingDocumentOptionId,  //DEL remove space
                        ProcessingTypeOptionsId = options.First(n => n.Name == "DE Received Process").IncomingDocumentOptionId,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.IncomingDocuments.Add(doc);
                }
                if (incomingDocuments.Count(i => i.IncomingDocumentTypeOptionsId == options.First(n => n.Name == "Notice").IncomingDocumentOptionId) == 0)
                {
                    var doc = new IncomingDocument
                    {
                        DocumentProcessingId = documentProcessingId,
                        IncomingDocumentTypeOptionsId = options.First(n => n.Name == "Notice").IncomingDocumentOptionId,
                        ProcessingTypeOptionsId = options.First(n => n.Name == "Scan Only").IncomingDocumentOptionId,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.IncomingDocuments.Add(doc);
                }

                if (context.IncomingDocuments != null)
                {
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateMailingDetail(int caseDetailId)
        {
            var mailing = GetMailing(caseDetailId);
            var mailingId = mailing.First().MailingId;
            var mailingDetail = GetMailingDetail(mailingId);
            var mailingOptions = GetMailingOption();
            var mailingFulfillmentFrequencyOptions = GetMailingAssigned("MailingFulfillmentFrequency", "Monthly");
            using (var context = new Database.Casebook())
            {
                if (mailingDetail.Count(n => n.MailingFulfillmentFrequencyOptionsId == 3) == 0) //DEL gotta fix this monthly

                 //if (mailingDetail.Count(n => n.MailingFulfillmentFrequency == "Monthly") == 0)  //DEL ORIGINAL
              //  if (mailingDetail.Count (m => m.mailingDetail.MailingFulfillmentFrequencyOptionsId.Where (n => n.Name == "Monthly"))0

                //if (mailingDetail.Count(m => m.Mailing == mailingOptions.Where(n => n.Name == "Monthly")) == 0) //DEL 

//            select count(name) from MailingDetailOption where MailingDetailOptionId in 
//            (select[MailingFulfillmentFrequencyOptionsId] from mailingdetail where mailingid = 5) and name = 'Monthly'
                 {
                    var mail = new MailingDetail
                    {
                        MailingId = mailingId,
                        Description = "Monthly Automated Entry",
                        DropDate = DateTime.Now,
                        MailingPopulation = 100,
                        PackageContent = "Monthly Package Contact", //DEL correct spelling
                        MailingFulfillmentFrequencyOptionsId = 3, //DEL gotta fix this monthly
                        DynamicImageCount = false, //DEL
                        Outsourced = true, //DEL
                        BrmPermittingRequired = true,
                        Foreign = false, //DEL
                        EstimatedPostageRate = "Monthly Rate",
                     
                         AssignedPostageRateOptionsId = 11 , //DEL gotta fix this full rate
                        // AssignedPostageRate = "Full Rate",  //DEL ORIGINAL
                        DropSchedule = "Monthly Schedule",
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.MailingDetails.Add(mail);
                }
                //if (mailingDetail.Count(n => n.MailingFulfillmentFrequency == "Weekly") == 0) //DEL ORIGINAL
                if (mailingDetail.Count(n => n.MailingFulfillmentFrequencyOptionsId == 5) == 0) //DEL gotta fix this weekly
                {
                    var mail = new MailingDetail
                    {
                        MailingId = mailingId,
                        Description = "Weekly Automated Entry",
                        DropDate = DateTime.Now,
                        MailingPopulation = 1000,
                        PackageContent = "Weekly Package Contact",
                        MailingFulfillmentFrequencyOptionsId = 5, //DEL gotta fix this weekly
                        DynamicImageCount = true, //DEL
                        Outsourced = false, //DEL
                        BrmPermittingRequired = true,
                        Foreign = false, //DEL
                        EstimatedPostageRate = "Weekly Rate",
                        AssignedPostageRateOptionsId = 12, //DEL gotta fix this other
                        //AssignedPostageRate = "Other", //DEL ORIGINAL
                        DropSchedule = "Weekly Schedule",
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.MailingDetails.Add(mail);
                }
                //if (mailingDetail.Count(n => n.MailingFulfillmentFrequency == "Other") == 0)//DEL ORIGINAL
                if (mailingDetail.Count(n => n.MailingFulfillmentFrequencyOptionsId == 4) == 0) //DEL gotta fix this other
                {
                    MailingDetail mail = new MailingDetail
                    {
                        MailingId = mailingId,
                        Description = "Other Automation Entry",
                        DropDate = DateTime.Now,
                        MailingPopulation = 10,
                        PackageContent = "Other Package Contact",
                        MailingFulfillmentFrequencyOptionsId = 4, //DEL gotta fix this other
                        DynamicImageCount = true, //DEL
                        Outsourced = false,   //DEL
                        BrmPermittingRequired = false,
                        Foreign = true,    //DEL
                        EstimatedPostageRate = "Other Rate",
                        AssignedPostageRateOptionsId = 6, //DEL gotta fix this 5 digit
                        DropSchedule = "Other Schedule",
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.MailingDetails.Add(mail);
                }

                if (context.MailingDetails != null)
                {
                    context.SaveChanges();
                }
            }
        }

        private static int? GetMailingAssigned(string t, string v) //DEL
        {
            using (var context = new Database.Casebook())
            {

                var query =
                    from c in context.MailingDetailOptions
                    where c.Type == t  && c.Name == v  //DEL
                    select c.MailingDetailOptionId;


                return query.FirstOrDefault();
            }
        }

       

        public static void GenerateNewContact()
        {
            var append = GetContactData().Max(i => i.ContactId) + 1;
            using (var context = new Database.Casebook())
            {
                var record = new Contact
                {
                    ContactTypeId = 1,
                    FirstName = "Random",
                    LastName = "Contact" + append,
                    Email = "RandomContact" + append + "@mail.com",
                    KeyContact = false,
                    InsertedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    UpdatedBy = "automation",
                };
                context.Contacts.Add(record);
                context.SaveChanges();
            }
        }

        public static void PopulateContact()
        {
            using (var context = new Database.Casebook())
            {
                var contact = GetContactData();

                if (contact.Count(t => t.ContactTypeId == 4) == 0)
                {
                    Contact update = new Contact
                    {
                        ContactTypeId = 4,
                        FirstName = "Automation",
                        LastName = "AssociateProjectManager",
                        Email = "AssociateProjectManager@mail.com",
                        KeyContact = false,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation",
                    };
                    context.Contacts.Add(update);
                }
                if (contact.Count(t => t.ContactTypeId == 15) == 0)
                {
                    Contact update = new Contact
                    {
                        ContactTypeId = 15,
                        FirstName = "Automation",
                        LastName = "ProjectCoordinator",
                        Email = "ProjectCoordinator@mail.com",
                        KeyContact = false,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation",
                    };
                    context.Contacts.Add(update);
                }
                if (contact.Count(t => t.ContactTypeId == 16) == 0)
                {
                    Contact update = new Contact
                    {
                        ContactTypeId = 16,
                        FirstName = "Automation",
                        LastName = "ProjectDirector",
                        Email = "ProjectDirector@mail.com",
                        KeyContact = false,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation",
                    };
                    context.Contacts.Add(update);
                }
                if (contact.Count(t => t.ContactTypeId == 17) == 0)
                {
                    Contact update = new Contact
                    {
                        ContactTypeId = 17,
                        FirstName = "Automation",
                        LastName = "ProjectManager",
                        Email = "ProjectManager@mail.com",
                        KeyContact = false,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation",
                    };
                    context.Contacts.Add(update);
                }
                if (contact.Count(t => t.ContactTypeId == 18) == 0)
                {
                    Contact update = new Contact
                    {
                        ContactTypeId = 18,
                        FirstName = "Automation",
                        LastName = "SalesDirector",
                        Email = "SalesDirector@mail.com",
                        KeyContact = false,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation",
                    };
                    context.Contacts.Add(update);
                }
                if (contact.Count(t => t.ContactTypeId == 20) == 0)
                {
                    Contact update = new Contact
                    {
                        ContactTypeId = 20,
                        FirstName = "Automation",
                        LastName = "TechnicalProjectManager",
                        Email = "TechnicalProjectManager@mail.com",
                        KeyContact = false,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation",
                    };
                    context.Contacts.Add(update);
                }
                if (context.Contacts != null)
                {
                    context.SaveChanges();
                }
            }

        }

        public static void PopulateProjectTeam(int caseDetailId)
        {
            PopulateContact();
            using (var context = new Database.Casebook())
            {
                var caseDetailContact = GetCaseDetailContact(caseDetailId);

                if (caseDetailContact.Count(n => n.ProjectRoleId == 4) == 0)
                {
                    var update = new CaseDetailContact
                    {
                        CaseDetailId = caseDetailId,
                        ContactId = GetContactDataUnassociated(caseDetailId).First(c => c.ContactTypeId == 4).ContactId,
                        ProjectRoleId = 4,
                        StartDate = null,
                        EndDate = null,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation"
                    };
                    context.CaseDetailContacts.Add(update);
                }
                if (caseDetailContact.Count(n => n.ProjectRoleId == 15) == 0)
                {
                    CaseDetailContact update = new CaseDetailContact
                    {
                        CaseDetailId = caseDetailId,
                        ContactId = GetContactDataUnassociated(caseDetailId).First(c => c.ContactTypeId == 15).ContactId,
                        ProjectRoleId = 15,
                        StartDate = null,
                        EndDate = null,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation"
                    };
                    context.CaseDetailContacts.Add(update);
                }
                if (caseDetailContact.Count(n => n.ProjectRoleId == 16) == 0)
                {
                    var update = new CaseDetailContact
                    {
                        CaseDetailId = caseDetailId,
                        ContactId = GetContactDataUnassociated(caseDetailId).First(c => c.ContactTypeId == 16).ContactId,
                        ProjectRoleId = 16,
                        StartDate = null,
                        EndDate = null,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation"
                    };
                    context.CaseDetailContacts.Add(update);
                }
                if (caseDetailContact.Count(n => n.ProjectRoleId == 17) == 0)
                {
                    var update = new CaseDetailContact
                    {
                        CaseDetailId = caseDetailId,
                        ContactId = GetContactDataUnassociated(caseDetailId).First(c => c.ContactTypeId == 17).ContactId,
                        ProjectRoleId = 17,
                        StartDate = null,
                        EndDate = null,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation"
                    };
                    context.CaseDetailContacts.Add(update);
                }
                if (caseDetailContact.Count(n => n.ProjectRoleId == 18) == 0)
                {
                    CaseDetailContact update = new CaseDetailContact
                    {
                        CaseDetailId = caseDetailId,
                        ContactId = GetContactDataUnassociated(caseDetailId).First(c => c.ContactTypeId == 18).ContactId,
                        ProjectRoleId = 18,
                        StartDate = null,
                        EndDate = null,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation"
                    };
                    context.CaseDetailContacts.Add(update);
                }
                if (caseDetailContact.Count(n => n.ProjectRoleId == 20) == 0)
                {
                    var update = new CaseDetailContact
                    {
                        CaseDetailId = caseDetailId,
                        ContactId = GetContactDataUnassociated(caseDetailId).First(c => c.ContactTypeId == 20).ContactId,
                        ProjectRoleId = 20,
                        StartDate = null,
                        EndDate = null,
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        UpdatedBy = "automation"
                    };
                    context.CaseDetailContacts.Add(update);
                }
                if (context.CaseDetailContacts != null)
                {
                    context.SaveChanges();
                }
                UpdateContactsToActive(caseDetailId);
                AssociateAllContactsToOrgs(caseDetailId);
            }
        }

        public static void AssociateAllContactsToOrgs(int caseDetailId)
        {
            var contacts = GetContactDataByCase(caseDetailId);
            var contactToOrganization = GetContactToOrganization();
            var organization = GetOrganizations().First();
        
            foreach (var contact in contacts)
            {
                if (contactToOrganization.Count(i => i.ContactId == contact.ContactId) == 0)
                {
                    AssociateContactToOrg(contact.ContactId, organization.OrganizationId);
                }         
            }
        }

        public static void UpdateContactsToActive(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                var caseDetailContact = context.CaseDetailContacts.Where(i => i.CaseDetailId == caseDetailId);
                var associateProjectManager = caseDetailContact.First(r => r.ProjectRoleId == 4);
                var projectCoordinator = caseDetailContact.First(r => r.ProjectRoleId == 15);
                var projectDirector = caseDetailContact.First(r => r.ProjectRoleId == 16);
                var projectManager = caseDetailContact.First(r => r.ProjectRoleId == 17);
                var salesDirector = caseDetailContact.First(r => r.ProjectRoleId == 18);
                var technicalProjectManager = caseDetailContact.First(r => r.ProjectRoleId == 20);

                if (associateProjectManager.EndDate != null && associateProjectManager.EndDate <= DateTime.Now)
                {
                    associateProjectManager.EndDate = DateTime.Now.AddDays(30);
                    associateProjectManager.UpdatedBy = "automation";
                    context.Entry(associateProjectManager).Property(x => x.UpdatedBy).IsModified = true;
                    context.SaveChanges();
                }
                if (projectCoordinator.EndDate != null && projectCoordinator.EndDate <= DateTime.Now)
                {
                    projectCoordinator.EndDate = DateTime.Now.AddDays(30);
                    projectCoordinator.UpdatedBy = "automation";
                    context.Entry(projectCoordinator).Property(x => x.UpdatedBy).IsModified = true;
                    context.SaveChanges();
                }
                if (projectDirector.EndDate != null && projectDirector.EndDate <= DateTime.Now)
                {
                    projectDirector.EndDate = DateTime.Now.AddDays(30);
                    projectDirector.UpdatedBy = "automation";
                    context.Entry(projectDirector).Property(x => x.UpdatedBy).IsModified = true;
                    context.SaveChanges();
                }
                if (projectManager.EndDate != null && projectManager.EndDate <= DateTime.Now)
                {
                    projectManager.EndDate = DateTime.Now.AddDays(30);
                    projectManager.UpdatedBy = "automation";
                    context.Entry(projectManager).Property(x => x.UpdatedBy).IsModified = true;
                    context.SaveChanges();
                }
                if (salesDirector.EndDate != null && salesDirector.EndDate <= DateTime.Now)
                {
                    salesDirector.EndDate = DateTime.Now.AddDays(30);
                    salesDirector.UpdatedBy = "automation";
                    context.Entry(salesDirector).Property(x => x.UpdatedBy).IsModified = true;
                    context.SaveChanges();
                }
                if (technicalProjectManager.EndDate != null && technicalProjectManager.EndDate <= DateTime.Now)
                {
                    technicalProjectManager.EndDate = DateTime.Now.AddDays(30);
                    technicalProjectManager.UpdatedBy = "automation";
                    context.Entry(technicalProjectManager).Property(x => x.UpdatedBy).IsModified = true;
                    context.SaveChanges();
                }
            }
        }

        public static void AssociateContactToOrg(int contactId, int organizationId)
        {
            using (var context = new Database.Casebook())
            {
                var update = new ContactToOrganization
                {
                    ContactId = contactId,
                    OrganizationId = organizationId,
                    StartDate = null,
                    EndDate = null,
                    InsertedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    UpdatedBy = "automation"
                };
                context.ContactToOrganizations.Add(update);
                context.SaveChanges();
            }
        }

        public static void GenerateMilestone(int caseDetailId, string name, int order, string date)
        {
            using (var context = new Database.Casebook())
            {
                var milestones = GetMilestones(caseDetailId);

                if (milestones.Count(n => n.Name == name) == 0)
                {
                    Milestone milestone = new Milestone
                    {
                        CaseDetailId = caseDetailId,
                        Name = name,
                        SortOrder = order,
                        DueDate = DateTime.Parse(date),
                        CourtOrdered = false,
                        RequiredDate = false,
                        ShowOnSummary = false,
                        ClientOrdered = false,
                        NotApplicable = false,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Milestones.Add(milestone);
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateMilestones(int caseDetailId)
        {
            var milestones = GetMilestones(caseDetailId);
            foreach (var milestone in milestones)
            {
                using (var context = new Database.Casebook())
                {
                    if (milestone.DueDate == null)
                    {
                        context.Milestones.Attach(milestone);
                        milestone.DueDate = DateTime.Now.AddDays(milestone.MilestoneId % 100);
                        milestone.NotApplicable = false;
                        milestone.DatePending = false;
                        milestone.UpdatedBy = "automation";
                        context.Entry(milestone).Property(x => x.UpdatedBy).IsModified = true; //Force update of username due to triggers
                        context.SaveChanges();
                    }
                }
            }
        }

        public static void PopulateIncidents()
        {
            var incidents = GetIncidents();

            using (var context = new Database.Casebook())
            {
                if (incidents.Count(u => u.Name == "Incident Number 1") == 0)
                {
                    Incident inc = new Incident
                    {
                        Name = "Incident Number 1",
                        IncidentDate = DateTime.Now,
                        EstimatedIncidentDate = DateTime.Now.AddDays(-1),
                        ClaimsOperationsResponsible = true,
                        ActualCost = (decimal)1.99,
                        RootCauseDescription = "Description 1",
                        ClientResolution = "Client Resolution 1",
                        InternalResolution = "Internal Resolution 1",
                        Owner = "User 1",
                        LessonsLearnedMeeting = true,
                        IncidentStatusId = 70,
                        HardCostId = 1,
                        ImpactToClientId = 1,
                        IndicatesTrend = false,
                        ImpactWouldBeGreaterIf = false,
                        SubjectivePoint = false,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Incidents.Add(inc);
                }
                if (incidents.Count(u => u.Name == "Incident Number 4") == 0)
                {
                    Incident inc = new Incident
                    {
                        Name = "Incident Number 4",
                        IncidentDate = DateTime.Now,
                        EstimatedIncidentDate = DateTime.Now.AddDays(-4),
                        ClaimsOperationsResponsible = true,
                        ActualCost = (decimal)4.99,
                        RootCauseDescription = "Description 4",
                        ClientResolution = "Client Resolution 4",
                        InternalResolution = "Internal Resolution 4",
                        Owner = "User 4",
                        LessonsLearnedMeeting = true,
                        IncidentStatusId = 70,
                        HardCostId = 2,
                        ImpactToClientId = 2,
                        IndicatesTrend = true,
                        ImpactWouldBeGreaterIf = false,
                        SubjectivePoint = false,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Incidents.Add(inc);
                }
                if (incidents.Count(u => u.Name == "Incident Number 7") == 0)
                {
                    Incident inc = new Incident
                    {
                        Name = "Incident Number 7",
                        IncidentDate = DateTime.Now,
                        EstimatedIncidentDate = DateTime.Now.AddDays(-7),
                        ClaimsOperationsResponsible = true,
                        ActualCost = (decimal)7.99,
                        RootCauseDescription = "Description 7",
                        ClientResolution = "Client Resolution 7",
                        InternalResolution = "Internal Resolution 7",
                        Owner = "User 7",
                        LessonsLearnedMeeting = true,
                        IncidentStatusId = 70,
                        HardCostId = 3,
                        ImpactToClientId = 3,
                        IndicatesTrend = false,
                        ImpactWouldBeGreaterIf = true,
                        SubjectivePoint = true,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Incidents.Add(inc);
                }
                if (context.Incidents != null)
                {
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateRiskMatrix(int caseDetailId)
        {
            var riskMatrix = GetRiskMatrix(caseDetailId);
            using (var context = new Database.Casebook())
            {
                if (riskMatrix.Count(u => u.RiskDescription == "Automation Risk Green") == 0)
                {
                    var nextNumber = GetRiskMatrix().Max(n => n.RiskNumber) + 1;
                    var risk = new RiskMatrix
                    {
                        CaseDetailId = caseDetailId,
                        DepartmentId = 1,
                        DescriptionOfConsequence = "Description of Consequence Green",
                        Impact = 1,
                        MitigationPlan = "Mitigation Plan Green",
                        NoRiskIdentified = false,
                        Owner = "User 1",
                        Probability = 2,
                        RiskCategoryId = 11,
                        RiskDescription = "Automation Risk Green",
                        RiskNumber = nextNumber,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.RiskMatrices.Add(risk);
                    context.SaveChanges();
                }
                if (riskMatrix.Count(u => u.RiskDescription == "Automation Risk Yellow") == 0)
                {
                    var nextNumber = GetRiskMatrix().Max(n => n.RiskNumber) + 1;
                    var risk2 = new RiskMatrix
                    {
                        CaseDetailId = caseDetailId,
                        DepartmentId = 2,
                        DescriptionOfConsequence = "Description of Consequence Yellow",
                        Impact = 2,
                        MitigationPlan = "Mitigation Plan Yellow",
                        NoRiskIdentified = false,
                        Owner = "User 2",
                        Probability = 3,
                        RiskCategoryId = 12,
                        RiskDescription = "Automation Risk Yellow",
                        RiskNumber = nextNumber,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.RiskMatrices.Add(risk2);
                    context.SaveChanges();
                }
                if (riskMatrix.Count(u => u.RiskDescription == "Automation Risk Red") == 0)
                {
                    var nextNumber = GetRiskMatrix().Max(n => n.RiskNumber) + 1;
                    var risk3 = new RiskMatrix
                    {
                        CaseDetailId = caseDetailId,
                        DepartmentId = 3,
                        DescriptionOfConsequence = "Description of Consequence Red",
                        Impact = 3,
                        MitigationPlan = "Mitigation Plan Red",
                        NoRiskIdentified = false,
                        Owner = "User 3",
                        Probability = 5,
                        RiskCategoryId = 13,
                        RiskDescription = "Automation Risk Red",
                        RiskNumber = nextNumber,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.RiskMatrices.Add(risk3);
                    context.SaveChanges();
                }
                if (riskMatrix.Count(u => u.NoRiskIdentified) == 0)
                {
                    var nextNumber = GetRiskMatrix().Max(n => n.RiskNumber) + 1;
                    var risk4 = new RiskMatrix
                    {
                        CaseDetailId = caseDetailId,
                        DepartmentId = GetRiskMatrixOption().Where(i => riskMatrix.All(r => r.DepartmentId != i.RiskMatrixOptionId)).Where(t => t.Type == "Department").OrderBy(x => Guid.NewGuid()).First().RiskMatrixOptionId,
                        NoRiskIdentified = true,
                        RiskDescription = "No Risk Identified",
                        RiskNumber = nextNumber,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.RiskMatrices.Add(risk4);
                    context.SaveChanges();
                }
                while (GetRiskMatrix(caseDetailId).Count < 11)
                {
                    var nextNumber = GetRiskMatrix().Max(n => n.RiskNumber) + 1;
                    var risk = new RiskMatrix
                    {
                        CaseDetailId = caseDetailId,
                        DepartmentId = 10,
                        DescriptionOfConsequence = "Automation Consequence",
                        Impact = 1,
                        MitigationPlan = "Automation Mitigation Plan",
                        NoRiskIdentified = false,
                        Owner = "Automation User",
                        Probability = 1,
                        RiskCategoryId = 17,
                        RiskDescription = "Automation Risk",
                        RiskNumber = nextNumber,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.RiskMatrices.Add(risk);
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateReports()
        {
            var reports = GetReports();

            using (var context = new Database.Casebook())
            {
                if (reports.Count(u => u.ReportName == "WAR") == 0)
                {
                    Report report = new Report
                    {
                        ReportName = "WAR",
                        URL = "http://ca016-prssrs01/Reports/Pages/Report.aspx?ItemPath=%2fProd%2fDepartment+Reporting%2fWAR%2fWeekly+Client+Report",
                        Right = "rpt-ui-v"
                    };
                    context.Reports.Add(report);
                }
                if (reports.Count(u => u.ReportName == "Summary Report") == 0)
                {
                    Report report = new Report
                    {
                        ReportName = "Summary Report",
                        URL = "http://ca016-prssrs01/Reports/Pages/Folder.aspx",
                        Right = "rpt-ui-v"
                    };
                    context.Reports.Add(report);
                }
                if (reports.Count(u => u.ReportName == "Milestone") == 0)
                {
                    Report report = new Report
                    {
                        ReportName = "Milestone",
                        URL = "http://ca016-prssrs01/Reports/Pages/Folder.aspx",
                        Right = "rpt-ui-v"
                    };
                    context.Reports.Add(report);
                }
                if (reports.Count(u => u.ReportName == "Key Date and Backlog") == 0)
                {
                    Report report = new Report
                    {
                        ReportName = "Key Date and Backlog",
                        URL = "http://ca016-prssrs01/Reports/Pages/Report.aspx?ItemPath=%2fProd%2fDepartment+Reporting%2fInterdepartmental%2fKey+Date+Deadline+Report",
                        Right = "rpt-ui-v"
                    };
                    context.Reports.Add(report);
                }
                if (reports.Count(u => u.ReportName == "Exception Report") == 0)
                {
                    Report report = new Report
                    {
                        ReportName = "Exception Report",
                        URL = "http://ca016-prssrs01/Reports/Pages/Report.aspx?ItemPath=%2fProd%2fException+Rpts%2fException_Report_(v4.0)",
                        Right = "rpt-ui-v"
                    };
                    context.Reports.Add(report);
                }
                if (reports.Count(u => u.ReportName == "ECA Health Report") == 0)
                {
                    Report report = new Report
                    {
                        ReportName = "ECA Health Report",
                        URL = "http://ca016-prssrs01/Reports/Pages/Folder.aspx",
                        Right = "rpt-ui-v"
                    };
                    context.Reports.Add(report);
                }
                if (reports.Count(u => u.ReportName == "Case Kickoff") == 0)
                {
                    Report report = new Report
                    {
                        ReportName = "Case Kickoff",
                        URL = "http://ca003-dvsql02/Reports/Pages/Report.aspx?ItemPath=%2fDev%2fDepartment+Reporting%2fCasebook%2fCasebook+Case+Kickoff+Report&ViewMode=Detail",
                        Right = "rpt-ui-v"
                    };
                    context.Reports.Add(report);
                }

                if (context.Reports != null)
                {
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateHealthStatusUpdates(int caseDetailId)
        {
            var statusUpdate = GetStatusUpdate(caseDetailId);
            using (var context = new Database.Casebook())
            {
                if (statusUpdate.Count(r => r.KeyStats == "Green Test Record Action") == 0)
                {
                    StatusUpdate update = new StatusUpdate
                    {
                        CaseDetailId = caseDetailId,
                        StatusDate = DateTime.Now.AddDays(30),
                        KeyStats = "Green Test Record Action",
                        Rating = "GREEN",
                        Comment = "Green Test Record Comment",
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.StatusUpdates.Add(update);
                }
                if (statusUpdate.Count(r => r.KeyStats == "Yellow Test Record Action") == 0)
                {
                    StatusUpdate update = new StatusUpdate
                    {
                        CaseDetailId = caseDetailId,
                        StatusDate = DateTime.Now.AddDays(20),
                        KeyStats = "Yellow Test Record Action",
                        Rating = "YELLOW",
                        Comment = "Yellow Test Record Comment",
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.StatusUpdates.Add(update);
                }
                if (statusUpdate.Count(r => r.KeyStats == "Red Test Record Action") == 0)
                {
                    StatusUpdate update = new StatusUpdate
                    {
                        CaseDetailId = caseDetailId,
                        StatusDate = DateTime.Now.AddDays(10),
                        KeyStats = "Red Test Record Action",
                        Rating = "RED",
                        Comment = "Red Test Record Comment",
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.StatusUpdates.Add(update);
                }
                if (context.StatusUpdates != null)
                {
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateInvoice(int caseDetailId)
        {
            var invoices = GetInvoice(caseDetailId);
            using (var context = new Database.Casebook())
            {
                DateTime date1 = new DateTime(2017, 1, 1);
                DateTime date2 = new DateTime(2017, 2, 1);
                DateTime date3 = new DateTime(2017, 3, 1);
                if (invoices.Count(d => d.InvoiceDate == date1) == 0)
                {
                    Invoice invoice = new Invoice
                    {
                        CaseDetailId = caseDetailId,
                        InvoiceDate = date1,
                        Amount = 10000,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Invoices.Add(invoice);
                }
                if (invoices.Count(d => d.InvoiceDate == date2) == 0)
                {
                    Invoice invoice = new Invoice
                    {
                        CaseDetailId = caseDetailId,
                        InvoiceDate = date2,
                        Amount = 5000,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Invoices.Add(invoice);
                }
                if (invoices.Count(d => d.InvoiceDate == date3) == 0)
                {
                    Invoice invoice = new Invoice
                    {
                        CaseDetailId = caseDetailId,
                        InvoiceDate = date3,
                        Amount = (decimal)999.99,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Invoices.Add(invoice);
                }
                if (context.Invoices != null)
                {
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateDocuments(int caseDetailId)
        {
            var documents = GetDocument(caseDetailId);
            using (var context = new Database.Casebook())
            {
                if (documents.Count(d => d.DocumentTypeId == 1) == 0)
                {
                    Document document = new Document
                    {
                        CaseDetailId = caseDetailId,
                        DocumentTypeId = 1,
                        FileName = "TestDocument" + 1 + ".txt",
                        DisplayName = "TestDocument" + 1 + ".txt",
                        Note = "Note: " + 1,
                        Owner = "automation",
                        UploadedDate = DateTime.Now,
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };
                    context.Documents.Add(document);
                }
                if (documents.Count(d => d.DocumentTypeId == 2) == 0)
                {
                    Document document = new Document
                    {
                        CaseDetailId = caseDetailId,
                        DocumentTypeId = 2,
                        FileName = "TestDocument" + 2 + ".doc",
                        DisplayName = "TestDocument" + 2 + ".doc",
                        Note = "Note: " + 2,
                        Owner = "automation",
                        UploadedDate = DateTime.Now.AddDays(-1),
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now.AddDays(-1),
                        UpdatedDate = DateTime.Now.AddDays(-1)
                    };
                    context.Documents.Add(document);
                }
                if (documents.Count(d => d.DocumentTypeId == 3) == 0)
                {
                    Document document = new Document
                    {
                        CaseDetailId = caseDetailId,
                        DocumentTypeId = 3,
                        FileName = "TestDocument" + 3 + ".xls",
                        DisplayName = "TestDocument" + 3 + ".xls",
                        Note = "Note: " + 3,
                        Owner = "automation",
                        UploadedDate = DateTime.Now.AddDays(-2),
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now.AddDays(-2),
                        UpdatedDate = DateTime.Now.AddDays(-2)
                    };
                    context.Documents.Add(document);
                }
                if (documents.Count(d => d.DocumentTypeId == 4) == 0)
                {
                    Document document = new Document
                    {
                        CaseDetailId = caseDetailId,
                        DocumentTypeId = 4,
                        FileName = "TestDocument" + 4 + ".pdf",
                        DisplayName = "TestDocument" + 4 + ".pdf",
                        Note = "Note: " + 4,
                        Owner = "automation",
                        UploadedDate = DateTime.Now.AddDays(-3),
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now.AddDays(-3),
                        UpdatedDate = DateTime.Now.AddDays(-3)
                    };
                    context.Documents.Add(document);
                }
                if (documents.Count(d => d.DocumentTypeId == 5) == 0)
                {
                    Document document = new Document
                    {
                        CaseDetailId = caseDetailId,
                        DocumentTypeId = 5,
                        FileName = "TestDocument" + 5 + ".jpg",
                        DisplayName = "TestDocument" + 5 + ".jpg",
                        Note = "Note: " + 5,
                        Owner = "automation",
                        UploadedDate = DateTime.Now.AddDays(-4),
                        UpdatedBy = "automation",
                        InsertedDate = DateTime.Now.AddDays(-4),
                        UpdatedDate = DateTime.Now.AddDays(-4)
                    };
                    context.Documents.Add(document);
                }
                if (context.Documents != null)
                {
                    context.SaveChanges();
                }
            }
        }

        public static void PopulateInitialRecords(int caseDetailId)
        {
            using (var context = new Database.Casebook())
            {
                context.Database.ExecuteSqlCommand(@"Exec CreateCaseDetail " + caseDetailId);
            }
        }

        public static void PopulateSapCode(int caseDetailId, int sapCode)
        {
            var caseDetail = GetCaseDataById(caseDetailId);
            using (var context = new Database.Casebook())
            {
                var caseData = context.CaseDetails.Single(c => c.CaseDetailId == caseDetailId);
                if (caseDetail.First(i => i.CaseDetailId == caseDetailId).SapContractCode == sapCode) return;
                caseData.SapContractCode = sapCode;
                caseData. UpdatedBy = "CBautomation";                                                   //DEL user names changed
                context.Entry(caseData).Property(x => x.UpdatedBy).IsModified = true; //Force update of username due to triggers
                context.SaveChanges();
            }
        }

        public static string RandomizeMockData()
        {
            var caseDetail = GetCaseData();
            var milestone = GetMilestones();
            var contact = GetContactData();
            var classSize = 0;
            var numclaims = 0;
            var date = 0;
            var lastName = 0;
            var emails = 0;
            using (var context = new Database.Casebook())
            {
                //Randomize Class Size
                if (caseDetail.First(i => i.CaseDetailId == 1).ClassSize == caseDetail.First(i => i.CaseDetailId == 2).ClassSize)
                {
                    classSize = context.Database.ExecuteSqlCommand(@"Update CaseDetail Set ClassSize = Round(Rand(ABS(Checksum(NewId()))) * 100000, 0), UpdatedBy = 'QA'");
                }
                if (caseDetail.First(i => i.CaseDetailId == 1).EstimatedNumberOfClaims == caseDetail.First(i => i.CaseDetailId == 2).EstimatedNumberOfClaims)
                {
                    numclaims = context.Database.ExecuteSqlCommand(@"Update CaseDetail Set EstimatedNumberOfClaims = Round(Rand(ABS(Checksum(NewId()))) * 100000, 0), UpdatedBy = 'QA'");
                }
                //Randomize Dates
                if (milestone.First(d => d.DueDate != null).DueDate == milestone.Where(d => d.DueDate != null).Skip(1).First().DueDate)
                {
                    date = context.Database.ExecuteSqlCommand(@"Update Milestone Set DueDate = DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 3650), '2015-01-01'), UpdatedBy = 'QA' WHERE DueDate is not null");
                }
                //Randomize Contact Names
                if (contact.First(i => i.ContactId == 1).LastName.Contains(contact.First(i => i.ContactId == 1).ContactId.ToString()) == false)
                {
                    lastName = context.Database.ExecuteSqlCommand(@"Update Contact Set LastName = LastName + right('0000' + convert(varchar(4), ContactId), 4), UpdatedBy = 'QA'");
                }
                //Populate Email
                if (contact.Count(e => e.Email == null) > 0 )
                {
                    emails = context.Database.ExecuteSqlCommand(@"Update Contact Set Email = FirstName + LastName + '@epiqsystems.com', UpdatedBy = 'QA' WHERE Email Is null");
                }
                return "Updates: Class Size = " + classSize + " rows; Num Claims = " + numclaims + " rows; Dates = " + date + " rows; Last Names = " + lastName + " rows; Emails = " + emails + " rows.";
            
            }
        }

        public static int ReturnMedianClassSize()
        {
            var caseData = GetCaseData().OrderBy(c => c.ClassSize).Where(c => c.ClassSize != null).ToList();
            if (caseData.Count == 0) throw new Exception ("There is no class size data.");
            var classSize = caseData.ElementAt(caseData.Count / 2).ClassSize;
            if (classSize != null) return (int) classSize;
            throw new Exception("Error occured while determining median class size.");
        }

        public static int ReturnMedianEstNumClaims()
        {
            var caseData = GetCaseData().OrderBy(c => c.EstimatedNumberOfClaims).Where(c => c.EstimatedNumberOfClaims != null).ToList();
            if (caseData.Count == 0) throw new Exception("There is no class size data.");
            var estimatedNumberOfClaims = caseData.ElementAt(caseData.Count / 2).EstimatedNumberOfClaims;
            if (estimatedNumberOfClaims != null) return (int) estimatedNumberOfClaims;
            throw new Exception("Error occured while determining median number of claims.");
        }

        public static int ReturnMedianSapContractCode()
        {
            var caseData = GetCaseData().OrderBy(c => c.SapContractCode);
            var index = caseData.Count() / 2;

            return caseData.ElementAt(index).SapContractCode;
        }

        public static void EnsureCaseNotClosed(int caseDetailId)
        {
            var caseDetail = GetCaseDataById(caseDetailId).First();
            var closedStatus = new[] {3, 5, 7};
            if (!closedStatus.Contains(caseDetail.CaseStatusId)) return;
            using (var context = new Database.Casebook())
            {
                context.CaseDetails.Attach(caseDetail);
                caseDetail.CaseStatusId = 1;
                caseDetail.UpdatedBy = "automation";
                context.Entry(caseDetail).Property(x => x.UpdatedBy).IsModified = true; //Force update of username due to triggers
                context.SaveChanges();    
            }
        }

        //Troubleshooting for DBValidationErrors
        public static void SaveChanges(Database.Casebook context)
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                    .SelectMany(x => x.ValidationErrors)
                    .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
        }

    }
}
