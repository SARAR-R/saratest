﻿using Automation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Casebook
{
    [TestClass]
    public class casebookTestSuite
    {
        public TestContext TestContext { get; set; }

        static void MyContext()
        {
            var type = typeof(System.Data.Entity.SqlServer.SqlProviderServices);
            if (type == null)
                throw new System.Exception("Do not remove, ensures static reference to System.Data.Entity.SqlServer");
        }

        void Main(string[] args) { }

        [TestInitialize]
        public void Startup()
        {
            TestContext.Properties["__Tfs_TestConfigurationName__"] = "Chrome";                           //DEL
            TestContext.Properties["BuildDirectory"] = AppDomain.CurrentDomain.BaseDirectory;         //DEL
            test.startup(TestContext); //DEL

        }

        [TestCleanup]
        public void Teardown()
        {
            test.teardown();
        }


        [TestCategory("Casebook_SmokeTest"), TestMethod]
        public void Casebook_SmokeTest()
        {
            usecase.SmokeTest("https://ecaqa.epiqsystems.com/casebook/", "CBExecutiveHealthRis", "P@ssword1"); //DEL new permissions required for risk and health
            //usecase.SmokeTest("https://ecaqa.epiqsystems.com/casebook/", "CBeExecutive", "P@ssword1"); //DEL
        }

        [TestCategory("ProductionSmoke"), TestMethod]
        public void ProdSmokeTest()
        {
            usecase.SmokeTest("https://secure.epiqfacilitator.com/casebook/", "TestAdmin", "P@ssword1");
        }

        [TestCategory("Performance"), TestMethod]
        public void OpsLoad()
        {
            usecase.OpsLoad(20);
        }

        [TestCategory("Performance"), TestMethod]
        public void DetailsLoad()
        {
            usecase.DetailsLoad(20);
        }

        [TestCategory("Performance"), TestMethod]
        public void BannerLoad()
        {
            usecase.BannerLoad(navigate.CaseDetailId);
        }

        [TestCategory("Regression"), TestMethod]
        public void Login()
        {
            usecase.Logon();
        }

        [TestCategory("Regression"), TestMethod]
        public void Logout()
        {
            usecase.Logout();
        }

        [TestCategory("Regression"), TestMethod]
        public void ChangePassword()
        {
            usecase.ChangePassword();
        }

        [TestCategory("Regression"), TestMethod]
        public void StandardSearchAllFields()
        {
            usecase.StandardSearchAllFields();
        }

        [TestCategory("Regression"), TestMethod]
        public void QuickSearchAllFields()
        {
            usecase.QuickSearchAllFields();
        }

        [TestCategory("Functional"), TestMethod, Timeout(7200000)]
        public void StandardSearchAllFieldsAndCriteria()
        {
            usecase.StandardSearchAllFieldsAndCriteria();
        }

        [TestCategory("Functional"), TestMethod, Timeout(7200000)]
        public void StandardSearchTextFieldsAndCriteria()
        {
            usecase.StandardSearchAllFieldsAndCriteria("Text");
        }

        [TestCategory("Functional"), TestMethod, Timeout(7200000)]
        public void StandardSearchNumberFieldsAndCriteria()
        {
            usecase.StandardSearchAllFieldsAndCriteria("Number");
        }

        [TestCategory("Functional"), TestMethod, Timeout(7200000)]
        public void StandardSearchListFieldsAndCriteria()
        {
            usecase.StandardSearchAllFieldsAndCriteria("List");
        }

        [TestCategory("Functional"), TestMethod, Timeout(7200000)]
        public void StandardSearchDateFieldsAndCriteria()
        {
            usecase.StandardSearchAllFieldsAndCriteria("Date");
        }

        [TestCategory("Functional"), TestMethod, Timeout(7200000)]
        public void StandardSearchBooleanFieldsAndCriteria()
        {
            usecase.StandardSearchAllFieldsAndCriteria("Boolean");
        }

        [TestCategory("Functional"), TestMethod, Timeout(7200000)]
        public void StandardSearchMiscFieldsAndCriteria()
        {
            usecase.StandardSearchAllFieldsAndCriteria("Misc");
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseSummary()
        {
            usecase.CaseSummary();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseDetail()
        {
            usecase.CaseDetail();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseDates()
        {
            usecase.CaseDates();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseContacts()
        {
            usecase.CaseContacts();
        }

        [TestCategory("Regression"), TestMethod]
        public void AdminOrganizations()
        {
            usecase.AdminOrganizations();
        }

        [TestCategory("Regression"), TestMethod]
        public void AdminContacts()
        {
            usecase.AdminContacts();
        }

        [TestCategory("Regression"), TestMethod]
        public void CreateNew()
        {
            usecase.CreateNew();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseOps()
        {
            usecase.CaseOps();
        }

        [TestCategory("Regression"), TestMethod]
        public void TestQuery()
        {
            usecase.TestQuery();
        }

        [TestCategory("Regression"), TestMethod]
        public void Incidents()
        {
            usecase.Incidents();
        }

        [TestCategory("Regression"), TestMethod]
        public void Reports()
        {
            usecase.Reports();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseStatistics()
        {
            usecase.CaseStatistics();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseHealthStatus()
        {
            usecase.CaseHealthStatus();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseDocuments()
        {
            usecase.CaseDocuments();
        }

        [TestCategory("Functional"), TestMethod]
        public void FieldValidation()
        {
            usecase.FieldValidation(55);
        }

        [TestCategory("Roles"), TestMethod]
        public void Executive()
        {
            usecase.Executive("CBExecutiveHealthRis", "P@ssword1");  //DEL Risk Matrix, Health Status require special permission now
            //usecase.Executive("CBeExecutive", "P@ssword1");   //DEL
        }

        [TestCategory("Roles"), TestMethod]
        public void ProjectManager()
        {
            usecase.ProjectManager("CBePM", "P@ssword1");
        }

        [TestCategory("Roles"), TestMethod]
        public void ProjectCoordinator()
        {
            usecase.ProjectCoordinator("CBePC", "P@ssword1");
        }

        [TestCategory("Roles"), TestMethod]
        public void ReadOnlyPlusViewIncidents()
        {
            usecase.ReadOnlyPlusViewIncidents("CBeReadOnly", "P@ssword1");
        }

        [TestCategory("Roles"), TestMethod]
        public void ViewOnly()
        {
            usecase.ViewOnly("CBeViewOnly", "P@ssword1");
        }

        [TestCategory("Session"), TestMethod, Timeout(3600000)]
        public void SessionContinuousUse()
        {
            usecase.SessionContinuousUse();
        }

        [TestCategory("Regression"), TestMethod]
        public void CaseRiskMatrix()
        {
            usecase.CaseRiskMatrix();
        }

        [TestCategory("Functional"), TestMethod]
        public void Testing()
        {
            usecase.Testing();
        }

        [TestCategory("Performance"), TestMethod]
        public void DocumentsHeaderLoad()
        {
            usecase.DocumentsHeaderLoad();
        }
    }
}
