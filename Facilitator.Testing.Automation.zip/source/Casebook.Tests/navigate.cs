﻿using OpenQA.Selenium;
using System.Configuration;
using Automation;

namespace Casebook
{
    public class navigate : Automation.navigate
    {
        public static int CaseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
        public static By _Search = By.XPath("//a[text()='Search']/parent::li");
        public static By _QuickSearch = By.XPath("//a[text()='Search']//following-sibling::ul//a[text()='Quick Search']/parent::li");
        public static By _StandardSearch = By.XPath("//a[text()='Search']//following-sibling::ul//a[text()='Standard Search']/parent::li");
        public static By _CaseInformation = By.XPath("//a[text()='Case Information']/parent::li");
        public static By _Summary = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Summary']/parent::li");
        public static By _Detail = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Detail']/parent::li");
        public static By _Dates = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Dates']/parent::li");
        public static By _Contacts = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Contacts']/parent::li");
        public static By _Ops = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Ops/Shared Services']/parent::li");
        public static By _Documents = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Documents']/parent::li");
        public static By _Statistics = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Statistics']/parent::li");
        public static By _HealthStatus = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Health Status']/parent::li");
        public static By _RiskMatrix = By.XPath("//a[text()='Case Information']//following-sibling::ul//a[text()='Risk Matrix']/parent::li");
        public static By _Incidents = By.XPath("//a[text()='Incidents']/parent::li");
        public static By _Reports = By.XPath("//a[text()='Reports']/parent::li");
        public static By _Queries = By.XPath("//a[text()='Queries']/parent::li");
        public static By _Administration = By.XPath("//a[text()='Administration']/parent::li");
        public static By _AdminOrganization = By.XPath("//a[text()='Administration']//following-sibling::ul//a[text()='Organization/Entity']/parent::li");
        public static By _AdminContacts = By.XPath("//a[text()='Administration']//following-sibling::ul//a[text()='Contacts']/parent::li");
        public static By _CreateNewCase = By.XPath("//a[text()='Create New Case']/parent::li");

        public new static void DirectToPage(string path, string cid)
        {
            var url = ConfigurationManager.AppSettings.Get("url");

            if (cid == null)
            {
                URL(url + "/" + path);
            }
            else
            {
                URL(url + "/" + path + "?cid=" + cid);
            }
            test.WaitForPageToLoad(test.driver);
        }

        public static void ValidatePageAccess(string path, string id, bool expected)
        {
            DirectToPage(path, id);
            test.vars.verify(test.VerifyAccess(expected));
        }

        public new static void Refresh()
        {
            report.Action("Navigate", "Refresh");           
            try
            {
                test.driver.Navigate().Refresh();
                test.WaitForPageToLoad(test.driver);
            }
            catch (WebDriverTimeoutException)
            { //retry refesh if it didn't load due to a timeout
                test.driver.Navigate().Refresh();
                test.WaitForPageToLoad(test.driver);
            }      
        }

        public static void MenuItem(By by)
        {
            if (by == _AdminContacts | by == _AdminOrganization) test.Click(_Administration);
            test.Click(by);
        }

        public static void QuickSearch()
        {
            test.Click(_Search);
            test.Click(_QuickSearch);
        }

    }
}
