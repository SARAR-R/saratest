namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ContactOrganization")]
    public partial class ContactOrganization
    {
        public int? ContactToOrganizationId { get; set; }

        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ContactId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ContactTypeId { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(1)]
        public string MiddleInitial { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(30)]
        public string LastName { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int OrganizationId { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(100)]
        public string OrganizationName { get; set; }

        [StringLength(150)]
        public string WebAddress { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        [Key]
        [Column(Order = 6)]
        [StringLength(50)]
        public string ContactType { get; set; }

        [StringLength(25)]
        public string Phone1 { get; set; }

        [StringLength(70)]
        public string Email { get; set; }

        [Key]
        [Column(Order = 7)]
        public bool KeyContact { get; set; }

        public bool? IsSetForDelete { get; set; }
    }
}
