namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ContactCenter")]
    public partial class ContactCenter
    {
        public int ContactCenterId { get; set; }

        public int CaseDetailId { get; set; }

        [StringLength(256)]
        public string CaseNameinCMX { get; set; }

        public int? ForeignLanguageIvrOptionsId { get; set; }

        public int? AgentsOptionsId { get; set; }

        public bool? CustomCallRouting { get; set; }

        public bool? BilingualAgents { get; set; }

        public bool? Chat { get; set; }

        public bool? ContractSla { get; set; }

        [StringLength(256)]
        public string ContractSlaNote { get; set; }

        public int? ForeignLanguageCallCenterOptionsId { get; set; }

        public int? OptionSuiteOptionsId { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual ContactCenterOption ContactCenterOption { get; set; }

        public virtual ContactCenterOption ContactCenterOption1 { get; set; }

        public virtual ContactCenterOption ContactCenterOption2 { get; set; }

        public virtual ContactCenterOption ContactCenterOption3 { get; set; }
    }
}
