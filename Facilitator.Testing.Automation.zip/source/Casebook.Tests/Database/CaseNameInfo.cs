namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CaseNameInfo")]
    public partial class CaseNameInfo
    {
        [Key]
        [Column(Order = 0)]
        public int CaseDetailId { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(500)]
        public string CaseName { get; set; }

        [StringLength(50)]
        public string BillingCode { get; set; }
    }
}
