namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DocumentProcessing")]
    public partial class DocumentProcessing
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public DocumentProcessing()
        {
            IncomingDocuments = new HashSet<IncomingDocument>();
        }

        public int DocumentProcessingId { get; set; }

        public int CaseDetailId { get; set; }

        public int? DeTypeOptionsId { get; set; }

        public int? DcSlaOptionsId { get; set; }

        public int? DeSlaOptionsId { get; set; }

        public int? IntakeTypeOptionsId { get; set; }

        public int? UndeliverableCheckOptionsId { get; set; }

        [StringLength(100)]
        public string NonStandardMonths { get; set; }

        public bool? BoxStorageBillable { get; set; }

        public bool? IvrTranscription { get; set; }

        public bool? NomineeClaimProcessing { get; set; }

        public bool? Remails { get; set; }

        public bool? SecuredPhysicalStorageRequired { get; set; }

        public bool? Undeliverables { get; set; }

        public bool? BrokerListProcessing { get; set; }

        [StringLength(8000)]
        public string DcSpecialInstructions { get; set; }

        [StringLength(8000)]
        public string DeSpecialInstructions { get; set; }

        [StringLength(100)]
        public string SpecialReportingRequirements { get; set; }

        [StringLength(100)]
        public string FaxInboxEmail { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual DocumentProcessingOption DocumentProcessingOption { get; set; }

        public virtual DocumentProcessingOption DocumentProcessingOption1 { get; set; }

        public virtual DocumentProcessingOption DocumentProcessingOption2 { get; set; }

        public virtual DocumentProcessingOption DocumentProcessingOption3 { get; set; }

        public virtual DocumentProcessingOption DocumentProcessingOption4 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<IncomingDocument> IncomingDocuments { get; set; }
    }
}
