namespace Casebook.Database
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Casebook : DbContext
    {
        public Casebook()
            : base("name=Casebook")
        {
        }

        public virtual DbSet<C__RefactorLog> C__RefactorLog { get; set; }
        public virtual DbSet<AuditLog> AuditLogs { get; set; }
        public virtual DbSet<BusinessLine> BusinessLines { get; set; }
        public virtual DbSet<CaseDetail> CaseDetails { get; set; }
        public virtual DbSet<CaseDetailColumn> CaseDetailColumns { get; set; }
        public virtual DbSet<CaseDetailColumnChange> CaseDetailColumnChanges { get; set; }
        public virtual DbSet<CaseDetailContact> CaseDetailContacts { get; set; }
        public virtual DbSet<CaseDetailContactColumn> CaseDetailContactColumns { get; set; }
        public virtual DbSet<CaseDetailContactColumnChange> CaseDetailContactColumnChanges { get; set; }
        public virtual DbSet<CaseHealth> CaseHealths { get; set; }
        public virtual DbSet<CaseHealthColumn> CaseHealthColumns { get; set; }
        public virtual DbSet<CaseHealthColumnChange> CaseHealthColumnChanges { get; set; }
        public virtual DbSet<CaseKickoffDetail> CaseKickoffDetails { get; set; }
        public virtual DbSet<CaseKickoffDetailsColumn> CaseKickoffDetailsColumns { get; set; }
        public virtual DbSet<CaseKickoffDetailsColumnChange> CaseKickoffDetailsColumnChanges { get; set; }
        public virtual DbSet<CaseKickoffDetailsOption> CaseKickoffDetailsOptions { get; set; }
        public virtual DbSet<CaseStatu> CaseStatus { get; set; }
        public virtual DbSet<CaseType> CaseTypes { get; set; }
        public virtual DbSet<Claim> Claims { get; set; }
        public virtual DbSet<ClaimColumn> ClaimColumns { get; set; }
        public virtual DbSet<ClaimColumnChange> ClaimColumnChanges { get; set; }
        public virtual DbSet<ClaimOption> ClaimOptions { get; set; }
        public virtual DbSet<Contact> Contacts { get; set; }
        public virtual DbSet<ContactCenter> ContactCenters { get; set; }
        public virtual DbSet<ContactCenterColumn> ContactCenterColumns { get; set; }
        public virtual DbSet<ContactCenterColumnChange> ContactCenterColumnChanges { get; set; }
        public virtual DbSet<ContactCenterOption> ContactCenterOptions { get; set; }
        public virtual DbSet<ContactColumn> ContactColumns { get; set; }
        public virtual DbSet<ContactColumnChange> ContactColumnChanges { get; set; }
        public virtual DbSet<ContactToOrganization> ContactToOrganizations { get; set; }
        public virtual DbSet<ContactToOrganizationColumn> ContactToOrganizationColumns { get; set; }
        public virtual DbSet<ContactToOrganizationColumnChange> ContactToOrganizationColumnChanges { get; set; }
        public virtual DbSet<ContactType> ContactTypes { get; set; }
        public virtual DbSet<Contract> Contracts { get; set; }
        public virtual DbSet<ContractColumn> ContractColumns { get; set; }
        public virtual DbSet<ContractColumnChange> ContractColumnChanges { get; set; }
        public virtual DbSet<ContractOption> ContractOptions { get; set; }
        public virtual DbSet<Court> Courts { get; set; }
        public virtual DbSet<Disbursement> Disbursements { get; set; }
        public virtual DbSet<DisbursementsColumn> DisbursementsColumns { get; set; }
        public virtual DbSet<DisbursementsColumnChange> DisbursementsColumnChanges { get; set; }
        public virtual DbSet<DisbursementsOption> DisbursementsOptions { get; set; }
        public virtual DbSet<Document> Documents { get; set; }
        public virtual DbSet<DocumentColumn> DocumentColumns { get; set; }
        public virtual DbSet<DocumentColumnChange> DocumentColumnChanges { get; set; }
        public virtual DbSet<DocumentProcessing> DocumentProcessings { get; set; }
        public virtual DbSet<DocumentProcessingColumn> DocumentProcessingColumns { get; set; }
        public virtual DbSet<DocumentProcessingColumnChange> DocumentProcessingColumnChanges { get; set; }
        public virtual DbSet<DocumentProcessingOption> DocumentProcessingOptions { get; set; }
        public virtual DbSet<DocumentType> DocumentTypes { get; set; }
        public virtual DbSet<HardCost> HardCosts { get; set; }
        public virtual DbSet<HumanResource> HumanResources { get; set; }
        public virtual DbSet<HumanResourcesColumn> HumanResourcesColumns { get; set; }
        public virtual DbSet<HumanResourcesColumnChange> HumanResourcesColumnChanges { get; set; }
        public virtual DbSet<ImpactToClient> ImpactToClients { get; set; }
        public virtual DbSet<Incident> Incidents { get; set; }
        public virtual DbSet<IncidentColumn> IncidentColumns { get; set; }
        public virtual DbSet<IncidentColumnChange> IncidentColumnChanges { get; set; }
        public virtual DbSet<IncomingDocument> IncomingDocuments { get; set; }
        public virtual DbSet<IncomingDocumentColumn> IncomingDocumentColumns { get; set; }
        public virtual DbSet<IncomingDocumentColumnChange> IncomingDocumentColumnChanges { get; set; }
        public virtual DbSet<IncomingDocumentOption> IncomingDocumentOptions { get; set; }
        public virtual DbSet<Invoice> Invoices { get; set; }
        public virtual DbSet<InvoiceColumn> InvoiceColumns { get; set; }
        public virtual DbSet<InvoiceColumnChange> InvoiceColumnChanges { get; set; }
        public virtual DbSet<lkp_ParameterType> lkp_ParameterType { get; set; }
        public virtual DbSet<Log> Logs { get; set; }
        public virtual DbSet<Lookup> Lookups { get; set; }
        public virtual DbSet<LookupType> LookupTypes { get; set; }
        public virtual DbSet<Mailing> Mailings { get; set; }
        public virtual DbSet<MailingColumn> MailingColumns { get; set; }
        public virtual DbSet<MailingColumnChange> MailingColumnChanges { get; set; }
        public virtual DbSet<MailingDetail> MailingDetails { get; set; }
        public virtual DbSet<MailingDetailColumn> MailingDetailColumns { get; set; }
        public virtual DbSet<MailingDetailColumnChange> MailingDetailColumnChanges { get; set; }
        public virtual DbSet<MailingDetailOption> MailingDetailOptions { get; set; }
        public virtual DbSet<MailingOption> MailingOptions { get; set; }
        public virtual DbSet<Milestone> Milestones { get; set; }
        public virtual DbSet<MilestoneColumn> MilestoneColumns { get; set; }
        public virtual DbSet<MilestoneColumnChange> MilestoneColumnChanges { get; set; }
        public virtual DbSet<MonthlyInvoiceAmount> MonthlyInvoiceAmounts { get; set; }
        public virtual DbSet<MonthlyInvoiceAmountColumn> MonthlyInvoiceAmountColumns { get; set; }
        public virtual DbSet<MonthlyInvoiceAmountColumnChange> MonthlyInvoiceAmountColumnChanges { get; set; }
        public virtual DbSet<Note> Notes { get; set; }
        public virtual DbSet<NoteColumn> NoteColumns { get; set; }
        public virtual DbSet<NoteColumnChange> NoteColumnChanges { get; set; }
        public virtual DbSet<NoteType> NoteTypes { get; set; }
        public virtual DbSet<OperationsClaim> OperationsClaims { get; set; }
        public virtual DbSet<OperationsClaimColumn> OperationsClaimColumns { get; set; }
        public virtual DbSet<OperationsClaimColumnChange> OperationsClaimColumnChanges { get; set; }
        public virtual DbSet<Organization> Organizations { get; set; }
        public virtual DbSet<OrganizationColumn> OrganizationColumns { get; set; }
        public virtual DbSet<OrganizationColumnChange> OrganizationColumnChanges { get; set; }
        public virtual DbSet<ProjectRole> ProjectRoles { get; set; }
        public virtual DbSet<Query> Queries { get; set; }
        public virtual DbSet<QueryLog> QueryLogs { get; set; }
        public virtual DbSet<QueryParameter> QueryParameters { get; set; }
        public virtual DbSet<QueryParameterValue> QueryParameterValues { get; set; }
        public virtual DbSet<Report> Reports { get; set; }
        public virtual DbSet<RiskMatrix> RiskMatrices { get; set; }
        public virtual DbSet<RiskMatrixColumn> RiskMatrixColumns { get; set; }
        public virtual DbSet<RiskMatrixColumnChange> RiskMatrixColumnChanges { get; set; }
        public virtual DbSet<RiskMatrixOption> RiskMatrixOptions { get; set; }
        public virtual DbSet<ShutdownAndRetention> ShutdownAndRetentions { get; set; }
        public virtual DbSet<ShutdownAndRetentionColumn> ShutdownAndRetentionColumns { get; set; }
        public virtual DbSet<ShutdownAndRetentionColumnChange> ShutdownAndRetentionColumnChanges { get; set; }
        public virtual DbSet<ShutdownAndRetentionOption> ShutdownAndRetentionOptions { get; set; }
        public virtual DbSet<StatusUpdate> StatusUpdates { get; set; }
        public virtual DbSet<StatusUpdateColumn> StatusUpdateColumns { get; set; }
        public virtual DbSet<StatusUpdateColumnChange> StatusUpdateColumnChanges { get; set; }
        public virtual DbSet<QuickSearchSortPriority> QuickSearchSortPriorities { get; set; }
        public virtual DbSet<SearchReportControlType> SearchReportControlTypes { get; set; }
        public virtual DbSet<SearchReportCriteriaFilter> SearchReportCriteriaFilters { get; set; }
        public virtual DbSet<SearchReportCriteriaItem> SearchReportCriteriaItems { get; set; }
        public virtual DbSet<SearchReportCriteriaItemDetail> SearchReportCriteriaItemDetails { get; set; }
        public virtual DbSet<SearchReportListItem> SearchReportListItems { get; set; }
        public virtual DbSet<SearchReportQuery> SearchReportQueries { get; set; }
        public virtual DbSet<SearchReportResultItem> SearchReportResultItems { get; set; }
        public virtual DbSet<SearchReportTableSql> SearchReportTableSqls { get; set; }
        public virtual DbSet<SearchResultItemColumn> SearchResultItemColumns { get; set; }
        public virtual DbSet<SearchReportFilterListType> SearchReportFilterListTypes { get; set; }
        public virtual DbSet<CaseDetailToContact> CaseDetailToContacts { get; set; }
        public virtual DbSet<CaseNameInfo> CaseNameInfoes { get; set; }
        public virtual DbSet<ContactOrganization> ContactOrganizations { get; set; }
        public virtual DbSet<vwCaseDetailContact> vwCaseDetailContacts { get; set; }
        public virtual DbSet<CaseQuickSearchStringIndex> CaseQuickSearchStringIndexes { get; set; }
        public virtual DbSet<Search> Searches { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AuditLog>()
                .Property(e => e.Username)
                .IsUnicode(false);

            modelBuilder.Entity<AuditLog>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<AuditLog>()
                .Property(e => e.ClientIp)
                .IsUnicode(false);

            modelBuilder.Entity<AuditLog>()
                .Property(e => e.ClientUrl)
                .IsUnicode(false);

            modelBuilder.Entity<AuditLog>()
                .Property(e => e.AdditionalData)
                .IsUnicode(false);

            modelBuilder.Entity<AuditLog>()
                .Property(e => e.WebServerName)
                .IsUnicode(false);

            modelBuilder.Entity<AuditLog>()
                .Property(e => e.WebApiServerName)
                .IsUnicode(false);

            modelBuilder.Entity<BusinessLine>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<BusinessLine>()
                .HasMany(e => e.CaseDetails)
                .WithRequired(e => e.BusinessLine)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.CaseName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.PhoneNumber)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.Url)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.CourtCaption)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.CourtName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.BillingCode)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.CaseDescription)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.CaseEmail)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.ImportantMessage)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.SettlementAmountBenefit)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.CaseFolder)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.ZipCode)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.POBox)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetail>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.OperationsClaims)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.CaseDetailContacts)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.CaseHealths)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.CaseKickoffDetails)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.Claims)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.ContactCenters)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.Contracts)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.Disbursements)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.Documents)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.DocumentProcessings)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.HumanResources)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.Invoices)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.Mailings)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.Milestones)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.MonthlyInvoiceAmounts)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.RiskMatrices)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.ShutdownAndRetentions)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetail>()
                .HasMany(e => e.StatusUpdates)
                .WithRequired(e => e.CaseDetail)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseDetailColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailContact>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailContactColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailContactColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailContactColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailContactColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailContactColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealth>()
                .Property(e => e.Comment)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealth>()
                .Property(e => e.ActionPending)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealth>()
                .Property(e => e.Rating)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealth>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealth>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CaseHealthColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealthColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealthColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealthColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseHealthColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.NotesForClaims)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.NotesForDataServices)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.NotesForDisbursements)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.NotesForDocumentControl)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.NotesForEblast)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.NotesForMailings)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.NotesForPublication)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.RequestedImports)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.SpecialInstructions)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.SupportedLanguages)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetail>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<CaseKickoffDetailsColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetailsColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetailsColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetailsColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetailsColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetailsOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetailsOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CaseKickoffDetailsOption>()
                .HasMany(e => e.CaseKickoffDetails)
                .WithOptional(e => e.CaseKickoffDetailsOption)
                .HasForeignKey(e => e.AddressResearchProtocolOptionsId);

            modelBuilder.Entity<CaseKickoffDetailsOption>()
                .HasMany(e => e.CaseKickoffDetails1)
                .WithOptional(e => e.CaseKickoffDetailsOption1)
                .HasForeignKey(e => e.ApplicationNameOptionsId);

            modelBuilder.Entity<CaseKickoffDetailsOption>()
                .HasMany(e => e.CaseKickoffDetails2)
                .WithOptional(e => e.CaseKickoffDetailsOption2)
                .HasForeignKey(e => e.EnvironmentOptionsId);

            modelBuilder.Entity<CaseKickoffDetailsOption>()
                .HasMany(e => e.CaseKickoffDetails3)
                .WithOptional(e => e.CaseKickoffDetailsOption3)
                .HasForeignKey(e => e.NoticeAndClaimFormFormatOptionsId);

            modelBuilder.Entity<CaseStatu>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CaseStatu>()
                .HasMany(e => e.CaseDetails)
                .WithRequired(e => e.CaseStatu)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CaseType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CaseType>()
                .HasMany(e => e.CaseDetails)
                .WithRequired(e => e.CaseType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Claim>()
                .Property(e => e.SpecialServicingComments)
                .IsUnicode(false);

            modelBuilder.Entity<Claim>()
                .Property(e => e.SlaServicingComments)
                .IsUnicode(false);

            modelBuilder.Entity<Claim>()
                .Property(e => e.DefectLetterNotificationsTiming)
                .IsUnicode(false);

            modelBuilder.Entity<Claim>()
                .Property(e => e.SupportedLanguagesForClaims)
                .IsUnicode(false);

            modelBuilder.Entity<Claim>()
                .Property(e => e.DisbursementDateExceptions)
                .IsUnicode(false);

            modelBuilder.Entity<Claim>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Claim>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<ClaimColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ClaimOption>()
                .HasMany(e => e.Claims)
                .WithOptional(e => e.ClaimOption)
                .HasForeignKey(e => e.RangerEnvironmentOptionsId);

            modelBuilder.Entity<ClaimOption>()
                .HasMany(e => e.Claims1)
                .WithOptional(e => e.ClaimOption1)
                .HasForeignKey(e => e.ReissueScheduleOptionsId);

            modelBuilder.Entity<ClaimOption>()
                .HasMany(e => e.Claims2)
                .WithOptional(e => e.ClaimOption2)
                .HasForeignKey(e => e.TranslationPreferencesOptionsId);

            modelBuilder.Entity<Contact>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.MiddleInitial)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Url)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Phone1)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Phone2)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Phone3)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Address1)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Address2)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Zipcode)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.Country)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Contact>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<Contact>()
                .HasMany(e => e.CaseDetailContacts)
                .WithRequired(e => e.Contact)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Contact>()
                .HasMany(e => e.ContactToOrganizations)
                .WithRequired(e => e.Contact)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ContactCenter>()
                .Property(e => e.CaseNameinCMX)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenter>()
                .Property(e => e.ContractSlaNote)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenter>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenter>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<ContactCenterColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenterColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenterColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenterColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenterColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenterOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenterOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ContactCenterOption>()
                .HasMany(e => e.ContactCenters)
                .WithOptional(e => e.ContactCenterOption)
                .HasForeignKey(e => e.AgentsOptionsId);

            modelBuilder.Entity<ContactCenterOption>()
                .HasMany(e => e.ContactCenters1)
                .WithOptional(e => e.ContactCenterOption1)
                .HasForeignKey(e => e.ForeignLanguageCallCenterOptionsId);

            modelBuilder.Entity<ContactCenterOption>()
                .HasMany(e => e.ContactCenters2)
                .WithOptional(e => e.ContactCenterOption2)
                .HasForeignKey(e => e.ForeignLanguageIvrOptionsId);

            modelBuilder.Entity<ContactCenterOption>()
                .HasMany(e => e.ContactCenters3)
                .WithOptional(e => e.ContactCenterOption3)
                .HasForeignKey(e => e.OptionSuiteOptionsId);

            modelBuilder.Entity<ContactColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ContactToOrganization>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ContactToOrganizationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactToOrganizationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactToOrganizationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactToOrganizationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContactToOrganizationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ContactType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ContactType>()
                .HasMany(e => e.Contacts)
                .WithRequired(e => e.ContactType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Contract>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<Contract>()
                .Property(e => e.SpecialSlaDetails)
                .IsUnicode(false);

            modelBuilder.Entity<Contract>()
                .Property(e => e.Comments)
                .IsUnicode(false);

            modelBuilder.Entity<Contract>()
                .Property(e => e.EstimatedRevenue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Contract>()
                .Property(e => e.CapAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Contract>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Contract>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<ContractColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContractColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ContractColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContractColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<ContractColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ContractOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<ContractOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ContractOption>()
                .HasMany(e => e.Contracts)
                .WithOptional(e => e.ContractOption)
                .HasForeignKey(e => e.CategoryOptionsId);

            modelBuilder.Entity<Court>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Disbursement>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Disbursement>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<DisbursementsColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DisbursementsColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DisbursementsColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<DisbursementsColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<DisbursementsColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DisbursementsOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<DisbursementsOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<DisbursementsOption>()
                .HasMany(e => e.Disbursements)
                .WithOptional(e => e.DisbursementsOption)
                .HasForeignKey(e => e.AwardTypeOptionsId);

            modelBuilder.Entity<DisbursementsOption>()
                .HasMany(e => e.Disbursements1)
                .WithOptional(e => e.DisbursementsOption1)
                .HasForeignKey(e => e.DistributionScheduleOptionsId);

            modelBuilder.Entity<DisbursementsOption>()
                .HasMany(e => e.Disbursements2)
                .WithOptional(e => e.DisbursementsOption2)
                .HasForeignKey(e => e.ResidualFundOptionsId);

            modelBuilder.Entity<DisbursementsOption>()
                .HasMany(e => e.Disbursements3)
                .WithOptional(e => e.DisbursementsOption3)
                .HasForeignKey(e => e.TaxReportingOptionsId);

            modelBuilder.Entity<DisbursementsOption>()
                .HasMany(e => e.Disbursements4)
                .WithOptional(e => e.DisbursementsOption4)
                .HasForeignKey(e => e.TaxVendorOptionsId);

            modelBuilder.Entity<Document>()
                .Property(e => e.FileName)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.DisplayName)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.Owner)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<DocumentColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessing>()
                .Property(e => e.NonStandardMonths)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessing>()
                .Property(e => e.DcSpecialInstructions)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessing>()
                .Property(e => e.DeSpecialInstructions)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessing>()
                .Property(e => e.SpecialReportingRequirements)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessing>()
                .Property(e => e.FaxInboxEmail)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessing>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessing>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<DocumentProcessing>()
                .HasMany(e => e.IncomingDocuments)
                .WithRequired(e => e.DocumentProcessing)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<DocumentProcessingColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessingColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessingColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessingColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessingColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessingOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessingOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentProcessingOption>()
                .HasMany(e => e.DocumentProcessings)
                .WithOptional(e => e.DocumentProcessingOption)
                .HasForeignKey(e => e.DcSlaOptionsId);

            modelBuilder.Entity<DocumentProcessingOption>()
                .HasMany(e => e.DocumentProcessings1)
                .WithOptional(e => e.DocumentProcessingOption1)
                .HasForeignKey(e => e.DeSlaOptionsId);

            modelBuilder.Entity<DocumentProcessingOption>()
                .HasMany(e => e.DocumentProcessings2)
                .WithOptional(e => e.DocumentProcessingOption2)
                .HasForeignKey(e => e.DeTypeOptionsId);

            modelBuilder.Entity<DocumentProcessingOption>()
                .HasMany(e => e.DocumentProcessings3)
                .WithOptional(e => e.DocumentProcessingOption3)
                .HasForeignKey(e => e.IntakeTypeOptionsId);

            modelBuilder.Entity<DocumentProcessingOption>()
                .HasMany(e => e.DocumentProcessings4)
                .WithOptional(e => e.DocumentProcessingOption4)
                .HasForeignKey(e => e.UndeliverableCheckOptionsId);

            modelBuilder.Entity<DocumentType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentType>()
                .HasMany(e => e.Documents)
                .WithRequired(e => e.DocumentType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<HardCost>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<HumanResource>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<HumanResource>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<HumanResourcesColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<HumanResourcesColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<HumanResourcesColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<HumanResourcesColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<HumanResourcesColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ImpactToClient>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Incident>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Incident>()
                .Property(e => e.Owner)
                .IsUnicode(false);

            modelBuilder.Entity<Incident>()
                .Property(e => e.RootCauseDescription)
                .IsUnicode(false);

            modelBuilder.Entity<Incident>()
                .Property(e => e.ClientResolution)
                .IsUnicode(false);

            modelBuilder.Entity<Incident>()
                .Property(e => e.InternalResolution)
                .IsUnicode(false);

            modelBuilder.Entity<Incident>()
                .Property(e => e.ActualCost)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Incident>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Incident>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<IncidentColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<IncidentColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<IncidentColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<IncidentColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<IncidentColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocument>()
                .Property(e => e.IncomingDocumentTypeOther)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocument>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocument>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<IncomingDocumentColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocumentColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocumentColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocumentColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocumentColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocumentOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocumentOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<IncomingDocumentOption>()
                .HasMany(e => e.IncomingDocuments)
                .WithOptional(e => e.IncomingDocumentOption)
                .HasForeignKey(e => e.IncomingDocumentTypeOptionsId);

            modelBuilder.Entity<IncomingDocumentOption>()
                .HasMany(e => e.IncomingDocuments1)
                .WithOptional(e => e.IncomingDocumentOption1)
                .HasForeignKey(e => e.ProcessingTypeOptionsId);

            modelBuilder.Entity<Invoice>()
                .Property(e => e.Amount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Invoice>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Invoice>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<InvoiceColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<InvoiceColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<InvoiceColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<InvoiceColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<InvoiceColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<lkp_ParameterType>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.Level)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.Message)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.StackTrace)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.Username)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.ClientIp)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.ClientUrl)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.AdditionalData)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.WebServerName)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.WebApiServerName)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .Property(e => e.SubsystemName)
                .IsUnicode(false);

            modelBuilder.Entity<Lookup>()
                .Property(e => e.LookupType)
                .IsUnicode(false);

            modelBuilder.Entity<Lookup>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Lookup>()
                .HasMany(e => e.Incidents)
                .WithOptional(e => e.Lookup)
                .HasForeignKey(e => e.IncidentStatusId);

            modelBuilder.Entity<Lookup>()
                .HasMany(e => e.OperationsClaims)
                .WithRequired(e => e.Lookup)
                .HasForeignKey(e => e.OptionSuiteID)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<LookupType>()
                .Property(e => e.LookupTypeName)
                .IsUnicode(false);

            modelBuilder.Entity<LookupType>()
                .HasMany(e => e.Lookups)
                .WithRequired(e => e.LookupType1)
                .HasForeignKey(e => e.LookupType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Mailing>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Mailing>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<Mailing>()
                .HasMany(e => e.MailingDetails)
                .WithRequired(e => e.Mailing)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MailingColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MailingColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MailingColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MailingColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MailingColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetail>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetail>()
                .Property(e => e.PackageContent)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetail>()
                .Property(e => e.DropSchedule)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetail>()
                .Property(e => e.EstimatedPostageRate)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetail>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetail>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MailingDetailColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetailColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetailColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetailColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetailColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetailOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetailOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<MailingDetailOption>()
                .HasMany(e => e.MailingDetails)
                .WithOptional(e => e.MailingDetailOption)
                .HasForeignKey(e => e.AssignedPostageRateOptionsId);

            modelBuilder.Entity<MailingDetailOption>()
                .HasMany(e => e.MailingDetails1)
                .WithOptional(e => e.MailingDetailOption1)
                .HasForeignKey(e => e.MailingFulfillmentFrequencyOptionsId);

            modelBuilder.Entity<MailingOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<MailingOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<MailingOption>()
                .HasMany(e => e.Mailings)
                .WithOptional(e => e.MailingOption)
                .HasForeignKey(e => e.PoBoxOptionsId);

            modelBuilder.Entity<Milestone>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Milestone>()
                .Property(e => e.Owner)
                .IsUnicode(false);

            modelBuilder.Entity<Milestone>()
                .Property(e => e.RelatedSR)
                .IsUnicode(false);

            modelBuilder.Entity<Milestone>()
                .Property(e => e.SRStatus)
                .IsUnicode(false);

            modelBuilder.Entity<Milestone>()
                .Property(e => e.Note)
                .IsUnicode(false);

            modelBuilder.Entity<Milestone>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Milestone>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<MilestoneColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MilestoneColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MilestoneColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MilestoneColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MilestoneColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MonthlyInvoiceAmount>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<MonthlyInvoiceAmount>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<MonthlyInvoiceAmountColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MonthlyInvoiceAmountColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<MonthlyInvoiceAmountColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<MonthlyInvoiceAmountColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<MonthlyInvoiceAmountColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Note>()
                .Property(e => e.Content)
                .IsUnicode(false);

            modelBuilder.Entity<Note>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<NoteColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<NoteColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<NoteColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<NoteColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<NoteColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<NoteType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<NoteType>()
                .HasMany(e => e.Notes)
                .WithRequired(e => e.NoteType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<OperationsClaim>()
                .Property(e => e.ClaimsOpsActingSupervisor)
                .IsUnicode(false);

            modelBuilder.Entity<OperationsClaim>()
                .Property(e => e.ClaimsOpsPointOfContact)
                .IsUnicode(false);

            modelBuilder.Entity<OperationsClaim>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<OperationsClaimColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<OperationsClaimColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<OperationsClaimColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<OperationsClaimColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<OperationsClaimColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Organization>()
                .Property(e => e.OrganizationName)
                .IsUnicode(false);

            modelBuilder.Entity<Organization>()
                .Property(e => e.WebAddress)
                .IsUnicode(false);

            modelBuilder.Entity<Organization>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<Organization>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<Organization>()
                .HasMany(e => e.ContactToOrganizations)
                .WithRequired(e => e.Organization)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<OrganizationColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<OrganizationColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<OrganizationColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<OrganizationColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<OrganizationColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ProjectRole>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ProjectRole>()
                .HasMany(e => e.CaseDetailContacts)
                .WithRequired(e => e.ProjectRole)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Query>()
                .Property(e => e.QueryName)
                .IsUnicode(false);

            modelBuilder.Entity<Query>()
                .Property(e => e.SPName)
                .IsUnicode(false);

            modelBuilder.Entity<Query>()
                .Property(e => e.Right)
                .IsUnicode(false);

            modelBuilder.Entity<Query>()
                .HasMany(e => e.QueryParameters)
                .WithRequired(e => e.Query)
                .HasForeignKey(e => e.fk_QueryID)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<QueryLog>()
                .Property(e => e.fk_UserID)
                .IsUnicode(false);

            modelBuilder.Entity<QueryLog>()
                .Property(e => e.SPName)
                .IsUnicode(false);

            modelBuilder.Entity<QueryParameter>()
                .Property(e => e.ParamName)
                .IsUnicode(false);

            modelBuilder.Entity<QueryParameter>()
                .Property(e => e.ParamNameForUser)
                .IsUnicode(false);

            modelBuilder.Entity<QueryParameter>()
                .Property(e => e.ParamDefValue)
                .IsUnicode(false);

            modelBuilder.Entity<QueryParameter>()
                .HasMany(e => e.QueryParameterValues)
                .WithRequired(e => e.QueryParameter)
                .HasForeignKey(e => e.fk_QueryParameterID)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<QueryParameterValue>()
                .Property(e => e.ParameterValue)
                .IsUnicode(false);

            modelBuilder.Entity<Report>()
                .Property(e => e.ReportName)
                .IsUnicode(false);

            modelBuilder.Entity<Report>()
                .Property(e => e.URL)
                .IsUnicode(false);

            modelBuilder.Entity<Report>()
                .Property(e => e.Right)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrix>()
                .Property(e => e.DescriptionOfConsequence)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrix>()
                .Property(e => e.MitigationPlan)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrix>()
                .Property(e => e.Owner)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrix>()
                .Property(e => e.RiskDescription)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrix>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrix>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<RiskMatrixColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrixColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrixColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrixColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrixColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrixOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrixOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<RiskMatrixOption>()
                .HasMany(e => e.RiskMatrices)
                .WithRequired(e => e.RiskMatrixOption)
                .HasForeignKey(e => e.DepartmentId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<RiskMatrixOption>()
                .HasMany(e => e.RiskMatrices1)
                .WithOptional(e => e.RiskMatrixOption1)
                .HasForeignKey(e => e.RiskCategoryId);

            modelBuilder.Entity<ShutdownAndRetention>()
                .Property(e => e.NonStandardExplanation)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetention>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetention>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<ShutdownAndRetentionColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetentionColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetentionColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetentionColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetentionColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .Property(e => e.Type)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions)
                .WithOptional(e => e.ShutdownAndRetentionOption)
                .HasForeignKey(e => e.AdministrativeRecordsOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions1)
                .WithOptional(e => e.ShutdownAndRetentionOption1)
                .HasForeignKey(e => e.ClaimantRecordsOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions2)
                .WithOptional(e => e.ShutdownAndRetentionOption2)
                .HasForeignKey(e => e.CloseDisbursementAccountsOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions3)
                .WithOptional(e => e.ShutdownAndRetentionOption3)
                .HasForeignKey(e => e.DigitalImagesOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions4)
                .WithOptional(e => e.ShutdownAndRetentionOption4)
                .HasForeignKey(e => e.DisableIVROptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions5)
                .WithOptional(e => e.ShutdownAndRetentionOption5)
                .HasForeignKey(e => e.DisableWebsiteOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions6)
                .WithOptional(e => e.ShutdownAndRetentionOption6)
                .HasForeignKey(e => e.DistributionRecordsOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions7)
                .WithOptional(e => e.ShutdownAndRetentionOption7)
                .HasForeignKey(e => e.EpiqOwnedMediaOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions8)
                .WithOptional(e => e.ShutdownAndRetentionOption8)
                .HasForeignKey(e => e.ExternalPortableMediaOptionsId);

            modelBuilder.Entity<ShutdownAndRetentionOption>()
                .HasMany(e => e.ShutdownAndRetentions9)
                .WithOptional(e => e.ShutdownAndRetentionOption9)
                .HasForeignKey(e => e.MailingsInventoryOptionsId);

            modelBuilder.Entity<StatusUpdate>()
                .Property(e => e.Comment)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdate>()
                .Property(e => e.KeyStats)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdate>()
                .Property(e => e.Rating)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdate>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdate>()
                .Property(e => e.ts)
                .IsFixedLength();

            modelBuilder.Entity<StatusUpdateColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdateColumnChange>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdateColumnChange>()
                .Property(e => e.OldValue)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdateColumnChange>()
                .Property(e => e.NewValue)
                .IsUnicode(false);

            modelBuilder.Entity<StatusUpdateColumnChange>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<QuickSearchSortPriority>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportControlType>()
                .Property(e => e.ControlType)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportControlType>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.Display)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.ComparisonOperator)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.FormatString)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaFilter>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItem>()
                .Property(e => e.PropertyName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItem>()
                .Property(e => e.DisplayName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItem>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.TableName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.TableAlias)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.FieldName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.FormatString)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.JoinClause)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.GroupByClause)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.StoredProcName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportCriteriaItemDetail>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.ListItemText)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.ListItemValue)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.TableSource)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.FieldSource)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.SqlSource)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportListItem>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.Query)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.CountQuery)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.SearchViewModel)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.LastAccessed)
                .HasPrecision(0);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportQuery>()
                .Property(e => e.Columns)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportResultItem>()
                .Property(e => e.FieldName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportResultItem>()
                .Property(e => e.FieldAlias)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportResultItem>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.FromSql)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.DecryptionOpenText)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.DecryptionCloseText)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportTableSql>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.TableName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.ColumnName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.AliasName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.DisplayName)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.Permission)
                .IsUnicode(false);

            modelBuilder.Entity<SearchResultItemColumn>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportFilterListType>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<SearchReportFilterListType>()
                .Property(e => e.UpdatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.CaseName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.OrganizationName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.MiddleInitial)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.ContactName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Address1)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Address2)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Zipcode)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Country)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Phone1)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Phone2)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Phone3)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.ProjectRole)
                .IsUnicode(false);

            modelBuilder.Entity<CaseDetailToContact>()
                .Property(e => e.ContactType)
                .IsUnicode(false);

            modelBuilder.Entity<CaseNameInfo>()
                .Property(e => e.CaseName)
                .IsUnicode(false);

            modelBuilder.Entity<CaseNameInfo>()
                .Property(e => e.BillingCode)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.MiddleInitial)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.OrganizationName)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.WebAddress)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.ContactType)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.Phone1)
                .IsUnicode(false);

            modelBuilder.Entity<ContactOrganization>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.ProjectRolej)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.ContactTypeName)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.ContactName)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.MiddleInitial)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Url)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Phone1)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Phone2)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Phone3)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Address1)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Address2)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Zipcode)
                .IsUnicode(false);

            modelBuilder.Entity<vwCaseDetailContact>()
                .Property(e => e.Country)
                .IsUnicode(false);

            modelBuilder.Entity<CaseQuickSearchStringIndex>()
                .Property(e => e.VALUE)
                .IsUnicode(false);

            modelBuilder.Entity<CaseQuickSearchStringIndex>()
                .Property(e => e.MatchedColumn)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CaseName)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CaseType)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.BusinessLine)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CaseStatus)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.SettlementAmountBenefit)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CaseURL)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.PhoneNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.ClassPeriod)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.BillingCode)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CaseDescription)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CourtCaption)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.CaseFolder)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.ContactName)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.OrganizationName)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.ProjectRole)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.TaxVendor)
                .IsUnicode(false);

            modelBuilder.Entity<Search>()
                .Property(e => e.TaxReporting)
                .IsUnicode(false);
        }
    }
}
