namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchReportCriteriaFilter")]
    public partial class SearchReportCriteriaFilter
    {
        public int SearchReportCriteriaFilterId { get; set; }

        public int SearchReportFilterListTypeId { get; set; }

        [Required]
        [StringLength(25)]
        public string Code { get; set; }

        [Required]
        [StringLength(30)]
        public string Display { get; set; }

        [Required]
        [StringLength(15)]
        public string ComparisonOperator { get; set; }

        [Required]
        [StringLength(20)]
        public string FormatString { get; set; }

        public int DisplayOrder { get; set; }

        public bool AutoProcess { get; set; }

        public bool? RequiresElevatedRights { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }
    }
}
