namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ShutdownAndRetentionOption")]
    public partial class ShutdownAndRetentionOption
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ShutdownAndRetentionOption()
        {
            ShutdownAndRetentions = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions1 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions2 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions3 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions4 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions5 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions6 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions7 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions8 = new HashSet<ShutdownAndRetention>();
            ShutdownAndRetentions9 = new HashSet<ShutdownAndRetention>();
        }

        public int ShutdownAndRetentionOptionId { get; set; }

        [Required]
        [StringLength(250)]
        public string Type { get; set; }

        [Required]
        [StringLength(250)]
        public string Name { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions2 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions3 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions4 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions5 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions6 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions7 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions8 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions9 { get; set; }
    }
}
