namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchReportTableSql")]
    public partial class SearchReportTableSql
    {
        public int SearchReportTableSqlId { get; set; }

        [Required]
        [StringLength(8000)]
        public string FromSql { get; set; }

        public bool UseTopStatement { get; set; }

        public int TopValue { get; set; }

        public bool UseDecryption { get; set; }

        [StringLength(100)]
        public string DecryptionOpenText { get; set; }

        [StringLength(100)]
        public string DecryptionCloseText { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }
    }
}
