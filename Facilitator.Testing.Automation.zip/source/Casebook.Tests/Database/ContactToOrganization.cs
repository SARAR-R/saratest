namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ContactToOrganization")]
    public partial class ContactToOrganization
    {
        public int ContactToOrganizationId { get; set; }

        public int ContactId { get; set; }

        public int OrganizationId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual Contact Contact { get; set; }

        public virtual Organization Organization { get; set; }
    }
}
