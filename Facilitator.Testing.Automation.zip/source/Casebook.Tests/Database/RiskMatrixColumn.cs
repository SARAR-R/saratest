namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("RiskMatrixColumn")]
    public partial class RiskMatrixColumn
    {
        public int RiskMatrixColumnId { get; set; }

        [Required]
        [StringLength(50)]
        public string ColumnName { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
