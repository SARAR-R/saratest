namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AuditLog")]
    public partial class AuditLog
    {
        public int Id { get; set; }

        public DateTime Date { get; set; }

        [Required]
        [StringLength(50)]
        public string Username { get; set; }

        [Required]
        [StringLength(50)]
        public string Type { get; set; }

        [Required]
        [StringLength(20)]
        public string ClientIp { get; set; }

        [StringLength(500)]
        public string ClientUrl { get; set; }

        public int? TrackingNumber { get; set; }

        public string AdditionalData { get; set; }

        [StringLength(100)]
        public string WebServerName { get; set; }

        [StringLength(100)]
        public string WebApiServerName { get; set; }

        public double? ExecutionTime { get; set; }
    }
}
