namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("QueryParameterValue")]
    public partial class QueryParameterValue
    {
        [Key]
        public int pk_QueryParameterValueID { get; set; }

        public int fk_QueryParameterID { get; set; }

        [Required]
        [StringLength(100)]
        public string ParameterValue { get; set; }

        public int SortOrder { get; set; }

        public virtual QueryParameter QueryParameter { get; set; }
    }
}
