namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ShutdownAndRetention")]
    public partial class ShutdownAndRetention
    {
        public int ShutdownAndRetentionId { get; set; }

        public int CaseDetailId { get; set; }

        public int? ClaimantRecordsOptionsId { get; set; }

        public int? ClaimantRecordsNonStandardNumberOfMonths { get; set; }

        public int? MailingsInventoryOptionsId { get; set; }

        public int? MailingsInventoryNonStandardNumberOfMonths { get; set; }

        public int? AdministrativeRecordsOptionsId { get; set; }

        public int? AdministrativeRecordsNonStandardNumberOfMonths { get; set; }

        public int? DistributionRecordsOptionsId { get; set; }

        public int? DistributionRecordsNonStandardNumberOfMonths { get; set; }

        public int? ExternalPortableMediaOptionsId { get; set; }

        public int? ExternalPortableMediaNonStandardNumberOfMonths { get; set; }

        public int? EpiqOwnedMediaOptionsId { get; set; }

        public int? EpiqOwnedMediaNonStandardNumberOfMonths { get; set; }

        public int? DigitalImagesOptionsId { get; set; }

        public int? DigitalImagesNonStandardNumberOfMonths { get; set; }

        public int? DisableWebsiteOptionsId { get; set; }

        public int? DisableWebsiteNonStandardNumberOfMonths { get; set; }

        public int? DisableIVROptionsId { get; set; }

        public int? DisableIVRNonStandardNumberOfMonths { get; set; }

        public int? CloseDisbursementAccountsOptionsId { get; set; }

        public int? CloseDisbursementAccountsNonStandardNumberOfMonths { get; set; }

        [StringLength(8000)]
        public string NonStandardExplanation { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption1 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption2 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption3 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption4 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption5 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption6 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption7 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption8 { get; set; }

        public virtual ShutdownAndRetentionOption ShutdownAndRetentionOption9 { get; set; }
    }
}
