namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Report")]
    public partial class Report
    {
        public int ReportId { get; set; }

        [Required]
        [StringLength(50)]
        public string ReportName { get; set; }

        [Required]
        [StringLength(250)]
        public string URL { get; set; }

        [StringLength(50)]
        public string Right { get; set; }
    }
}
