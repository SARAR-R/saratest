namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Claim")]
    public partial class Claim
    {
        public int ClaimId { get; set; }

        public int CaseDetailId { get; set; }

        public bool? EmailProcessing { get; set; }

        public bool? ClaimProcessing { get; set; }

        [Column(TypeName = "date")]
        public DateTime? OverallProcessingDueDate { get; set; }

        public bool? SpecialServicing { get; set; }

        [StringLength(8000)]
        public string SpecialServicingComments { get; set; }

        public bool? SpecialSlaForClaims { get; set; }

        [StringLength(8000)]
        public string SlaServicingComments { get; set; }

        public bool? ManualClearSearch { get; set; }

        public int? TranslationPreferencesOptionsId { get; set; }

        public int? RangerEnvironmentOptionsId { get; set; }

        public int? ReissueScheduleOptionsId { get; set; }

        public bool? Qa { get; set; }

        public bool? ClearSearch { get; set; }

        public bool? Correspondence { get; set; }

        public bool? SubmitViaFax { get; set; }

        public bool? SubmitViaEmail { get; set; }

        public bool? SubmitViaPaper { get; set; }

        public bool? SubmitViaWeb { get; set; }

        public bool? FormsAvailableMailOnly { get; set; }

        public bool? FormsAvailableOnRequest { get; set; }

        public bool? FormsAvailablePrintedOffWeb { get; set; }

        public bool? DefectLetterNotifications { get; set; }

        [StringLength(500)]
        public string DefectLetterNotificationsTiming { get; set; }

        [StringLength(500)]
        public string SupportedLanguagesForClaims { get; set; }

        [StringLength(500)]
        public string DisbursementDateExceptions { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual ClaimOption ClaimOption { get; set; }

        public virtual ClaimOption ClaimOption1 { get; set; }

        public virtual ClaimOption ClaimOption2 { get; set; }
    }
}
