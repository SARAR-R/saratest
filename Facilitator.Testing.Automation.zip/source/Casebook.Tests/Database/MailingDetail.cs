namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MailingDetail")]
    public partial class MailingDetail
    {
        public int MailingDetailId { get; set; }

        public int MailingId { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DropDate { get; set; }

        public int? MailingPopulation { get; set; }

        [StringLength(4000)]
        public string PackageContent { get; set; }

        public int? MailingFulfillmentFrequencyOptionsId { get; set; }

        public bool? DynamicImageCount { get; set; }

        public bool? Outsourced { get; set; }

        public bool? BrmPermittingRequired { get; set; }

        public bool? Foreign { get; set; }

        [StringLength(500)]
        public string DropSchedule { get; set; }

        [StringLength(100)]
        public string EstimatedPostageRate { get; set; }

        public int? AssignedPostageRateOptionsId { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual Mailing Mailing { get; set; }

        public virtual MailingDetailOption MailingDetailOption { get; set; }

        public virtual MailingDetailOption MailingDetailOption1 { get; set; }
    }
}
