namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CaseDetailToContact")]
    public partial class CaseDetailToContact
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CaseDetailContactId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CaseDetailId { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ContactId { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ContactTypeId { get; set; }

        public int? OrganizationId { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(500)]
        public string CaseName { get; set; }

        [Key]
        [Column(Order = 5)]
        public bool KeyContact { get; set; }

        [StringLength(100)]
        public string OrganizationName { get; set; }

        [Key]
        [Column(Order = 6)]
        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(1)]
        public string MiddleInitial { get; set; }

        [Key]
        [Column(Order = 7)]
        [StringLength(30)]
        public string LastName { get; set; }

        [Key]
        [Column(Order = 8)]
        [StringLength(56)]
        public string ContactName { get; set; }

        [StringLength(70)]
        public string Address1 { get; set; }

        [StringLength(70)]
        public string Address2 { get; set; }

        [StringLength(35)]
        public string City { get; set; }

        [StringLength(2)]
        public string State { get; set; }

        [StringLength(9)]
        public string Zipcode { get; set; }

        [StringLength(50)]
        public string Country { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        [StringLength(25)]
        public string Phone1 { get; set; }

        [StringLength(25)]
        public string Phone2 { get; set; }

        [StringLength(25)]
        public string Phone3 { get; set; }

        [StringLength(70)]
        public string Email { get; set; }

        [Key]
        [Column(Order = 9)]
        [StringLength(50)]
        public string ProjectRole { get; set; }

        [Key]
        [Column(Order = 10)]
        [StringLength(50)]
        public string ContactType { get; set; }

        [Key]
        [Column(Order = 11)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ProjectRoleId { get; set; }

        [Key]
        [Column(Order = 12)]
        public bool Internal { get; set; }
    }
}
