namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("QueryLog")]
    public partial class QueryLog
    {
        [Key]
        public int pk_QueryLogID { get; set; }

        [StringLength(20)]
        public string fk_UserID { get; set; }

        [StringLength(50)]
        public string SPName { get; set; }

        public string ParamXMl { get; set; }

        public DateTime? Started { get; set; }

        public DateTime? Finished { get; set; }

        [StringLength(4000)]
        public string Message { get; set; }
    }
}
