namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CaseDetailContact")]
    public partial class CaseDetailContact
    {
        public int CaseDetailContactId { get; set; }

        public int CaseDetailId { get; set; }

        public int ContactId { get; set; }

        public int ProjectRoleId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual Contact Contact { get; set; }

        public virtual ProjectRole ProjectRole { get; set; }
    }
}
