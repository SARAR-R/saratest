namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CaseKickoffDetailsOption")]
    public partial class CaseKickoffDetailsOption
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CaseKickoffDetailsOption()
        {
            CaseKickoffDetails = new HashSet<CaseKickoffDetail>();
            CaseKickoffDetails1 = new HashSet<CaseKickoffDetail>();
            CaseKickoffDetails2 = new HashSet<CaseKickoffDetail>();
            CaseKickoffDetails3 = new HashSet<CaseKickoffDetail>();
        }

        public int CaseKickoffDetailsOptionId { get; set; }

        [Required]
        [StringLength(250)]
        public string Type { get; set; }

        [Required]
        [StringLength(250)]
        public string Name { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseKickoffDetail> CaseKickoffDetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseKickoffDetail> CaseKickoffDetails1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseKickoffDetail> CaseKickoffDetails2 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseKickoffDetail> CaseKickoffDetails3 { get; set; }
    }
}
