namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("RiskMatrix")]
    public partial class RiskMatrix
    {
        public int RiskMatrixId { get; set; }

        public int CaseDetailId { get; set; }

        public int DepartmentId { get; set; }

        public string DescriptionOfConsequence { get; set; }

        public int? Impact { get; set; }

        public string MitigationPlan { get; set; }

        public bool NoRiskIdentified { get; set; }

        [StringLength(256)]
        public string Owner { get; set; }

        public int? Probability { get; set; }

        public int? RiskCategoryId { get; set; }

        public string RiskDescription { get; set; }

        public int? RiskNumber { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual RiskMatrixOption RiskMatrixOption { get; set; }

        public virtual RiskMatrixOption RiskMatrixOption1 { get; set; }
    }
}
