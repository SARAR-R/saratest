namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MonthlyInvoiceAmountColumn")]
    public partial class MonthlyInvoiceAmountColumn
    {
        public int MonthlyInvoiceAmountColumnId { get; set; }

        [Required]
        [StringLength(50)]
        public string ColumnName { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
