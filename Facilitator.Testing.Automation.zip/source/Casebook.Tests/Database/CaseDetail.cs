namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CaseDetail")]
    public partial class CaseDetail
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CaseDetail()
        {
            OperationsClaims = new HashSet<OperationsClaim>();
            CaseDetailContacts = new HashSet<CaseDetailContact>();
            CaseHealths = new HashSet<CaseHealth>();
            CaseKickoffDetails = new HashSet<CaseKickoffDetail>();
            Claims = new HashSet<Claim>();
            ContactCenters = new HashSet<ContactCenter>();
            Contracts = new HashSet<Contract>();
            Disbursements = new HashSet<Disbursement>();
            Documents = new HashSet<Document>();
            DocumentProcessings = new HashSet<DocumentProcessing>();
            HumanResources = new HashSet<HumanResource>();
            Incidents = new HashSet<Incident>();
            Invoices = new HashSet<Invoice>();
            Mailings = new HashSet<Mailing>();
            Milestones = new HashSet<Milestone>();
            MonthlyInvoiceAmounts = new HashSet<MonthlyInvoiceAmount>();
            RiskMatrices = new HashSet<RiskMatrix>();
            ShutdownAndRetentions = new HashSet<ShutdownAndRetention>();
            StatusUpdates = new HashSet<StatusUpdate>();
        }

        public int CaseDetailId { get; set; }

        public int CaseTypeId { get; set; }

        public int CaseStatusId { get; set; }

        public int BusinessLineId { get; set; }

        [Required]
        [StringLength(500)]
        public string CaseName { get; set; }

        [StringLength(15)]
        public string PhoneNumber { get; set; }

        public int? ClassSize { get; set; }

        public DateTime? ClassPeriodFrom { get; set; }

        public DateTime? ClassPeriodTo { get; set; }

        [Required]
        [StringLength(250)]
        public string Url { get; set; }

        public int SapContractCode { get; set; }

        public int? CaseNumber { get; set; }

        [Required]
        public string CourtCaption { get; set; }

        [StringLength(250)]
        public string CourtName { get; set; }

        [StringLength(50)]
        public string BillingCode { get; set; }

        [Required]
        public string CaseDescription { get; set; }

        public string CaseEmail { get; set; }

        public bool AllowMultipleEmails { get; set; }

        public bool FLSA { get; set; }

        public bool HIPAA { get; set; }

        public bool FISMA { get; set; }

        public bool SpecialReporting { get; set; }

        public bool StrategicCase { get; set; }

        public bool SendInterestLetter { get; set; }

        public bool LiveOperator { get; set; }

        [Required]
        public string ImportantMessage { get; set; }

        public string SettlementAmountBenefit { get; set; }

        public int? EstimatedNumberOfClaims { get; set; }

        [StringLength(256)]
        public string CaseFolder { get; set; }

        [StringLength(10)]
        public string ZipCode { get; set; }

        [StringLength(30)]
        public string POBox { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public virtual BusinessLine BusinessLine { get; set; }

        public virtual CaseStatu CaseStatu { get; set; }

        public virtual CaseType CaseType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<OperationsClaim> OperationsClaims { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseDetailContact> CaseDetailContacts { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseHealth> CaseHealths { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseKickoffDetail> CaseKickoffDetails { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Claim> Claims { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ContactCenter> ContactCenters { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Contract> Contracts { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Disbursement> Disbursements { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Document> Documents { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<DocumentProcessing> DocumentProcessings { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<HumanResource> HumanResources { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Incident> Incidents { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Invoice> Invoices { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Mailing> Mailings { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Milestone> Milestones { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MonthlyInvoiceAmount> MonthlyInvoiceAmounts { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RiskMatrix> RiskMatrices { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShutdownAndRetention> ShutdownAndRetentions { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<StatusUpdate> StatusUpdates { get; set; }
    }
}
