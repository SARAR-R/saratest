namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Disbursement
    {
        [Key]
        public int DisbursementsId { get; set; }

        public int CaseDetailId { get; set; }

        public int? AwardTypeOptionsId { get; set; }

        public int? TaxReportingOptionsId { get; set; }

        public int? TaxVendorOptionsId { get; set; }

        public int? DistributionScheduleOptionsId { get; set; }

        public int? ResidualFundOptionsId { get; set; }

        public bool? ForeignAddresses { get; set; }

        public bool? Deminimis { get; set; }

        public bool? Householding { get; set; }

        public bool? Withholding { get; set; }

        public bool? Qsf { get; set; }

        public bool? CustomEnvelope { get; set; }

        public bool? InsertWithCheck { get; set; }

        public bool? AttorneyPayment { get; set; }

        public bool? NamedPlaintiffAwards { get; set; }

        public bool? ReserveHoldback { get; set; }

        public bool? CustomReporting { get; set; }

        public bool? EpiqInvoicesPaidFromFund { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual DisbursementsOption DisbursementsOption { get; set; }

        public virtual DisbursementsOption DisbursementsOption1 { get; set; }

        public virtual DisbursementsOption DisbursementsOption2 { get; set; }

        public virtual DisbursementsOption DisbursementsOption3 { get; set; }

        public virtual DisbursementsOption DisbursementsOption4 { get; set; }
    }
}
