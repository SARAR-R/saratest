namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("OperationsClaim")]
    public partial class OperationsClaim
    {
        public int OperationsClaimID { get; set; }

        public int OptionSuiteID { get; set; }

        public int PercentageOfValidClaimsToBeReviewed { get; set; }

        public bool EmailProcessing { get; set; }

        [StringLength(256)]
        public string ClaimsOpsActingSupervisor { get; set; }

        [StringLength(256)]
        public string ClaimsOpsPointOfContact { get; set; }

        public int CaseDetailID { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual Lookup Lookup { get; set; }
    }
}
