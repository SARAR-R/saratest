namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.Search")]
    public partial class Search
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CaseDetailId { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(500)]
        public string CaseName { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string CaseType { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(50)]
        public string BusinessLine { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(50)]
        public string CaseStatus { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(50)]
        public string Status { get; set; }

        public int? CaseNumber { get; set; }

        [Key]
        [Column(Order = 6)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int SapContractCode { get; set; }

        public string SettlementAmountBenefit { get; set; }

        [Key]
        [Column(Order = 7)]
        [StringLength(250)]
        public string CaseURL { get; set; }

        [StringLength(15)]
        public string PhoneNumber { get; set; }

        public int? ClassSize { get; set; }

        [Key]
        [Column(Order = 8)]
        [StringLength(63)]
        public string ClassPeriod { get; set; }

        [Column(TypeName = "date")]
        public DateTime? InitialNoticeMailingDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? OptOutDeadlineDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? InitialPaymentDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ClaimsDeadlineDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? PreliminaryApprovalGrantedDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ObjectionDeadlineDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? FinalApprovalHearingDate { get; set; }

        [StringLength(50)]
        public string BillingCode { get; set; }

        [Key]
        [Column(Order = 9)]
        public string CaseDescription { get; set; }

        [Key]
        [Column(Order = 10)]
        public string CourtCaption { get; set; }

        [Key]
        [Column(Order = 11)]
        public bool FLSA { get; set; }

        [Key]
        [Column(Order = 12)]
        public bool HIPAA { get; set; }

        [Key]
        [Column(Order = 13)]
        public bool FISMA { get; set; }

        [Key]
        [Column(Order = 14)]
        public bool SpecialReporting { get; set; }

        public int? EstimatedNumberOfClaims { get; set; }

        public string TechnicalProjectManager { get; set; }

        public string TechnicalProjectManagerPhone { get; set; }

        public string TechnicalProjectManagerEmail { get; set; }

        public string ProjectManager { get; set; }

        public string ProjectManagerPhone { get; set; }

        public string ProjectManagerEmail { get; set; }

        [StringLength(256)]
        public string CaseFolder { get; set; }

        [StringLength(56)]
        public string ContactName { get; set; }

        [StringLength(56)]
        public string FirstName { get; set; }

        [StringLength(56)]
        public string LastName { get; set; }

        public string OrganizationName { get; set; }

        [StringLength(50)]
        public string ProjectRole { get; set; }

        [StringLength(250)]
        public string TaxVendor { get; set; }

        [StringLength(250)]
        public string TaxReporting { get; set; }
    }
}
