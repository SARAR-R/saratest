namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ProjectRole")]
    public partial class ProjectRole
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ProjectRole()
        {
            CaseDetailContacts = new HashSet<CaseDetailContact>();
        }

        public int ProjectRoleId { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        public bool Internal { get; set; }

        public bool IsRequired { get; set; }

        public bool PreventSave { get; set; }

        public bool IsUniqueRequired { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CaseDetailContact> CaseDetailContacts { get; set; }
    }
}
