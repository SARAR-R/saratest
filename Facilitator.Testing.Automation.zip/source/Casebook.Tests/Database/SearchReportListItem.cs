namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchReportListItem")]
    public partial class SearchReportListItem
    {
        public int SearchReportListItemId { get; set; }

        [Required]
        [StringLength(100)]
        public string ListItemText { get; set; }

        [Required]
        [StringLength(100)]
        public string ListItemValue { get; set; }

        public int? SearchReportCriteriaItemId { get; set; }

        public bool LoadFromTable { get; set; }

        [StringLength(50)]
        public string TableSource { get; set; }

        [StringLength(50)]
        public string FieldSource { get; set; }

        public bool LoadFromSqlStatement { get; set; }

        public string SqlSource { get; set; }

        public int? SortOrder { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }
    }
}
