namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Milestone")]
    public partial class Milestone
    {
        public int MilestoneId { get; set; }

        public int CaseDetailId { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        public bool CourtOrdered { get; set; }

        public bool RequiredDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DueDate { get; set; }

        [StringLength(256)]
        public string Owner { get; set; }

        [StringLength(50)]
        public string RelatedSR { get; set; }

        public DateTime? SRCreateDate { get; set; }

        public DateTime? SRDueDate { get; set; }

        [StringLength(256)]
        public string SRStatus { get; set; }

        public bool ShowOnSummary { get; set; }

        public string Note { get; set; }

        public int? SortOrder { get; set; }

        public bool ClientOrdered { get; set; }

        public bool NotApplicable { get; set; }

        public bool DatePending { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }
    }
}
