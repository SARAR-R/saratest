namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("search.SearchReportResultItem")]
    public partial class SearchReportResultItem
    {
        public int SearchReportResultItemId { get; set; }

        [Required]
        [StringLength(1000)]
        public string FieldName { get; set; }

        [Required]
        [StringLength(100)]
        public string FieldAlias { get; set; }

        public int? OrderByOrdinal { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }
    }
}
