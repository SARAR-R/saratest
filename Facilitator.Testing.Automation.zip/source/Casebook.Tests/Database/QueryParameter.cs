namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("QueryParameter")]
    public partial class QueryParameter
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public QueryParameter()
        {
            QueryParameterValues = new HashSet<QueryParameterValue>();
        }

        [Key]
        public int pk_QueryParameterID { get; set; }

        public int fk_QueryID { get; set; }

        [Required]
        [StringLength(50)]
        public string ParamName { get; set; }

        [Required]
        [StringLength(50)]
        public string ParamNameForUser { get; set; }

        public int Fk_ParamTypeID { get; set; }

        [Required]
        [StringLength(250)]
        public string ParamDefValue { get; set; }

        public int Fk_ParamValueListTypeID { get; set; }

        public int SortOrder { get; set; }

        public virtual Query Query { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<QueryParameterValue> QueryParameterValues { get; set; }
    }
}
