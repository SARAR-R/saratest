namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Incident")]
    public partial class Incident
    {
        public int IncidentId { get; set; }

        public int? IncidentStatusId { get; set; }

        public int? ImpactToClientId { get; set; }

        public int? HardCostId { get; set; }

        public int? CaseDetailId { get; set; }

        public int? IncidentNumber { get; set; }

        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        public DateTime IncidentDate { get; set; }

        public DateTime? EstimatedIncidentDate { get; set; }

        [Required]
        [StringLength(256)]
        public string Owner { get; set; }

        [Required]
        public string RootCauseDescription { get; set; }

        public string ClientResolution { get; set; }

        public string InternalResolution { get; set; }

        [Column(TypeName = "money")]
        public decimal? ActualCost { get; set; }

        public bool? LessonsLearnedMeeting { get; set; }

        public bool? ClaimsOperationsResponsible { get; set; }

        public bool? ClientServicesResponsible { get; set; }

        public bool? ContactCenterResponsible { get; set; }

        public bool? CorporateServicesResponsible { get; set; }

        public bool? DataEntryResponsible { get; set; }

        public bool? DataServicesResponsible { get; set; }

        public bool? DisbursementsResponsible { get; set; }

        public bool? DocumentControlResponsible { get; set; }

        public bool? FileProcessingResponsible { get; set; }

        public bool? ITResponsible { get; set; }

        public bool? LegalNoticingResponsible { get; set; }

        public bool? MailingsResponsible { get; set; }

        public bool? PrintOperationsResponsible { get; set; }

        public bool? PrintServicesResponsible { get; set; }

        public bool? SalesDirectorResponsible { get; set; }

        public bool? SoftwareEngineeringResponsible { get; set; }

        public bool? TechnicalProjectManagementResponsible { get; set; }

        public bool? VendorResponsible { get; set; }

        public bool ApplicationDefectRootCause { get; set; }

        public bool ApplicationFunctionalityRootCause { get; set; }

        public bool CommunicationRootCause { get; set; }

        public bool HardwareInfrastructureRootCause { get; set; }

        public bool ManagementSupervisionRootCause { get; set; }

        public bool MaterialHandlingControlRootCause { get; set; }

        public bool NonIssueRootCause { get; set; }

        public bool OversightRootCause { get; set; }

        public bool PoliciesProceduresRootCause { get; set; }

        public bool ProcessNotFollowedRootCause { get; set; }

        public bool SkillLevelRootCause { get; set; }

        public bool ToolsEquipmentRootCause { get; set; }

        public bool TrainingKnowledgeTransferRootCause { get; set; }

        public bool WorkPlanningRootCause { get; set; }

        public bool? IndicatesTrend { get; set; }

        public bool? ImpactWouldBeGreaterIf { get; set; }

        public bool? SubjectivePoint { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual HardCost HardCost { get; set; }

        public virtual ImpactToClient ImpactToClient { get; set; }

        public virtual Lookup Lookup { get; set; }
    }
}
