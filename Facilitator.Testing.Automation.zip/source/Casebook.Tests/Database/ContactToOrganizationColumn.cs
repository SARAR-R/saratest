namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ContactToOrganizationColumn")]
    public partial class ContactToOrganizationColumn
    {
        public int ContactToOrganizationColumnId { get; set; }

        [Required]
        [StringLength(50)]
        public string ColumnName { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
