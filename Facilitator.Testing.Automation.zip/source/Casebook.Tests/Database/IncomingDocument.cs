namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("IncomingDocument")]
    public partial class IncomingDocument
    {
        public int IncomingDocumentId { get; set; }

        public int DocumentProcessingId { get; set; }

        public int? IncomingDocumentTypeOptionsId { get; set; }

        public int? ProcessingTypeOptionsId { get; set; }

        [StringLength(100)]
        public string IncomingDocumentTypeOther { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual DocumentProcessing DocumentProcessing { get; set; }

        public virtual IncomingDocumentOption IncomingDocumentOption { get; set; }

        public virtual IncomingDocumentOption IncomingDocumentOption1 { get; set; }
    }
}
