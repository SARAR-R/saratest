namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Note")]
    public partial class Note
    {
        public int NoteId { get; set; }

        public int NoteTypeId { get; set; }

        [Required]
        [StringLength(500)]
        public string Content { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual NoteType NoteType { get; set; }
    }
}
