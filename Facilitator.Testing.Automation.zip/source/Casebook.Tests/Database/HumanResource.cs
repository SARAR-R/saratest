namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class HumanResource
    {
        [Key]
        public int HumanResourcesId { get; set; }

        public int CaseDetailId { get; set; }

        public bool? DrugTesting { get; set; }

        public bool? BankruptcyScreening { get; set; }

        public bool? CreditCheck { get; set; }

        public bool? CriminalBackground { get; set; }

        public bool? AnnualComplianceTraining { get; set; }

        public bool? FingerPrint { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }
    }
}
