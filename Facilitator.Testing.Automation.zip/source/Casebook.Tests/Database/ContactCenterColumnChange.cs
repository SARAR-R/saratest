namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ContactCenterColumnChange")]
    public partial class ContactCenterColumnChange
    {
        public int ContactCenterColumnChangeId { get; set; }

        public int Id { get; set; }

        public DateTime ChangeDate { get; set; }

        [Required]
        [StringLength(50)]
        public string ColumnName { get; set; }

        public byte Action { get; set; }

        [StringLength(4000)]
        public string OldValue { get; set; }

        [StringLength(4000)]
        public string NewValue { get; set; }

        [StringLength(256)]
        public string UpdatedBy { get; set; }

        public int? Tracking_Number { get; set; }
    }
}
