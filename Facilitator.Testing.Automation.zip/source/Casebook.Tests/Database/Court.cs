namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Court")]
    public partial class Court
    {
        public int CourtId { get; set; }

        [Required]
        [StringLength(250)]
        public string Name { get; set; }
    }
}
