namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CaseKickoffDetail
    {
        [Key]
        public int CaseKickoffDetailsId { get; set; }

        public int CaseDetailId { get; set; }

        public int? AddressResearchProtocolOptionsId { get; set; }

        public int? ApplicationNameOptionsId { get; set; }

        public int? EnvironmentOptionsId { get; set; }

        [StringLength(8000)]
        public string NotesForClaims { get; set; }

        [StringLength(8000)]
        public string NotesForDataServices { get; set; }

        [StringLength(8000)]
        public string NotesForDisbursements { get; set; }

        [StringLength(8000)]
        public string NotesForDocumentControl { get; set; }

        [StringLength(8000)]
        public string NotesForEblast { get; set; }

        [StringLength(8000)]
        public string NotesForMailings { get; set; }

        [StringLength(8000)]
        public string NotesForPublication { get; set; }

        public int? NoticeAndClaimFormFormatOptionsId { get; set; }

        [StringLength(8000)]
        public string RequestedImports { get; set; }

        [StringLength(8000)]
        public string SpecialInstructions { get; set; }

        [StringLength(8000)]
        public string SupportedLanguages { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual CaseKickoffDetailsOption CaseKickoffDetailsOption { get; set; }

        public virtual CaseKickoffDetailsOption CaseKickoffDetailsOption1 { get; set; }

        public virtual CaseKickoffDetailsOption CaseKickoffDetailsOption2 { get; set; }

        public virtual CaseKickoffDetailsOption CaseKickoffDetailsOption3 { get; set; }
    }
}
