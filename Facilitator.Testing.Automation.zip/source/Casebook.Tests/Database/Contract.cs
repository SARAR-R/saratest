namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Contract")]
    public partial class Contract
    {
        public int ContractId { get; set; }

        public int CaseDetailId { get; set; }

        public int? CategoryOptionsId { get; set; }

        [StringLength(500)]
        public string Title { get; set; }

        [StringLength(500)]
        public string SpecialSlaDetails { get; set; }

        [StringLength(8000)]
        public string Comments { get; set; }

        [Column(TypeName = "money")]
        public decimal? EstimatedRevenue { get; set; }

        [Column(TypeName = "money")]
        public decimal? CapAmount { get; set; }

        [Column(TypeName = "date")]
        public DateTime? StartDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? CaseClosureDate { get; set; }

        public DateTime InsertedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        [Required]
        [StringLength(256)]
        public string UpdatedBy { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ts { get; set; }

        public bool? IsSetForDelete { get; set; }

        public virtual CaseDetail CaseDetail { get; set; }

        public virtual ContractOption ContractOption { get; set; }
    }
}
