namespace Casebook.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vwCaseDetailContact")]
    public partial class vwCaseDetailContact
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CaseDetailId { get; set; }

        [Key]
        [Column(Order = 1)]
        public bool KeyContact { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string ProjectRolej { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ContactId { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ContactTypeId { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(50)]
        public string ContactTypeName { get; set; }

        [Key]
        [Column(Order = 6)]
        [StringLength(56)]
        public string ContactName { get; set; }

        [Key]
        [Column(Order = 7)]
        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(1)]
        public string MiddleInitial { get; set; }

        [Key]
        [Column(Order = 8)]
        [StringLength(30)]
        public string LastName { get; set; }

        [StringLength(250)]
        public string Url { get; set; }

        [StringLength(25)]
        public string Phone1 { get; set; }

        [StringLength(25)]
        public string Phone2 { get; set; }

        [StringLength(25)]
        public string Phone3 { get; set; }

        [StringLength(70)]
        public string Email { get; set; }

        [StringLength(70)]
        public string Address1 { get; set; }

        [StringLength(70)]
        public string Address2 { get; set; }

        [StringLength(35)]
        public string City { get; set; }

        [StringLength(2)]
        public string State { get; set; }

        [StringLength(9)]
        public string Zipcode { get; set; }

        [StringLength(50)]
        public string Country { get; set; }
    }
}
