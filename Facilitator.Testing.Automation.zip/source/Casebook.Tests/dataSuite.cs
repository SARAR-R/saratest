﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Automation;
using System.Configuration;

namespace Casebook
{
    [TestClass]
    public class casebookDataSuite
    {
        public TestContext TestContext { get; set; }
        public int CaseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
        
        [TestInitialize]
        public void Startup()
        {
            //test.startup(TestContext);
        }

        [TestCleanup]
        public void Teardown()
        {
            //test.teardown();
        }

        [TestCategory("Data"), TestMethod]
        public void RandomizeData()
        {
            report.Step(Data.RandomizeMockData());
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateIncomingDocuments()
        {
            Data.PopulateIncomingDocuments(CaseDetailId); 
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateMailingDetail()
        {
            Data.PopulateMailingDetail(CaseDetailId);
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateProjectTeam()
        {
            Data.PopulateProjectTeam(CaseDetailId);
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateIncidents()
        {
            Data.PopulateIncidents();
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateReports()
        {
            Data.PopulateReports();
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateHealthStatusUpdates()
        {
            Data.PopulateHealthStatusUpdates(CaseDetailId);
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateInvoice()
        {
            Data.PopulateInvoice(CaseDetailId);
        }
        [TestCategory("Data"), TestMethod]
        public void PopulateDocuments()
        {
            Data.PopulateDocuments(CaseDetailId);
        }
    }
}
