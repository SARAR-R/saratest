﻿using System;
using System.Configuration;
using Automation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Casebook
{
    public class testHelper
    {
        public static string Url = ConfigurationManager.AppSettings.Get("url");
        public static string Username = ConfigurationManager.AppSettings.Get("username");
        public static string Password = ConfigurationManager.AppSettings.Get("password");

        public static string Start()
        {
            report.Step("Log in");
            Start(Url, Username, Password);
            return "success";
        }

        public static string Start(string username, string password)
        {
            report.Step("Log in");
            Start(Url, username, password);
            return "success";
        }

        public static string Start(int cid)
        {
            report.Step("Log in, load case");
            Start(Url, Username, Password);
            Automation.navigate.URL(ConfigurationManager.AppSettings.Get("url") + "/casesummary?cid=" + cid);
            return "success";
        }
   
        public static string Start(string username, string password, int cid)
        {
            report.Step("Log in, load case");
            Start(Url, username, password);
            Automation.navigate.URL(ConfigurationManager.AppSettings.Get("url") + "/casesummary?cid=" + cid);
            return "success";
        }

        public static string Start(string url, string username, string password)
        {
            report.Action("Navigate", url);

            test.driver.Navigate().GoToUrl(url);
            test.driver.Manage().Window.Maximize();
            //test.driver.Manage().Window.Size = new System.Drawing.Size(1280, 800);  //For troubleshooting mtm runs.

            string result;
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
            test.startTime();
            wait.Until(d => (d.FindElements(By.Name("username")).Count != 0));
            test.stopTime("01. Load Logon page");

            report.Action("Login", username);
            test.EditField(test.driver, By.Name("username"), username);
            System.Threading.Thread.Sleep(500);
            test.EditField(test.driver, By.Name("password"), password);

            System.Threading.Thread.Sleep(500);
            test.startTime();
            test.Click(test.driver, By.XPath("//button[@type='submit']"));


            //Wait for default page (i.e., standard search page) or validation error to render first before proceeding further
            for (int second = 0; ; second++)
            {
                if (second >= 60)
                {
                    Assert.Fail("timeout");
                }
                try
                {
                    result = test.driver.FindElement(By.CssSelector("span.text-danger.ng-binding")).Text;
                    if (result != "")
                    {
                        break;
                    }
                }
                catch (Exception)
                {
                    try
                    {
                        if (test.driver.FindElements(By.CssSelector("label.btn:nth-child(1)")).Count != 0)
                        {
                            result = "Success";
                            break;
                        }
                    }
                    catch (Exception e)
                    {
                        report.Fail("Login failed:", e);
                        test.GlobalFailureDescription = ("Login failed exception: " + e);
                    }
                }
                System.Threading.Thread.Sleep(1000);
            }
            test.stopTime("02. Logon");
            return result;
        }

        public static string Start2(string url, string username, string password)
        {
            report.Action("Navigate", url);

            test.driver.Navigate().GoToUrl(url);
            test.driver.Manage().Window.Maximize();
            //test.driver.Manage().Window.Size = new System.Drawing.Size(1280, 800);  //For troubleshooting mtm runs.

            string result;
            var wait = new WebDriverWait(test.driver, TimeSpan.FromSeconds(config.TIMEOUT));
            test.startTime();
            wait.Until(d => (d.FindElements(By.Name("username")).Count != 0));
            test.stopTime("01. Load Logon page");

            report.Action("Login", username);
            test.EditField(test.driver, By.Name("username"), username);
            System.Threading.Thread.Sleep(500);
            test.EditField(test.driver, By.Name("password"), password);

            System.Threading.Thread.Sleep(500);
            test.startTime();
            test.Click(test.driver, By.XPath("//button[@type='submit']"));


            //Wait for default page (i.e., standard search page) or validation error to render first before proceeding further
            for (int second = 0; ; second++)
            {
                if (second >= 60)
                {
                    Assert.Fail("timeout");
                }
                try
                {
                    result = test.driver.FindElement(By.CssSelector("span.text-danger.ng-binding")).Text;
                    if (result != "")
                    {
                        break;
                    }
                }
                catch (Exception)
                {
                    try
                    {
                        if (test.driver.FindElements(By.XPath("//div[@ng-style='rowStyle(row)']")).Count != 0)
                        {
                            result = "Success";
                            break;
                        }
                    }
                    catch (Exception e)
                    {
                        report.Fail("Login failed:", e);
                        test.GlobalFailureDescription = ("Login failed exception: " + e);
                    }
                }
                System.Threading.Thread.Sleep(1000);
            }
            test.stopTime("02. Logon");
            return result;
        }

        public static void End()
        {
            report.Step("Log out");
            test.Click(By.CssSelector("a.dropdown-toggle > span.ng-binding"));
            test.Click(By.LinkText("Logout"));
        }
    }    
    
}
