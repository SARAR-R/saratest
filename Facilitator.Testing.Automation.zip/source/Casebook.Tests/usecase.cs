﻿using System;
using System.Configuration;
using System.Linq;
using Automation;
using Facilitator.Template;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using config = Automation.config;

namespace Casebook
{
    [TestClass]
    public class usecase
    {
        public static void Logon()
        {
            try
            {
                report.Step("Verify page loads without error");
                Automation.navigate.URL(ConfigurationManager.AppSettings.Get("url"));
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));

                //Logon - Invalid
                report.Step("Verify invalid login");
                var result = Facilitator.Template.user.Login(test.driver, "Automation", "BadPassword");
                //Verify Access Denied
                Assert.IsTrue(result.Contains("Login was unsuccessful."));
                //Refresh page
                navigate.Refresh();

                //Logon - Valid
                report.Step("Verify valid login without errors");
                result = Facilitator.Template.user.Login(test.driver);
                //Verify Logged in
                Assert.AreEqual("Success", result);
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));

                testHelper.End();
            }
            catch (Exception e)
            {
                report.Fail("Error occurred with Logon test.", e);
            }
        }

        public static void Logout()
        {
            try
            {
                //Logon - Valid
                var result = Facilitator.Template.user.Login(test.driver);
                //Verify Logged in
                Assert.AreEqual("Success", result);

                //Log out
                report.Step("Verify logout without errors, and identity token removed");
                Facilitator.Template.user.Logout(test.driver);
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));
                test.vars.verify(test.VerifyCookie("identityData", false));

                //Navigate to a restricted page
                report.Step("Verify redirect to login page, unauthenticated access");
                //navigate.URL(driver, ConfigurationManager.AppSettings.Get("url") + "/standardsearch");
                Automation.navigate.URL(ConfigurationManager.AppSettings.Get("url") + "/techconfig");
                //Verify redirect to login
                test.vars.verify(test.VerifyURL(test.driver, ConfigurationManager.AppSettings.Get("url") + "/login"));

            }
            catch (Exception e)
            {
                report.Fail("Error occurred with Logout test.", e);
            }
        }

        public static void ChangePassword()
        {
            var username2 = ConfigurationManager.AppSettings.Get("username2");
            var password = ConfigurationManager.AppSettings.Get("password");
            var newPassword = ConfigurationManager.AppSettings.Get("new_password");

            try  //Change password for user "automation2"
            {
                Facilitator.Template.user.Login(test.driver, username2, password);

                report.Step("Verify user can change password without error");
                user.ChangePassword(test.driver, username2, password, newPassword);
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));
                user.Logout();

                report.Step("Verify old password rejected.");
                test.vars.verify(test.VerifyLogin(Facilitator.Template.user.Login(test.driver, username2, password), "Login was unsuccessful. The username or password is incorrect."));

                report.Step("Verify new password login without error");
                test.vars.verify(test.VerifyLogin(Facilitator.Template.user.Login(test.driver, username2, newPassword)));
                test.vars.verify(test.VerifyNoErrorToasts(test.driver));
                user.ChangePassword(test.driver, username2, newPassword, password);
                user.Logout();
            }
            catch (Exception e)  //most likely the user is stuck with the 2nd password hence changing it back to the default password
            {
                Facilitator.Template.user.Login(test.driver, username2, newPassword);
                user.ChangePassword(test.driver, username2, newPassword, password);
                user.Logout();
                report.Fail("Password has been reset back to default.  Please run test again. ", e);
                
            }
        }

        public static void QuickSearchAllFields()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));                 
            Data.PopulateQuickSearchFields(caseDetailId);
            Data.PopulateProjectTeam(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId);
            var contact = Data.GetContactDataByCase(caseDetailId);

            testHelper.Start();

            search.ValidateQuickSearch("caseName", "Case Name", caseDetail.First().CaseName, false);
            search.ValidateQuickSearch("url", "Case URL", caseDetail.First().Url, true);
            search.ValidateQuickSearch("sapContractCode", "SAP Contract Code", caseDetail.First().SapContractCode.ToString(), true);
            search.ValidateQuickSearch("billingCode", "Billing Code", caseDetail.First().BillingCode, false, true);
            search.ValidateQuickSearch("caseFolder", "Case Folder", caseDetail.First().CaseFolder, false, true);
            report.Step("Verify Quick Search by Contact Name (first)");
            var firstName = contact.First().FirstName;
            navigate.QuickSearch();
            test.EditField(search._QuickPageCriteria, firstName);
            test.Click(search._QuickPageSubmit);
            test.vars.verify(test.VerifyNoErrorToasts());
            search.SelectResultByIndex(1);
            test.Click(caseinfo._ContactsTab);
            test.EditField(caseinfo._ContactsTextFilter, firstName);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "First Name", firstName));
            report.Step("Verify Quick Search by Contact Name (last)");
            var lastName = contact.First().LastName;
            navigate.QuickSearch();
            test.EditField(search._QuickPageCriteria, lastName);
            test.Click(search._QuickPageSubmit);
            test.vars.verify(test.VerifyNoErrorToasts());
            search.SelectResultByIndex(1);
            test.Click(caseinfo._ContactsTab);
            test.EditField(caseinfo._ContactsTextFilter, lastName);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Last Name", lastName));

            testHelper.End();
        }

        public static void StandardSearchAllFields()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            Data.PopulateStandardSearchFields(caseDetailId);
            Data.PopulateProjectTeam(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId);
            var contact = Data.GetContactDataByCase(caseDetailId).OrderBy(l => l.LastName).ThenBy(f => f.FirstName);

            testHelper.Start();

            search.ValidateStandardSearchList("caseType", "Case Type", search._StandardOperatorCaseType, search._StandardFilterCaseType, "Equals", Data.GetCaseType(caseDetail.First().CaseTypeId).First().Name, false);
            search.ValidateStandardSearchList("businessLine", "Business Line", search._StandardOperatorBusinessLine, search._StandardFilterBusinessLine, "Equals", Data.GetBusinessLine(caseDetail.First().BusinessLineId).First().Name, true);
            search.ValidateStandardSearchInput("classSize", "Class Size", search._StandardOperatorClassSize, search._StandardFilterClassSize, "=", caseDetail.First().ClassSize.ToString(), true);
            search.ValidateStandardSearchInput("courtCaption", "Court Caption", search._StandardOperatorCourtCaption, search._StandardFilterCourtCaption, "Equals", caseDetail.First().CourtCaption, false, true, false);
            search.ValidateStandardSearchList("caseStatusId", "Status", search._StandardOperatorStatus, search._StandardFilterStatus, "Equals", Data.GetCaseStatus(caseDetail.First().CaseStatusId).First().Name, false);
            search.ValidateStandardSearchInput("settlementAmountBenefit", "Settlement Amount", search._StandardOperatorSettlement, search._StandardFilterSettlement, "Equals", caseDetail.First().SettlementAmountBenefit, true);
            search.ValidateStandardSearchInput("estimatedNumberOfClaims", "Estimated Number Of Claims", search._StandardOperatorEstimated, search._StandardFilterEstimated, "=", caseDetail.First().EstimatedNumberOfClaims.ToString(), false, true, false);
            search.ValidateStandardSearchInput("sapContractCode", "SAP Contract Code", search._StandardOperatorSAP, search._StandardFilterSAP, "=", caseDetail.First().SapContractCode.ToString(), true, false, false);
            //search.ValidateStandardSearchBool("signedAgreementPricing", search._StandardOperatorSignedAgreementPricing, search._StandardFilterSignedAgreementPricing, "=", caseDetail.First().SignedAgreementPricing.ToString(), false);  //DEL
            search.ValidateStandardSearchBool("flsa", search._StandardOperatorFLSA, search._StandardFilterFLSA, "=", caseDetail.First().FLSA.ToString(), false);
            search.ValidateStandardSearchBool("hipaa", search._StandardOperatorHIPAA, search._StandardFilterHIPAA, "=", caseDetail.First().HIPAA.ToString(), false);
            search.ValidateStandardSearchBool("fisma", search._StandardOperatorFISMA, search._StandardFilterFISMA, "=", caseDetail.First().FISMA.ToString(), false);
            //search.ValidateStandardSearchBool("cappedCase", search._StandardOperatorCappedCase, search._StandardFilterCappedCase, "=", caseDetail.First().CappedCase.ToString(), false);  //DEL
            //search.ValidateStandardSearchBool("specialSLAs", search._StandardOperatorSpecialSLAs, search._StandardFilterSpecialSLAs, "=", caseDetail.First().SpecialSLAs.ToString(), false);  //DEL
            search.ValidateStandardSearchInput("caseName", "Case Name", search._StandardOperatorCaseName, search._StandardFilterCaseName, "Equals", caseDetail.First().CaseName, false);
            search.ValidateStandardSearchInput("url", "Case URL", search._StandardOperatorUrl, search._StandardFilterUrl, "Equals", caseDetail.First().Url, true);
            search.ValidateStandardSearchInput("billingCode", "Billing Code", search._StandardOperatorBilling, search._StandardFilterBilling, "Equals", caseDetail.First().BillingCode, false, true, false);
            search.ValidateStandardSearchInput("caseFolder", "Case Folder", search._StandardOperatorCaseFolder, search._StandardFilterCaseFolder, "Equals", caseDetail.First().CaseFolder, false, true, false);

            report.Step("Verify Standard Search by Contact Name (first)");
            var firstName = contact.First().FirstName;
            search.NewStandardSearch();
            Facilitator.Template.search.StandardSearch(test.driver, search._StandardOperatorContactName, search._StandardFilterContactName, "Equals", firstName);
            test.vars.verify(test.VerifyNoErrorToasts());
            search.SelectResultByIndex(1);
            caseinfo.WaitForPageLoad();
            test.Click(caseinfo._ContactsTab);
            Facilitator.Template.grid.WaitForGridData();
            test.EditField(caseinfo._ContactsTextFilter, firstName);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "First Name", firstName));

            report.Step("Verify Standard Search by Contact Name (last)");
            var lastName = contact.First().LastName;
            search.NewStandardSearch();
            Facilitator.Template.search.StandardSearch(test.driver, search._StandardOperatorContactName, search._StandardFilterContactName, "Equals", lastName);
            test.vars.verify(test.VerifyNoErrorToasts());
            search.SelectResultByIndex(1);
            caseinfo.WaitForPageLoad();
            test.Click(caseinfo._ContactsTab);
            Facilitator.Template.grid.WaitForGridData();
            test.EditField(caseinfo._ContactsTextFilter, lastName);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Last Name", lastName));

            report.Step("Verify Standard Search by Contact Name (combined)");
            var fullName = contact.First().FirstName + " " + contact.First().LastName;
            search.NewStandardSearch();
            Facilitator.Template.search.StandardSearch(test.driver, search._StandardOperatorContactName, search._StandardFilterContactName, "Equals", fullName);
            test.vars.verify(test.VerifyNoErrorToasts());
            search.SelectResultByIndex(1);
            test.Click(caseinfo._ContactsTab);
            Facilitator.Template.grid.WaitForGridData();
            test.EditField(caseinfo._ContactsTextFilter, lastName);
            test.Click(By.XPath(caseinfo._Contacts + "//div[text()='First Name']"));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "First Name", firstName));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Last Name", lastName));

            report.Step("Verify Standard Search by Project Role");
            var role = Data.GetProjectRole().OrderBy(n => n.Name).First().Name;  //Get first role alphabetically
            search.NewStandardSearch();
            Facilitator.Template.search.StandardSearchList(test.driver, search._StandardOperatorProjectRole, search._StandardFilterProjectRole, "Equals", role);
            test.vars.verify(test.VerifyNoErrorToasts());
            search.SelectResultByIndex(1);
            caseinfo.WaitForPageLoad();
            test.Click(caseinfo._ContactsTab);
            Facilitator.Template.grid.WaitForGridData();
            Facilitator.Template.grid.SortByColumn("Project Role");
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Project Role", role));

            var dates = Data.GetAllDates(caseDetailId);
            search.ValidateStandardSearchDateEval(caseinfo._InitialNoticeMailing, search._StandardOperatorInitialNoticeMailing, search._StandardFilterInitialNoticeMailing, "=", dates.InitialNoticeMailing, false);
            search.ValidateStandardSearchDateEval(caseinfo._OptOutDeadline, search._StandardOperatorOptOutDeadline, search._StandardFilterOptOutDeadline, "=", dates.OptOutDeadline, false);
            search.ValidateStandardSearchDateEval(caseinfo._InitialDistribution, search._StandardOperatorInitialDistribution, search._StandardFilterInitialDistribution, "=", dates.InitialDistribution, false);
            search.ValidateStandardSearchDateEval(caseinfo._ClaimsDeadline, search._StandardOperatorClaimsDeadline, search._StandardFilterClaimsDeadline, "=", dates.ClaimsDeadline, false);
            search.ValidateStandardSearchDateEval(caseinfo._PreliminaryApprovalGranted, search._StandardOperatorPreliminaryApprovalGranted, search._StandardFilterPreliminaryApprovalGranted, "=", dates.PreliminaryApprovalGranted, false);
            search.ValidateStandardSearchDateEval(caseinfo._ObjectionDeadline, search._StandardOperatorObjectionDeadline, search._StandardFilterObjectionDeadline, "=", dates.ObjectionDeadline, false);
            search.ValidateStandardSearchDateEval(caseinfo._FinalApprovalHearing, search._StandardOperatorFinalApprovalHearing, search._StandardFilterFinalApprovalHearing, "=", dates.FinalApprovalHearing, false);

            var orgName = Data.GetOrganizationByContact(contact.First().ContactId).First().OrganizationName;
            search.ValidateStandardSearchInput("", "Organization Name", search._StandardOperatorOrganizationName, search._StandardFilterOrganizationName, "Includes", orgName, true, false, false);

            var disbursement = Data.GetDisbursement(caseDetailId).First();
            var options = Data.GetDisbursementsOption();
            search.ValidateStandardSearchList("TaxVendor", "Tax Vendor", search._StandardOperatorTaxVendor, search._StandardFilterTaxVendor, "Equals", options.First(i => i.DisbursementsOptionId == disbursement.TaxVendorOptionsId).Name, true, false, false);
            search.ValidateStandardSearchList("TaxReporting", "Tax Reporting", search._StandardOperatorTaxReporting, search._StandardFilterTaxReporting , "Equals", options.First(i => i.DisbursementsOptionId == disbursement.TaxReportingOptionsId).Name, true, false, false);

            testHelper.End();
        }

        public static void StandardSearchAllFieldsAndCriteria(string section = "All")
        {
            config.TIMEOUT = 120; 
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));          
            Data.PopulateStandardSearchFields(caseDetailId);
            Data.PopulateProjectTeam(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId);
            var contactToOrganization = Data.GetContactToOrganization();
            var contacts = Data.GetContactDataByCase(caseDetailId);
            var contact = contacts.Where(c => contactToOrganization.Any(i => c.ContactId == i.ContactId))
                .OrderBy(l => l.LastName).ThenBy(f => f.FirstName).First();
            var disbursement = Data.GetDisbursement(caseDetailId).First();
            var options = Data.GetDisbursementsOption();

            testHelper.Start();

            if (section == "Text" || section == "All")
            { 
                report.Step("Standard Search on Text Fields");
                search.ValidateStandardSearchAllTextOperators("courtCaption", "Court Caption", search._StandardOperatorCourtCaption, search._StandardFilterCourtCaption, caseDetail.First().CourtCaption, false, true, false);
                search.ValidateStandardSearchAllTextOperators("settlementAmountBenefit", "Settlement Amount", search._StandardOperatorSettlement, search._StandardFilterSettlement, caseDetail.First().SettlementAmountBenefit, true, false, true);
                search.ValidateStandardSearchAllTextOperators("caseName", "Case Name", search._StandardOperatorCaseName, search._StandardFilterCaseName, caseDetail.First().CaseName, false, false, false);
                search.ValidateStandardSearchAllTextOperators("url", "Case URL", search._StandardOperatorUrl, search._StandardFilterUrl, caseDetail.First().Url, true, false, false);
                search.ValidateStandardSearchAllTextOperators("billingCode", "Billing Code", search._StandardOperatorBilling, search._StandardFilterBilling, caseDetail.First().BillingCode, false, true, false);
                search.ValidateStandardSearchAllTextOperators("caseFolder", "Case Folder", search._StandardOperatorCaseFolder, search._StandardFilterCaseFolder, caseDetail.First().CaseFolder, false, true, true);
            }
            if (section == "Number" || section == "All")
            {
                report.Step("Standard Search on Number Fields");
                search.ValidateStandardSearchAllNumberOperators("classSize", "Class Size", search._StandardOperatorClassSize, search._StandardFilterClassSize, Data.ReturnMedianClassSize().ToString(), true, false, true);
                search.ValidateStandardSearchAllNumberOperators("estimatedNumberOfClaims", "Estimated # of Claims", search._StandardOperatorEstimated, search._StandardFilterEstimated, Data.ReturnMedianEstNumClaims().ToString(), false, true, true);
                search.ValidateStandardSearchAllNumberOperators("sapContractCode", "SAP Contract Code", search._StandardOperatorSAP, search._StandardFilterSAP, Data.ReturnMedianSapContractCode().ToString(), true, false, false);
            }
            if (section == "List" || section == "All")
            {
                report.Step("Standard Search on List Fields");
                search.ValidateStandardSearchAllListOperators("caseTypeId", "Case Type", search._StandardOperatorCaseType, search._StandardFilterCaseType, Data.GetCaseType(caseDetail.First().CaseTypeId).First().Name, false, false, false);
                search.ValidateStandardSearchAllListOperators("businessLineId", "Business Line", search._StandardOperatorBusinessLine, search._StandardFilterBusinessLine, Data.GetBusinessLine(caseDetail.First().BusinessLineId).First().Name, true, false, false);
                search.ValidateStandardSearchAllListOperators("caseStatusId", "Status", search._StandardOperatorStatus, search._StandardFilterStatus, Data.GetCaseStatus(caseDetail.First().CaseStatusId).First().Name, false, false, false);
                search.ValidateStandardSearchAllListOperators("TaxVendor", "Tax Vendor", search._StandardOperatorTaxVendor, search._StandardFilterTaxVendor, options.First(i => i.DisbursementsOptionId == disbursement.TaxVendorOptionsId).Name, true, false, true);  //Note: Is Empty will fail due to bug 202013
                search.ValidateStandardSearchAllListOperators("TaxReporting", "Tax Reporting", search._StandardOperatorTaxReporting, search._StandardFilterTaxReporting, options.First(i => i.DisbursementsOptionId == disbursement.TaxReportingOptionsId).Name, true, false, true); //Note: Is Empty will fail due to bug 202013
            }
            if (section == "Date" || section == "All")
            {
                report.Step("Standard Search on Date Fields");
                var dates = Data.GetAllDates(caseDetailId);
                search.ValidateStandardSearchAllDateOperators(caseinfo._InitialNoticeMailing, search._StandardOperatorInitialNoticeMailing, search._StandardFilterInitialNoticeMailing, dates.InitialNoticeMailing, true);
                search.ValidateStandardSearchAllDateOperators(caseinfo._OptOutDeadline, search._StandardOperatorOptOutDeadline, search._StandardFilterOptOutDeadline, dates.OptOutDeadline, true);
                search.ValidateStandardSearchAllDateOperators(caseinfo._InitialDistribution, search._StandardOperatorInitialDistribution, search._StandardFilterInitialDistribution, dates.InitialDistribution, true);
                search.ValidateStandardSearchAllDateOperators(caseinfo._ClaimsDeadline, search._StandardOperatorClaimsDeadline, search._StandardFilterClaimsDeadline, dates.ClaimsDeadline, true);
                search.ValidateStandardSearchAllDateOperators(caseinfo._PreliminaryApprovalGranted, search._StandardOperatorPreliminaryApprovalGranted, search._StandardFilterPreliminaryApprovalGranted, dates.PreliminaryApprovalGranted, true);
                search.ValidateStandardSearchAllDateOperators(caseinfo._ObjectionDeadline, search._StandardOperatorObjectionDeadline, search._StandardFilterObjectionDeadline, dates.ObjectionDeadline, true);
                search.ValidateStandardSearchAllDateOperators(caseinfo._FinalApprovalHearing, search._StandardOperatorFinalApprovalHearing, search._StandardFilterFinalApprovalHearing, dates.FinalApprovalHearing, true);
            }
            if (section == "Boolean" || section == "All")
            {
                report.Step("Standard Search on Boolean Fields");
                //search.ValidateStandardSearchAllBoolOperators("signedAgreementPricing", search._StandardOperatorSignedAgreementPricing, search._StandardFilterSignedAgreementPricing, caseDetail.First().SignedAgreementPricing.ToString());  //DEL
                search.ValidateStandardSearchAllBoolOperators("flsa", search._StandardOperatorFLSA, search._StandardFilterFLSA, caseDetail.First().FLSA.ToString());
                search.ValidateStandardSearchAllBoolOperators("hipaa", search._StandardOperatorHIPAA, search._StandardFilterHIPAA, caseDetail.First().HIPAA.ToString());
                search.ValidateStandardSearchAllBoolOperators("fisma", search._StandardOperatorFISMA, search._StandardFilterFISMA, caseDetail.First().FISMA.ToString());
                //search.ValidateStandardSearchAllBoolOperators("cappedCase", search._StandardOperatorCappedCase, search._StandardFilterCappedCase, caseDetail.First().CappedCase.ToString()); //DEL
                //search.ValidateStandardSearchAllBoolOperators("specialSLAs", search._StandardOperatorSpecialSLAs, search._StandardFilterSpecialSLAs, caseDetail.First().SpecialSLAs.ToString()); //DEL
            }
            if (section == "Misc" || section == "All")
            {
                report.Step("Standard Search on Contact Name");
                search.ValidateStandardSearchAllContactName(contact);
                report.Step("Standard Search on Organization Name");
                search.ValidateStandardSearchAllOrganizationName(Data.GetOrganizationByContact(contact.ContactId).First().OrganizationName);
                report.Step("Standard Search on Project Role");
                search.ValidateStandardSearchAllProjectRole(Data.GetProjectRole().OrderBy(n => n.Name).First().Name);
            }

            testHelper.End();
        }

        public static void CaseSummary()
        {
            var caseDetail = Data.GetCaseDataById(int.Parse(ConfigurationManager.AppSettings.Get("caseId"))).First();
            Data.PopulateProjectTeam(caseDetail.CaseDetailId);
            var caseStatus = Data.GetCaseStatus(caseDetail.CaseStatusId).First().Name;
            var existingCase = Data.GetCaseData().First(i => i.CaseDetailId != caseDetail.CaseDetailId);
            var updateRecord = caseinfo.GenerateOverviewData(caseDetail.CaseDetailId);

            testHelper.Start(caseDetail.CaseDetailId);

            report.Step("Validate Overview section");
            caseinfo.WaitForPageLoad();
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyClassExists(By.XPath("//section[@id='content']//li[a[text()='Summary']]"), "active")); //Validate Summary tab is in focus
            test.vars.verify(caseinfo.VerifyCaseBanner(caseDetail.CaseName, caseDetail.BillingCode, caseStatus));
            caseinfo.ValidateOverviewData(caseDetail);

            report.Step("Validate Project Team section");
            caseinfo.ValidateProjectTeamData(caseDetail.CaseDetailId);

            report.Step("Validate Duplicate Billing Code");
            test.EditField(By.Name("billingCode"), existingCase.BillingCode);
            test.Click(caseinfo._Save);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyText(test.driver, caseinfo._ErrorMessage, "Billing Code " + existingCase.BillingCode + " is already in use by case " + existingCase.CaseName.Replace("  ", " ") + " and must be unique."));
            test.EditField(By.Name("billingCode"), updateRecord.BillingCode);
            test.Click(caseinfo._Save);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyFieldValueById("billingCode", updateRecord.BillingCode));

            report.Step("Update Overview section");
            caseinfo.UpdateOverviewData(updateRecord);
            if (updateRecord.CaseStatusId == 3 || updateRecord.CaseStatusId == 5 || updateRecord.CaseStatusId == 7)  //If status is set to a terminal status
            {
                test.ClickandConfirmHtml(caseinfo._Save);
            }
            else
            {
                test.Click(caseinfo._Save);
            }
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(caseinfo.VerifyCaseBanner(updateRecord.CaseName, updateRecord.BillingCode, Data.GetCaseStatus(updateRecord.CaseStatusId).Single().Name));
            navigate.Refresh();
            caseinfo.WaitForPageLoad();
            caseinfo.ValidateOverviewData(updateRecord);

            testHelper.End();
        }

        public static void CaseDetail()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            const int caseDetailIdWithoutData = 2;
            const int sapWithData = 40009156;
            const int sapWithoutData = 40000002;
            Data.PopulateSapCode(caseDetailId, sapWithData);
            Data.PopulateSapCode(caseDetailIdWithoutData, sapWithoutData);
            testHelper.Start(caseDetailId);
            caseinfo.SelectTab("Detail");
            test.vars.verify(test.VerifyNoErrorToasts());

            report.Step("Case Kickoff Details Section");
            var originalCaseKickoff = Data.GetCaseKickoffDetail(caseDetailId).First();
            caseinfo.ValidateCaseKickoffData(originalCaseKickoff);
            var updateCaseKickoff = caseinfo.GenerateCaseKickoffData();
            caseinfo.UpdateCaseKickoffData(updateCaseKickoff);
            test.Click(caseinfo._SaveAll);
            test.vars.verify(test.VerifyNoErrorToasts());
            navigate.Refresh();
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Detail");
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateCaseKickoffData(updateCaseKickoff);

            report.Step("Allocated Hours Section");
            var allocatedHoursWithData = Data.ExecuteGetReportData_EVAEstimates_Result(sapWithData);
            var allocatedHoursWithoutData = Data.ExecuteGetReportData_EVAEstimates_Result(sapWithoutData);
            grid.WaitForGridData();
            report.Step("Validate Allocated Hours tab - Data Available");
            caseinfo.ValidateAllocatedHoursData(allocatedHoursWithData.First());
            report.Step("Validate Allocated Hours tab - Data Unavailable");
            navigate.DirectToPage("casedetail", caseDetailIdWithoutData.ToString());
            grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateAllocatedHoursData(allocatedHoursWithoutData.FirstOrDefault());
            navigate.DirectToPage("casedetail", caseDetailId.ToString());  //return to original case

            report.Step("Shutdown and Retention Section");
            caseinfo.ValidateShutdownRetentionData(Data.GetShutdownAndRetention(caseDetailId).FirstOrDefault());
            var updateCaseClosure = caseinfo.GenerateShutdownAndRetentionData();
            caseinfo.UpdateShutdownRetentionData(updateCaseClosure);
            test.Click(caseinfo._SaveAll);
            test.vars.verify(test.VerifyNoErrorToasts());
            navigate.Refresh();
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Detail");
            caseinfo.ValidateShutdownRetentionData(updateCaseClosure);

            testHelper.End();
        }

        public static void CaseDates()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            var milestones = Data.GetMilestones(caseDetailId);
            var originalDate = milestones.OrderBy(r => r.SortOrder).First();
            if (originalDate.SortOrder == 1)
                throw new Exception("Case (?cid=" + caseDetailId + ") already has a record at sort order 1.  Please delete the record or modify it's sort order and re-run the test.");

            testHelper.Start(caseDetailId);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Dates");
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            report.Step("Verify Date Grid Count");
            var datesCount = milestones.Count;
            test.vars.verify(test.VerifyText(test.driver, caseinfo._DatesTotal, "Total Items: " + datesCount));
            report.Step("Verify Date Grid Contents (First Record)");
            caseinfo.SortByColumnAndSection(caseinfo._Dates, "Name");
            caseinfo.SortByColumnAndSection(caseinfo._Dates, "Order");
            caseinfo.ValidateMilestoneGridData(originalDate);
            report.Step("Verify Filter Functionality");
            var filter = originalDate.Name.Split(' ');
            test.EditField(caseinfo._DatesTextFilter, filter[0]);
            test.vars.verify(caseinfo.VerifyGridValue(caseinfo._Dates, "Name", filter[0]));
            test.ClearField(caseinfo._DatesTextFilter);
            report.Step("Add Date");
            var addDate = caseinfo.GenerateMilestoneData(caseDetailId);
            test.Click(caseinfo._DatesAdd);
            caseinfo.UpdateMilestoneData(addDate);
            test.vars.verify(test.VerifyFieldValue(By.Name("srStatus"), "Closed"));
            test.vars.verify(test.VerifyFieldValue(By.Name("srDueDate"), "06/18/2009"));
            test.vars.verify(test.VerifyFieldValue(By.Name("srCreateDate"), "06/17/2009"));
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateMilestoneGridData(addDate);
            report.Step("Edit Date");
            var updateDate = caseinfo.GenerateMilestoneData(caseDetailId);
            test.Click(caseinfo._DatesEdit);
            caseinfo.ValidateMilestoneData(addDate);
            caseinfo.UpdateMilestoneData(updateDate);
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateMilestoneGridData(updateDate);
            report.Step("Delete Date");
            test.Click(caseinfo._DatesDelete);
            caseinfo.ValidateMilestoneData(updateDate);
            test.ClickandConfirm(test.driver, caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateMilestoneGridData(originalDate);
            report.Step("Not Applicable");
            test.EditField(caseinfo._DatesTextFilter, "Initial Notice Mailing");
            test.Click(caseinfo._DatesEdit);
            var initialDate = DateTime.Parse(test.driver.FindElement(caseinfo._DueDate).GetAttribute("value")).ToString("MM/dd/yyyy");
            if (initialDate == "")  //If record is in the wrong state, fix it.
            {
                initialDate = DateTime.Now.ToString("MM/dd/yyyy");
                test.SetCheckbox(caseinfo._NotApplicable, false);
                test.SetCheckbox(caseinfo._DatePending, false);
                test.EditField(caseinfo._DueDate, initialDate);
            }
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DueDate, true));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DatePending, false));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._NotApplicable, false));
            test.EditField(caseinfo._DueDate, "");
            test.SetCheckbox(caseinfo._NotApplicable, true);
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DueDate, false));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DatePending, false));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._NotApplicable, true));
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Summary");
            test.vars.verify(test.VerifyFieldValue(caseinfo._InitialNoticeMailing, "Not Applicable"));
            report.Step("Date Pending");
            caseinfo.SelectTab("Dates");
            test.EditField(caseinfo._DatesTextFilter, "Initial Notice Mailing");
            test.Click(caseinfo._DatesEdit);
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DueDate, false));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DatePending, false));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._NotApplicable, true));
            test.SetCheckbox(caseinfo._NotApplicable, false);
            test.SetCheckbox(caseinfo._DatePending, true);
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DueDate, false));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DatePending, true));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._NotApplicable, false));
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Summary");
            test.vars.verify(test.VerifyFieldValue(caseinfo._InitialNoticeMailing, "Date Pending"));
            report.Step("Revert Date");
            caseinfo.SelectTab("Dates");
            test.EditField(caseinfo._DatesTextFilter, "Initial Notice Mailing");
            test.Click(caseinfo._DatesEdit);
            test.SetCheckbox(caseinfo._DatePending, false);
            test.EditField(caseinfo._DueDate, initialDate);
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DueDate, true));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._DatePending, false));
            test.vars.verify(test.VerifyElementEnabled(caseinfo._NotApplicable, false));
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Summary");
            test.vars.verify(test.VerifyFieldValue(caseinfo._InitialNoticeMailing, initialDate));
            testHelper.End();
        }

        public static void CaseContacts()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            Data.PopulateProjectTeam(caseDetailId);
            Data.EnsureCaseNotClosed(caseDetailId);
            var contacts = Data.GetContactDataByCase(caseDetailId);
            testHelper.Start(caseDetailId);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Contacts");
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            report.Step("Verify Contacts Grid");
            var contactsCount = contacts.Count;
            test.vars.verify(test.VerifyText(test.driver, caseinfo._ContactsTotal, "Total Items: " + contactsCount));
            var contact = contacts.OrderBy(l => l.LastName).ThenBy(i => i.ContactId).First();
            caseinfo.SortByColumnAndSection(caseinfo._Contacts, "First Name");
            caseinfo.SortByColumnAndSection(caseinfo._Contacts, "Last Name");
            caseinfo.ValidateContactsData(contact, caseDetailId);

            report.Step("Verify Filter Functionality");
            var lName = contacts.First().LastName;
            var fName = contacts.First().FirstName;
            test.EditField(caseinfo._ContactsTextFilter, lName);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Last Name", lName));
            test.EditField(caseinfo._ContactsTextFilter, fName);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "First Name", fName));
            test.ClearField(caseinfo._ContactsTextFilter);

            report.Step("Add Contact");
            var unassociatedContacts = Data.GetContactDataUnassociated(caseDetailId).Where(c => c.ContactTypeId == 1).ToList();
            if (!unassociatedContacts.Any())
            {
                Data.GenerateNewContact();
                unassociatedContacts = Data.GetContactDataUnassociated(caseDetailId).Where(c => c.ContactTypeId == 1).ToList();
            }
            var addCount = Data.GetContactData().Count(l => contacts.All(l2 => l2.ContactId != l.ContactId));
            var addIndex = new Random().Next(unassociatedContacts.Count);
            var addLastName = unassociatedContacts.Skip(addIndex).First().LastName; //select a random last name to use for filtering
            var addRecord = unassociatedContacts.Where(u => u.LastName == addLastName).OrderBy(o => o.FirstName).ThenBy(i => i.ContactId).First();  //select record that will be ordered first once sorted
            test.Click(caseinfo._ContactsAdd);
            test.WaitForElement(caseinfo._ContactsAddTotal);
            test.vars.verify(test.VerifyText(test.driver, caseinfo._ContactsAddTotal, "Total Items: " + addCount));
            test.EditField(caseinfo._ContactsAddFilter, addRecord.LastName);
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._ContactsAddModal, "Last Name", addRecord.LastName ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._ContactsAddModal, "First Name", addRecord.FirstName ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._ContactsAddModal, "Contact Type", Data.GetContactType(addRecord.ContactTypeId).First().Name ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._ContactsAddModal, "Phone", addRecord.Phone1 ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._ContactsAddModal, "Email", addRecord.Email ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._ContactsAddModal, "Organization Name", caseinfo.AssociatedBusinesses(addRecord.ContactId) ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._ContactsAddModal, "Key", test.ToYesNoString(addRecord.KeyContact)));
            caseinfo.SortByColumnAndSection(caseinfo._ContactsAddModal, "Contact Type");
            test.Click(caseinfo._ContactsAddAssociate);
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.EditField(caseinfo._ContactsTextFilter, addRecord.LastName);
            var caseDetailContact = Data.GetCaseDetailContact(addRecord.ContactId, caseDetailId).First();
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Active", caseinfo.GetContactStatus(caseDetailContact.StartDate, caseDetailContact.EndDate)));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Project Role", "Adjudicator"));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Last Name", addRecord.LastName ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "First Name", addRecord.FirstName ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Key", test.ToYesNoString(addRecord.KeyContact)));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Organization Name", caseinfo.AssociatedBusinesses(addRecord.ContactId) ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Phone 1", addRecord.Phone1 ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Email", addRecord.Email ?? ""));
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Contact Type", "Adjudicator"));

            report.Step("Edit Contact");
            var role = Data.GetProjectRole().Where(u => u.IsUniqueRequired != true).OrderBy(x => Guid.NewGuid()).First().Name;
            test.Click(caseinfo._ContactsEdit);
            Facilitator.Template.grid.WaitForGridData();
            caseinfo.ValidateContactsModalData(addRecord, caseDetailId);
            caseinfo.ValidateContactOrgGrid(addRecord);
            test.SelectField(caseinfo._ContactsEditRole, role);
            test.EditField(caseinfo._ContactsEditStart, DateTime.Now.AddDays(-DateTime.Now.Second).ToShortDateString());
            test.EditField(caseinfo._ContactsEditEnd, DateTime.Now.AddDays(DateTime.Now.Second).ToShortDateString());
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(caseinfo.VerifyValueBySectionandColumn(caseinfo._Contacts, "Project Role", role));

            report.Step("Delete Contact");
            var deleteRecord = Data.GetContactDataByCase(caseDetailId).First(i => i.ContactId == addRecord.ContactId); //Get the updated contacts data
            test.Click(caseinfo._ContactsDelete);
            caseinfo.ValidateContactsModalData(deleteRecord, caseDetailId);
            test.ClickandConfirm(test.driver, caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyText(test.driver, search._AlertMessage, "There are no contacts that match the currently entered filter."));
            test.ClearField(caseinfo._ContactsTextFilter);
            test.vars.verify(test.VerifyText(test.driver, caseinfo._ContactsTotal, "Total Items: " + contactsCount)); //ensure count is back to original count

            report.Step("Unique Project Role Validation");
            try
            {
                var uniqueRole = Data.GetProjectRole().First(i => i.IsUniqueRequired);
                test.Click(caseinfo._ContactsAdd);
                test.WaitForElement(caseinfo._ContactsAddTotal);
                test.EditField(caseinfo._ContactsAddFilter, uniqueRole.Name);
                test.Click(caseinfo._ContactsAddAssociate);
                test.Click(caseinfo._ModalSave);
                test.vars.verify(test.VerifyPageSourceText(test.driver, "This Case has more than one active contact in the following Project Roles:"));
                test.Click(By.XPath("//button[@ng-click='close()']"));
                test.Click(caseinfo._ContactsPendingRemove);
                test.Click(caseinfo._ModalCancel);
            }
            catch (Exception e)
            {
                report.Fail("Error occurred: " + e.Message);
                
            }

            report.Step("Required Project Role Validation");
            try
            {
                var requiredRole = Data.GetProjectRole().First(i => i.IsUniqueRequired);
                caseinfo.DeleteContactByValue(requiredRole.Name);
                test.vars.verify(caseinfo.VerifyMissingRole(requiredRole.Name));
                var nonrequiredRole = Data.GetProjectRole().First(i => i.IsRequired == false);
                test.Click(caseinfo._ContactsAdd);
                test.WaitForElement(caseinfo._ContactsAddTotal);
                test.EditField(caseinfo._ContactsAddFilter, nonrequiredRole.Name);
                test.Click(caseinfo._ContactsAddAssociate);
                test.Click(caseinfo._ModalSave);
                test.vars.verify(test.VerifyPageSourceText(test.driver, "This Case does not have an active contact in the following Project Roles:"));
                test.Click(By.XPath("//button[@ng-click='close()']"));
                test.EditField(caseinfo._ContactsAddFilter, requiredRole.Name);
                test.Click(caseinfo._ContactsAddAssociate);
                test.Click(caseinfo._ModalSave);
                test.vars.verify(test.VerifyNoErrorToasts());
                test.vars.verify(caseinfo.VerifyNoMissingRoles());
                caseinfo.DeleteContactByValue(nonrequiredRole.Name); //Clean up extra record.
            }
            catch (Exception e)
            {
                report.Fail("Error occurred: " + e.Message);
                
            }

            //temporary workaround for known bug (126046) causing an unexpected unsaved data prompt if logging out
            test.driver.Navigate().Refresh();
            test.driver.SwitchTo().Alert().Accept();
            test.WaitForPageToLoad(test.driver);
            //

            testHelper.End();
        }

        public static void CaseOps()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            Data.PopulateIncomingDocuments(caseDetailId);
            Data.PopulateMailingDetail(caseDetailId);
            testHelper.Start(caseDetailId);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Ops/Shared Services");
            OpsClaims(caseDetailId);
            //OpsContactCenter(caseDetailId);  //Skipping until section reworked.
            OpsDisbursements(caseDetailId);
            OpsDocumentProcessing(caseDetailId);
            OpsHr(caseDetailId);
            //OpsMailings(caseDetailId);  //Skipping until section reworked.
            testHelper.End();
        }

        public static void OpsClaims(int caseDetailId)
        {
            try
            {
                report.Step("Claims Section");
                test.Click(By.XPath("//span[text()='Claims']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                var existingRecord = Data.GetClaim(caseDetailId).FirstOrDefault();
                report.Step("Verify Data");
                caseinfo.ValidateClaimsData(existingRecord);
                report.Step("Update Data");
                var updateClaims = caseinfo.GenerateClaimsData();
                caseinfo.UpdateClaimsData(updateClaims);
                test.Click(caseinfo._SaveAll);
                test.vars.verify(test.VerifyNoErrorToasts());
                navigate.Refresh();
                test.vars.verify(test.VerifyNoErrorToasts());
                test.Click(By.XPath("//span[text()='Claims']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateClaimsData(updateClaims);
            }
            catch (Exception e)
            {
                report.Fail("Claims Section failed due to: ", e);
                
            }
        }

        public static void OpsContactCenter(int caseDetailId)
        {
            try
            {
                report.Step("Contact Center Section");
                test.Click(By.XPath("//span[text()='Contact Center']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                var contactCenter = Data.GetContactCenter(caseDetailId).First();
                report.Step("Verify Data");
                caseinfo.ValidateContactCenterData(contactCenter);
                report.Step("Update Data");
                var updateContactCenter = caseinfo.GenerateContactCenterData(caseDetailId);
                caseinfo.UpdateContactCenterData(updateContactCenter);
                test.Click(caseinfo._SaveAllDF);
                test.vars.verify(test.VerifyNoErrorToasts());
                navigate.Refresh();
                test.vars.verify(test.VerifyNoErrorToasts());
                test.Click(By.XPath("//span[text()='Contact Center']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateContactCenterData(updateContactCenter);
            }
            catch (Exception e)
            {
                report.Fail("Contact Center Section failed due to: ", e);
                
            }
        }

        public static void OpsDisbursements(int caseDetailId)
        {
            try
            {
                report.Step("Disbursements Section");
                test.ToggleSection("Disbursements");
                test.vars.verify(test.VerifyNoErrorToasts());
                var initialrecord = Data.GetDisbursement(caseDetailId).First();
                report.Step("Verify Data");
                if (initialrecord != null)
                {
                    caseinfo.ValidateDisbursementsData(initialrecord);
                }
                report.Step("Update Data");
                var updaterecord = caseinfo.GenerateDisbursementData(caseDetailId);
                caseinfo.UpdateDisbursementData(updaterecord);
                test.ScrollUp(test.driver);
                test.Click(caseinfo._SaveAll);
                test.vars.verify(test.VerifyNoErrorToasts());
                navigate.Refresh();
                test.vars.verify(test.VerifyNoErrorToasts());
                test.ToggleSection("Disbursements");
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateDisbursementsData(updaterecord);
            }
            catch (Exception e)
            {
                report.Fail("Disbursements Section failed due to: ", e);
                
            }
        }

        public static void OpsDocumentProcessing(int caseDetailId)
        {
            try
            {
                report.Step("Document Processing Section");
                test.Click(By.XPath("//span[text()='Document Processing']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.VerifyElementDisplayed(By.XPath("//span[text()='Incoming Document Type']"));
                caseinfo.VerifyElementDisplayed(By.XPath("//span[text()='Processing Type']"));
                var documentProcessing = Data.GetDocumentProcessing(caseDetailId).First();
                var incomingDocuments = Data.GetIncomingDocument(documentProcessing.DocumentProcessingId);
                report.Step("Verify Form");
                caseinfo.ValidateDocumentProcessingData(documentProcessing);
                report.Step("Verify Form Update");
                var updateDocumentProcessing = caseinfo.GenerateDocumentProcessingData();
                caseinfo.UpdatedDocumentProcessingData(updateDocumentProcessing);
                test.Click(caseinfo._SaveAll);
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateDocumentProcessingData(updateDocumentProcessing);
                report.Step("Verify Grid");
                caseinfo.ValidateIncomingDocumentsGridData(incomingDocuments);
                report.Step("Add Document");
                var addDocument = caseinfo.GenerateIncomingDocumentData();
                incomingDocuments.Add(addDocument);
                test.Click(caseinfo._DocumentAdd);
                caseinfo.UpdateIncomingDocumentData(addDocument);
                test.Click(caseinfo._ModalSave);
                test.vars.verify(test.VerifyNoErrorToasts());
                //test.Click(caseinfo._SaveAll);                                        //DEL modified so that modal save does full save, so save all button not enabled 
                //test.vars.verify(test.VerifyNoErrorToasts());                         //DEL modified so that modal save does full save, so save all button not enabled 
                caseinfo.ValidateIncomingDocumentsGridData(incomingDocuments);
                report.Step("Edit Document");
                test.Click(By.XPath("(" + caseinfo.DocumentEdit + ")[last()]"));
                var updateDocument = caseinfo.GenerateIncomingDocumentData();
                incomingDocuments.Remove(addDocument);
                incomingDocuments.Add(updateDocument);
                caseinfo.UpdateIncomingDocumentData(updateDocument);
                test.Click(caseinfo._ModalSave);
                test.vars.verify(test.VerifyNoErrorToasts());
                //test.Click(caseinfo._SaveAll);                                        //DEL modified so that modal save does full save, so save all button not enabled 
                //test.vars.verify(test.VerifyNoErrorToasts());                         //DEL modified so that modal save does full save, so save all button not enabled 
                caseinfo.ValidateIncomingDocumentsGridData(incomingDocuments);
                report.Step("Delete Document");
                test.Click(By.XPath("(" + caseinfo.DocumentDelete + ")[last()]"));
                test.ClickandCancel(caseinfo._ModalSave);
                test.vars.verify(test.VerifyElementAvailability(By.XPath("//div[contains(@class, 'documentprocessing-modal')]"), true));
                test.ClickandConfirm(caseinfo._ModalSave);
                test.vars.verify(test.VerifyNoErrorToasts());
                //test.Click(caseinfo._SaveAll);                                        //DEL modified so that modal save does full save, so save all button not enabled 
                //test.vars.verify(test.VerifyNoErrorToasts());                         //DEL modified so that modal save does full save, so save all button not enabled 

                incomingDocuments.Remove(updateDocument);
                caseinfo.ValidateIncomingDocumentsGridData(incomingDocuments);
            }
            catch (Exception e)
            {
                report.Fail("Document Processing Section failed due to: ", e);
                
            }
        }

        public static void OpsHr(int caseDetailId)
        {
            try
            {
                report.Step("HR Section");
                test.Click(caseinfo._HrToggle);
                test.vars.verify(test.VerifyNoErrorToasts());
                var hr = Data.GetHr(caseDetailId).FirstOrDefault();
                report.Step("Verify Data");
                if (hr != null)
                {
                    caseinfo.ValidateHrData(hr);
                }
                report.Step("Update Data");
                var updateHr = caseinfo.GenerateHrData();
                caseinfo.UpdateHrData(updateHr);
                test.Click(caseinfo._SaveAll);
                test.vars.verify(test.VerifyNoErrorToasts());
                navigate.Refresh();
                test.vars.verify(test.VerifyNoErrorToasts());
                test.Click(caseinfo._HrToggle);
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateHrData(updateHr);
            }
            catch (Exception e)
            {
                report.Fail("HR Section failed due to: ", e);
                
            }
        }

        public static void OpsMailings(int caseDetailId)
        {
            try
            {
                report.Step("Mailings Section");
                test.Click(By.XPath("//span[text()='Mailings']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                var mailings = Data.GetMailing(caseDetailId).First();
                var mailingDetail = Data.GetMailingDetail(mailings.MailingId).OrderBy(d => d.Description).First();
                report.Step("Verify Form");
                test.vars.verify(test.VerifyFieldValueByName("PoBoxType", mailings.PoBoxOptionsId.ToString()));
                report.Step("Verify Form Update");
                var addMailings = caseinfo.GenerateMailingsData();
                caseinfo.UpdateMailingsData(addMailings);
                test.Click(caseinfo._SaveAllDF);
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateMailingsData(addMailings);
                report.Step("Verify Grid");
                caseinfo.ValidateMailingDetailGridData(mailingDetail);
                report.Step("Add Mailing");
                test.Click(caseinfo._MailingAdd);
                var addMailingDetail = caseinfo.GenerateMailingDetailData();
                caseinfo.UpdateMailingDetailData(addMailingDetail);
                test.Click(caseinfo._SaveAllDF);
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateMailingDetailGridData(addMailingDetail);
                report.Step("Edit Mailing");
                var updateMailingDetail = caseinfo.GenerateMailingDetailData();
                test.Click(By.XPath("//div[contains(@class, 'ngCellText')]//span[text()='" + addMailingDetail.Description + "']"));
                caseinfo.ValidateMailingDetailData(addMailingDetail);
                caseinfo.UpdateMailingDetailData(updateMailingDetail);
                test.Click(caseinfo._SaveAllDF);
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateMailingDetailGridData(updateMailingDetail);
                report.Step("Delete Mailing");
                test.Click(By.XPath("//div[contains(@class, 'ngCellText')]//span[text()='" + updateMailingDetail.Description + "']"));
                caseinfo.ValidateMailingDetailData(updateMailingDetail);
                test.Click(caseinfo._MailingDelete);
                test.Click(caseinfo._ModalSave);
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateMailingDetailGridData(mailingDetail);
            }
            catch (Exception e)
            {
                report.Fail("Mailings Section failed due to: ", e);
                
            }
        }

        public static void CaseDocuments()  //Note: Requires browser window to be in focus when selecting the document to upload.
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            Data.PopulateDocuments(caseDetailId);
            testHelper.Start(caseDetailId);
            caseinfo.SelectTab("Documents");
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            var originalRecords = Data.GetDocuments(caseDetailId).OrderByDescending(d => d.UploadedDate);
            caseinfo.ValidateDocumentsGridData(originalRecords.First());
            test.EditField(caseinfo._DocumentsFilter, originalRecords.Last().Note);
            caseinfo.ValidateDocumentsGridData(originalRecords.LastOrDefault());
            test.ClearField(caseinfo._DocumentsFilter);
            var addRecord = caseinfo.GenerateDocumentsRecord("UploadTestDoc.docx");
            test.Click(caseinfo._DocumentsAdd);
            caseinfo.UpdateDocumentsData(addRecord);
            test.Click(caseinfo._DocumentsSelectFiles);
            caseinfo.FileSelect(config.upload_filepath);
            test.Click(caseinfo._DocumentsUploadFiles);
            test.vars.verify(caseinfo.VerifyUpload());
            test.vars.verify(test.VerifyNoErrorToasts());
            test.Click(caseinfo._ModalSave);
            caseinfo.ValidateDocumentsGridData(addRecord);
            test.vars.verify(caseinfo.VerifyDocumentDownload(addRecord.DisplayName));
            test.Click(caseinfo._DocumentsEdit);
            caseinfo.ValidateDocumentsData(addRecord);
            var updateRecord = caseinfo.GenerateDocumentsRecord("Readme.doc");
            caseinfo.UpdateDocumentsData(updateRecord);
            test.Click(caseinfo._DocumentsSelectFiles);
            caseinfo.FileSelect("C:\\Selenium\\Readme.doc");
            test.Click(caseinfo._DocumentsUploadFiles);
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateDocumentsGridData(updateRecord);
            test.vars.verify(caseinfo.VerifyDocumentDownload(updateRecord.DisplayName));
            test.Click(caseinfo._DocumentsDelete);
            caseinfo.ValidateDocumentsData(updateRecord);
            test.ClickandConfirm(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            System.Threading.Thread.Sleep(1000);
            caseinfo.ValidateDocumentsGridData(originalRecords.First());
            testHelper.End();
        }

        public static void CaseStatistics()
        {
            const int caseDetailIdWithData = 1;
            const int caseDetailIdWithoutData = 2;
            const int sapWithData = 40004297;
            const int sapWithoutData = 40000002;
            Data.PopulateSapCode(caseDetailIdWithData, sapWithData);
            Data.PopulateSapCode(caseDetailIdWithoutData, sapWithoutData);
            var statsWithData = Data.ExecuteGetReportData_WAR_Result(sapWithData);
            var statsWithoutData = Data.ExecuteGetReportData_WAR_Result(sapWithoutData);

            testHelper.Start(caseDetailIdWithData);
            report.Step("Validate Statistics tab - Data Available");
            caseinfo.SelectTab("Statistics");
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateStatisticsData(statsWithData.First());
            report.Step("Validate Statistics tab - Data Unavailable");
            navigate.DirectToPage("stats", caseDetailIdWithoutData.ToString());
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateStatisticsData(statsWithoutData.FirstOrDefault());
            testHelper.End();
        }

        public static void CaseHealthStatus()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            testHelper.Start(caseDetailId);
            Data.PopulateHealthStatusUpdates(caseDetailId);
            Data.PopulateInvoice(caseDetailId);
            caseinfo.SelectTab("Health Status");
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            var originalrecord = Data.GetStatusUpdate(caseDetailId).OrderByDescending(d => d.StatusDate).First();
            caseinfo.ValidateHealthGridData(originalrecord);
            report.Step("Add Health Status Update");
            test.Click(caseinfo._HealthAdd);
            var addrecord = caseinfo.GenerateHealthData(caseDetailId, "GREEN");
            caseinfo.UpdateHealthData(addrecord);
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateHealthGridData(addrecord);
            report.Step("Update Health Status Update");
            test.Click(caseinfo._HealthEdit);
            caseinfo.ValidateHealthData(addrecord);
            var updaterecord = caseinfo.GenerateHealthData(caseDetailId, "RED");
            caseinfo.UpdateHealthData(updaterecord);
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateHealthGridData(updaterecord);
            report.Step("Delete Health Status Update");
            test.Click(caseinfo._HealthDelete);
            caseinfo.ValidateHealthData(updaterecord);
            test.ClickandConfirm(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.ValidateHealthGridData(originalrecord);

            var invoice = Data.GetInvoice(caseDetailId).OrderByDescending(d => d.InvoiceDate).First();
            caseinfo.ValidateInvoiceGridData(invoice);
            test.Click(caseinfo._InvoiceView);
            caseinfo.ValidateInvoiceData(invoice);
            test.Click(caseinfo._ModalCancel);
            testHelper.End();
        }

        public static void CaseRiskMatrix()
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId"));
            Data.PopulateRiskMatrix(caseDetailId);
            testHelper.Start(caseDetailId);
            if (test.driver.FindElements(By.LinkText("Risk Matrix")).Count < 1)
                throw new Exception("Risk Matrix menu item is missing.  Ensure user has the Risk Matrix role.");
            test.Click(By.LinkText("Risk Matrix"));
            test.vars.verify(test.VerifyNoErrorToasts());
            var riskMatrix = Data.GetRiskMatrix(caseDetailId).OrderBy(d => d.DepartmentId).ToList();
            if (riskMatrix.Count(d => d.RiskDescription?.Contains("aaaRisk") == true) > 0)
                throw new Exception(
                    "Please clean up any records from previous incomplete runs (e.g. Description starting with aaa) and then run again.");
            caseinfo.ValidateRiskMatrixGridData(riskMatrix);
            caseinfo.ValidateRiskSummary(riskMatrix);
            report.Step("Filter on Department");
            var filterDepartment = Data.GetRiskMatrixOptionName(riskMatrix.OrderBy(x => Guid.NewGuid()).First().DepartmentId);
            test.EditField(caseinfo._RiskFilter, filterDepartment);
            var filteredByDepartment = riskMatrix.Where(d => d.DepartmentId == Data.GetRiskMatrixOption().First(n => n.Name == filterDepartment).RiskMatrixOptionId).OrderBy(d => d.DepartmentId).ToList();
            caseinfo.ValidateRiskMatrixGridData(filteredByDepartment);
            report.Step("Filter on Risk Category");
            var filterCategory = Data.GetRiskMatrixOptionName(riskMatrix.OrderBy(x => Guid.NewGuid()).First().RiskCategoryId);
            test.EditField(caseinfo._RiskFilter, filterCategory);
            var filteredByCategory = riskMatrix.Where(d => d.RiskCategoryId == Data.GetRiskMatrixOption().First(n => n.Name == filterCategory).RiskMatrixOptionId).OrderBy(d => d.DepartmentId).ToList();
            caseinfo.ValidateRiskMatrixGridData(filteredByCategory);
            test.ClearField(caseinfo._RiskFilter);
            grid.ValidateColumnSorting(caseinfo.RiskColumns);
            grid.ValidatePaging(caseinfo.RiskMatrix, "20");
            report.Step("Add Risk to new department");
            var addDepartmentId = Data.GetRiskMatrixOption().Where(i => riskMatrix.All(r => r.DepartmentId != i.RiskMatrixOptionId && i.Type == "Department")).OrderBy(x => Guid.NewGuid()).FirstOrDefault()?.RiskMatrixOptionId;
            if (addDepartmentId == null) throw new Exception("There are no unsued departments to populate");
            var addRisk = caseinfo.GenerateRiskMatrixData(false, addDepartmentId);
            test.Click(caseinfo._RiskAdd);
            caseinfo.UpdateRiskMatrixData(addRisk);
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            grid.SortByColumn("Description", "ascending");
            caseinfo.ValidateRiskMatrixGridData(addRisk);
            report.Step("Edit Risk to new department");
            var updateDepartmentId = Data.GetRiskMatrixOption().Where(i => riskMatrix.All(r => r.DepartmentId != i.RiskMatrixOptionId && i.Type == "Department")).OrderBy(x => Guid.NewGuid()).FirstOrDefault()?.RiskMatrixOptionId;
            if (updateDepartmentId == null) throw new Exception("There are no unused departments to populate");
            var updateRisk = caseinfo.GenerateRiskMatrixData(false, updateDepartmentId);
            test.Click(caseinfo._RiskEdit);
            caseinfo.UpdateRiskMatrixData(updateRisk);
            test.Click(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            grid.SortByColumn("Department", "ascending");
            caseinfo.ValidateRiskMatrixGridData(updateRisk);
            report.Step("Delete Risk");
            test.Click(caseinfo._RiskDelete);
            test.ClickandConfirm(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            report.Step("Add No Risk to existing No Risk");
            var dupeNoRiskDeptId = Data.GetRiskMatrix(caseDetailId).First(n => n.NoRiskIdentified).DepartmentId;
            var dupeNoRisk = caseinfo.GenerateRiskMatrixData(true, dupeNoRiskDeptId);
            test.Click(caseinfo._RiskAdd);
            caseinfo.UpdateRiskMatrixData(dupeNoRisk);
            test.ClickAndVerifyAlert(caseinfo._ModalSave, "No Risk Identified has already been saved for this department.", true);
            test.Click(caseinfo._ModalCancel);
            report.Step("Add No Risk to existing Risks");
            var noRiskToRiskDeptId = Data.GetRiskMatrix(caseDetailId).First(n => n.NoRiskIdentified == false).DepartmentId;
            var noRiskToRisk = caseinfo.GenerateRiskMatrixData(true, noRiskToRiskDeptId);
            test.Click(caseinfo._RiskAdd);
            caseinfo.UpdateRiskMatrixData(noRiskToRisk);
            test.ClickAndVerifyAlert(caseinfo._ModalSave, @"Risks have already been saved for this department. Would you like to permanently delete the saved risks and add the ""No Risk Identified"" record?", true);
            test.EditField(caseinfo._RiskFilter, Data.GetRiskMatrixOptionName(noRiskToRiskDeptId));
            grid.SortByColumn("Description", "descending");
            caseinfo.ValidateRiskMatrixGridData(noRiskToRisk);
            report.Step("Add Risk to existing No Risks");
            var riskToNoRisk = caseinfo.GenerateRiskMatrixData(false, noRiskToRiskDeptId);
            test.Click(caseinfo._RiskAdd);
            caseinfo.UpdateRiskMatrixData(riskToNoRisk);
            test.ClickAndVerifyAlert(caseinfo._ModalSave, @"A ""No Risk Identified"" record has already been saved for this department. Would you like to permanently delete the ""No Risk Identified"" record and add the risk?", true);
            test.EditField(caseinfo._RiskFilter, Data.GetRiskMatrixOptionName(noRiskToRiskDeptId));
            grid.SortByColumn("Description", "ascending");
            caseinfo.ValidateRiskMatrixGridData(riskToNoRisk);
            report.Step("Delete Risk");
            test.Click(caseinfo._RiskDelete);
            test.ClickandConfirm(caseinfo._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            testHelper.End();

        }

        public static void Incidents()
        {
            Data.PopulateIncidents();
            var incident = Data.GetIncidents().OrderByDescending(i => i.IncidentNumber);
            testHelper.Start();

            report.Step("Load Incidents Page");
            test.Click(By.LinkText("Incidents"));
            test.vars.verify(test.VerifyNoErrorToasts());
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyText(test.driver, incidents._Total, "Total Items: " + incident.Count()));
            incidents.ValidateIncidentsGrid(incident.First());

            report.Step("Add Incident");
            var addRecord = incidents.GenerateIncidentRecord();
            test.Click(incidents._Add);
            incidents.UpdateIncident(addRecord);
            test.Click(incidents._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            incidents.ValidateIncidentsGrid(addRecord);

            report.Step("Edit Incident");
            var updateRecord = incidents.GenerateIncidentRecord();
            test.Click(incidents._Edit);
            incidents.ValidateIncidentsModal(addRecord);
            incidents.UpdateIncident(updateRecord);
            test.Click(incidents._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            incidents.ValidateIncidentsGrid(updateRecord);

            report.Step("Delete Incident");
            test.Click(incidents._Delete);
            incidents.ValidateIncidentsModal(updateRecord);
            test.ClickandConfirm(test.driver, incidents._ModalDelete);

            incidents.ValidateIncidentsGrid(incident.First());

            testHelper.End();
        }

        public static void AdminOrganizations()
        {
            var businesses = Data.GetOrganizations();
            if (businesses.OrderBy(n => n.OrganizationName).First().OrganizationName.Contains("111 Org"))
                throw new Exception("There is a leftover org record from a previous run (111 Org*).  Please remove the record and re-run.");

            testHelper.Start();
            test.Click(By.LinkText("Administration"));
            test.Click(By.LinkText("Organization/Entity"));
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            report.Step("Verify Organization/Entity Grid Count");
            test.vars.verify(test.VerifyText(test.driver, admin._TotalItems, "Total Items: " + businesses.Count));
            report.Step("Verify Organization/Entity Grid (First Record)");
            var org = businesses.OrderBy(n => n.OrganizationName).First();
            admin.ValidateOrgGrid(org);
            report.Step("Add Organization/Entity");
            var timestamp = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            var name = "111 Org Added: " + timestamp;
            var url = "http://www." + timestamp + ".com";
            test.Click(admin._Add);
            test.EditField(By.Name("organizationName"), name);
            test.EditField(By.Name("webAddress"), url);
            test.Click(By.Name("strategicClient"));
            test.Click(admin._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.WaitForElement(By.XPath("//span[text()='" + name + "']"));
            test.vars.verify(admin.VerifyValueByColumn("Name", name));
            test.vars.verify(admin.VerifyHrefByColumn("Web Address", url));
            test.vars.verify(admin.VerifyValueByColumn("Strategic Client", "Yes"));
            report.Step("Edit Organization/Entity");
            timestamp = DateTime.Now.ToString("yyyyMMddhhmmssfff");
            test.Click(admin._Edit);
            name = "111 Org Updated: " + timestamp;
            url = "http://www." + timestamp + ".com";
            test.EditField(By.Name("organizationName"), name);
            test.EditField(By.Name("webAddress"), url);
            test.Click(By.Name("strategicClient"));
            test.Click(admin._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.WaitForElement(By.XPath("//span[text()='" + name + "']"));
            test.vars.verify(admin.VerifyValueByColumn("Name", name));
            test.vars.verify(admin.VerifyHrefByColumn("Web Address", url));
            test.vars.verify(admin.VerifyValueByColumn("Strategic Client", "No"));
            report.Step("Delete Organization/Entity - Associated"); //Block Delete
            var associations = Data.GetContactToOrganization();
            var associated = businesses.Where(b => associations.Select(i => i.OrganizationId).ToList().Contains(b.OrganizationId));
            test.EditField(admin._TextFilter, associated.First().OrganizationName);
            test.Click(admin._Delete);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyElementEnabled(admin._ModalSave, false));
            test.Click(admin._ModalCancel);
            report.Step("Delete Organization/Entity - Unassociated"); //Allow Delete  
            test.EditField(admin._TextFilter, name);
            test.Click(admin._Delete);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyElementEnabled(admin._ModalSave, true));
            test.ClickandConfirm(test.driver, admin._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.WaitForElementNotPresent(By.XPath("//span[text()='" + name + "']"));
            test.vars.verify(test.VerifyText(test.driver, search._AlertMessage, "There are no organizations that match the currently entered filter."));

            testHelper.End();
        }

        public static void AdminContacts()
        {
            Data.RandomizeMockData();
            var contacts = Data.GetContactData().OrderBy(n => n.LastName).ThenBy(c => c.ContactId);
            var currentContactRecord = contacts.First();
            var addContactRecord = admin.GenerateContactRecord();
            if (currentContactRecord.LastName.Contains("AAALast")) throw new Exception("There is a leftover Contact test record ('AAALastXXX') from a previous run.  Please remove and re-run this test.");
            var addOrgRecordName = Data.GetOrganizations().Skip(new Random().Next(1, Data.GetOrganizations().Count)).First().OrganizationName;  //Randomly selected orgname
            var addOrgRecord = Data.GetOrganizations().First(n => n.OrganizationName == addOrgRecordName);  //Ensure record used is the first with that name
                        
            testHelper.Start();
            test.Click(By.LinkText("Administration"));
            test.Click(By.XPath("//a[text()='Administration']/..//a[text()='Contacts']"));
            Facilitator.Template.grid.WaitForGridData();
            test.vars.verify(test.VerifyNoErrorToasts());
            report.Step("Verify Contacts Grid Count");
            test.vars.verify(test.VerifyText(test.driver, admin._TotalItems, "Total Items: " + contacts.Count()));
            report.Step("Verify Filter and Contacts Grid (First Record)");
            test.EditField(admin._TextFilter, contacts.First().FirstName);
            admin.ValidateContactGrid(currentContactRecord);
            test.ClearField(admin._TextFilter);
            report.Step("Add Contact");
            test.Click(admin._Add);
            admin.UpdateContactRecord(addContactRecord);
            test.Click(admin._AddOrg);
            admin.AddContactOrgRecord(addOrgRecord);
            test.Click(admin._LinkToContact);
            test.Click(admin._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.WaitForElement(By.XPath("//span[text()='" + addContactRecord.LastName + "']"));
            admin.ValidateContactGrid(addContactRecord);
            var contactId = Data.GetContactData().Max(m => m.ContactId);  //Get the ContactId most recently inserted for the record
            addContactRecord.ContactId = contactId;
            report.Step("Edit Contact");
            test.Click(admin._Edit);
            Facilitator.Template.grid.WaitForGridData();
            admin.ValidateContactAndOrgRecords(addContactRecord, addOrgRecord);

            var updateContactRecord = admin.GenerateContactRecord(contactId);
            admin.UpdateContactRecord(updateContactRecord);
            test.Click(admin._EditOrg);
            admin.UpdateContactOrgRecord();
            test.Click(admin._SaveOrg);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.Click(admin._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            admin.ValidateContactGrid(updateContactRecord);
            report.Step("Delete Contact - Associated"); //Block Delete
            var associations = Data.GetCaseDetailContact();
            var associated = contacts.Where(b => associations.Select(i => i.ContactId).ToList().Contains(b.ContactId));
            test.EditField(admin._TextFilter, associated.First().FirstName);
            test.Click(admin._Delete);
            test.vars.verify(test.VerifyElementEnabled(admin._ModalSave, false));
            test.Click(admin._ModalCancel);
            test.ClearField(admin._TextFilter);
            report.Step("Delete Organization from Contact");
            test.Click(admin._Edit);
            Facilitator.Template.grid.WaitForGridData();
            admin.ValidateContactAndOrgRecords(updateContactRecord, addOrgRecord);
            test.Click(admin._DeleteOrg);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyText(test.driver, search._AlertMessage, "There are no Organizations that match the currently entered filter."));
            test.ClickandConfirmHtml(test.driver, admin._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            //temporary workaround for known issue where concurrency will block a delete after an edit of the same record.
            test.driver.Navigate().Refresh();
            test.driver.SwitchTo().Alert().Accept();
            test.WaitForPageToLoad(test.driver);
            grid.WaitForGridData();
            //
            report.Step("Delete Contact - Unassociated"); //Allow Delete
            test.Click(admin._Delete);
            test.ClickandConfirm(admin._ModalSave);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.WaitForElementNotPresent(By.XPath("//span[text()='" + updateContactRecord.LastName + "']"));
            test.vars.verify(admin.VerifyValueNotByColumn("Last Name", updateContactRecord.LastName));

            //Not needed while above issue workaround is present, may be needed again if that is fixed without this.
            //temporary workaround for known issue (126046) causing an unexpected unsaved data prompt if logging out
            //test.driver.Navigate().Refresh();
            //test.driver.SwitchTo().Alert().Accept();
            //test.WaitForPageToLoad(test.driver);
            ////
            testHelper.End();
        }

        public static void CreateNew()
        {
            var dupeCase = Data.GetCaseData().OrderBy(i => i.CaseDetailId).First();

            testHelper.Start();
            test.Click(By.LinkText("Create New Case"));
            report.Step("Verify duplicate check");
            var addRecord = caseinfo.GenerateNewCase();
            caseinfo.UpdateOverviewData(addRecord);

            test.EditField(By.Name("billingCode"), dupeCase.BillingCode);  // set to dupe case number
            //test.Click(caseinfo._Save);                                   //DEL button name changed
            test.Click(caseinfo._SaveOK);                                   //DEL button name changed
            test.vars.verify(test.VerifyText(test.driver, caseinfo._ErrorMessage, "Billing Code " + dupeCase.BillingCode + " is already in use by case " + dupeCase.CaseName.Replace("  ", " ") + " and must be unique."));
                    
            test.EditField(By.Name("billingCode"), addRecord.BillingCode); //set to new case number
            test.Click(caseinfo._SaveOK);                                    //DEL button name changed
            //test.Click(caseinfo._Save);                                    //DEL button name changed
            test.vars.verify(test.VerifyNoErrorToasts());

            navigate.Refresh();
            test.vars.verify(caseinfo.VerifyCaseBanner(addRecord.CaseName, addRecord.BillingCode, Data.GetCaseStatus(addRecord.CaseStatusId).First().Name)); //Validate Banner
            caseinfo.ValidateOverviewData(addRecord); //Validate Overview populated
            testHelper.End();
        }

        public static void TestQuery()
        {
            testHelper.Start();
            test.Click(By.LinkText("Queries"));
            test.vars.verify(test.VerifyNoErrorToasts());
            test.SelectField(test.driver, queries._Select, "Test Query 1");
            test.EditField(By.Name("StartDate"), "1/1/2000");
            test.EditField(By.Name("EndDate"), "12/31/2019");
            test.Click(By.XPath("//button[@ng-click='vm.submit()']"));
            test.vars.verify(test.VerifyNoErrorToasts());
            Facilitator.Template.grid.WaitForGridData();
            testHelper.End();
        }

        public static void Reports()  //Note: Doesn't work in IE.  Driver doesn't allow links to be clicked (even manually) as long as the driver is running .
        {
            Data.PopulateReports();
            testHelper.Start();
            test.Click(By.LinkText("Reports"));
            test.vars.verify(test.VerifyNoErrorToasts());
            var randomreport = Data.GetReports().OrderBy(x => Guid.NewGuid()).First();
            reports.ValidateReport(randomreport.ReportName, randomreport.URL);
            testHelper.End();
        }

        public static void Executive(string username, string password)
        { 
            //Assumes both Executive and Risk Matrix roles
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId")) + 1;
            permissions.PopulateData(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId).First();
            testHelper.Start(username, password);
            permissions.ValidateMenuItems(false, true, true, true, true, true);
            permissions.ValidateSearch(caseDetail);
            permissions.ValidateMenuItems(true, true, true, true, true, true);
            permissions.ValidateCaseSummary(caseDetail, true, true);
            permissions.ValidateCaseDetail(caseDetailId, true);
            permissions.ValidateDates(caseDetail.CaseDetailId, true, true, true, true);
            permissions.ValidateContacts(caseDetailId, true, true, true);
            permissions.ValidateOps(caseDetailId, true);
            permissions.ValidateDocuments(caseDetailId, true, true, true);
            permissions.ValidateStatistics(caseDetailId);
            permissions.ValidateHealthStatus(caseDetailId, true, true, true);
            permissions.ValidateRiskMatrix(caseDetailId);
            permissions.ValidateIncidents(true);
            permissions.ValidateReports(null);
            permissions.ValidateQueries(true);
            permissions.ValidateAdminOrgs(true, true, true);
            permissions.ValidateAdminContacts(true, true, true);
            permissions.ValidateCreateCase(true);
            permissions.ValidateUserMenu();
            testHelper.End();
        }

        public static void ProjectManager(string username, string password)
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId")) + 1;
            permissions.PopulateData(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId).First();
            testHelper.Start(username, password);
            permissions.ValidateMenuItems(false, true, true, true, true);
            permissions.ValidateSearch(caseDetail);
            permissions.ValidateMenuItems(true, true, true, true, true);
            permissions.ValidateCaseSummary(caseDetail, true, false);
            permissions.ValidateCaseDetail(caseDetailId, true);
            permissions.ValidateDates(caseDetail.CaseDetailId, true, true, true, true);
            permissions.ValidateContacts(caseDetailId, true, true, true);
            permissions.ValidateOps(caseDetailId, true);
            permissions.ValidateDocuments(caseDetailId, true, true, true);
            permissions.ValidateStatistics(caseDetailId);
            permissions.ValidateHealthStatus(caseDetailId, true, true, true);
            navigate.ValidatePageAccess("riskmatrix", caseDetailId.ToString(), false);
            permissions.ValidateIncidents(false);
            permissions.ValidateReports(null);
            permissions.ValidateQueries(true);
            permissions.ValidateAdminOrgs(true, true, true);
            permissions.ValidateAdminContacts(true, true, true);
            permissions.ValidateCreateCase(true);
            permissions.ValidateUserMenu();
            testHelper.End();
        }

        public static void ProjectCoordinator(string username, string password)
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId")) + 1;
            permissions.PopulateData(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId).First();
            testHelper.Start(username, password);
            permissions.ValidateMenuItems(false, true, true, true, true);
            permissions.ValidateSearch(caseDetail);
            permissions.ValidateMenuItems(true, true, true, true, true);
            permissions.ValidateCaseSummary(caseDetail, true, false);
            permissions.ValidateCaseDetail(caseDetailId, true);
            permissions.ValidateDates(caseDetail.CaseDetailId, true, true, true, false);
            permissions.ValidateContacts(caseDetailId, true, true, true);
            permissions.ValidateOps(caseDetailId, true);
            permissions.ValidateDocuments(caseDetailId, true, true, true);
            permissions.ValidateStatistics(caseDetailId);
            permissions.ValidateHealthStatus(caseDetailId, true, true, true);
            navigate.ValidatePageAccess("riskmatrix", caseDetailId.ToString(), false);
            permissions.ValidateIncidents(false);
            permissions.ValidateReports(null);
            permissions.ValidateQueries(true);
            permissions.ValidateAdminOrgs(true, true, false);
            permissions.ValidateAdminContacts(true, true, false);
            permissions.ValidateCreateCase(true);
            permissions.ValidateUserMenu();
            testHelper.End();
        }

        public static void ReadOnlyPlusViewIncidents(string username, string password)
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId")) + 1;
            permissions.PopulateData(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId).First();
            testHelper.Start(username, password);
            permissions.ValidateMenuItems(false, false, true, false, false);
            permissions.ValidateSearch(caseDetail);
            permissions.ValidateMenuItems(true, false, true, false, false);
            permissions.ValidateCaseSummary(caseDetail, false, false);
            permissions.ValidateCaseDetail(caseDetailId, false);
            permissions.ValidateDates(caseDetailId, false, false, false, false);
            permissions.ValidateContacts(caseDetailId, false, false, false);
            permissions.ValidateOps(caseDetailId, false);
            permissions.ValidateDocuments(caseDetailId, false, false, false);
            permissions.ValidateStatistics(caseDetailId);
            navigate.ValidatePageAccess("riskmatrix", caseDetailId.ToString(), false);
            navigate.ValidatePageAccess("healthstatus", null, false);
            permissions.ValidateIncidents(false);
            permissions.ValidateReports(null);
            permissions.ValidateQueries(true);
            navigate.ValidatePageAccess("organization", null, false);
            navigate.ValidatePageAccess("contact", null, false);
            navigate.ValidatePageAccess("createcase", null, false);

            permissions.ValidateUserMenu();
            testHelper.End();
        }

        public static void ViewOnly(string username, string password)
        {
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId")) + 1;
            permissions.PopulateData(caseDetailId);
            var caseDetail = Data.GetCaseDataById(caseDetailId).First();
            testHelper.Start(username, password);
            permissions.ValidateMenuItems(false, false, false, false, false);
            permissions.ValidateSearch(caseDetail);
            permissions.ValidateMenuItems(true, false, false, false, false);
            permissions.ValidateCaseSummary(caseDetail, false, false);
            permissions.ValidateCaseDetail(caseDetailId, false);
            permissions.ValidateDates(caseDetailId, false, false, false, false);
            permissions.ValidateContacts(caseDetailId, false, false, false);
            permissions.ValidateOps(caseDetailId, false);
            permissions.ValidateDocuments(caseDetailId, false, false, false);
            permissions.ValidateStatistics(caseDetailId);
            navigate.ValidatePageAccess("riskmatrix", caseDetailId.ToString(), false);
            navigate.ValidatePageAccess("healthstatus", null, false);
            navigate.ValidatePageAccess("incident", null, false);
            permissions.ValidateReports(null);
            permissions.ValidateQueries(true);
            navigate.ValidatePageAccess("organization", null, false);
            navigate.ValidatePageAccess("contact", null, false);
            navigate.ValidatePageAccess("createcase", null, false);
            permissions.ValidateUserMenu();
            testHelper.End();
        }

        public static void OpsLoad(int iterations)//Bug 167801
        {
            report._debuglevel = 3;
            var sectionfailures = 0;
            var pagefailures = 0;
            testHelper.Start();
            navigate.DirectToPage("ops", "50");
            for (var i = 0; i < iterations; i++)
            {
                var errorcount = 0;
                test.WaitForPageToLoad(test.driver);
                errorcount = errorcount + caseinfo.VerifySectionLoad("Claims", caseinfo._EmailProcessing);
                //errorcount = errorcount + caseinfo.VerifySectionLoad("Contact Center", caseinfo._OptionSuite);
                //errorcount = errorcount + caseinfo.VerifySectionLoad("Disbursements", caseinfo._InitialDistributionDate);
                //errorcount = errorcount + caseinfo.VerifySectionLoad("Document Processing", caseinfo._DpServicingTier);
                //errorcount = errorcount + caseinfo.VerifySectionLoad("HR", caseinfo._DrugTesting);
                //errorcount = errorcount + caseinfo.VerifySectionLoad("Mailings", caseinfo._PoBoxType);
                sectionfailures = sectionfailures + errorcount;
                if (errorcount > 0)
                {
                    report.Step("Iteration " + i + " failed.");
                    
                    pagefailures = pagefailures + 1;
                }
                else
                {
                    report.Step("Iteration " + i + " passed.");
                }
                navigate.Refresh();
            }
            report.Step("For a total of " + iterations + " page loads, there were " + pagefailures + " page failures, and " + sectionfailures + " sectionfailures.");
            testHelper.End();
        }

        public static void DetailsLoad(int iterations)//Bug 167801
        {
            report._debuglevel = 3;
            var sectionfailures = 0;
            var pagefailures = 0;
            testHelper.Start();
            navigate.DirectToPage("casedetail", "50");
            for (var i = 0; i < iterations; i++)
            {
                var errorcount = 0;
                test.WaitForPageToLoad(test.driver);
                errorcount = errorcount + caseinfo.VerifySectionLoad("Case Kickoff Details", caseinfo._NoticeAndClaimFormFormat);
                errorcount = errorcount + caseinfo.VerifySectionLoad("Shutdown and Retention", caseinfo._ClaimantRecords);
                sectionfailures = sectionfailures + errorcount;
                if (errorcount > 0)
                {
                    report.Step("Iteration " + i + " failed.");
                    
                    pagefailures = pagefailures + 1;
                }
                else
                {
                    report.Step("Iteration " + i + " passed.");
                }
                navigate.Refresh();
            }
            report.Step("For a total of " + iterations + " page loads, there were " + pagefailures + " page failures, and " + sectionfailures + " sectionfailures.");
            testHelper.End();
        }

        public static void BannerLoad(int caseDetailId)  //Bug 153835
        {
            var caseDetail = Data.GetCaseDataById(caseDetailId);
            var name = caseDetail.First().CaseName;
            var code = caseDetail.First().BillingCode;
            var status = Data.GetCaseStatus(caseDetail.First().CaseStatusId).First().Name;
            testHelper.Start();
            navigate.DirectToPage("casesummary", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            navigate.DirectToPage("casedetail", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            navigate.DirectToPage("milestone", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            navigate.DirectToPage("casecontact", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            navigate.DirectToPage("ops", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            navigate.DirectToPage("casedocument", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            navigate.DirectToPage("stats", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            navigate.DirectToPage("healthstatus", caseDetailId.ToString());
            test.vars.verify(caseinfo.VerifyCaseBanner(name, code, status));
            testHelper.End();
        }

        public static void TabNavigation(int caseDetailId) //Bug 171436
        {
            testHelper.Start(caseDetailId);
            caseinfo.SelectTab("Detail");
            test.VerifyURL("?cid=" + caseDetailId);
            caseinfo.SelectTab("Summary");
            caseinfo.SelectTab("Dates");
            test.VerifyURL("?cid=" + caseDetailId);
            caseinfo.SelectTab("Summary");
            caseinfo.SelectTab("Contacts");
            test.VerifyURL("?cid=" + caseDetailId);
            caseinfo.SelectTab("Summary");
            caseinfo.SelectTab("Ops/Shared Services");
            test.VerifyURL("?cid=" + caseDetailId);
            caseinfo.SelectTab("Summary");
            caseinfo.SelectTab("Documents");
            test.VerifyURL("?cid=" + caseDetailId);
            caseinfo.SelectTab("Summary");
            caseinfo.SelectTab("Statistics");
            test.VerifyURL("?cid=" + caseDetailId);
            caseinfo.SelectTab("Summary");
            caseinfo.SelectTab("Health Status");
            test.VerifyURL("?cid=" + caseDetailId);
            caseinfo.SelectTab("Summary");
            testHelper.End();
        }

        public static void SmokeTest(string url, string username, string password)
        {//Logic assumes user is executive role
            testHelper.Start(url, username, password);
            test.vars.verify(test.VerifyNoErrorToasts());
            report.Step("Validate Standard Search - Load and Perform Search");
            search.ValidateStandardSearchInput("caseName", "Case Name", search._StandardOperatorCaseName, search._StandardFilterCaseName, "Begins with", "a", false);
            test.vars.verify(test.VerifyNoErrorToasts());           
            search.ValidateQuickSearch("billingCode", "Billing Code", "CA0", false, true);
            test.vars.verify(test.VerifyNoErrorToasts());
            test.vars.verify(test.VerifyFieldPopulation(By.Name("billingCode"), true));
            permissions.ValidateMenuItems(true, true, true, true, true, true);
            caseinfo.ValidatePageLoad("Detail", By.Name("noticeAndClaimFormFormat"), false);
            caseinfo.ValidatePageLoad("Dates", null, true);
            caseinfo.ValidatePageLoad("Contacts", null, true);
            caseinfo.ValidatePageLoad("Ops/Shared Services", By.Name("reissueSchedule"), false);
            caseinfo.ValidatePageLoad("Documents", null, true);
            caseinfo.ValidatePageLoad("Statistics", null, true);
            caseinfo.ValidatePageLoad("Health Status", null, true);
            caseinfo.ValidatePageLoad("Risk Matrix", null, true);
            caseinfo.ValidatePageLoad("Incidents", null, true);
            caseinfo.ValidatePageLoad("Reports", By.XPath("//a[contains(@ng-repeat, 'report')]"), false);
            caseinfo.ValidatePageLoad("Queries", By.XPath("//select[@ng-model='vm.selectedQueryId']"), false);
            caseinfo.ValidatePageLoad("Organization/Entity", null, true);
            caseinfo.ValidatePageLoad("AdminContacts", null, true);
            caseinfo.ValidatePageLoad("Create New Case", null, false);
            testHelper.End();
        }

        public static void FieldValidation(int caseDetailId)
        {
            testHelper.Start(caseDetailId);
            caseinfo.ValidateOverviewFieldValidation();
            caseinfo.SelectTab("Detail");
            caseinfo.ValidateCaseDetailFieldValidation();
            caseinfo.SelectTab("Dates");
            caseinfo.ValidateMilestoneFieldValidation();
            caseinfo.SelectTab("Ops/Shared Services");
            caseinfo.ValidateOpsFieldValidation(caseDetailId);
            caseinfo.SelectTab("Documents");
            caseinfo.ValidateDocumentsRequiredFields();
            caseinfo.SelectTab("Health Status");
            caseinfo.ValidateHealthFieldValidation();
            navigate.MenuItem(navigate._Incidents);
            incidents.ValidateIncidentsFieldValidation();
            navigate.MenuItem(navigate._AdminOrganization);
            admin.ValidateOrganizationFieldValidation();
            navigate.MenuItem(navigate._AdminContacts);
            admin.ValidateContactFieldValidation();

            //temporary workaround for known bug (126046) causing an unexpected unsaved data prompt if logging out
            test.driver.Navigate().Refresh();
            test.driver.SwitchTo().Alert().Accept();
            test.WaitForPageToLoad(test.driver);
            //         

            testHelper.End();
        }

        public static void SessionContinuousUse()
        {
            const int iterations = 20;
            testHelper.Start();
            report.Step("Start: " + DateTime.Now.ToLongTimeString());
            for (var i = 0; i < iterations; i++)
            {
                System.Threading.Thread.Sleep(120000);
                report.Step("Refresh at: " + DateTime.Now.ToLongTimeString());
                navigate.Refresh();
                if (test.driver.Url.Contains("/login")) throw new Exception("User session has been lost at: " + DateTime.Now.ToLongTimeString());
            }
            report.Step("End: " + DateTime.Now.ToLongTimeString());
            testHelper.End();
        }

        public static void Testing()
        {
            //For testing random snippets of code quickly.
            var caseDetailId = int.Parse(ConfigurationManager.AppSettings.Get("caseId")) + 1;
            testHelper.Start("eExecutive", "P@ssword1", caseDetailId);
            caseinfo.SelectTab("Ops/Shared Services");
            permissions.ValidateClaims(caseDetailId, true);
            testHelper.End();
        }

        public static void DocumentsHeaderLoad() //bug 229830 closed but maybe intermittent
        {
            Data.PopulateIncomingDocuments(navigate.CaseDetailId);
            testHelper.Start(navigate.CaseDetailId);
            test.vars.verify(test.VerifyNoErrorToasts());
            caseinfo.SelectTab("Ops/Shared Services");
            System.Threading.Thread.Sleep(5000);                    //DEL stupid slow computers
            OpsDisbursements(navigate.CaseDetailId);
            System.Threading.Thread.Sleep(5000);                    //DEL stupid slow computers
            OpsDocumentProcessing(navigate.CaseDetailId);
            testHelper.End();
        }

    }
}
