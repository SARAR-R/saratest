﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using OpenQA.Selenium;
using Automation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;

namespace Casebook
{
    public class grid
    {
        public static By _PageSize = By.XPath("//select[contains(@ng-model, 'paginationPageSize')]");
        public static By _FilteredItems = By.XPath("//div[@class='ui-grid-footer-item-counts']/span[contains(text(), 'Filtered Items')]");
        public static By _TotalItems = By.XPath("//div[@class='ui-grid-footer-item-counts']/span[contains(text(), 'Total Items')]");
        public static By _CurPage = By.XPath("//input[@title='Selected page']");
        public static By _NumPages = By.XPath("//span[contains(@class, 'ui-grid-pager-max-pages-number')]");
        public static By _FirstPage = By.XPath("//button[@class='ui-grid-pager-first']");
        public static By _PreviousPage = By.XPath("//button[@class='ui-grid-pager-previous']");
        public static By _NextPage = By.XPath("//button[@class='ui-grid-pager-next']");
        public static By _LastPage = By.XPath("//button[@class='ui-grid-pager-last']");
        public static By _ExcelExport = By.XPath("//button[contains(@ng-click, 'excelExport')]");
        public static By _Add = By.XPath("//button[contains(@ng-click, 'add')]");
        public static By _View = By.XPath("//div[contains(@class, 'ui-grid-row') and not(contains(@style, 'margin-top'))]//a[contains(@ng-click , 'edit')]/i[contains(@class, 'fa-eye')]");
        public static By _Edit = By.XPath("//div[contains(@class, 'ui-grid-row') and not(contains(@style, 'margin-top'))]//a[contains(@ng-click , 'edit')]/i[contains(@class, 'fa-pencil')]");
        public static By _Delete = By.XPath("//div[contains(@class, 'ui-grid-row') and not(contains(@style, 'margin-top'))]//a[contains(@ng-click , 'delete')]");
        public static By _ModalSave = By.XPath("//div[contains(@class, 'modal-footer')]//button[contains(@ng-click, 'vm.confirm')]");
        public static By _ModalCancel = By.XPath("//div[contains(@class, 'modal-footer')]//button[contains(@ng-click, 'vm.cancel')]");
        public static By _ModalDelete = By.XPath("//div[contains(@class, 'modal-footer')]//button[contains(@ng-click , 'vm.delete')]");
        public static string Row = "//div[contains(@class, 'ui-grid-row')]";
        public static By _TextFilter = By.XPath("//input[@ng-model='qs.criteria']");
        public static By _ActiveFilter = By.XPath("//input[@ng-model='qs.filterActive']");
        public static By _Submit = By.XPath("//button[@ng-click='qs.filterClick()']");

        public static void SelectRowByText(string text)
        {
            test.Click(By.XPath("//div[@class='ngCanvas']//span[.='" + text + "']"));
        }

        public new static void WaitForGridData()
        {
          for (var i = 0; i < config.TIMEOUT; i++)
            {
                if (test.driver.FindElements(By.XPath("//div[contains(@class, 'ngCell')]")).Count > 0) return;  //ngGrid cells loaded
                if (test.driver.FindElements(By.XPath("//div[contains(@class, 'ui-grid-cell-contents')]")).Count > 0) return;  //uiGrid cells loaded
                if (test.driver.FindElements(By.XPath("//div[contains(@class, 'alert')]/parent::div[not(contains(@class, 'ng-hide'))]")).Count > 0) return; //User is notified of no data
                System.Threading.Thread.Sleep(1000);
            }
            report.Fail("Grid failed to load");
        }

        public static void SortByColumn(string columnName, string sort)
        {
                  if (test.driver.FindElements(By.XPath("//span[text()='" + columnName + "' and contains(@class, 'ui-grid-header-cell-label')]/ancestor::div[@aria-sort='" + sort + "']"))
                    .Count != 0) return;//If properly sorted, exit method.
            test.Click(test.driver, By.XPath("//span[text()='" + columnName + "' and contains(@class, 'ui-grid-header-cell-label')]"));
            if (test.driver.FindElements(By.XPath("//span[text()='" + columnName + "' and contains(@class, 'ui-grid-header-cell-label')]/ancestor::div[@aria-sort='" + sort + "']"))
                    .Count != 0) return;//If properly sorted, exit method.
            test.Click(test.driver, By.XPath("//span[text()='" + columnName + "' and contains(@class, 'ui-grid-header-cell-label')]"));
        }

        public static string ColumnUid(string column)
        {
            var col = test.driver
                .FindElement(By.XPath("//span[text()='" + column +
                                      "']/ancestor::div[contains(@class, 'ui-grid-header-cell') and contains(@class, 'ng-scope')]"))
                .GetAttribute("class");
            var attributes = col.Split(' ');
            return attributes[4];
        }

        public class ColumnDetails
        {
            public string Label { get; set; }
            public string Type { get; set; } = "text";
        }

        public static int VerifySortOrder(string column, string type)
        {
            var by = By.XPath("//div[contains(@class, '" + ColumnUid(column) + "') and contains(@class, 'ui-grid-cell')]//div");

            try
            {
                //Ascending Sort
                if (test.driver.FindElements(By.XPath("//span[text()='" + column +
                                                      "']/ancestor::div[@aria-sort='ascending']"))
                        .Count == 0) //If not already sorted by ascending
                {
                    SortByColumn(column, "ascending");
                }
                test.WaitForElement(By.XPath("//span[text()='" + column + "']/ancestor::div[@aria-sort='ascending']"));
                var asc = test.driver.FindElements(by).Where(s => !string.IsNullOrWhiteSpace(s.Text)).ToList();
                Assert.IsTrue(type == "numeric" ? asc.OrderBy(t => int.Parse(t.Text)).SequenceEqual(asc)
                    : asc.OrderBy(t => t.Text, StringComparer.OrdinalIgnoreCase).SequenceEqual(asc), test.ListToString(asc));
                report.Pass(column + " column is sorting by ascending correctly.");
            }
            catch (Exception e)
            {
                report.Fail(column + " column is not sorting by ascending correctly.", e);
                return 1;
            }
            try
            {
                //Descending Sort
                SortByColumn(column, "descending");
                test.WaitForElement(By.XPath("//span[text()='" + column + "']/ancestor::div[@aria-sort='descending']"));
                var desc = test.driver.FindElements(by).Where(s => !string.IsNullOrWhiteSpace(s.Text)).ToList();
                Assert.IsTrue(type == "numeric" ? desc.OrderByDescending(t => int.Parse(t.Text)).SequenceEqual(desc)
                    : desc.OrderByDescending(t => t.Text).SequenceEqual(desc), test.ListToString(desc));
                report.Pass(column + " column is sorting by descending correctly.");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail(column + " column is not sorting by descending correctly.", e);
                return 1;
            }

        }

        public static void ValidateColumnSorting(List<ColumnDetails> columns)
        {
            foreach (var column in columns)
            {
                test.vars.verify(VerifySortOrder(column.Label, column.Type));
            }
        }

        public static void ValidatePaging(string table, string defaultSize, bool filter = false)
        {
            report.Step("Validate Paging");
            try
            {
                double records = filter
                    ? int.Parse(test.driver.FindElement(_FilteredItems).Text.Substring(16))
                    : int.Parse(test.driver.FindElement(_TotalItems).Text.Substring(13));
                var sizes = new[] { "10", "20", "50", "100" };
                //Page Sizing
                test.vars.verify(VerifyNumberOfPages(filter));
                test.vars.verify(VerifyRowCount(By.XPath(table + Row), int.Parse(defaultSize), records));
                foreach (var size in sizes)
                {
                    if (size == defaultSize) continue;
                    test.SelectField(_PageSize, size);
                    test.vars.verify(VerifyNumberOfPages(filter));
                    test.vars.verify(VerifyRowCount(By.XPath(table + Row), int.Parse(size), records));
                }
                //Page Navigation
                test.SelectField(_PageSize, "10");

                double pageSize = int.Parse(new SelectElement(test.driver.FindElement(_PageSize)).SelectedOption.Text);

                if (records < pageSize)
                    throw new InvalidOperationException(
                        "There are not enough records in this grid to validate page navigation.");

                test.Click(_NextPage);
                test.vars.verify(test.VerifyFieldValue(_CurPage, "2"));
                test.Click(_PreviousPage);
                test.vars.verify(test.VerifyFieldValue(_CurPage, "1"));
                test.Click(_LastPage);
                test.vars.verify(test.VerifyFieldValue(_CurPage,
                    Math.Ceiling(records / pageSize).ToString(CultureInfo.InvariantCulture)));
                test.Click(_FirstPage);
                test.vars.verify(test.VerifyFieldValue(_CurPage, "1"));
                test.SelectField(_PageSize, defaultSize);
            }
            catch (Exception e)
            {
                report.Fail("Unable to validate paging: " + e.Message);
                
            }

        }

        public static int VerifyPageSize(int expectedSize)
        {
            try
            {
                var recordsDisplayed = int.Parse(test.driver.FindElement(_FilteredItems).Text.Substring(16));
                var pageSize = new SelectElement(test.driver.FindElement(_PageSize));
                var total = int.Parse(test.driver.FindElement(_TotalItems).Text.Substring(13));

                var expectedRows = expectedSize > total ? total : expectedSize;  //If there aren't enough records use max available for validation.

                Assert.IsTrue(recordsDisplayed == expectedSize, "Rows displayed (" + recordsDisplayed + ") does not match expected number of rows (" + expectedRows + ").");
                Assert.IsTrue(pageSize.SelectedOption.GetAttribute("value") == expectedSize.ToString(), "Selected page size (" + pageSize + ") does not match expected page size (" + expectedRows + ").");
                report.Pass("Page size is correct.");
                return 0;
            }
            catch (Exception e)
            {
                report.Fail("Page Size is not correct.", e);
                return 1;
            }
        }

        public static int VerifyNumberOfPages(bool filter)
        {
            try
            {
                var numPages = double.Parse(test.driver.FindElement(_NumPages).Text.Substring(2));
                var pageSize = double.Parse(new SelectElement(test.driver.FindElement(_PageSize)).SelectedOption.Text);
                var records = filter
                    ? int.Parse(test.driver.FindElement(_FilteredItems).Text.Substring(16))
                    : int.Parse(test.driver.FindElement(_TotalItems).Text.Substring(13));

                try
                {
                    Assert.AreEqual(Math.Ceiling(records / pageSize), numPages);
                    report.Pass("Number of pages (" + numPages + ") matches expected value for page size (" + pageSize +
                                ") and total records (" + records + ").");
                    return 0;
                }
                catch (Exception e)
                {
                    report.Fail(
                        "Number of pages (" + numPages + ") does not match expected value for page size (" + pageSize +
                        ") and total records (" + records + ").", e);
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail(
                    "Unable to Verify Number of Pages", e);
                return 1;
            }
        }

        public static int VerifyRowCount(By rowXpath, int expected, double totalRecords)
        {
            try
            {
                var count = test.driver.FindElements(rowXpath).Count;
                if (expected > totalRecords)
                {
                    expected = Convert.ToInt32(totalRecords);
                }

                if (count == expected)
                {
                    report.Pass("Number of columns found matches expected (" + expected + ")");
                    return 0;
                }
                else
                {
                    report.Fail("Number of columns found (" + count + ") does not match expected (" + expected + ")");
                    return 1;
                }
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying the row count", e);
                return 1;
            }
        }

        public new static int VerifyCellContents(string directive, string columnName, string expectedValue, int row = 1)
        {
            try
            {
                var columnClass = test.driver.FindElement(By.XPath(directive + "//span[text()='" + columnName + "']")).GetAttribute("id");
                var columnNumber = columnClass.Split('-')[2];
                return test.VerifyTextContains(test.driver, By.XPath("(" + directive + "//div[@class = 'ui-grid-cell ng-scope ui-grid-coluiGrid-" + columnNumber + "'])[" + row + "]"), expectedValue ?? "");
            }
            catch (Exception e)
            {
                report.Fail(columnName + " does not contain " + expectedValue + ".", e);
                return 1;
            }
        }


    }
}
