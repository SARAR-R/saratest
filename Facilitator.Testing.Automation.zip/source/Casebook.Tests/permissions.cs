﻿using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using Automation;
using System.Linq;
using Casebook.Database;

namespace Casebook
{
    public static class permissions
    {
        public static void PopulateData(int caseDetailId)
        {
            Data.PopulateInitialRecords(caseDetailId);
            Data.GenerateMilestone(caseDetailId, "Automation", 1, "1/1/1900");
            Data.PopulateIncomingDocuments(caseDetailId);
            Data.PopulateMailingDetail(caseDetailId);
            Data.PopulateProjectTeam(caseDetailId);
            Data.PopulateIncidents();
            Data.PopulateReports();
            Data.PopulateHealthStatusUpdates(caseDetailId);
            Data.PopulateInvoice(caseDetailId);
        }

        public static void ValidateMenuItems(bool caseSelected, bool adminAccess, bool incidentsAccess, bool healthStatusAccess, bool createNewAccess, bool riskMatrixAccess = false)
        {
            try
            {
                report.Step("Verify Menu Items");
                test.vars.verify(test.VerifyElementVisibility(navigate._Search, true));
                test.Click(By.LinkText("Search"));
                test.vars.verify(test.VerifyElementVisibility(navigate._QuickSearch, true));
                test.vars.verify(test.VerifyElementVisibility(navigate._StandardSearch, true));
                test.Click(By.LinkText("Search"));
                test.vars.verify(test.VerifyElementVisibility(navigate._CaseInformation, caseSelected));
                if (caseSelected)
                {
                    test.Click(By.LinkText("Case Information"));
                    test.vars.verify(test.VerifyElementVisibility(navigate._Summary, true));
                    test.vars.verify(test.VerifyElementVisibility(navigate._Detail, true));
                    test.vars.verify(test.VerifyElementVisibility(navigate._Dates, true));
                    test.vars.verify(test.VerifyElementVisibility(navigate._Contacts, true));
                    test.vars.verify(test.VerifyElementVisibility(navigate._Ops, true));
                    test.vars.verify(test.VerifyElementVisibility(navigate._Documents, true));
                    test.vars.verify(test.VerifyElementVisibility(navigate._Statistics, true));
                    //test.vars.verify(test.VerifyElementVisibility(navigate._HealthStatus, healthStatusAccess)); //DEL removed by user story 268534
                    test.vars.verify(test.VerifyElementVisibility(navigate._RiskMatrix, riskMatrixAccess));
                    test.Click(By.LinkText("Case Information"));
                }
                test.vars.verify(test.VerifyElementVisibility(navigate._Incidents, incidentsAccess));
                test.vars.verify(test.VerifyElementVisibility(navigate._Reports, true));
                test.vars.verify(test.VerifyElementVisibility(navigate._Queries, true));
                test.vars.verify(test.VerifyElementVisibility(navigate._Administration, adminAccess));
                if (adminAccess)
                {
                    test.Click(By.LinkText("Administration"));
                    test.vars.verify(test.VerifyElementVisibility(navigate._AdminOrganization, true));
                    test.vars.verify(test.VerifyElementVisibility(navigate._AdminContacts, true));
                    test.Click(By.LinkText("Administration"));
                }
                test.vars.verify(test.VerifyElementVisibility(navigate._CreateNewCase, createNewAccess));
            }
            catch (Exception e)
            {
                report.Fail("Validate Menu Items failed due to: " + e.Message);
                
            }
        }

        public static void ValidateSearch(CaseDetail record)
        {
            try
            {
                report.Step("Validate Search");
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Case Name", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Case Type", true));              
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Business Line", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("SAP Contract Code", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Settlement Amount", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Case URL", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Phone Number", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Class Size", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Class Period", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Status", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Project Manager Phone", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Project Manager Email", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Technical Project Manager Email", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Technical Project Manager Phone", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Technical Project Manager", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Project Manager", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Preliminary Approval Granted", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Final Approval Hearing", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Claims Deadline", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Opt Out Deadline", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Initial Notice Mailing", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Objection Deadline", true));
                test.vars.verify(Facilitator.Template.search.VerifyColumnAvailable("Initial Distribution", true));
                //validate standard search functionality
                search.ValidateStandardSearchInput("sapContractCode", "SAP Contract Code", search._StandardOperatorSAP, search._StandardFilterSAP, ">=", record.SapContractCode.ToString(), true);
                test.Click(By.XPath("//div//span[text()='Filter Criteria & Available Columns']"));
                test.vars.verify(test.VerifySelectOptionsContain(search._StandardOperatorCaseName, "Includes", true));
                test.vars.verify(test.VerifyElementEnabled(Facilitator.Template.search._ExcelExport, true));
                //validate quick search functionality
                search.ValidateQuickSearch("sapContractCode", "SAP Contract Code", record.SapContractCode.ToString(), true);

            }
            catch (Exception e)
            {
                report.Fail("Validate Search failed due to: " + e.Message);
                
            }
        }

        public static void ValidateCaseSummary(CaseDetail record, bool edit, bool executive)
        {  
            try
            {
                report.Step("Validate Case Summary");
                //Case Info tabs
                caseinfo.VerifyCaseBanner(record.CaseName, record.BillingCode, Data.GetCaseStatus(record.CaseStatusId).First().Name);
                test.vars.verify(test.VerifyLinkAvailability("Summary", true));
                test.vars.verify(test.VerifyLinkAvailability("Detail", true));
                test.vars.verify(test.VerifyLinkAvailability("Dates", true));
                test.vars.verify(test.VerifyElementAvailability(caseinfo._ContactsTab, true));
                test.vars.verify(test.VerifyLinkAvailability("Ops/Shared Services", true));
                test.vars.verify(test.VerifyLinkAvailability("Documents", true));
                test.vars.verify(test.VerifyLinkAvailability("Statistics", true));
                //test.vars.verify(test.VerifyLinkAvailability("Health Status", edit));  //DEL removed per user story 268534
                report.Step("Validate Overview tab");
                //Summary tab data 
                caseinfo.ValidateOverviewData(record);
                caseinfo.ValidateProjectTeamData(record.CaseDetailId);
                //Summary tab editability
                test.vars.verify(test.VerifyElementEnabled(caseinfo._AddIncident, executive));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseName"), edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._CourtSelect, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._CaseTypeSelect, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._StatusSelect, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._BusinessLineSelect, edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("sapContractCode"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("billingCode"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("classPeriodFrom"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("classPeriodTo"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("estimatedNumberOfClaims"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("classSize"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("phoneNumber"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("poBox"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("zipCode"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("url"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseFolder"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseEmail"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseDescription"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("courtCaption"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("settlementAmountBenefit"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("importantMessage"), edit));
                test.vars.verify(test.VerifyElementEnabled(By.Name("specialReporting"), edit));
                //test.vars.verify(test.VerifyElementEnabled(By.Name("signedAgreementPricing"), edit));      //DEL removed story 276773
                test.vars.verify(test.VerifyElementEnabled(By.Name("flsa"), edit));
                test.vars.verify(test.VerifyElementEnabled(By.Name("hipaa"), edit));
                test.vars.verify(test.VerifyElementEnabled(By.Name("fisma"), edit));
                //test.vars.verify(test.VerifyElementEnabled(By.Name("cappedCase"), edit));          //DEL removed story 276773
                //test.vars.verify(test.VerifyElementEnabled(By.Name("specialSLAs"), edit));          //DEL removed story 276773
                test.vars.verify(test.VerifyElementEnabled(By.Name("strategicCase"), executive));
                test.vars.verify(test.VerifyElementEnabled(By.Name("sendInterestLetter"), edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._PreliminaryApprovalGranted, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._InitialNoticeMailing, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._OptOutDeadline, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._ObjectionDeadline, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._ClaimsDeadline, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._FinalApprovalHearing, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._InitialDistribution, false));

            }
            catch (Exception e)
            {
                report.Fail("Validate Case Summary failed due to: " + e.Message);
                
            }
         }

        public static void ValidateCaseDetail(int caseDetailId, bool edit)
        {
            try
            {
                var caseKickoff = Data.GetCaseKickoffDetail(caseDetailId).First();
                report.Step("Validate Detail tab");
                test.Click(By.LinkText("Detail"));
                test.vars.verify(test.VerifyNoErrorToasts());
                //Verify Case Kickoff
                report.Step("Validate Case Kickoff Editability");
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NoticeAndClaimFormFormat, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ApplicationName, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._AddressResearchProtocol, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Environment, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NotesForMailings, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NotesForEblast, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NotesForDisbursements, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NotesForPublication, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NotesForClaims, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SupportedLanguages, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NotesForDataServices, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SpecialInstructions, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NotesForDocumentControl, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RequestedImports, edit));
                caseinfo.ValidateCaseKickoffData(caseKickoff);
                //Verify Allocated Hours
                var allocatedHours = Data.ExecuteGetReportData_EVAEstimates_Result(caseDetailId).FirstOrDefault();
                caseinfo.ValidateAllocatedHoursData(allocatedHours);
                //Verify Case Closure
                var shutdownAndRetention = Data.GetShutdownAndRetention(caseDetailId).FirstOrDefault();
                caseinfo.ValidateShutdownRetentionEditability(shutdownAndRetention, edit);
                caseinfo.ValidateShutdownRetentionData(shutdownAndRetention);
            }
            catch (Exception e)
            {
                report.Fail("Validate Case Detail failed due to: " + e.Message);
                
            }
 
        }

        public static void ValidateDates(int caseDetailId, bool add, bool edit, bool delete, bool canEditRequired)
        {
            try
            {
                report.Step("Validate Dates tab");
                test.Click(By.LinkText("Dates"));
                Facilitator.Template.grid.WaitForGridData();
                var milestone = Data.GetMilestones(caseDetailId).OrderBy(o => o.SortOrder).First();
                caseinfo.SortByColumnAndSection(caseinfo._Dates, "Name");
                caseinfo.SortByColumnAndSection(caseinfo._Dates, "Order");
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DatesAdd, add));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DatesExport, true));
                test.vars.verify(test.VerifyElementEditability(caseinfo._DatesTextFilter, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DatesCourtOrderedFilter, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DatesRequiredDateFilter, true));
                test.vars.verify(test.VerifyElementExists(caseinfo._DatesView, !edit));
                test.vars.verify(test.VerifyElementExists(caseinfo._DatesEdit, edit));
                test.vars.verify(test.VerifyElementVisibility(caseinfo._DatesDelete, delete));
                caseinfo.ValidateMilestoneGridData(milestone);
                if (add)
                {
                    test.Click(caseinfo._DatesAdd);
                    test.Click(By.XPath(caseinfo._DatesCombo));
                    test.vars.verify(test.VerifyElementVisibility(caseinfo._DatesComboVisibility, true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("dueDate"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("courtOrdered"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("clientOrdered"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("requiredDate"), canEditRequired));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("notApplicable"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("relatedSR"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("owner"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("sortOrder"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("srStatus"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("srDueDate"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("srCreateDate"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("note"), true));
                    test.Click(caseinfo._ModalCancel);
                }
                if (edit)
                {
                    test.Click(caseinfo._DatesEdit);
                    test.Click(By.XPath(caseinfo._DatesCombo));
                    test.vars.verify(test.VerifyElementVisibility(caseinfo._DatesComboVisibility, true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("dueDate"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("courtOrdered"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("clientOrdered"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("requiredDate"), canEditRequired));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("notApplicable"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("relatedSR"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("owner"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("sortOrder"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("note"), true));
                    test.Click(caseinfo._ModalCancel);
                }
                else
                {
                    test.Click(caseinfo._DatesView);
                    test.vars.verify(test.VerifyElementVisibility(caseinfo._DatesComboVisibility, false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("dueDate"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("courtOrdered"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("clientOrdered"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("requiredDate"), canEditRequired));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("notApplicable"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("relatedSR"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("owner"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("sortOrder"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("note"), false));
                    test.Click(caseinfo._ModalCancel);
                }
                if (delete)
                {
                    test.Click(caseinfo._DatesDelete);
                    test.vars.verify(test.VerifyElementEditability(caseinfo._DatesName, false));
                    test.vars.verify(test.VerifyElementEditability(By.XPath("//label[text()='Date']/following-sibling::input"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.XPath("//input[contains(@ng-model, 'courtOrdered')]"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.XPath("//input[contains(@ng-model, 'clientOrdered')]"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.XPath("//input[contains(@ng-model, 'requiredDate')]"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.XPath("//input[contains(@ng-model, 'notApplicable')]"), false));
                    test.vars.verify(test.VerifyElementEditability(By.XPath("//label[text()='Related SR']/following-sibling::input"), false));
                    test.vars.verify(test.VerifyElementEditability(By.XPath("//label[text()='Owner']/following-sibling::input"), false));
                    test.vars.verify(test.VerifyElementEditability(By.XPath("//label[text()='Order']/following-sibling::input"), false));
                    test.vars.verify(test.VerifyElementEditability(By.XPath("//label[text()='Note']/following-sibling::textarea"), false));
                    test.Click(caseinfo._ModalCancel);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Dates failed due to: " + e.Message);
                
            }
        }

        public static void ValidateContacts(int caseDetailId, bool add, bool edit, bool delete)
        {
            try
            {
                report.Step("Validate Contacts tab");
                test.Click(By.LinkText("Contacts"));
                Facilitator.Template.grid.WaitForGridData();
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ContactsAdd, add));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ContactsExport, true));
                test.vars.verify(test.VerifyElementEditability(caseinfo._ContactsTextFilter, true));
                test.vars.verify(test.VerifyElementExists(caseinfo._ContactsView, !edit));
                test.vars.verify(test.VerifyElementExists(caseinfo._ContactsEdit, edit));
                test.vars.verify(test.VerifyElementVisibility(caseinfo._ContactsDelete, delete));
                var contact = Data.GetContactDataByCase(caseDetailId).OrderBy(l => l.LastName).ThenBy(i => i.ContactId).First();
                caseinfo.SortByColumnAndSection(caseinfo._Contacts, "First Name");
                caseinfo.SortByColumnAndSection(caseinfo._Contacts, "Last Name");
                caseinfo.ValidateContactsData(contact, caseDetailId);
                //verify modals
                if (add)
                {
                    test.Click(caseinfo._ContactsAdd);
                    test.vars.verify(test.VerifyElementVisibility(caseinfo._ContactsAddAssociate, true));
                    test.Click(caseinfo._ModalSave);
                }
                if (edit)
                {
                    test.Click(caseinfo._ContactsEdit);
                    test.vars.verify(test.VerifyElementEnabled(By.Name("projectRoleId"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("startDate"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("endDate"), true));
                    caseinfo.ValidateContactsData(contact, caseDetailId);
                    caseinfo.ValidateContactOrgGrid(contact);
                    test.Click(caseinfo._ModalCancel);
                }
                else
                {
                    test.Click(caseinfo._ContactsView);
                    test.vars.verify(test.VerifyElementEnabled(By.Name("projectRoleId"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("startDate"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("endDate"), false));
                    caseinfo.ValidateContactsData(contact, caseDetailId);
                    caseinfo.ValidateContactOrgGrid(contact);
                    test.Click(caseinfo._ModalCancel);
                }
                if (delete)
                {
                    test.Click(caseinfo._ContactsDelete);
                    test.vars.verify(test.VerifyElementEnabled(By.Name("projectRoleId"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("caseStartDate"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("caseEndDate"), false));
                    caseinfo.ValidateContactsData(contact, caseDetailId);
                    test.Click(caseinfo._ModalCancel);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Contacts failed due to: " + e.Message);
                
            }
        }

        public static void ValidateOps(int caseDetailId, bool edit)
        {
            report.Step("Validate Ops/Shared Services");
            test.Click(By.LinkText("Ops/Shared Services"));
            ValidateClaims(caseDetailId, edit);
            //ValidateContactCenter(caseDetailId, edit);  //Skipping until section reworked. //DEL needs to be created
            ValidateDisbursements(caseDetailId, edit);
            ValidateDocumentProcessing(caseDetailId, edit, edit, edit);
            ValidateHr(caseDetailId, edit);
            //ValidateMailings(caseDetailId, edit, edit, edit);  //Skipping until section reworked. //DEL needs to be created
        }

        public static void ValidateClaims(int caseDetailId, bool edit)
        {
            try
            {
                report.Step("Validate Claims");
                navigate.Refresh();
                test.Click(By.XPath("//span[text()='Claims']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateClaimsData(Data.GetClaim(caseDetailId).FirstOrDefault());
                test.vars.verify(test.VerifyElementEnabled(caseinfo._EmailProcessing, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ClaimProcessing, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._OverallProcessingDueDate, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SpecialServicing, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SpecialSlaForClaims, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SpecialServicingComments, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SlaServicingComments, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RangerEnvironment, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ReissueSchedule, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ManualClearSearch, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._TranslationPreferences, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Qa, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ClearSearch, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Correspondence, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SubmitViaFax, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SubmitViaEmail, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SubmitViaPaper, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SubmitViaWeb, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._FormsAvailableMailOnly, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._FormsAvailableOnRequest, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._FormsAvailablePrintedOffWeb, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DefectLetterNotifications, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DefectLetterNotificationsTiming, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SupportedLanguagesForClaims, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DisbursementDateExceptions, edit));
            }
            catch (Exception e)
            {
                report.Fail("Validate Claims failed due to: " + e.Message);
                
            }
        }

        public static void ValidateContactCenter(int caseDetailId, bool edit)
        {
            try
            {
                report.Step("Validate Contact Center");
                test.Click(By.XPath("//span[text()='Contact Center']"));
                System.Threading.Thread.Sleep(1000); //For some reason, page is a bit slower to load all fields than expected
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateContactCenterData(Data.GetContactCenter(caseDetailId).FirstOrDefault());
                test.vars.verify(test.VerifyElementEditability(caseinfo._OptionSuite, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._AgentGoLiveDate, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._ForeignLanguageIvr, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._WebsiteGoLiveDate, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._CaseNameinCMX, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._ForeignLanguageCallCenter, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._Agents, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ContractSlaForAsa, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._ContractSlaForAsaNote, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._CustomCallRouting, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._BilingualAgents, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Chat, edit));
            }
           catch(Exception e)
            {
                report.Fail("Validate Contact Center failed due to: " + e.Message);
                
            }
}

        public static void ValidateDisbursements(int caseDetailId, bool edit)
        {
            try
            { 
                report.Step("Validate Disbursements");
                test.Click(By.XPath("//span[text()='Disbursements']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                var record = Data.GetDisbursement(caseDetailId).FirstOrDefault();
                caseinfo.ValidateDisbursementsData(record);
                test.vars.verify(test.VerifyElementEditability(caseinfo._InitialDistributionDate, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._AwardType, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._TaxReporting, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._TaxVendor, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DistributionSchedule, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ResidualFund, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ForeignAddresses, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Deminimis, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Householding, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Withholding, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Qsf, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._CustomEnvelope, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._InsertWithCheck, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._AttorneyPayment, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NamedPlaintiffAwards, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ReserveHoldback, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._CustomReporting, edit));
            }
            catch (Exception e)
            {
                report.Fail("Validate Disbursements failed due to: " + e.Message);
                
            }
        }

        public static void ValidateDocumentProcessing(int caseDetailId, bool add, bool edit, bool delete)
        {
            try
            {
                report.Step("Validate Document Processing section");
                test.Click(By.XPath("//span[text()='Document Processing']"));
                test.vars.verify(test.VerifyNoErrorToasts());
                var documentProcessing = Data.GetDocumentProcessing(caseDetailId).FirstOrDefault();
                caseinfo.ValidateDocumentProcessingData(Data.GetDocumentProcessing(caseDetailId).FirstOrDefault());
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DeType, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DcSla, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DeSla, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._IntakeType, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._UndeliverableCheck, edit));
                // test.vars.verify(test.VerifyElementEditability(caseinfo._NonStandardMonths, edit)); //DEL returns Null and always fails
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NonStandardMonths, edit)); //DEL change method to enabled rather than editable
                test.vars.verify(test.VerifyElementEnabled(caseinfo._BoxStorageBillable, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._IvrTranscription, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NomineeClaimProcessing, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Remails, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SecuredPhysicalStorageRequired, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Undeliverables, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._BrokerListProcessing, edit));
                //test.vars.verify(test.VerifyElementEditability(caseinfo._DcSpecialInstructions, edit)); //DEL returns Null and always fails
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DcSpecialInstructions, edit));  //DEL change method to enabled rather than editable
                // test.vars.verify(test.VerifyElementEditability(caseinfo._DeSpecialInstructions, edit));  //DEL returns Null and always fails
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DeSpecialInstructions, edit));  //DEL change method to enabled rather than editable
                //test.vars.verify(test.VerifyElementEditability(caseinfo._SpecialReportingRequirements, edit));//DEL returns Null and always fails
                test.vars.verify(test.VerifyElementEnabled(caseinfo._SpecialReportingRequirements, edit));
                //test.vars.verify(test.VerifyElementEditability(caseinfo._FaxInboxEmail, edit));//DEL returns Null and always fails
                test.vars.verify(test.VerifyElementEnabled(caseinfo._FaxInboxEmail, edit));   //DEL change method to enabled rather than editable

                List<IncomingDocument> documents = null;
                if (documentProcessing != null)
                {
                    documents = Data.GetIncomingDocument(documentProcessing.DocumentProcessingId);
                    caseinfo.ValidateIncomingDocumentsGridData(documents);
                }

                test.vars.verify(test.VerifyElementEnabled(caseinfo._DocumentAdd, add));
                if (add)
                {
                    test.Click(caseinfo._DocumentAdd);
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._IncomingDocumentType, true));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._ProcessingType, true));
                    test.Click(caseinfo._ModalCancel);
                }
                if (documents == null) return;
                test.vars.verify(test.VerifyElementExists(By.XPath(caseinfo.DocumentView), !edit));
                test.vars.verify(test.VerifyElementExists(By.XPath(caseinfo.DocumentEdit), edit));
                test.Click(By.XPath("(" + (edit ? caseinfo.DocumentEdit : caseinfo.DocumentView) + ")"));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ModalSave, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._IncomingDocumentType, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ProcessingType, edit));
                test.Click(caseinfo._ModalCancel);

                test.vars.verify(test.VerifyElementExists(By.XPath(caseinfo.DocumentEdit), delete));
                if (!delete) return;
                test.Click(By.XPath("(" + caseinfo.DocumentDelete + ")"));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ModalSave, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._IncomingDocumentType, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._ProcessingType, false));
                test.Click(caseinfo._ModalCancel);
            }
            catch (Exception e)
            {
                report.Fail("Validate Document Processing failed due to: " + e.Message);
                
            }
        }

        public static void ValidateHr(int caseDetailId, bool edit)
        {
            try
            {
                report.Step("Validate HR");
                test.Click(caseinfo._HrToggle);
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateHrData(Data.GetHr(caseDetailId).FirstOrDefault());
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DrugTesting, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._BankruptcyScreening, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._CreditCheck, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._CriminalBackground, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._AnnualComplianceTraining, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._FingerPrint, edit));
            }
            catch (Exception e)
            {
                report.Fail("Validate HR failed due to: " + e.Message);
                
            }
        }

        public static void ValidateMailings(int caseDetailId, bool add, bool edit, bool delete)
        {
            try
            { 
                report.Step("Validate Mailing Detail section");
                test.Click(By.XPath("//span[text()='Mailings']"));
                System.Threading.Thread.Sleep(1000); //For some reason, page is a bit slower to load all fields than expected
                Facilitator.Template.grid.WaitForGridData();
                test.vars.verify(test.VerifyNoErrorToasts());
                var mailing = Data.GetMailing(caseDetailId).FirstOrDefault();
                test.vars.verify(test.VerifyElementEditability(caseinfo._PoBoxType, edit));
                var description = "";
                if (mailing != null)
                {
                    test.vars.verify(test.VerifyFieldValueByName("PoBoxType", mailing.MailingOption?.Name ?? "")); //DEL
                    var mailingDetail = Data.GetMailingDetail(mailing.MailingId).OrderBy(d => d.Description).FirstOrDefault();
                    description = mailingDetail?.Description;
                    caseinfo.ValidateMailingDetailGridData(mailingDetail);
                }      

                //test.vars.verify(test.VerifyElementExists(caseinfo._MailingAdd, add));  //Current bug (170787). Might need to change to enabled, depends on whether they fix this to hide or just disable the button.
                if (add)
                {
                    test.Click(caseinfo._MailingAdd);
                    test.vars.verify(test.VerifyElementEditability(caseinfo._Description, true));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._DropDate, true));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._MailingPopulation, true));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._MailingFulfillmentFrequency, true));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._PackageContent, true));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._BrmPermittingRequired, true));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._IsDynamicImageCount, true));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._IsForeign, true));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._IsOutsourced, true));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._DropSchedule, true));
                }

                if (mailing != null)
                {
                    grid.SelectRowByText(description);
                    test.vars.verify(test.VerifyElementEditability(caseinfo._Description, edit));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._DropDate, edit));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._MailingPopulation, edit));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._MailingFulfillmentFrequency, edit));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._PackageContent, edit));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._BrmPermittingRequired, edit));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._IsDynamicImageCount, edit));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._IsForeign, edit));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._IsOutsourced, edit));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._DropSchedule, edit));
                }

                test.vars.verify(test.VerifyElementExists(caseinfo._MailingDelete, delete));
            }
            catch (Exception e)
            {
                report.Fail("Validate Mailings failed due to: " + e.Message);
                
            }

        }

        public static void ValidateDocuments(int caseDetailId, bool add, bool edit, bool delete)
        {
            
            try
            {
                Data.PopulateDocuments(caseDetailId);
                report.Step("Validate Documents");
                caseinfo.SelectTab("Documents");
                var originalRecord = Data.GetDocuments(caseDetailId).OrderByDescending(d => d.UploadedDate).First();
                caseinfo.ValidateDocumentsGridData(originalRecord);
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DocumentsExport, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DocumentsAdd, add));
                test.vars.verify(test.VerifyElementExists(caseinfo._DocumentsView, !edit));
                test.vars.verify(test.VerifyElementExists(caseinfo._DocumentsEdit, edit));
                test.vars.verify(test.VerifyElementVisibility(caseinfo._DocumentsDelete, delete));
                if (add)
                {
                    test.Click(caseinfo._DocumentsAdd);
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._DocumentsType, true));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._DocumentsNote, true));
                    test.Click(caseinfo._ModalCancel);
                }
                test.Click(edit ? caseinfo._DocumentsEdit : caseinfo._DocumentsView);
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DocumentsType, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._DocumentsNote, edit));
                test.Click(caseinfo._ModalCancel);
                if (delete)
                {
                    test.Click(caseinfo._DocumentsDelete);
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._DocumentsType, false));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._DocumentsNote, false));
                    test.Click(caseinfo._ModalCancel);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Documents failed due to: " + e.Message);
                
            }

        }

        public static void ValidateStatistics(int caseDetailId)
        {
            try
            {
                var stats = Data.ExecuteGetReportData_WAR_Result(Data.GetCaseDataById(caseDetailId).First().SapContractCode);
                report.Step("Validate Statistics tab");
                test.Click(By.LinkText("Statistics"));
                test.vars.verify(test.VerifyNoErrorToasts());
                caseinfo.ValidateStatisticsData(stats.FirstOrDefault());
            }
            catch (Exception e)
            {
                report.Fail("Validate Statistics failed due to: " + e.Message);
                
            }
        }

        public static void ValidateHealthStatus(int caseDetailId, bool add, bool edit, bool delete)
        {
            try
            {
                report.Step("Validate Health Status tab");
                test.Click(By.LinkText("Health Status"));
                Facilitator.Template.grid.WaitForGridData();
                var record = Data.GetStatusUpdate(caseDetailId).OrderByDescending(d => d.StatusDate).First();
                caseinfo.ValidateHealthGridData(record);
                test.vars.verify(test.VerifyElementEnabled(caseinfo._HealthAdd, add));
                test.vars.verify(test.VerifyElementExists(caseinfo._HealthView, !edit));
                test.vars.verify(test.VerifyElementExists(caseinfo._HealthEdit, edit));
                test.vars.verify(test.VerifyElementVisibility(caseinfo._HealthDelete, delete));
                if (add)
                {
                    test.Click(caseinfo._HealthAdd);
                    test.vars.verify(test.VerifyElementEditability(caseinfo._HealthDate, true));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._KeyStats, true));
                    test.vars.verify(test.VerifyElementEnabled(caseinfo._HealthRating, true));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._HealthComment, true));
                    test.Click(caseinfo._ModalCancel);
                }
                test.Click(edit ? caseinfo._HealthEdit : caseinfo._HealthView);
                test.vars.verify(test.VerifyElementEditability(caseinfo._HealthDate, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._KeyStats, edit));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._HealthRating, edit));
                test.vars.verify(test.VerifyElementEditability(caseinfo._HealthComment, edit));
                caseinfo.ValidateHealthData(record);
                test.Click(caseinfo._ModalCancel);
                if (delete)
                {
                    test.Click(caseinfo._HealthDelete);
                    test.vars.verify(test.VerifyElementEditability(caseinfo._HealthDate, false));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._KeyStats, false));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._HealthRating, false));
                    test.vars.verify(test.VerifyElementEditability(caseinfo._HealthComment, false));
                    caseinfo.ValidateHealthData(record);
                    test.Click(caseinfo._ModalCancel);
                }

                var invoice = Data.GetInvoice(caseDetailId).OrderByDescending(d => d.InvoiceDate).First();
                test.vars.verify(test.VerifyElementExists(caseinfo._InvoiceView, true));
                caseinfo.ValidateInvoiceGridData(invoice);
                test.Click(caseinfo._InvoiceView);
                caseinfo.ValidateInvoiceData(invoice);
                test.Click(caseinfo._ModalCancel);
            }
            catch (Exception e)
            {
                report.Fail("Validate Health Status failed due to: " + e.Message);
                
            }            
        }

        public static void ValidateIncidents(bool edit)
        {
            try
            {
                report.Step("Validate Incidents page");
                test.Click(test.driver, By.LinkText("Incidents"));
                Facilitator.Template.grid.WaitForGridData();
                var incident = Data.GetIncidents().OrderByDescending(d => d.IncidentNumber).First();
                test.vars.verify(test.VerifyElementEnabled(incidents._Add, edit));
                test.vars.verify(test.VerifyElementVisibility(incidents._Export, true));
                test.vars.verify(test.VerifyElementExists(incidents._View, !edit));
                test.vars.verify(test.VerifyElementExists(incidents._Edit, edit));
                test.vars.verify(test.VerifyElementVisibility(incidents._Delete, edit));
                incidents.ValidateIncidentsGrid(incident);
                if (edit)
                {
                    test.Click(incidents._Add);
                    incidents.ValidateIncidentModalEditability(true);
                    test.Click(incidents._ModalCancel);
                    test.Click(incidents._Edit);
                    incidents.ValidateIncidentModalEditability(true);
                    test.Click(incidents._ModalCancel);
                    test.Click(incidents._Delete);
                    incidents.ValidateIncidentModalEditability(false);
                    test.Click(incidents._ModalCancel);
                }
                else
                {
                    test.Click(incidents._View);
                    incidents.ValidateIncidentModalEditability(false);
                    test.Click(incidents._ModalCancel);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Incidents failed due to: " + e.Message);
                
            }
        }

        public static void ValidateReports(string reportname)
        {
            try
            {
                report.Step("Validate Reports page");
                test.Click(By.LinkText("Reports"));
                test.vars.verify(test.VerifyNoErrorToasts());
                var record = reportname == null ? Data.GetReports().OrderBy(x => Guid.NewGuid()).First() : Data.GetReports().First(n => n.ReportName == reportname);
                reports.ValidateReport(record.ReportName, record.URL);
            }
            catch (Exception e)
            {
                report.Fail("Validate Reports failed due to: " + e.Message);
                
            }
        
        }

        public static void ValidateQueries(bool queryAccess)
        {
            try
            {
                report.Step("Validate Queries page");
                test.Click(By.LinkText("Queries"));
                test.vars.verify(test.VerifyNoErrorToasts());
                test.vars.verify(test.VerifySelectOptionsContain(Facilitator.Template.queries._Select, "Test Query 1", queryAccess));
            }
            catch (Exception e)
            {
                report.Fail("Validate Queries failed due to: " + e.Message);
                
            }     
        }

        public static void ValidateAdminContacts(bool add, bool edit, bool delete)
        {
            try
            {
                report.Step("Validate Admin Contacts");
                test.Click(By.LinkText("Administration"));
                test.Click(By.XPath("//a[text()='Administration']/..//a[text()='Contacts']"));
                Facilitator.Template.grid.WaitForGridData();
                var contact = Data.GetContactData().OrderBy(n => n.LastName).ThenBy(f => f.FirstName).First();
                test.vars.verify(test.VerifyElementVisibility(admin._Add, add));
                test.vars.verify(test.VerifyElementVisibility(admin._Export, true));
                test.vars.verify(test.VerifyElementEditability(admin._TextFilter, true));
                test.EditField(admin._TextFilter, contact.LastName);
                Facilitator.Template.grid.SortByColumn("First Name");
                test.vars.verify(test.VerifyElementExists(admin._View, !edit));
                test.vars.verify(test.VerifyElementExists(admin._Edit, edit));
                test.vars.verify(test.VerifyElementVisibility(admin._Delete, delete));
                admin.ValidateContactGrid(contact);
                if (add)
                {
                    test.Click(admin._Add);
                    test.vars.verify(test.VerifyElementEditability(By.Name("firstName"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("middleInitial"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("lastName"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("contactTypeId"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("keyContact"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("phone1"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("phone2"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("phone3"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("emailAddress"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("address1"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("address2"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("city"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("state"), true));
                    test.vars.verify(test.VerifyElementEditability(By.Name("zipcode"), true));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("country"), true));
                    test.Click(admin._ModalCancel);
                }
                test.Click(edit ? admin._Edit : admin._View);
                test.vars.verify(test.VerifyElementEditability(By.Name("firstName"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("middleInitial"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("lastName"), edit));
                test.vars.verify(test.VerifyElementEnabled(By.Name("contactTypeId"), edit));
                test.vars.verify(test.VerifyElementEnabled(By.Name("keyContact"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("phone1"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("phone2"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("phone3"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("emailAddress"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("address1"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("address2"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("city"), edit));
                test.vars.verify(test.VerifyElementEnabled(By.Name("state"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("zipcode"), edit));
                test.vars.verify(test.VerifyElementEnabled(By.Name("country"), edit));
                test.vars.verify(test.VerifyElementEnabled(admin._AddOrg, edit));
                if (Data.GetContactToOrganization().All(c => c.ContactId != contact.ContactId))
                {
                    test.vars.verify(test.VerifyText(admin._Alert, "There are no Organizations that match the currently entered filter."));
                }
                else
                {
                    test.vars.verify(test.VerifyElementEnabled(admin._EditOrg, edit));
                    test.vars.verify(test.VerifyElementEnabled(admin._DeleteOrg, edit));
                }
                test.Click(admin._ModalCancel);
                if (delete)
                {
                    test.Click(admin._Delete);
                    test.vars.verify(test.VerifyElementEditability(By.Name("firstName"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("middleInitial"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("lastName"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("contactTypeId"), false));
                    test.vars.verify(test.VerifyElementEnabled(By.Name("keyContact"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("phone1"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("phone2"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("phone3"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("emailAddress"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("address1"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("address2"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("city"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("state"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("zipcode"), false));
                    test.vars.verify(test.VerifyElementEditability(By.Name("country"), false));
                    test.Click(admin._ModalCancel);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Admin Contacts failed due to: " + e.Message);
                
            }
        }

        public static void ValidateAdminOrgs(bool add, bool edit, bool delete)
        {
            try
            {
                report.Step("Validate Admin Orgs");
                test.Click(By.LinkText("Administration"));
                test.Click(By.LinkText("Organization/Entity"));
                Facilitator.Template.grid.WaitForGridData();
                var org = Data.GetOrganizations().OrderBy(n => n.OrganizationName).First();
                test.vars.verify(test.VerifyElementVisibility(admin._Add, add));
                test.vars.verify(test.VerifyElementVisibility(admin._Export, true));
                test.vars.verify(test.VerifyElementEditability(admin._TextFilter, true));
                test.vars.verify(test.VerifyElementExists(admin._View, !edit));
                test.vars.verify(test.VerifyElementExists(admin._Edit, edit));
                test.vars.verify(test.VerifyElementVisibility(admin._Delete, delete));
                admin.ValidateOrgGrid(org);
                if (add)
                {
                    test.Click(admin._Add);
                    test.vars.verify(test.VerifyElementEditability(admin._OrganizationName, true));
                    test.vars.verify(test.VerifyElementEditability(admin._WebAddress, true));
                    test.vars.verify(test.VerifyElementEnabled(admin._StrategicClient, true));
                    test.Click(admin._ModalCancel);
                }
                test.Click(edit ? admin._Edit : admin._View);
                test.vars.verify(test.VerifyElementEditability(admin._OrganizationName, edit));
                test.vars.verify(test.VerifyElementEditability(admin._WebAddress, edit));
                test.vars.verify(test.VerifyElementEnabled(admin._StrategicClient, edit));
                test.Click(admin._ModalCancel);
                if (delete)
                {
                    test.Click(admin._Delete);
                    test.vars.verify(test.VerifyElementEditability(admin._OrganizationName, false));
                    test.vars.verify(test.VerifyElementEditability(admin._WebAddress, false));
                    test.vars.verify(test.VerifyElementEnabled(admin._StrategicClient, false));
                    test.Click(admin._ModalCancel);
                }
            }
            catch (Exception e)
            {
                report.Fail("Validate Admin Orgs failed due to: " + e.Message);
                
            }
        }

        public static void ValidateCreateCase(bool edit)
        {
            try
            {
                test.Click(By.LinkText("Create New Case"));
                test.vars.verify(test.VerifyNoErrorToasts());
                test.vars.verify(test.VerifyElementEditability(By.Name("caseName"), edit));
                test.vars.verify(test.VerifyElementEditability(By.XPath(caseinfo._Court), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseTypeId"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseStatusId"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("businessLineId"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("sapContractCode"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("billingCode"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("classPeriodFrom"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("classPeriodTo"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("estimatedNumberOfClaims"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("classSize"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("phoneNumber"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("poBox"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("zipCode"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("url"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseFolder"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseEmail"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("caseDescription"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("courtCaption"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("settlementAmountBenefit"), edit));
                test.vars.verify(test.VerifyElementEditability(By.Name("importantMessage"), edit));
            }
            catch (Exception e)
            {
                report.Fail("Validate Create Case failed due to: " + e.Message);
                
            }
        }

        public static void ValidateUserMenu()
        {
            try
            {
                report.Step("Validate User Menu");
                test.Click(By.CssSelector("a.dropdown-toggle > span.ng-binding"));
                test.vars.verify(test.VerifyLinkAvailability("Logout", true));
                test.vars.verify(test.VerifyLinkAvailability("Change Password", true));
                test.Click(By.CssSelector("a.dropdown-toggle > span.ng-binding"));
            }
            catch (Exception e)
            {
                report.Fail("Validate User Menu failed due to: " + e.Message);
                
            }
     
        }

        public static void ValidateRiskMatrix(int caseDetailId)
        {
            try
            {
                Data.PopulateRiskMatrix(caseDetailId);
                report.Step("Validte Risk Matrix");
                caseinfo.SelectTab("Risk Matrix");
                var originalRecords = Data.GetRiskMatrix(caseDetailId).OrderBy(d => d.DepartmentId).ToList();
                caseinfo.ValidateRiskMatrixGridData(originalRecords);
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskExport, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskAdd, true));
                test.vars.verify(test.VerifyElementExists(caseinfo._RiskView, false));
                test.vars.verify(test.VerifyElementExists(caseinfo._RiskEdit, true));
                test.vars.verify(test.VerifyElementVisibility(caseinfo._RiskDelete, true));
                test.Click(caseinfo._RiskAdd);
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Department, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Owner, true));
                test.vars.verify(test.VerifyElementEditability(caseinfo._Number, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._DateAdded, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskCategory, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NoRiskIdentified, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskDescription, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DescriptionOfConsequences, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Probability, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Impact, true));
                test.vars.verify(test.VerifyElementEditability(caseinfo._RiskValue, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._MitigationPlan, true));
                test.Click(caseinfo._ModalCancel);
                test.Click(caseinfo._RiskEdit);
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Department, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Owner, true));
                test.vars.verify(test.VerifyElementEditability(caseinfo._Number, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._DateAdded, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskCategory, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NoRiskIdentified, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskDescription, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DescriptionOfConsequences, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Probability, true));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Impact, true));
                test.vars.verify(test.VerifyElementEditability(caseinfo._RiskValue, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._MitigationPlan, true));
                test.Click(caseinfo._ModalCancel);
                test.Click(caseinfo._RiskDelete);
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Department, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Owner, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._Number, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._DateAdded, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskCategory, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._NoRiskIdentified, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._RiskDescription, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._DescriptionOfConsequences, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Probability, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._Impact, false));
                test.vars.verify(test.VerifyElementEditability(caseinfo._RiskValue, false));
                test.vars.verify(test.VerifyElementEnabled(caseinfo._MitigationPlan, false));
                test.Click(caseinfo._ModalCancel);
            }
            catch (Exception e)
            {
                report.Fail("Error occured while validating Risk Matrix.", e);
            }
        }
    } 
}
