﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;

namespace Automation
{

    public class testVars
    {       
        public testVars(IWebDriver driver)
        {
            browsername = ((RemoteWebDriver)driver).Capabilities.BrowserName;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(config.TIMEOUT));           
            errorcount = 0;
            skipcount = 0;
        }

        public string browsername;
        public WebDriverWait wait;       
        public int errorcount;
        public int skipcount;
        public string failures;
        public string skips;

        public void verify(int error)
        {
            //errorcount = errorcount + error;
        }

        public void verify()
        {
            if (errorcount > 0)
            {
                Assert.Fail("Test failed " + errorcount + " verification steps: " + failures);
                test.assignFailureDescription("Test failed on " + errorcount + " verification step(s)" + " :: " + test.readConsole("Fail_on_ErrorCount"));
            }

            if (skipcount > 0)
            {
                Assert.Inconclusive("Test skipped " + skipcount + " verification steps: " + skips);
            }
        }
        
    }        
}
