﻿using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace Automation
{
    public static class download
    {

        public static IWebElement ExpandRootElement(this IWebElement element, IWebDriver driver)
        {
            return (IWebElement)((IJavaScriptExecutor)driver)
                .ExecuteScript("return arguments[0].shadowRoot", element);
        }

        public static int VerifyDownloadInBrowser(string fileName)
        {
            var browser = ((RemoteWebDriver) test.driver).Capabilities.BrowserName;
            var currUrl = test.driver.Url;
            int result;
            switch (browser)
            {
                case "internet explorer":
                    result = VerifyDownloadInBrowserInternetExplorer(fileName);
                    break;
                case "firefox":
                    result = VerifyDownloadInBrowserFirefox(fileName);
                    break;
                case "chrome":
                    result = VerifyDownloadInBrowserChrome(fileName);
                    break;
                default:
                    report.Fail("Could not determine browser.");
                    return 1;
            }

            test.driver.Navigate().GoToUrl(currUrl);
            return result;
        }

        private static int VerifyDownloadInBrowserChrome(string fileName)
        {
            test.driver.Navigate().GoToUrl("chrome://downloads");
            var element = test.driver.FindElement(By.TagName("downloads-manager")).ExpandRootElement(test.driver)
                .FindElement(By.CssSelector("iron-list"))
                .FindElement(By.CssSelector("downloads-item")).ExpandRootElement(test.driver)
                .FindElement(By.Id("file-link"));
            try
            {
                Assert.IsTrue(element.Text.Contains(fileName));
                report.Pass("Download (" + fileName + ") was found.");
                return 0;
            }
            catch (AssertFailedException)
            {
                report.Fail("Download (" + fileName + ") was not found.");
                return 1;
            }
            catch (Exception e)
            {
                report.Fail("Error occurred while verifying download.", e);
                return 1;
            }
        }

        private static int VerifyDownloadInBrowserFirefox(string fileName)
        {
            test.driver.Navigate().GoToUrl("about:downloads");
            //To be determined.
            report.Fail("Method not written yet.");
            return 1;
        }

        private static int VerifyDownloadInBrowserInternetExplorer(string fileName)
        {
            report.Fail("Method not written yet.");
            return 1;
        }

        public static void DownloadFile(By by)
        {
            var browser = ((RemoteWebDriver)test.driver).Capabilities.BrowserName;
            test.Click(by);
            //Handle browser dialogues. Chrome auto-downloads so no special handling needed.
            //Note: Window must remain in focus for sendkeys to work.
            switch (browser)
            {
                case "firefox":
                    //Firefox always prompts.  Seems there was an old way to force it to directly save via profile settings,
                    //but with Quantum that doesn't seem to work anymore.   Revisit later.
                    System.Threading.Thread.Sleep(3000);  //Short delay for download window to popup.
                    SendKeys.SendWait("{DOWN}");
                    SendKeys.SendWait("{ENTER}");
                    break;
                case "internet explorer":
                    //Doesn't seem like there's anyway to modify this with IE.
                    System.Threading.Thread.Sleep(3000);  //Short delay for download window to popup.
                    SendKeys.SendWait("{TAB}");
                    SendKeys.SendWait("{TAB}");
                    SendKeys.SendWait("{ENTER}");
                    break;
            }
        }

        public static void WaitForDownload(string filePath)
        {
            var exists = false;
            var i = 0;
            var timeout = config.TIMEOUT;
            while (!exists && i < timeout)  //Wait for file to exist.
            {
                exists = File.Exists(filePath);
                System.Threading.Thread.Sleep(1000);
                i++;
            }

            if (i < timeout) return;
            throw new Exception("Timed out after " + i + " seconds while trying to delete file.");
        }

        public static int VerifyDownloadedFile(string fileName, string downloadPath = null, bool delete = true)
        {
            //Default windows location for downloads. Can be overriden by providing a specific path.
            if (downloadPath == null)
            {
                var pathUser = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                downloadPath = Path.Combine(pathUser, "Downloads");
            }

            var filePath = Path.Combine(downloadPath, fileName);

            try
            {                
                WaitForDownload(filePath);
                report.Pass("File has been downloaded to: " + filePath);
            }
            catch
            {
                report.Fail("File was not downloaded to: " + filePath);
                return 1;
            }

            try
            {   //Presuming we want to keep directory clean for subsequent tests.
                if (delete)
                {
                    var downloading = true;
                    var i = 0;
                    while (downloading && i < 60)  //Wait for file to finish downloading, timeout after 60 seconds.
                    {
                        try
                        {
                            File.Delete(filePath);
                            downloading = false;
                        }
                        catch
                        {
                            System.Threading.Thread.Sleep(1000);
                            i++;
                        }
                    }
                    
                    if (i >= 60) throw new Exception("Timed out after " + i + " seconds while trying to delete file.");
                    report.Pass("File has been deleted: " + filePath);
                }
            }
            catch (Exception e)
            {
                report.Fail("Unable to delete file: " + filePath, e);
                return 1;
            }
            return 0;
        }

    }
}
