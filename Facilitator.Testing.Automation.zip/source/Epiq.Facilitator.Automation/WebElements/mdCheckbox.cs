﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Internal;

namespace Automation
{
    /// <summary>
    /// Provides a convenience method for manipulating a Material Design checkbox element.
    /// </summary>
    public class mdCheckbox : IWrapsElement
    {
        private readonly IWebElement element;

        /// <summary>
        /// Initializes a new instance of the <see cref="mdCheckbox"/> class.
        /// </summary>
        /// <param name="element">The element to be wrapped</param>
        /// <exception cref="ArgumentNullException">Thrown when the <see cref="IWebElement"/> object is <see langword="null"/></exception>
        /// <exception cref="UnexpectedTagNameException">Thrown when the element wrapped is not a &lt;checkbox&gt; element.</exception>
        public mdCheckbox(IWebElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }

            if (string.IsNullOrEmpty(element.TagName) || string.Compare(element.TagName, "md-checkbox", StringComparison.OrdinalIgnoreCase) != 0)
            {
                throw new UnexpectedTagNameException("md-checkbox", element.TagName);
            }
            
            this.element = element;
                                    
            string attribute = element.GetAttribute("aria-checked");
            this.IsChecked = attribute != null && attribute.ToLowerInvariant() != "false";

            this.Label = element.FindElement(By.XPath(".//span")).Text;            
        }
       
        /// <summary>
        /// Gets the <see cref="IWebElement"/> wrapped by this object.
        /// </summary>
        public IWebElement WrappedElement
        {
            get { return this.element; }
        }

        /// <summary>
        /// Gets a value indicating whether the checkbox is checked.
        /// </summary>
        public bool IsChecked { get; private set; }

        /// <summary>
        /// Gets the checkbox label.
        /// </summary>
        public string Label { get; private set; }
    }
}



