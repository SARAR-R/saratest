﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using OpenQA.Selenium.Internal;

namespace Automation
{
    /// <summary>
    /// Provides a convenience method for manipulating selections of options in an Material Design Select element.
    /// </summary>
    public class mdSelectElement : IWrapsElement
    {
        private readonly IWebElement element;
        private readonly string select_id;
        private readonly string select_container_id;
        private IWebElement elementOptions;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="mdSelectElement"/> class.
        /// </summary>
        /// <param name="element">The element to be wrapped</param>
        /// <exception cref="ArgumentNullException">Thrown when the <see cref="IWebElement"/> object is <see langword="null"/></exception>
        /// <exception cref="UnexpectedTagNameException">Thrown when the element wrapped is not a &lt;select&gt; element.</exception>
        public mdSelectElement(IWebElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }

            if (string.IsNullOrEmpty(element.TagName) || string.Compare(element.TagName, "md-select", StringComparison.OrdinalIgnoreCase) != 0)
            {
                throw new UnexpectedTagNameException("md-select", element.TagName);
            }

            // get the id of the select tag
            select_id = element.GetAttribute("id");

            try
            {
                // get the id of the container that holds the options
                select_container_id = element.FindElement(By.XPath(".//div[@class='md-select-menu-container']")).GetAttribute("id");
            }
            catch (Exception)
            {
                // the options container has been opened and left; find the id of the previously-opened container
                select_container_id = test.driver.FindElement(By.XPath(".//div[@class='md-select-menu-container md-leave']")).GetAttribute("id");
            }
            
            this.element = element;
                                    
            string attribute = element.GetAttribute("aria-multiselectable");
            this.IsMultiple = attribute != null && attribute.ToLowerInvariant() != "false";

            // open (make visible) the options
            selectOptions();
        }

        private void selectOptions()
        {
            test.Click(By.Id(select_id));
            this.elementOptions = test.driver.FindElement(By.Id(select_container_id));
            this.Options = this.elementOptions.FindElements(By.TagName("md-option"));            
        }

        /// <summary>
        /// Closes the container that displays available options
        /// </summary>
        public void closeSelectContainer()
        {
            try
            {
                SelectByText(SelectedOption.Text);
            }
            catch (Exception)
            {
                test.driver.FindElement(By.Id(select_container_id)).FindElement(By.TagName("md-content")).Click();

                var js = (IJavaScriptExecutor)test.driver;
                js.ExecuteScript("document.activeElement.blur();");
            }
        }

        /// <summary>
        /// Is the option selected
        /// </summary>
        private static bool isSelected(IWebElement element)
        {
            bool isSelected = false;
            string attribute = element.GetAttribute("selected");

            if (attribute != null && attribute.ToLowerInvariant() != "false")
            {
                isSelected = true;
            }

            return isSelected;
        }

        /// <summary>
        /// Gets the <see cref="IWebElement"/> wrapped by this object.
        /// </summary>
        public IWebElement WrappedElement
        {
            get { return this.element; }
        }

        /// <summary>
        /// Gets a value indicating whether the parent element supports multiple selections.
        /// </summary>
        public bool IsMultiple { get; private set; }

        /// <summary>
        /// Gets the list of options for the select element.
        /// </summary>
        public IList<IWebElement> Options;
       
        /// <summary>
        /// Gets the selected item within the select element.
        /// </summary>
        /// <remarks>If more than one item is selected this will return the first item.</remarks>
        /// <exception cref="NoSuchElementException">Thrown if no option is selected.</exception>
        public IWebElement SelectedOption
        {
            get
            {
                foreach (IWebElement option in this.Options)
                {                    
                    if (isSelected(option))
                    {
                        return option;
                    }
                }

                throw new NoSuchElementException("No option is selected");
            }
        }
               
        /// <summary>
        /// Gets all of the selected options within the select element.
        /// </summary>
        public IList<IWebElement> AllSelectedOptions
        {
            get
            {
                List<IWebElement> returnValue = new List<IWebElement>();
                foreach (IWebElement option in this.Options)
                {                    
                    if (isSelected(option))
                    {
                        returnValue.Add(option);
                    }
                }

                return returnValue;
            }
        }

        /// <summary>
        /// Select all options by the text displayed.
        /// </summary>
        /// <param name="text">The text of the option to be selected.</param>
        /// <param name="partialMatch">Default value is false. If true a partial match on the Options list will be performed, otherwise exact match.</param>
        /// <remarks>When given "Bar" this method would select an option like:
        /// <para>
        /// &lt;option value="foo"&gt;Bar&lt;/option&gt;
        /// </para>
        /// </remarks>
        /// <exception cref="NoSuchElementException">Thrown if there is no element with the given text present.</exception>
        public void SelectByText(string text, bool partialMatch = false)
        {
            if (text == null)
            {
                throw new ArgumentNullException("text", "text must not be null");
            }
            
            bool matched = false;
            IList<IWebElement> options;

            if (!partialMatch)
            {
                // try to find the option via XPATH ...
                options = this.elementOptions.FindElements(By.XPath(".//md-option//div[normalize-space(.) = " + EscapeQuotes(text) + "]"));
            }
            else
            {
                options = this.elementOptions.FindElements(By.XPath(".//md-option//div[contains(normalize-space(.),  " + EscapeQuotes(text) + ")]"));
            }

            foreach (IWebElement option in options)
            {
                SetSelected(option, true);
                if (!this.IsMultiple)
                {
                    return;
                }

                matched = true;
            }

            if (options.Count == 0 && text.Contains(" "))
            {
                string substringWithoutSpace = GetLongestSubstringWithoutSpace(text);
                IList<IWebElement> candidates;
                if (string.IsNullOrEmpty(substringWithoutSpace))
                {
                    // hmm, text is either empty or contains only spaces - get all options ...
                    candidates = this.elementOptions.FindElements(By.TagName("md-option"));
                }
                else
                {
                    // get candidates via XPATH ...
                    candidates = this.elementOptions.FindElements(By.XPath(".//md-option//div[contains(., " + EscapeQuotes(substringWithoutSpace) + ")]"));
                }

                foreach (IWebElement option in candidates)
                {
                    if (text == option.Text)
                    {
                        SetSelected(option, true);
                        if (!this.IsMultiple)
                        {
                            return;
                        }

                        matched = true;
                    }
                }
            }

            if (!matched)
            {
                throw new NoSuchElementException("Cannot locate element with text: " + text);
            }
        }

        /// <summary>
        /// Select an option by the value.
        /// </summary>
        /// <param name="value">The value of the option to be selected.</param>
        /// <remarks>When given "foo" this method will select an option like:
        /// <para>
        /// &lt;option value="foo"&gt;Bar&lt;/option&gt;
        /// </para>
        /// </remarks>
        /// <exception cref="NoSuchElementException">Thrown when no element with the specified value is found.</exception>
        public void SelectByValue(string value)
        {
            StringBuilder builder = new StringBuilder(".//md-option[@value = ");
            builder.Append(EscapeQuotes(value));
            builder.Append("]");
            
            IList<IWebElement> options = this.elementOptions.FindElements(By.XPath(builder.ToString()));

            bool matched = false;
            foreach (IWebElement option in options)
            {
                SetSelected(option, true);
                if (!this.IsMultiple)
                {
                    return;
                }

                matched = true;
            }

            if (!matched)
            {
                throw new NoSuchElementException("Cannot locate option with value: " + value);
            }
        }

        /// <summary>
        /// Select the option by the index, as determined by the "index" attribute of the element.
        /// </summary>
        /// <param name="index">The value of the index attribute of the option to be selected.</param>
        /// <exception cref="NoSuchElementException">Thrown when no element exists with the specified index attribute.</exception>
        public void SelectByIndex(int index)
        {   
            SetSelected(this.Options[index], true);
            return;                   

            throw new NoSuchElementException("Cannot locate option with index: " + index);
        }

        /// <summary>
        /// Clear all selected entries. This is only valid when the SELECT supports multiple selections.
        /// </summary>
        /// <exception cref="WebDriverException">Thrown when attempting to deselect all options from a SELECT
        /// that does not support multiple selections.</exception>
        public void DeselectAll()
        {
            if (!this.IsMultiple)
            {
                throw new InvalidOperationException("You may only deselect all options if multi-select is supported");
            }

            foreach (IWebElement option in this.Options)
            {
                SetSelected(option, false);
            }
        }

        /// <summary>
        /// Deselect the option by the text displayed.
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown when attempting to deselect option from a SELECT
        /// that does not support multiple selections.</exception>
        /// <exception cref="NoSuchElementException">Thrown when no element exists with the specified test attribute.</exception>
        /// <param name="text">The text of the option to be deselected.</param>
        /// <remarks>When given "Bar" this method would deselect an option like:
        /// <para>
        /// &lt;option value="foo"&gt;Bar&lt;/option&gt;
        /// </para>
        /// </remarks>
        public void DeselectByText(string text)
        {
            if (!this.IsMultiple)
            {
                throw new InvalidOperationException("You may only deselect option if multi-select is supported");
            }

            bool matched = false;
            StringBuilder builder = new StringBuilder(".//md-option//div[normalize-space(.) = ");
            builder.Append(EscapeQuotes(text));
            builder.Append("]");
            IList<IWebElement> options = this.element.FindElements(By.XPath(builder.ToString()));
            foreach (IWebElement option in options)
            {
                SetSelected(option, false);
                matched = true;
            }

            if (!matched)
            {
                throw new NoSuchElementException("Cannot locate option with text: " + text);
            }
        }

        /// <summary>
        /// Deselect the option having value matching the specified text.
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown when attempting to deselect option from a SELECT
        /// that does not support multiple selections.</exception>
        /// <exception cref="NoSuchElementException">Thrown when no element exists with the specified value attribute.</exception>
        /// <param name="value">The value of the option to deselect.</param>
        /// <remarks>When given "foo" this method will deselect an option like:
        /// <para>
        /// &lt;option value="foo"&gt;Bar&lt;/option&gt;
        /// </para>
        /// </remarks>
        public void DeselectByValue(string value)
        {
            if (!this.IsMultiple)
            {
                throw new InvalidOperationException("You may only deselect option if multi-select is supported");
            }

            bool matched = false;
            StringBuilder builder = new StringBuilder(".//md-option[@value = ");
            builder.Append(EscapeQuotes(value));
            builder.Append("]");
            IList<IWebElement> options = this.element.FindElements(By.XPath(builder.ToString()));
            foreach (IWebElement option in options)
            {
                SetSelected(option, false);
                matched = true;
            }

            if (!matched)
            {
                throw new NoSuchElementException("Cannot locate option with value: " + value);
            }
        }

        /// <summary>
        /// Deselect the option by the index, as determined by the "index" attribute of the element.
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown when attempting to deselect option from a SELECT
        /// that does not support multiple selections.</exception>
        /// <exception cref="NoSuchElementException">Thrown when no element exists with the specified index attribute.</exception>
        /// <param name="index">The value of the index attribute of the option to deselect.</param>
        public void DeselectByIndex(int index)
        {
            if (!this.IsMultiple)
            {
                throw new InvalidOperationException("You may only deselect option if multi-select is supported");
            }

            string match = index.ToString(CultureInfo.InvariantCulture);
            foreach (IWebElement option in this.Options)
            {
                if (match == option.GetAttribute("index"))
                {
                    SetSelected(option, false);
                    return;
                }
            }

            throw new NoSuchElementException("Cannot locate option with index: " + index);
        }

        private static string EscapeQuotes(string toEscape)
        {
            // Convert strings with both quotes and ticks into: foo'"bar -> concat("foo'", '"', "bar")
            if (toEscape.IndexOf("\"", StringComparison.OrdinalIgnoreCase) > -1 && toEscape.IndexOf("'", StringComparison.OrdinalIgnoreCase) > -1)
            {
                bool quoteIsLast = false;
                if (toEscape.LastIndexOf("\"", StringComparison.OrdinalIgnoreCase) == toEscape.Length - 1)
                {
                    quoteIsLast = true;
                }

                List<string> substrings = new List<string>(toEscape.Split('\"'));
                if (quoteIsLast && string.IsNullOrEmpty(substrings[substrings.Count - 1]))
                {
                    // If the last character is a quote ('"'), we end up with an empty entry
                    // at the end of the list, which is unnecessary. We don't want to split
                    // ignoring *all* empty entries, since that might mask legitimate empty
                    // strings. Instead, just remove the empty ending entry.
                    substrings.RemoveAt(substrings.Count - 1);
                }

                StringBuilder quoted = new StringBuilder("concat(");
                for (int i = 0; i < substrings.Count; i++)
                {
                    quoted.Append("\"").Append(substrings[i]).Append("\"");
                    if (i == substrings.Count - 1)
                    {
                        if (quoteIsLast)
                        {
                            quoted.Append(", '\"')");
                        }
                        else
                        {
                            quoted.Append(")");
                        }
                    }
                    else
                    {
                        quoted.Append(", '\"', ");
                    }
                }

                return quoted.ToString();
            }

            // Escape string with just a quote into being single quoted: f"oo -> 'f"oo'
            if (toEscape.IndexOf("\"", StringComparison.OrdinalIgnoreCase) > -1)
            {
                return string.Format(CultureInfo.InvariantCulture, "'{0}'", toEscape);
            }

            // Otherwise return the quoted string
            return string.Format(CultureInfo.InvariantCulture, "\"{0}\"", toEscape);
        }

        private static string GetLongestSubstringWithoutSpace(string s)
        {
            string result = string.Empty;
            string[] substrings = s.Split(' ');
            foreach (string substring in substrings)
            {
                if (substring.Length > result.Length)
                {
                    result = substring;
                }
            }

            return result;
        }

        private static void SetSelected(IWebElement option, bool select)
        {  
            if ((!isSelected(option) && select) || (isSelected(option) && !select))
            {
                option.Click();
            }
        }
    }
}



