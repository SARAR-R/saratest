﻿using System;
using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Internal;

namespace Automation
{
    /// <summary>
    /// Provides a convenience method for manipulating an ng-grid element.
    /// </summary>
    public class ngGrid : IWrapsElement
    {
        private readonly IWebElement element;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="ngGrid"/> class.
        /// </summary>
        /// <param name="element">The element to be wrapped</param>
        /// <exception cref="ArgumentNullException">Thrown when the <see cref="IWebElement"/> object is <see langword="null"/></exception>        
        public ngGrid(IWebElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
           
            this.element = element;
        }
             
        /// <summary>
        /// Gets the <see cref="IWebElement"/> wrapped by this object.
        /// </summary>
        public IWebElement WrappedElement
        {
            get { return element; }
        }
              
        /// <summary>
        /// Gets a list of columns 
        /// </summary>
        public IList<IWebElement> columns
        {            
            get { return element.FindElements(By.XPath(".//*[@ng-header-cell]")); }
        }

        /// <summary>
        /// Gets a list of rows 
        /// </summary>
        public IList<IWebElement> rows
        {
            get { return element.FindElements(By.XPath(".//*[@ng-row]")); }
        }

        /// <summary>
        /// Gets the footer element 
        /// </summary>
        public IWebElement Footer
        {
            get
            {
                try
                {
                    return element.FindElement(By.XPath(".//[@ng-grid-footer]"));
                }
                catch
                {
                    return null;
                }
            }
        }
       
        /// <summary>
        /// Click the Edit button for a row 
        /// <param name="index">The index of the row</param>
        /// </summary>
        public void EditRow(int index)
        {
            IWebElement element = null;
            IList<IWebElement> cells = getCellsByRow(index);                
            foreach (IWebElement cell in cells)
            {
                try
                {
                    element = cell.FindElement(By.XPath(".//a[contains(@ng-click,'edit')]"));                  
                }
                catch
                {

                }
            }
            if (element == null)
            {
                throw new NoSuchElementException("Could not find 'Edit' element to click");
            }
            //element.Click();
            test.Click(element);
        }

        /// <summary>
        /// Click the Edit button for the first row that matches the column value
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public void EditRow(string columnname, string columnvalue)
        {
            int index = getRowIndex(columnname, columnvalue);

            if (index == -1)
            {
                throw new NoSuchElementException("Could not find column value: " + columnvalue);
            }

            EditRow(index);
        }

        /// <summary>
        /// Click the Delete button for a row 
        /// <param name="index">The index of the row</param>
        /// </summary>
        public void DeleteRow(int index)
        {
            IWebElement element = null;
            IList<IWebElement> cells = getCellsByRow(index);
            foreach (IWebElement cell in cells)
            {
                try
                {
                    element = cell.FindElement(By.XPath(".//a[contains(@ng-click,'delete')]"));
                }
                catch
                {

                }
            }
            if (element == null)
            {
                throw new NoSuchElementException("Could not find 'Delete' element to click");
            }
            //element.Click();
            test.Click(element);
            //test.driver.FindElement(By.XPath("//button[contains(@class,'md-confirm-button')]")).Click();
        }

        /// <summary>
        /// Click the Delete button for the first row that matches the column value
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public void DeleteRow(string columnname, string columnvalue)
        {
            int index = getRowIndex(columnname, columnvalue);

            if (index == -1)
            {
                throw new NoSuchElementException("Could not find column value: " + columnvalue);
            }

            DeleteRow(index);
        }

        ///// <summary>
        ///// Gets a list of cells by column name 
        ///// <param name="columnname">The name of the column</param>
        ///// </summary>
        //public IList<IWebElement> getCellsByColumn(string columnname)
        //{
        //    int colindex = getColumnIndex(columnname)+1;
        //    //return element.FindElements(By.XPath(".//*[@ng-row]//div[contains(@class,'ng-cell')][" + colindex + "]"));            
        //    return element.FindElements(By.XPath(".//div[contains(@class,'ng-cell')][" + colindex + "]"));
        //}

        /// <summary>
        /// Gets a list of cells by row index 
        /// <param name="rowindex">The index of the row</param>
        /// </summary>
        public IList<IWebElement> getCellsByRow(int rowindex)
        {
            return rows[rowindex-1].FindElements(By.XPath(".//*[@ng-cell]"));
        }

        /// <summary>
        /// Gets a list of rows by column value 
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public IList<IWebElement> getRowsByColumnValue(string columnname, string columnvalue)
        {
            int colindex = getColumnIndex(columnname) + 1;
            IList<IWebElement> elements = new List<IWebElement>();
            int rowindex = 0;
            int cellindex = 1;

            if (colindex == 0)
            {
                throw new NoSuchElementException("Could not find column: " + columnname);
            }

            foreach (IWebElement row in rows)
            {
                IList<IWebElement> cells = getCellsByRow(rowindex);
                foreach (IWebElement cell in cells)
                {
                    if (cell.Text == columnvalue & cellindex == colindex)
                    {                       
                        elements.Add(row);
                    }
                    cellindex++;
                }
                rowindex++;
                cellindex = 1;
            }

            return elements;
        }

        /// <summary>
        /// Sort table by column name 
        /// <param name="columnname">The name of the column</param>
        /// </summary>
        public void sort(string columnname)
        {
            foreach (IWebElement col in columns)
            {
                if (col.Text == columnname)
                {
                    col.Click();
                }                
            }
        }

        /// <summary>
        /// Gets column index by column name 
        /// <param name="columnname">The name of the column</param>
        /// </summary>
        public int getColumnIndex(string columnname)
        {
            int counter = 0;
            foreach (IWebElement col in columns)
            {
                if (col.Text== columnname)
                {
                    return counter;
                }
                else
                {
                    counter++;
                }
            }

            return -1;
        }

        /// <summary>
        /// Gets row index by column value 
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public int getRowIndex(string columnname, string columnvalue)
        {
            int counter = 1;
            int colindex = getColumnIndex(columnname);

            if (colindex == -1)
            {
                throw new NoSuchElementException("Could not find column: " + columnname);
            }

            foreach (IWebElement row in rows)
            {               
                if (row.FindElements(By.XPath(".//*[@ng-cell]"))[colindex].Text == columnvalue)
                {
                    return counter;
                }
                else
                {
                    counter++;
                }              
            }

            return -1;
        }

        /// <summary>
        /// Gets the column value of the first record in grid 
        /// <param name="columnname">The name of the column</param>        
        /// </summary>
        public string getFirstColumnValue(string columnname)
        {
            int colindex = getColumnIndex(columnname);

            if (colindex == -1)
            {
                throw new NoSuchElementException("Could not find column: " + columnname);
            }

            return getCellsByRow(1)[colindex].Text;
        }

        /// <summary>
        /// Click an icon for a row 
        /// <param name="index">The index of the row</param>
        /// <param name="icon">The icon to click</param>
        /// </summary>
        public void ClickRowIcon(int index, By icon)
        {
            IWebElement element = null;
            IList<IWebElement> cells = getCellsByRow(index);
            foreach (IWebElement cell in cells)
            {
                try
                {
                    element = cell.FindElement(icon);
                }
                catch
                {

                }
            }
            if (element == null)
            {
                throw new NoSuchElementException("Could not find '" + icon.ToString() + "' element to click");
            }
            //element.Click();
            test.Click(element);
        }

    }
}



