﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using OpenQA.Selenium.Internal;

namespace Automation
{
    /// <summary>
    /// Provides a convenience method for manipulating a Material Design table element.
    /// </summary>
    public class mdTable : IWrapsElement
    {
        private readonly IWebElement element;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="mdTable"/> class.
        /// </summary>
        /// <param name="element">The element to be wrapped</param>
        /// <exception cref="ArgumentNullException">Thrown when the <see cref="IWebElement"/> object is <see langword="null"/></exception>
        /// <exception cref="UnexpectedTagNameException">Thrown when the element wrapped is not a &lt;select&gt; element.</exception>
        public mdTable(IWebElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }

            if (string.IsNullOrEmpty(element.TagName) || string.Compare(element.TagName, "table", StringComparison.OrdinalIgnoreCase) != 0)
            {
                throw new UnexpectedTagNameException("table", element.TagName);
            }
            
            this.element = element;
        }
             
        /// <summary>
        /// Gets the <see cref="IWebElement"/> wrapped by this object.
        /// </summary>
        public IWebElement WrappedElement
        {
            get { return element; }
        }
              
        /// <summary>
        /// Gets a list of columns 
        /// </summary>
        public IList<IWebElement> columns
        {
            get { return element.FindElements(By.TagName("th")); }
        }

        /// <summary>
        /// Gets a list of rows 
        /// </summary>
        public IList<IWebElement> rows
        {
            get { return element.FindElements(By.TagName("tr")); }
        }

        /// <summary>
        /// Gets the pagination element 
        /// </summary>
        public IWebElement Pagination
        {
            get
            {
                try {
                    string attribute = this.element.GetAttribute("class");
                    By by = By.XPath("//table[@class='" + attribute + "']/parent::md-table-container/parent::ng-form/following-sibling::md-table-pagination");
                    IWebElement element = test.driver.FindElement(by);
                    return element;
                }
                catch
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets the toolbar elements 
        /// </summary>
        public IList<IWebElement> Toolbars
        {
            get
            {
                try
                {
                    string attribute = this.element.GetAttribute("class");
                    By by = By.XPath("//table[@class='" + attribute + "']/parent::md-table-container/parent::ng-form/preceding-sibling::md-toolbar | //table[@class='" + attribute + "']/parent::md-table-container/parent::div/preceding-sibling::md-toolbar");
                    IList<IWebElement> elements = test.driver.FindElements(by);
                    return elements;
                }
                catch
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Click the Add button 
        /// </summary>
        public void AddRow()
        {
            IWebElement element = null;
            foreach (IWebElement toolbar in Toolbars)
            {
                try
                {
                    element = toolbar.FindElement(By.XPath(".//md-icon[text()='add']"));
                }
                catch
                {

                }                    
            }
            if (element == null)
            {
                throw new NoSuchElementException("Could not find 'Add' element to click");
            }
            //element.Click();
            test.Click(element);
        }

        /// <summary>
        /// Click an icon for a row 
        /// <param name="index">The index of the row</param>
        /// <param name="icon">The icon to click</param>
        /// </summary>
        public void ClickRowIcon(int index, By icon)
        {
            IWebElement element = null;
            IList<IWebElement> cells = getCellsByRow(index);
            foreach (IWebElement cell in cells)
            {
                try
                {
                    element = cell.FindElement(icon);
                }
                catch
                {

                }
            }
            if (element == null)
            {
                throw new NoSuchElementException("Could not find '" + icon.ToString() + "' element to click");
            }
            //element.Click();
            test.Click(element);
        }

        /// <summary>
        /// Click an icon for the first row that matches the column value
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// <param name="icon">The icon to click</param>
        /// </summary>
        public void ClickRowIcon(string columnname, string columnvalue, By icon)
        {
            int index = getRowIndex(columnname, columnvalue);

            if (index == -1)
            {
                throw new NoSuchElementException("Could not find column value: " + columnvalue);
            }

            ClickRowIcon(index, icon);
        }

        /// <summary>
        /// Click the Edit button for a row 
        /// <param name="index">The index of the row</param>
        /// </summary>
        public void EditRow(int index)
        {
            IWebElement element = null;
            IList<IWebElement> cells = getCellsByRow(index);                
            foreach (IWebElement cell in cells)
            {
                try
                {
                    element = cell.FindElement(By.XPath(".//md-icon[text()='edit']"));                       
                }
                catch
                {

                }
            }
            if (element == null)
            {
                throw new NoSuchElementException("Could not find 'Edit' element to click");
            }
            //element.Click();
            test.Click(element);
        }

        /// <summary>
        /// Click the Edit button for the first row that matches the column value
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public void EditRow(string columnname, string columnvalue)
        {
            int index = getRowIndex(columnname, columnvalue);

            if (index == -1)
            {
                throw new NoSuchElementException("Could not find column value: " + columnvalue);
            }

            EditRow(index);
        }

        /// <summary>
        /// Click the Delete (and confirm) button for a row 
        /// <param name="index">The index of the row</param>
        /// </summary>
        public void DeleteRow(int index)
        {
            IWebElement element = null;
            IList<IWebElement> cells = getCellsByRow(index);
            foreach (IWebElement cell in cells)
            {
                try
                {
                    element = cell.FindElement(By.XPath(".//md-icon[text()='delete']"));
                }
                catch
                {

                }
            }
            if (element == null)
            {
                throw new NoSuchElementException("Could not find 'Delete' element to click");
            }            
            test.Click(element);
            if (test.doesElementExist(By.XPath("//button[contains(@class,'md-confirm-button')]"),1))
            {
                test.driver.FindElement(By.XPath("//button[contains(@class,'md-confirm-button')]")).Click();
            }            
        }

        /// <summary>
        /// Click the Delete (and confirm) button for the first row that matches the column value
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public void DeleteRow(string columnname, string columnvalue)
        {
            int index = getRowIndex(columnname, columnvalue);

            if (index == -1)
            {
                throw new NoSuchElementException("Could not find column value: " + columnvalue);
            }

            DeleteRow(index);
        }

        /// <summary>
        /// Gets a list of cells by column name 
        /// <param name="columnname">The name of the column</param>
        /// </summary>
        public IList<IWebElement> getCellsByColumn(string columnname)
        {
            int colindex = getColumnIndex(columnname) + 1;

            if (colindex == 0)
            {
                throw new NoSuchElementException("Could not find column: " + columnname);
            }

            //return element.FindElements(By.XPath(".//tr/td[" + colindex + "]"));
            return getCellsByColumn(colindex);
        }

        /// <summary>
        /// Gets a list of cells by column name 
        /// <param name="index">The index of the column</param>
        /// </summary>
        public IList<IWebElement> getCellsByColumn(int index)
        {
            return element.FindElements(By.XPath(".//tr/td[" + index + "]"));
        }

        /// <summary>
        /// Gets a list of cells by row index 
        /// <param name="rowindex">The index of the row</param>
        /// </summary>
        public IList<IWebElement> getCellsByRow(int rowindex)
        {
            return element.FindElements(By.XPath(".//tr[" + rowindex + "]/td"));
        }

        /// <summary>
        /// Gets a list of rows by column value 
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public IList<IWebElement> getRowsByColumnValue(string columnname, string columnvalue)
        {
            int colindex = getColumnIndex(columnname) + 1;

            if (colindex == 0)
            {
                throw new NoSuchElementException("Could not find column: " + columnname);
            }

            return element.FindElements(By.XPath(".//tr/td[" + colindex + "][text()='" + columnvalue + "']"));            
        }

        /// <summary>
        /// Sort table by column name 
        /// <param name="columnname">The name of the column</param>
        /// </summary>
        public void sort(string columnname)
        {            
            element.FindElement(By.XPath(".//th[text()='" + columnname + "']")).Click();
        }

        /// <summary>
        /// Gets column index by column name 
        /// <param name="columnname">The name of the column</param>
        /// </summary>
        public int getColumnIndex(string columnname)
        {
            int counter = 0;
            foreach (IWebElement col in columns)
            {
                if (col.Text== columnname)
                {
                    return counter;
                }
                else
                {
                    counter++;
                }
            }

            return -1;
        }

        /// <summary>
        /// Gets row index by column value 
        /// <param name="columnname">The name of the column</param>
        /// <param name="columnvalue">The value of the column</param>
        /// </summary>
        public int getRowIndex(string columnname, string columnvalue)
        {
            int counter = 1;
            int colindex = getColumnIndex(columnname);

            if (colindex == -1)
            {
                throw new NoSuchElementException("Could not find column: " + columnname);
            }

            foreach (IWebElement row in rows)
            {
                if (row.FindElements(By.TagName("td")).Count > 0)
                { 
                    if (row.FindElements(By.TagName("td"))[colindex].Text == columnvalue)
                    {
                        return counter;
                    }
                    else
                    {
                        counter++;
                    }
                }               
            }

            return -1;
        }

        /// <summary>
        /// Gets the column value of the first record in table 
        /// <param name="columnname">The name of the column</param>        
        /// </summary>
        public string getFirstColumnValue(string columnname)
        {
            int colindex = getColumnIndex(columnname);

            if (colindex == -1)
            {
                throw new NoSuchElementException("Could not find column: " + columnname);
            }

            return getCellsByRow(1)[colindex].Text;
        }

    }
}



