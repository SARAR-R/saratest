﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using System.Configuration;

namespace Automation
{
    public static class report
    {
        public static int _debuglevel = int.Parse(ConfigurationManager.AppSettings.Get("debuglevel") ?? "1"); 

        public static void Action(string action, string controlname, string value)
        {
            if (_debuglevel < 3)
            {
                string str;
                if (value == null)
                {
                    str = string.Format("> {0}: {1}", action, controlname);
                }
                else
                {
                    str = string.Format("> {0}: {1}, {2}", action, controlname, value);
                }
                Console.WriteLine(str);
            }
        }

        public static void Action(string action, string controlname)
        {            
                Action(action, controlname, null);           
        }

        public static void Step(string description)
        {
            if (_debuglevel < 4)
            {
                Console.WriteLine(string.Format("STEP: {0}", description));
            }
        }

        public static void Pass(string description)
        {
            if (_debuglevel < 2)
            {
                Console.WriteLine(string.Format("PASS: {0}", description));
            }
        }

        public static void Fail(string description)
        {
            string f = string.Format("FAIL: {0}", description);
            Console.WriteLine(f);
            test.vars.failures = test.vars.failures + Environment.NewLine + f;
            test.vars.errorcount = test.vars.errorcount + 1;                   
        }

        public static void Fail(string description, Exception e)
        {
            string f = string.Format("FAIL: {0}", description);
            Console.WriteLine(f);            
            Console.WriteLine(e.Message);
            test.vars.failures = test.vars.failures + Environment.NewLine + f + ": " + e.Message;
            test.vars.errorcount = test.vars.errorcount + 1;
        }

        public static void Skip(string description)
        {
            string s = string.Format("SKIP: {0}", description);
            Console.WriteLine(s);
            test.vars.skips = test.vars.skips + Environment.NewLine + s;
            test.vars.skipcount = test.vars.skipcount + 1;
        }

    }    
    
}
