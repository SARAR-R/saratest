﻿using System;


namespace Automation
{
    public class config
    {
        public static string upload_filepath = "C:\\Selenium\\UploadTestDoc.docx";
        public static string testname;
        public static int TIMEOUT = 30;
        public static int TIMEOUT_CHROME = 30;
        public static int TIMEOUT_PAGELOAD = 120;
    }
}
