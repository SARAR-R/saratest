﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;

namespace Automation
{
    public class random
    {
        public static string GenerateString(int size)
        {
            var rand = new Random();
            const string alphabet = "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var chars = new char[size];
            for (var i = 0; i < size; i++)
            {
                chars[i] = alphabet[rand.Next(alphabet.Length)];
            }
            return new string(chars);
        }

        public static string GenerateNumberString(int size)
        {
            var rand = new Random();
            const string alphabet = "0123456789";
            var chars = new char[size];
            chars[0] = alphabet[rand.Next(1, alphabet.Length)];  //Ensure string doesn't start with a zero
            for (var i = 1; i < size; i++)
            {
                chars[i] = alphabet[rand.Next(alphabet.Length)];
            }
            return new string(chars);
        }

        public static DateTime GenerateDate()
        {
            var rnd = new Random();
            var start = new DateTime(1995, 1, 1);
            var range = (DateTime.Today - start).Days;
            return start.AddDays(rnd.Next(range));
        }

        public static bool RandomBoolean()
        {
            Thread.Sleep(100);
            var rnd = new Random();
            return (rnd.NextDouble() > .5);
        }

        public static int RandomInteger(int start, int end)
        {
            Thread.Sleep(100);
            var rnd = new Random();
            return rnd.Next(start, end);
        }

        public static decimal RandomDecimal(int start, int end)
        {
            Thread.Sleep(100);
            var rnd = new Random();
            decimal remainder = new Random().Next(1, 99);
            Thread.Sleep(100); //Ensure it randomizes again
            return rnd.Next(start, end) + remainder/100;
        }

        public static T Record<T>(IEnumerable<T> source)
        {
            return source.OrderBy(x => Guid.NewGuid()).First();
        }
    }
}
