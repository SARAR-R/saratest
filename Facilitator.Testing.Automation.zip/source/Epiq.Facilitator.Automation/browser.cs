﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;

namespace Automation
{
    public class browser
    {
        public enum browserType { Chrome, Firefox, IE }

        private static IWebDriver driver;

        public browser(browserType type)
        {
            switch (type)
            {
                case browserType.Chrome:
                    driver = new ChromeDriver();
                    break;
                case browserType.Firefox:
                    //FirefoxDriverService service = FirefoxDriverService.CreateDefaultService("C:\\Selenium", "geckodriver.exe");
                    //service.FirefoxBinaryPath = "C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe";
                    driver = new FirefoxDriver();
                    break;
                case browserType.IE:
                    driver = new InternetExplorerDriver();
                    break;
                default:
                    driver = new ChromeDriver();
                    break;
            }
        }

        public static string browserName() { 
            return ((RemoteWebDriver)driver).Capabilities.BrowserName; 
        }

        public class browserWait
        {
            public browserWait() { 
                new WebDriverWait(driver, TimeSpan.FromSeconds(config.TIMEOUT)); 
            }            
        }

        public browserWait wait() { 
            return new browserWait(); 
        }

        public void Quit() {
            driver.Quit();
        }
        public static void TakeScreenshot(string callingMethod)
        {
            TakeScreenshot(test.driver, test.GetCurrentDateTime("HHmmssfff"), callingMethod);
        }
        public static void TakeScreenshot(IWebDriver driver, string fileappend, string callingMethod)
        {
            if (ConfigurationManager.AppSettings.Get("capture_screenshots") == "true")
            { 
                try
                {
                    string pathString = @"C:\Selenium\Screenshots\" + test.GetCurrentDateTime("yyyyMMdd") + @"\" + config.testname;
                    if (!File.Exists(pathString))
                    {
                        Directory.CreateDirectory(pathString);
                    }
                    Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
                    ss.SaveAsFile(pathString + @"\" + callingMethod + fileappend + ".jpg", ScreenshotImageFormat.Jpeg);
                    report.Action("Screenshot saved", pathString);
                }

                catch (Exception e)
                {
                    Console.WriteLine("Unable to capture screenshot: " + e.Message);
                }
            }
        }

    }        
}
