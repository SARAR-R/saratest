﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Configuration;
using System.Web;

namespace Automation
{
    public static class email
    {
        public static By _PasswdResetTitle = By.XPath("//span/b[text()='Epiq Systems Access Control Password Reset']");
        public static By _PasswdResetLink = By.XPath("//a[contains(@href, 'resetPassword?uid')]");
        public static By _2FTitle = By.XPath("//span/b[text()='Security Code']");


        public static void gmail_login()
        {
            gmail_login(test.driver, "epiq.automation@gmail.com", "EpiqP@ssword1");
        }
        public static void gmail_login(IWebDriver driver)
        {
            gmail_login(driver, "epiq.automation@gmail.com", "EpiqP@ssword1");
        }

        public static void gmail_login(string email, string password)
        {
            gmail_login(test.driver, email, password);
        }

        public static void gmail_login(IWebDriver driver, string email, string password)
        {
            report.Action("Navigate", "https://mail.google.com/");
            driver.Navigate().GoToUrl("https://mail.google.com/");
            report.Action("Edit", By.Name("identifier").ToString(), email);
            driver.FindElement(By.Name("identifier")).SendKeys(email);
            driver.FindElement(By.Name("identifier")).SendKeys(Keys.Return);
            test.WaitForElement(driver, By.Name("password"));
            report.Action("Edit", By.Name("password").ToString(), password);
            driver.FindElement(By.Name("password")).SendKeys(password);
            driver.FindElement(By.Name("password")).SendKeys(Keys.Return);
        }

        public static void gmail_open(By title)
        {
            gmail_open(test.driver, title);
        }

        public static void gmail_open(IWebDriver driver, By title)
        {
            test.WaitForElement(driver, title);
            report.Action("Click", title.ToString());
            driver.FindElement(title).Click();
        }
        public static void gmail_navigatetolink(By linktext)
        {
            gmail_navigatetolink(test.driver, linktext);
        }

        public static void gmail_navigatetolink(IWebDriver driver, By linktext)
        {
            var url = driver.FindElement(linktext).GetAttribute("href");
            report.Action("navigate", url);
            driver.Navigate().GoToUrl(url);
        }

        public static string gmail_getcode()
        {
            return gmail_getcode(test.driver);
        }

        public static string gmail_getcode(IWebDriver driver)
        {
            string message = driver.FindElement(By.XPath("//div[2][contains(text(), 'Your security code is')]")).Text;
            int startPos = message.LastIndexOf("Your security code is ", StringComparison.Ordinal) + "Your security code is ".Length;       
            return message.Substring(startPos, 6);
        }
        public static void gmail_logout()
        {
            gmail_logout(test.driver);
        }

        public static void gmail_logout(IWebDriver driver)
        {
            driver.FindElement(By.XPath("//a[contains(@href, 'SignOutOptions')]")).Click();
            driver.FindElement(By.XPath("//a[text()='Sign out']")).Click();
            try
            {
                driver.SwitchTo().Alert().Accept();
            }
            catch {/*supress error*/}
        }
    } 
}
