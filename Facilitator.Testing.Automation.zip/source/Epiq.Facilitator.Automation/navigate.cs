﻿using System;
using OpenQA.Selenium;
using System.Configuration;
using System.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Automation
{

    public class navigate
    {
        public static int ByLinkText(string location)
        {
            return ByLinkText(test.driver, location);
        }
        public static int ByLinkText(IWebDriver driver, string location)
        {
            try
            {
                test.Click(driver, By.LinkText(location));
                return 0;
            }
            catch
            {                
                Assert.Fail("Unable to click " + location);
                return 1;
            }
        }

        public static int ByButtonText(IWebDriver driver, string location)
        {
            try
            {
                test.Click(driver, By.XPath("//button[.='" + location + "']"));
                return 0;
            }
            catch
            {
                Assert.Fail("Unable to click " + location);
                return 1;
            }
        }

        public static int ByMdTabText(IWebDriver driver, string location)
        {
            try
            {
                test.Click(driver, By.XPath("//md-tab-item/span[.='" + location + "']"));
                return 0;
            }
            catch
            {
                Assert.Fail("Unable to click " + location);
                return 1;
            }
        }
        
        public static void URL(string url)
        {
            report.Action("Navigate", url);
            test.driver.Navigate().GoToUrl(url);
            test.WaitForPageToLoad(test.driver);
        }

        public static void Refresh()
        {
            Refresh(test.driver);
        }

        public static void Refresh(IWebDriver driver)
        {
            report.Action("Navigate", "Refresh");
            driver.Navigate().Refresh();
            test.WaitForPageToLoad(driver);
        }

        public static void DirectToPage(string path, string tn)
        {
            string url = ConfigurationManager.AppSettings.Get("url");
            var theUri = new Uri(test.driver.Url);
            string ssid = HttpUtility.ParseQueryString(theUri.Query).Get("ssid");

            if (tn == null)
            {
                navigate.URL(url + "/" + path + "?ssid=" + ssid);
            }
            else
            {
                navigate.URL(url + "/" + path + "?ssid=" + ssid + "&tn=" + tn);
            }
            test.WaitForPageToLoad(test.driver);
        }

    } 
}
