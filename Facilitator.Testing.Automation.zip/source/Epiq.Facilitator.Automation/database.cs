﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Configuration;

namespace Automation
{
    public static class database
    {
        public static void updateclaimant(string connectionstring, int trackingnumber, string fieldname, string value)
        {
            var cn = new SqlConnection();
            var ClaimantDataSet = new DataSet();
            SqlDataAdapter da;
            SqlCommandBuilder cmdBuilder;
            //Set the connection string of the SqlConnection object to connect
            //to the SQL Server database in which you created the sample
            //table.
            cn.ConnectionString = connectionstring;

            cn.Open();

            //Initialize the SqlDataAdapter object by specifying a Select command 
            //that retrieves data from the sample table.
            da = new SqlDataAdapter("select * from Claimant WHERE Tracking_Number = " + trackingnumber, cn);
            //Initialize the SqlCommandBuilder object to automatically generate and initialize
            //the UpdateCommand, InsertCommand, and DeleteCommand properties of the SqlDataAdapter.
            cmdBuilder = new SqlCommandBuilder(da);
            //Populate the DataSet by running the Fill method of the SqlDataAdapter.
            da.Fill(ClaimantDataSet, "Claimant");

            //Write out the value in the CustName field before updating the data using the DataSet.
            Debug.WriteLine(fieldname + " before Update : " + ClaimantDataSet.Tables["Claimant"].Rows[0][fieldname]);

            //Modify the value of the CustName field.
            ClaimantDataSet.Tables["Claimant"].Rows[0][fieldname] = value;

            //Post the data modification to the database.
            da.Update(ClaimantDataSet, "Claimant");

            Debug.WriteLine(fieldname + " updated to " + value);

            //Close the database connection.
            cn.Close();

        }

        public static void clearfield(string connectionstring, int trackingnumber, string fieldname)
        {
            var cn = new SqlConnection();
            var ClaimantDataSet = new DataSet();
            SqlDataAdapter da;
            SqlCommandBuilder cmdBuilder;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("select * from Claimant WHERE Tracking_Number = " + trackingnumber, cn);

            cmdBuilder = new SqlCommandBuilder(da);

            da.Fill(ClaimantDataSet, "Claimant");

            Debug.WriteLine(fieldname + " before Update : " + ClaimantDataSet.Tables["Claimant"].Rows[0][fieldname]);

            ClaimantDataSet.Tables["Claimant"].Rows[0][fieldname] = null;

            da.Update(ClaimantDataSet, "Claimant");

            Debug.WriteLine(fieldname + " updated to NULL");

            cn.Close();

        }

        public static string getfieldvaluebytn(string connectionstring, string table, string fieldname, int trackingnumber)
        {
            
            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("select * from " + table + " WHERE Tracking_Number = " + trackingnumber, cn);

            da.Fill(TableDataSet, table);

            Debug.WriteLine(fieldname + " equals : " + TableDataSet.Tables[table].Rows[0][fieldname]);

            //Only returns the first value
            string result = TableDataSet.Tables[table].Rows[0][fieldname].ToString();

            cn.Close();

            return result;
        }

        public static string gettopfieldvalue(string connectionstring, string table, string fieldname)
        {

            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("select top 1 * from " + table, cn);

            da.Fill(TableDataSet, table);

            Debug.WriteLine(fieldname + " equals : " + TableDataSet.Tables[table].Rows[0][fieldname]);

            string result = TableDataSet.Tables[table].Rows[0][fieldname].ToString();

            cn.Close();

            return result;
        }

        public static string gettopfieldvaluewhere(string connectionstring, string table, string fieldname, string where)
        {

            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("select top 1 * from " + table + " where " + where, cn);

            da.Fill(TableDataSet, table);

            Debug.WriteLine(fieldname + " equals : " + TableDataSet.Tables[table].Rows[0][fieldname]);

            string result = TableDataSet.Tables[table].Rows[0][fieldname].ToString();

            cn.Close();

            return result;
        }
        public static string getencryptedfieldvaluebytn(string connectionstring, string table, string fieldname, int trackingnumber)
        {

            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("OPEN SYMMETRIC KEY dboSymKeyAsym_CMx DECRYPTION BY ASYMMETRIC KEY dboAsymKey_CMx SELECT RTRIM(CONVERT(char(11), DecryptByKey(" + fieldname + "))) as " + fieldname + " FROM Claimant WHERE Tracking_Number = " + trackingnumber + " CLOSE SYMMETRIC KEY dboSymKeyAsym_CMx CLOSE MASTER KEY", cn);

            da.Fill(TableDataSet, table);

            Debug.WriteLine(fieldname + " equals : " + TableDataSet.Tables[table].Rows[0][fieldname]);

            //Only returns the first value
            string result = TableDataSet.Tables[table].Rows[0][fieldname].ToString();

            cn.Close();

            return result;
        }

        public static DataSet gettabledatabytn(string connectionstring, string table, int trackingnumber)
        {
            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("select * from " + table + " WHERE Tracking_Number = " + trackingnumber, cn);

            da.Fill(TableDataSet, table);

            cn.Close();

            return TableDataSet;
        }

        public static DataSet getmostrecentauditentry(string connectionstring)
        {
            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();
            
            string application = ConfigurationManager.AppSettings.Get("application");
            switch (application)
            {
                case "Access Control":
                    da = new SqlDataAdapter("select Top 1 * from AuditLog order by Id desc", cn);
                    break;
                default:
                    da = new SqlDataAdapter("select Top 1 * from fac.AuditLog order by Id desc", cn);
                    break;
            }

            da.Fill(TableDataSet, "AuditLog");

            cn.Close();
            
            return TableDataSet;
        }

        public static DataSet gettablefieldbytn(string connectionstring, string table, string field, int trackingnumber, string sort)
        {
            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();
                       
            da = new SqlDataAdapter("SELECT " + field + " FROM " + table + " WHERE Tracking_Number = " + trackingnumber + " and " + field + " IS NOT NULL ORDER BY " + field + " " + sort, cn);
        

            da.Fill(TableDataSet, table);

            cn.Close();

            return TableDataSet;
        }

        public static DataSet gettablefieldbytn(string connectionstring, string table, string field, int trackingnumber)
        {
            return gettablefieldbytn(connectionstring, table, field, trackingnumber, "ASC");
        }

        public static DataSet getAltAddressDatabytn(string connectionstring, string table, int trackingnumber, string addresstype)
        {
            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("SELECT ad.* FROM AltAddress aa INNER JOIN AltAddressData ad on aa.pk_AltAddressID = ad.fk_AltAddressID and aa.AddressType = '" + addresstype + "' WHERE aa.Tracking_Number = " + trackingnumber, cn);

            da.Fill(TableDataSet, table);

            cn.Close();

            return TableDataSet;
        }
        
        public static DataSet getcustomdataset(string connectionstring, string query)
        {
            var cn = new SqlConnection();
            var TableDataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter(query, cn);

            da.Fill(TableDataSet, "resultset");

            cn.Close();

            return TableDataSet;
        }
      

        public static string getsubsystemid(string connectionstring, string subsystemname)
        {
            var cn = new SqlConnection();
            var DataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("SELECT * FROM Subsystem WHERE Name = '" + subsystemname + "'", cn);
            
            da.Fill(DataSet, "Subsystem");

            string result = DataSet.Tables["Subsystem"].Rows[0]["SubsystemId"].ToString();

            cn.Close();

            return result;

        }

        public static void toggletwofactor(string connectionstring, string subsystemname, bool value)
        {
            var date = DateTime.Now.ToString("HHmmssfff");
            var subsystemid = getsubsystemid(connectionstring, subsystemname);
            var cn = new SqlConnection();
            var DataSet = new DataSet();
            SqlDataAdapter da;
            SqlCommandBuilder cmdBuilder;
            
            cn.ConnectionString = connectionstring;

            cn.Open();
 
            da = new SqlDataAdapter("select * from Subsystem WHERE subsystemid = " + subsystemid, cn);
            cmdBuilder = new SqlCommandBuilder(da);
            da.Fill(DataSet, "Subsystem");

            DataSet.Tables["Subsystem"].Rows[0]["RequireTwoFactorAuth"] = value;
            DataSet.Tables["Subsystem"].Rows[0]["UpdatedBy"] = "Auto" + date;

            da.Update(DataSet, "Subsystem");

            cn.Close();

        }

        public static string getrandomrecord(string connectionstring, string tablename, string fieldname, string where)
        {
            var cn = new SqlConnection();
            var DataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;
            cn.Open();

            da = new SqlDataAdapter("SELECT " + fieldname + " FROM " + tablename + where + " ORDER BY NEWID()", cn);
            da.Fill(DataSet, tablename);

            string result = DataSet.Tables[tablename].Rows[0][fieldname].ToString();
            cn.Close();
            return result;

        }

        public static int getnextdocid(string connectionstring, string documenttype)
        {
            var cn = new SqlConnection();
            var DataSet = new DataSet();
            SqlDataAdapter da;

            cn.ConnectionString = connectionstring;

            cn.Open();

            da = new SqlDataAdapter("SELECT MAX(DocID) as 'DocID' FROM Documents WHERE Document_Type =  '" + documenttype + "'", cn);

            da.Fill(DataSet, "Documents");

            if (DataSet.Tables["Documents"].Rows[0]["DocID"].ToString() == "")
            {
                DataSet.Clear();
                da = new SqlDataAdapter("SELECT SequenceStart as 'DocID' FROM Lkp_Document_Type WHERE DocumentTypeName =  '" + documenttype + "'", cn);
                da.Fill(DataSet, "Documents");
            }

            int result = int.Parse(DataSet.Tables["Documents"].Rows[0]["DocID"].ToString()) + 1;

            cn.Close();

            return result;
        }
    }        
}
